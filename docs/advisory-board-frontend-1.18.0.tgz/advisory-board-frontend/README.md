# Climate Advisory Board frontend - Plone 6

This chart deployes the Climate Advisory Board frontend app 


## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| links.backend | string | NAME.NAMESPACE | Service name for varnish for backend instance, followed by the namespace. |

## Releases

### Version 1.18.0 - 12 June 2026
- Automated release of [eeacms/advisory-board-frontend:1.30.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`f02be35e`](https://github.com/eea/helm-charts/commit/f02be35eab7f9484839f32f16aed770ce8c72390)]

### Version 1.17.0 - 10 June 2026
- Automated release of [eeacms/advisory-board-frontend:1.29.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`b3fe67b8`](https://github.com/eea/helm-charts/commit/b3fe67b838fc84e5798242a2ebdbffae6f22dfa8)]

### Version 1.16.0 - 15 April 2026
- Automated release of [eeacms/advisory-board-frontend:1.28.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`fd235378`](https://github.com/eea/helm-charts/commit/fd235378a5c6f4cd74fd81feef3ae55bb38e0435)]

### Version 1.15.0 - 25 February 2026
- Automated release of [eeacms/advisory-board-frontend:1.26.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`e2d3ba5e`](https://github.com/eea/helm-charts/commit/e2d3ba5ecf37d2bb411c12e4d7964f172b98726f)]

### Version 1.14.0 - 19 February 2026
- Automated release of [eeacms/advisory-board-frontend:1.25.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`b6fabef8`](https://github.com/eea/helm-charts/commit/b6fabef839c8d55b74ebb6edff64e7b35e91793a)]

### Version 1.13.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`a3815add`](https://github.com/eea/helm-charts/commit/a3815add4734afe03b410c17b8d9d891e6d0ab85)]

### Version 1.13.0 - 19 January 2026
- Automated release of [eeacms/advisory-board-frontend:1.24.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`0945c8a4`](https://github.com/eea/helm-charts/commit/0945c8a472cf9d92d8eecd88a1c1323e5f6ed19f)]

### Version 1.12.0 - 16 September 2025
- Automated release of [eeacms/advisory-board-frontend:1.23.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`423e6d26`](https://github.com/eea/helm-charts/commit/423e6d26150c67e783605d69c8db0c301296efd8)]

### Version 1.11.0 - 15 September 2025
- Automated release of [eeacms/advisory-board-frontend:1.22.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`b68e0034`](https://github.com/eea/helm-charts/commit/b68e003482faf9db39b8b5f5ee036ce9cd6907e3)]

### Version 1.10.0 - 02 September 2025
- Automated release of [eeacms/advisory-board-frontend:1.21.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`8d081aca`](https://github.com/eea/helm-charts/commit/8d081acad8c098490572d7881f927398b99a3c8a)]

### Version 1.9.0 - 02 September 2025
- Automated release of [eeacms/advisory-board-frontend:1.20.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`5304df3a`](https://github.com/eea/helm-charts/commit/5304df3ab39529a1193e07fe0ec0afb07f5529bf)]

### Version 1.8.0 - 20 August 2025
- Automated release of [eeacms/advisory-board-frontend:1.19.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`5c3ff650`](https://github.com/eea/helm-charts/commit/5c3ff650bce5f94157a775416dcbf4c044778e0e)]

### Version 1.7.0 - 12 August 2025
- Automated release of [eeacms/advisory-board-frontend:1.18.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`e742c990`](https://github.com/eea/helm-charts/commit/e742c9904e31044c089dedcd5c6e7f15358926fb)]

### Version 1.6.0 - 08 August 2025
- Automated release of [eeacms/advisory-board-frontend:1.17.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`dea7217d`](https://github.com/eea/helm-charts/commit/dea7217dc502f26a42ee9c1bead27ba400361abd)]

### Version 1.5.0 - 06 August 2025
- Automated release of [eeacms/advisory-board-frontend:1.16.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`705ccb66`](https://github.com/eea/helm-charts/commit/705ccb662d05d2bed9c9349e3e3fa2c6f042c83d)]

### Version 1.4.2 - 01 August 2025
- Automated release of [eeacms/plone-varnish:7.7-1.1](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`69d67840`](https://github.com/eea/helm-charts/commit/69d67840c1dee3ed4cf3ef3fb2e735b19474587b)]

### Version 1.4.1 - 21 May 2025
- Automated release of [eeacms/plone-varnish:7.7-1.0](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`6dfa0a9`](https://github.com/eea/helm-charts/commit/6dfa0a9ee178c65428561851b78113c762859c2a)]

### Version 1.4.0 - 16 May 2025
- Automated release of [eeacms/advisory-board-frontend:1.15.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`3e3e4b3`](https://github.com/eea/helm-charts/commit/3e3e4b32fb9fa187a8e342b40a13d096f5ef20ca)]

### Version 1.3.1 - 16 April 2025
- Added debug deployment with volume for dev adddons [valentinab25 - [`ad6c433`](https://github.com/eea/helm-charts/commit/ad6c433e289e5ec796b6aed8a46ab16f366ba51b)]

### Version 1.3.0 - 02 April 2025
- Automated release of [eeacms/advisory-board-frontend:1.14.0](https://github.com/eea/advisory-board-frontend/releases) [EEA Jenkins - [`8c38ff0`](https://github.com/eea/helm-charts/commit/8c38ff0bb87494e5e85b0f4614a245d46830e88c)]

### Version 1.2.2 - 31 March 2025
- Added variable to allow empty certificate name for default certificate [valentinab25 - [`f8e7b62`](https://github.com/eea/helm-charts/commit/f8e7b627bd0e1ede8fa7e16a5b39a7665cbf89bb)]

### Version 1.2.1 - 12 March 2025
- Automated release of [eeacms/plone-varnish:7.6-1.0](https://github.com/eea/plone-varnish/releases)

### Version 1.2.0 - 24 February 2025
- Automated release of eeacms/advisory-board-frontend:1.12.0

### Version 1.0.2 
- Rename services to be frontend

### Version 1.0.1
- Add http probes to volto

### Version 1.0.0
- Initial release. Version matching Rancher 1 catalog version.
