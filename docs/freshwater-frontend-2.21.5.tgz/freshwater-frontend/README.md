# Wise Freshwater Frontend

A Helm chart for deploying the WISE Freshwater frontend application.

## Releases

### Version 2.21.5 - 28 August 2026
- Automated release of [eeacms/freshwater-frontend:2.39.0-beta.05](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`dd495ce4`](https://github.com/eea/helm-charts/commit/dd495ce4dd6bc56908f53dc4d6afbffb8532ad22)]

### Version 2.21.4 - 28 August 2026
- rename RAZZLE_PROXY_ES/QA_DSN_globalsearch env vars to match volto-searchlib 5.x [laszlocseh - [`e05e8ba7`](https://github.com/eea/helm-charts/commit/e05e8ba767c70864fc7deb557d2a432ea5863352)]

### Version 2.21.3 - 21 August 2026
- Automated release of [eeacms/freshwater-frontend:2.39.0-beta.04](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`c3522be4`](https://github.com/eea/helm-charts/commit/c3522be4f9da8a45c178754dc9157dbb54567f6e)]

### Version 2.21.2 - 20 August 2026
- Automated release of [eeacms/freshwater-frontend:2.39.0-beta.03](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`c1b9b9fc`](https://github.com/eea/helm-charts/commit/c1b9b9fc84794d8f7466867a9e04c9074db41a0c)]

### Version 2.21.1 - 20 August 2026
- Automated release of [eeacms/freshwater-frontend:2.39.0-beta.02](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`3c82a037`](https://github.com/eea/helm-charts/commit/3c82a0374d2414c12de4f225db6ad957cba144b8)]

### Version 2.21.0 - 13 August 2026
- Automated release of [eeacms/freshwater-frontend:2.38.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`eaee0db5`](https://github.com/eea/helm-charts/commit/eaee0db52f5c6cf7e48699c779f189c124990436)]

### Version 2.20.0 - 15 July 2026
- Automated release of [eeacms/freshwater-frontend:2.37.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`9a105eca`](https://github.com/eea/helm-charts/commit/9a105eca216298b69dd74f9f4a82aa9ee98b7336)]

### Version 2.19.0 - 09 July 2026
- Automated release of [eeacms/freshwater-frontend:2.36.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`78e8953d`](https://github.com/eea/helm-charts/commit/78e8953d8f861ebf00fdb284336e05d0d8d24ab0)]

### Version 2.18.0 - 23 June 2026
- Automated release of [eeacms/freshwater-frontend:2.35.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`8210dc11`](https://github.com/eea/helm-charts/commit/8210dc11692e1a44149d91ed80e7f6d08badb5e9)]

### Version 2.17.1 - 16 June 2026
- Automated release of [eeacms/freshwater-frontend:2.35.0-beta.1](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`8e9ad0c9`](https://github.com/eea/helm-charts/commit/8e9ad0c9ac9900ef98ac958bda8689ddd726c7a0)]

### Version 2.17.0 - 15 June 2026
- Automated release of [eeacms/freshwater-frontend:2.34.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`f3604311`](https://github.com/eea/helm-charts/commit/f3604311e3f7f8562b39385fb6161aeff013d3fa)]

### Version 2.16.3 - 14 June 2026
- Automated release of [eeacms/freshwater-frontend:2.34.0-beta.3](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`d2d08589`](https://github.com/eea/helm-charts/commit/d2d08589972d8c6d00bbd2875876f8c750d13abe)]

### Version 2.16.2 - 09 June 2026
- Automated release of [eeacms/freshwater-frontend:2.34.0-beta.2](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`3961cd2d`](https://github.com/eea/helm-charts/commit/3961cd2da1d88c665dc0815f3f642bfee42dff2c)]

### Version 2.16.1 - 09 June 2026
- Automated release of [eeacms/freshwater-frontend:2.34.0-beta.1](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`8d327f32`](https://github.com/eea/helm-charts/commit/8d327f322ffa1f61ba50724092d4180f6860d637)]

### Version 2.16.0 - 03 June 2026
- Automated release of [eeacms/freshwater-frontend:2.33.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`4709f1eb`](https://github.com/eea/helm-charts/commit/4709f1eb17efbd0c65ae9ef5ad2bb87600cf87b9)]

### Version 2.15.2 - 03 June 2026
- Update nginx to 1.31.1 - Refs [#304237](https://taskman.eionet.europa.eu/issues/304237) [valentinab25 - [`b9d2603a`](https://github.com/eea/helm-charts/commit/b9d2603af87b586680771c436436b2778bbbe151)]

### Version 2.15.1 - 25 May 2026
- Automated release of [eeacms/freshwater-frontend:2.33.0-beta.1](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`c479a60d`](https://github.com/eea/helm-charts/commit/c479a60d1f6359a13994cdb585b6eb1dbcc124a2)]

### Version 2.15.0 - 08 May 2026
- Automated release of [eeacms/freshwater-frontend:2.32.4](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`8419a69f`](https://github.com/eea/helm-charts/commit/8419a69f7eb00907d828905c057079a9b7146772)]

### Version 2.14.0 - 24 April 2026
- Automated release of [eeacms/freshwater-frontend:2.32.3](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`8ce3e31f`](https://github.com/eea/helm-charts/commit/8ce3e31f02d15f2c983a319321db29f933f00860)]

### Version 2.13.0 - 22 April 2026
- Automated release of [eeacms/freshwater-frontend:2.32.2](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`5a708350`](https://github.com/eea/helm-charts/commit/5a708350440330dd2edf8cf932c83077a5e7b904)]

### Version 2.12.0 - 20 April 2026
- Automated release of [eeacms/freshwater-frontend:2.32.1](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`71f6c31a`](https://github.com/eea/helm-charts/commit/71f6c31a0fedcb0eaf0a3168cebe132b708cfcb1)]

### Version 2.11.0 - 08 April 2026
- Automated release of [eeacms/freshwater-frontend:2.32.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`69424cd9`](https://github.com/eea/helm-charts/commit/69424cd9e22379aa40558553c36f83f904f9482c)]

### Version 2.10.0 - 30 March 2026
- Automated release of [eeacms/freshwater-frontend:2.31.0-demo.02](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`6cec0ab9`](https://github.com/eea/helm-charts/commit/6cec0ab96287940aef2f7646988e3385188b707b)]

### Version 2.9.0 - 27 March 2026
- Automated release of [eeacms/freshwater-frontend:2.31.0-demo.01](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`abfeec35`](https://github.com/eea/helm-charts/commit/abfeec35416214d53073d8cbe16e73c4cf3451d9)]

### Version 2.8.0 - 24 March 2026
- Automated release of [eeacms/freshwater-frontend:2.31.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`9ab686fa`](https://github.com/eea/helm-charts/commit/9ab686fa489350e7a17bd17f1f4a2ee261c3cd08)]

### Version 2.7.0 - 23 March 2026
- Automated release of [eeacms/freshwater-frontend:2.30.0-demo.01](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`d727801a`](https://github.com/eea/helm-charts/commit/d727801a6de2c4c35944a7431f47c680e11ad183)]

### Version 2.6.0 - 13 March 2026
- Automated release of [eeacms/freshwater-frontend:2.30.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`7b7fcae2`](https://github.com/eea/helm-charts/commit/7b7fcae266f5df997f29ec7efe4ff9b9831dcd56)]

### Version 2.5.0 - 24 February 2026
- Automated release of [eeacms/freshwater-frontend:2.29.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`fcf6ddce`](https://github.com/eea/helm-charts/commit/fcf6ddcef7c8054777581f9ebd1751d5eed58492)]

### Version 2.4.0 - 18 February 2026
- bump freshwater-frontend version [laszlocseh - [`c5d0437b`](https://github.com/eea/helm-charts/commit/c5d0437b51a0c67f8d3c2a1f3f497d567767d2c4)]

### Version 2.2.0 - 18 February 2026
- Automated release of [eeacms/freshwater-frontend:2.28.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`62d756a4`](https://github.com/eea/helm-charts/commit/62d756a41b9231a2ff58eda71c83ebb02dfeab8d)]

### Version 2.1.0 - 13 February 2026
- Automated release of [eeacms/freshwater-frontend:2.27.0](https://github.com/eea/freshwater-frontend/releases) [EEA Jenkins - [`c76c6c88`](https://github.com/eea/helm-charts/commit/c76c6c88d7810717f5e2088cde880f0369d55b0b)]

### Version 2.0.6 - 10 February 2026
- fix search [Dobricean Ioan Dorian - [`3d9201b8`](https://github.com/eea/helm-charts/commit/3d9201b8658e8bb5f2f4e184d3b57a174f6e4fb7)]

### Version 2.0.4 - 09 February 2026
- fix ingress [Dobricean Ioan Dorian - [`4d47e821`](https://github.com/eea/helm-charts/commit/4d47e821f66ce0338e78d249a0ae018ef531404f)]

### Version 2.0.2 - 09 February 2026
- fix ingress [Dobricean Ioan Dorian - [`05f36f69`](https://github.com/eea/helm-charts/commit/05f36f692384b52c7e4d8ebb1830710a0f065b7e)]

### Version 2.0.0 - 09 February 2026
- release frontend [Dobricean Ioan Dorian - [`831f4730`](https://github.com/eea/helm-charts/commit/831f473037ec33ddcc6c35b718237744da35656f)]

### Version 1.0.1 - 08 February 2026
- change app version [Dobricean Ioan Dorian - [`8266b543`](https://github.com/eea/helm-charts/commit/8266b54337d771cac3f90b63bd0936fb910f942c)]

### Version 1.0.0

- Initial release based on marine-frontend chart
