# COPERNICUS IN-SITU COMPONENT website backend - Plone 6

This chart deployes the COPERNICUS IN-SITU COMPONENT website backend app

## Values

| Key           | Type | Default | Description                       |
| ------------- | ---- | ------- | --------------------------------- |
| debug.enabled | bool | false   | Activate the Plone debug instance |

## Releases

### Version 6.44.0 - 22 April 2026
- Automated release of [eeacms/insitu-backend:6.1.3-17](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`34798521`](https://github.com/eea/helm-charts/commit/347985213f7264ac22a147917ff804570a1e25d6)]

### Version 6.43.0 - 18 April 2026
- Automated release of [eeacms/insitu-backend:6.1.3-16](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`3b8acca6`](https://github.com/eea/helm-charts/commit/3b8acca653485a2fadc2860e708e304b93771985)]

### Version 6.42.0 - 17 April 2026
- Automated release of [eeacms/insitu-backend:6.1.3-15](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`3bff6a6b`](https://github.com/eea/helm-charts/commit/3bff6a6b2d2854030bcfc2eb58618a632b79e778)]

### Version 6.41.0 - 16 April 2026
- Automated release of [eeacms/insitu-backend:6.1.3-14](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`1ec40c80`](https://github.com/eea/helm-charts/commit/1ec40c80a4fb0549af8c7452ff45484ba25f9175)]

### Version 6.40.0 - 15 April 2026
- Automated release of [eeacms/insitu-backend:6.1.3-13](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`040b4537`](https://github.com/eea/helm-charts/commit/040b4537b510d3f252466514e69571f8e0281d73)]

### Version 6.39.0 - 26 March 2026
- Automated release of [eeacms/insitu-backend:6.1.3-12](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`a0b331cd`](https://github.com/eea/helm-charts/commit/a0b331cdc0f5597bdd0d6a67e91a888fa6ac7175)]

### Version 6.38.0 - 07 March 2026
- Automated release of [eeacms/insitu-backend:6.1.3-11](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`55cad729`](https://github.com/eea/helm-charts/commit/55cad729e0170d21830acc3b0e7a569f016f8f5b)]

### Version 6.37.0 - 26 February 2026
- Automated release of [eeacms/insitu-backend:6.1.3-9](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`724428e6`](https://github.com/eea/helm-charts/commit/724428e6e405848cfffd5620b12b2ef9112bf11f)]

### Version 6.36.0 - 06 February 2026
- Automated release of [eeacms/insitu-backend:6.1.3-8](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`359ba36e`](https://github.com/eea/helm-charts/commit/359ba36e08873038f0cecc90596ac5fc167b7e70)]

### Version 6.35.0 - 04 February 2026
- Automated release of [eeacms/insitu-backend:6.1.3-7](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`e11d17ea`](https://github.com/eea/helm-charts/commit/e11d17eac8df2555f98b2dc011a2a7a34ce2a361)]

### Version 6.33.0 - 28 January 2026
- Automated release of [eeacms/insitu-backend:6.1.3-6](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`b2841f39`](https://github.com/eea/helm-charts/commit/b2841f3950fd7f3463ee8f8afadc4d2f206dfd89)]

### Version 6.32.0 - 28 January 2026
- Automated release of [eeacms/insitu-backend:6.1.3-5](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`9dc591e2`](https://github.com/eea/helm-charts/commit/9dc591e2c15eee99b71db408c6fb2ab1d4369767)]

### Version 6.31.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`e1f4203e`](https://github.com/eea/helm-charts/commit/e1f4203e23e536bdf752bd5b916d46a0900db5b1)]

### Version 6.31.0 - 23 December 2025
- Automated release of [eeacms/insitu-backend:6.1.3-4](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`35e86034`](https://github.com/eea/helm-charts/commit/35e86034d01ed99f77c47d0cdb85329babfe81f7)]

### Version 6.30.0 - 22 December 2025
- Automated release of [eeacms/insitu-backend:6.1.3-3](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`d6d0542a`](https://github.com/eea/helm-charts/commit/d6d0542a8aaf70dc52b5952f81181b5d4cda9fe3)]

### Version 6.29.0 - 22 December 2025
- Automated release of [eeacms/insitu-backend:6.1.3-2](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`26279599`](https://github.com/eea/helm-charts/commit/26279599aaa399a8685b0c19271ed29a12898afe)]

### Version 6.28.0 - 20 December 2025
- Automated release of [eeacms/insitu-backend:6.1.3-1](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`d4b77e02`](https://github.com/eea/helm-charts/commit/d4b77e024f5ff3d013db5b1e2b02de552f58fe53)]

### Version 6.27.1 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`2c6421ec`](https://github.com/eea/helm-charts/commit/2c6421ec6e0c6c90710b4d5ed0aa9aa896f6e68a)]

### Version 6.27.0 - 25 October 2025
- Automated release of [eeacms/insitu-backend:6.0.15-36](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`a365b4ca`](https://github.com/eea/helm-charts/commit/a365b4cab6b1cd25b976423d4993c985733ccc07)]

### Version 6.26.0 - 24 October 2025
- Automated release of [eeacms/insitu-backend:6.0.15-35](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`3a1b2352`](https://github.com/eea/helm-charts/commit/3a1b2352ff304dee0216608393a05c9ecb750391)]

### Version 6.25.0 - 08 October 2025
- Automated release of [eeacms/insitu-backend:6.0.15-34](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`1b504148`](https://github.com/eea/helm-charts/commit/1b5041486fcb2fa8e4687271bdea54cf6f4b9089)]

### Version 6.24.0 - 28 August 2025
- Automated release of [eeacms/insitu-backend:6.0.15-33](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`20734e14`](https://github.com/eea/helm-charts/commit/20734e14af04e5ca4cf857aede4589826e7432bb)]

### Version 6.23.0 - 27 August 2025
- Automated release of [eeacms/insitu-backend:6.0.15-32](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`a5ade721`](https://github.com/eea/helm-charts/commit/a5ade72196dfb20872b9560f18cf289fbc60e849)]

### Version 6.22.0 - 27 August 2025
- Automated release of [eeacms/insitu-backend:6.0.15-31](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`b9eef54a`](https://github.com/eea/helm-charts/commit/b9eef54a23b144c7206aa51edefbd77bafcc8d15)]

### Version 6.21.1 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`cf107d47`](https://github.com/eea/helm-charts/commit/cf107d47a0ba2009d8d6c1bb3fabd4f742dc6889)]

### Version 6.21.0 - 20 August 2025
- Automated release of [eeacms/insitu-backend:6.0.15-30](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`b94d9a85`](https://github.com/eea/helm-charts/commit/b94d9a85dc41038838e2bd396ff959a8578ca82d)]

### Version 6.20.0 - 20 August 2025
- Automated release of [eeacms/insitu-backend:6.0.15-29](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`2090311c`](https://github.com/eea/helm-charts/commit/2090311c326caa2679d327f9dad0a029b6a7830c)]

### Version 6.19.0 - 13 August 2025
- Automated release of [eeacms/insitu-backend:6.0.16-beta.3](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`611adc46`](https://github.com/eea/helm-charts/commit/611adc465187fe69cb9388707c4295a9c47b7b19)]

### Version 6.18.0 - 11 August 2025
- Automated release of [eeacms/insitu-backend:6.0.15-28](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`553f2f2d`](https://github.com/eea/helm-charts/commit/553f2f2d1a86e3216e6cbd78a7a6ec9b54fa8855)]

### Version 6.17.0 - 11 August 2025
- Automated release of [eeacms/insitu-backend:6.0.16-beta.1](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`8067058e`](https://github.com/eea/helm-charts/commit/8067058ec8e30e277b764e6e61e92963b9f7b1c6)]

### Version 6.16.0 - 05 August 2025
- Automated release of [eeacms/insitu-backend:6.0.15-27](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`634ec35d`](https://github.com/eea/helm-charts/commit/634ec35d7b11daf10ede3c1cf0c0bdcf6ec4fc7c)]

### Version 6.15.0 - 05 August 2025
- Automated release of [eeacms/insitu-backend:6.0.15-26](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`8dcbd183`](https://github.com/eea/helm-charts/commit/8dcbd183d2b338b9257bcc40e552c449b3a67954)]

### Version 6.14.0 - 01 August 2025
- Automated release of [eeacms/insitu-backend:6.0.15-25](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`7799f933`](https://github.com/eea/helm-charts/commit/7799f933e0bae7ecbf623a822f5988d5d698cb2a)]

### Version 6.13.1 - 01 August 2025
- Automated release of [eeacms/plone-varnish:7.7-1.1](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`7df7fdbb`](https://github.com/eea/helm-charts/commit/7df7fdbbfba6ad201bc837c193abe474093de2f6)]

### Version 6.13.0 - 28 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-24](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`4d207fa2`](https://github.com/eea/helm-charts/commit/4d207fa202c602ae0a9f28244c2ed57ab50ac940)]

### Version 6.12.0 - 28 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-23](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`c68f2907`](https://github.com/eea/helm-charts/commit/c68f2907c15a4e2713519dd87a9ec6e116ee1432)]

### Version 6.11.0 - 28 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-22](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`133f6bd5`](https://github.com/eea/helm-charts/commit/133f6bd5b5064554c60bd07f26883e200c63a2a4)]

### Version 6.10.0 - 24 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-21](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`3352088c`](https://github.com/eea/helm-charts/commit/3352088c0c01505b217a1ed417cae53ee46e36d3)]

### Version 6.9.0 - 24 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-20](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`ccc00e81`](https://github.com/eea/helm-charts/commit/ccc00e814d8e7c28a8ffc3fbdbdb77c40ddc7b7b)]

### Version 6.8.0 - 23 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-19](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`f2bdb5d8`](https://github.com/eea/helm-charts/commit/f2bdb5d8c26ce1ca24fc1f4859b829742b2df02e)]

### Version 6.7.0 - 23 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-18](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`c2d56813`](https://github.com/eea/helm-charts/commit/c2d56813cfea3c066a62a41defd4c8f2499d718a)]

### Version 6.6.0 - 23 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-17](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`4e22ecc0`](https://github.com/eea/helm-charts/commit/4e22ecc0ffa1b8f0d7f035ad0c0c31ad8d4c0f87)]

### Version 6.5.0 - 23 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-16](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`eb878f67`](https://github.com/eea/helm-charts/commit/eb878f67976dfe45ddb3ffd21f566a8b3d33a741)]

### Version 6.4.0 - 23 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-15](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`2edf2859`](https://github.com/eea/helm-charts/commit/2edf285967bd98cc3f8269165f0235e5f478567b)]

### Version 6.3.0 - 23 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-14](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`93cc03dd`](https://github.com/eea/helm-charts/commit/93cc03dd1827576bc5d31876e879b1a2b8e0d2b9)]

### Version 6.2.0 - 22 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-13](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`2e289cfa`](https://github.com/eea/helm-charts/commit/2e289cfa38c777b3fbd297df8ee05ee65ae5b3e0)]

### Version 6.1.0 - 15 July 2025
- Automated release of [eeacms/insitu-backend:6.0.15-12](https://github.com/eea/insitu-backend/releases) [EEA Jenkins - [`f77ca804`](https://github.com/eea/helm-charts/commit/f77ca80485a9dd7056d00d8219df82d0e567c309)]

### Version 6.0.15

- Initial release.