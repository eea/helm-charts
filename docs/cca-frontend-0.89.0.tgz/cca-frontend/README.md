# CCA Frontend

Helm chart for the Climate-ADAPT frontend stack.

The chart follows the Volto/Varnish pattern already present in this repository
and adds the Apache routing layer used by the existing Rancher stack. Secrets
and tokens are intentionally left empty in `values.yaml`.
## Releases

### Version 0.89.0 - 03 November 2026
- Automated release of [eeacms/cca-frontend:4.50.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`a96e34f99`](https://github.com/eea/helm-charts/commit/a96e34f99ba97c05407ef36cc23820164acf9704)]

### Version 0.88.2 - 03 November 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.47](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`16820c2f0`](https://github.com/eea/helm-charts/commit/16820c2f0a1caaa39e5c8828d2d6789ffa0ccc0d)]

### Version 0.88.0 - 30 October 2026
- Automated release of [eeacms/cca-frontend:4.49.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`a1c52cde4`](https://github.com/eea/helm-charts/commit/a1c52cde423143139daf56742adb71ee7675b2a9)]

### Version 0.87.0 - 29 October 2026
- Automated release of [eeacms/cca-frontend:4.48.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`9d7a78e25`](https://github.com/eea/helm-charts/commit/9d7a78e252d426cfe4cfb9ad3cfd31f8c4eaec25)]

### Version 0.86.0 - 28 October 2026
- Automated release of [eeacms/cca-frontend:4.47.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`821e4a8b5`](https://github.com/eea/helm-charts/commit/821e4a8b5ecd41c5168a260ab77d763a4462ffc5)]

### Version 0.85.0 - 26 October 2026
- Automated release of [eeacms/cca-frontend:4.46.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`6fff7c351`](https://github.com/eea/helm-charts/commit/6fff7c351ec0e669f36be3f74bbf01a45465aebc)]

### Version 0.84.0 - 26 October 2026
- Automated release of [eeacms/cca-frontend:4.45.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`c79f5e73c`](https://github.com/eea/helm-charts/commit/c79f5e73c9c4ddc4bdcd23ceb1d5e7483a71d7b9)]

### Version 0.83.0 - 23 October 2026
- Automated release of [eeacms/cca-frontend:4.44.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`486146744`](https://github.com/eea/helm-charts/commit/486146744a1e5245d26ceee8d3d3946393fa9c3b)]

### Version 0.82.1 - 22 October 2026
- 4.43.0 [GhitaB - [`2b289516b`](https://github.com/eea/helm-charts/commit/2b289516b622fcdb83b5e5c326adf52332031f50)]

### Version 0.82.0 - 22 October 2026
- Automated release of [eeacms/cca-frontend:4.43.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`e961c0e81`](https://github.com/eea/helm-charts/commit/e961c0e81b3e60c6384e644e7ebd5e6074684703)]

### Version 0.81.0 - 21 October 2026
- Automated release of [eeacms/cca-frontend:4.42.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`476074ded`](https://github.com/eea/helm-charts/commit/476074ded897fa6c7ef2ec81ee6d3835990133ba)]

### Version 0.80.0 - 20 October 2026
- Automated release of [eeacms/cca-frontend:4.41.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`a4eb15c04`](https://github.com/eea/helm-charts/commit/a4eb15c0457ed869c827c29c869758820e72dada)]

### Version 0.79.0 - 19 October 2026
- Automated release of [eeacms/cca-frontend:4.40.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`ee6f7e9e5`](https://github.com/eea/helm-charts/commit/ee6f7e9e5bf21e5d2135e3978a70a7c81c09ed38)]

### Version 0.78.0 - 16 October 2026
- Automated release of [eeacms/cca-frontend:4.39.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`4a14ae6ef`](https://github.com/eea/helm-charts/commit/4a14ae6efbcace0800751e1bbf01ec5b4db50d94)]

### Version 0.77.0 - 15 October 2026
- Automated release of [eeacms/cca-frontend:4.38.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`fa7ae9466`](https://github.com/eea/helm-charts/commit/fa7ae9466b1f9d5b8a9c2f72069dd82ff5d665be)]

### Version 0.76.0 - 12 October 2026
- Automated release of [eeacms/cca-frontend:4.37.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`4d99bad9`](https://github.com/eea/helm-charts/commit/4d99bad9e967a6798018c8a0bdac31c7310fa199)]

### Version 0.75.0 - 12 October 2026
- Automated release of [eeacms/cca-frontend:4.36.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`fc247a0a`](https://github.com/eea/helm-charts/commit/fc247a0ac09f7c1e4b024389e24c5f48bcac6d85)]

### Version 0.74.2 - 09 October 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.44](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`38ab59ec`](https://github.com/eea/helm-charts/commit/38ab59ec191633eeb24c96a19f329f96e2698599)]

### Version 0.74.0 - 08 October 2026
- Automated release of [eeacms/cca-frontend:4.35.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`57ec140d`](https://github.com/eea/helm-charts/commit/57ec140da380c8cdb5541374b7ec10c28e794836)]

### Version 0.73.3 - 08 October 2026
- 4.34.0 [GhitaB - [`bea486e2`](https://github.com/eea/helm-charts/commit/bea486e2144b9af84d60488c0637a949ac950a1f)]

### Version 0.73.1 - 08 October 2026
- 4.0.0-alpha.42 [GhitaB - [`2831fabe`](https://github.com/eea/helm-charts/commit/2831fabe62a5efc0435f917d284a7e04723ac604)]

### Version 0.73.0 - 08 October 2026
- Automated release of [eeacms/cca-frontend:4.34.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`a4c65992`](https://github.com/eea/helm-charts/commit/a4c65992ca342f9c6e27a5f198f5c8d84efb2d82)]

### Version 0.72.0 - 06 October 2026
- Automated release of [eeacms/cca-frontend:4.33.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`0ece0864`](https://github.com/eea/helm-charts/commit/0ece0864d72240f32ca05986ca5caf4b7bd04516)]

### Version 0.71.0 - 06 October 2026
- Automated release of [eeacms/cca-frontend:4.32.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`c06e9cc9`](https://github.com/eea/helm-charts/commit/c06e9cc9e5f0800540c1783bb866a74562dbabdc)]

### Version 0.70.0 - 05 October 2026
- Automated release of [eeacms/cca-frontend:4.31.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`36b1873b`](https://github.com/eea/helm-charts/commit/36b1873b946376c900e9b5177c8fa408eb24b943)]

### Version 0.69.2 - 05 October 2026
- 4.0.0-alpha.40 [GhitaB - [`070d959a`](https://github.com/eea/helm-charts/commit/070d959a15292e814498022c8a483906619de74c)]

### Version 0.69.0 - 01 October 2026
- Automated release of [eeacms/cca-frontend:4.30.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`fc501595`](https://github.com/eea/helm-charts/commit/fc5015956a9661eb42b7d6abbc932e03ddeea8cb)]

### Version 0.68.0 - 29 September 2026
- Automated release of [eeacms/cca-frontend:4.29.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`ca67366c`](https://github.com/eea/helm-charts/commit/ca67366ccf18d9eae6a00f948273939ea2b93e75)]

### Version 0.67.0 - 29 septembrie 2026
- Link to varnish_frontend for images and download paths [Tiberiu Ichim - [`a28bc86b`](https://github.com/eea/helm-charts/commit/a28bc86be85f7c955baa2de934cfaccd048dfc28)]

### Version 0.66.0 - 25 September 2026
- Automated release of [eeacms/cca-frontend:4.28.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`fe5cf6bf`](https://github.com/eea/helm-charts/commit/fe5cf6bfd43cf7fb6eb48a6fa4e2d41f9a6efc44)]

### Version 0.65.0 - 23 September 2026
- Automated release of [eeacms/cca-frontend:4.27.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`8f511aa5`](https://github.com/eea/helm-charts/commit/8f511aa5795df4b59739405059a853566aac9a41)]

### Version 0.64.2 - 23 September 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.39](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`c1e6fd1a`](https://github.com/eea/helm-charts/commit/c1e6fd1a547bbe579e81e0c982b294b1bfaa8c8d)]

### Version 0.64.0 - 21 September 2026
- Automated release of [eeacms/cca-frontend:4.26.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`76dc0024`](https://github.com/eea/helm-charts/commit/76dc0024b6c79bdb267d9df5c63021df85a4d885)]

### Version 0.63.0 - 21 September 2026
- Automated release of [eeacms/cca-frontend:4.25.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`f1328f46`](https://github.com/eea/helm-charts/commit/f1328f4629276687c1b62c45a814b9f80028429c)]

### Version 0.62.0 - 17 September 2026
- Automated release of [eeacms/cca-frontend:4.24.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`fa9cac12`](https://github.com/eea/helm-charts/commit/fa9cac129e7e79cc0faeb1ceef91fec34bb5ced6)]

### Version 0.61.0 - 16 September 2026
- Automated release of [eeacms/cca-frontend:4.23.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`c5ccd57d`](https://github.com/eea/helm-charts/commit/c5ccd57ded950a4bffdb3e2b6b39f26cf74c7839)]

### Version 0.60.0 - 15 September 2026
- Automated release of [eeacms/cca-frontend:4.22.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`39db13fc`](https://github.com/eea/helm-charts/commit/39db13fcc900011ab62fb32dcd989e2e488bf8a6)]

### Version 0.59.0 - 14 September 2026
- Automated release of [eeacms/cca-frontend:4.21.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`5b3cb4e0`](https://github.com/eea/helm-charts/commit/5b3cb4e010c592f99f12432ac45c7530ae4bab18)]

### Version 0.58.1 - 14 septembrie 2026
- Upgrade to volto-cca-policy [Tiberiu Ichim - [`73fa17f0`](https://github.com/eea/helm-charts/commit/73fa17f05cbb29a446b3a023c1efe3af6f07ad30)]

### Version 0.58.0 - 10 September 2026
- Automated release of [eeacms/cca-frontend:4.19.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`c73d9813`](https://github.com/eea/helm-charts/commit/c73d98134bf918462f744379494f14577a7a3896)]

### Version 0.57.0 - 10 September 2026
- Automated release of [eeacms/cca-frontend:4.18.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`d478e677`](https://github.com/eea/helm-charts/commit/d478e67766501e6b4e46d360a51f2ef133d03758)]

### Version 0.56.0 - 08 September 2026
- Automated release of [eeacms/cca-frontend:4.17.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`e2f7ec42`](https://github.com/eea/helm-charts/commit/e2f7ec425f37b6c7213c47c2e118ed74c0e8b203)]

### Version 0.55.0 - 04 septembrie 2026
- Upgrade to latest volto-cca-policy which includes volto-eea-chatbot 4.x branch [Tiberiu Ichim - [`0cda8899`](https://github.com/eea/helm-charts/commit/0cda88995d2e93d6a68bcb01d43d01ee3ef878c7)]

### Version 0.54.0 - 01 September 2026
- Automated release of [eeacms/cca-frontend:4.15.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`577f0423`](https://github.com/eea/helm-charts/commit/577f0423c9eb668f54cda51a214ddce4becfb4ff)]

### Version 0.53.2 - 31 August 2026
- 4.0.0-alpha.36 [GhitaB - [`7861719c`](https://github.com/eea/helm-charts/commit/7861719c564a92b042c842db74c9f85fcfb5a7f1)]

### Version 0.53.0 - 31 August 2026
- Automated release of [eeacms/cca-frontend:4.14.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`5a711320`](https://github.com/eea/helm-charts/commit/5a711320662387ca68d7f51413af3c020bcc7b15)]

### Version 0.52.3 - 28 August 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.35](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`74ae1c21`](https://github.com/eea/helm-charts/commit/74ae1c21b3722d9a53eb48e1c0c25f70cf59f9f8)]

### Version 0.52.2 - 28 August 2026
- 4.0.0-alpha.34 [GhitaB - [`91cc9cc5`](https://github.com/eea/helm-charts/commit/91cc9cc5efb158939ff61a169f409c835b0bbb12)]

### Version 0.52.0 - 24 August 2026
- Automated release of [eeacms/cca-frontend:4.13.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`a7a1c37a`](https://github.com/eea/helm-charts/commit/a7a1c37a22bf267229d83e5fd6aa203f607f21ae)]

### Version 0.51.0 - 21 August 2026
- Automated release of [eeacms/cca-frontend:4.12.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`b2eed4c6`](https://github.com/eea/helm-charts/commit/b2eed4c610b1f89afc95352037cd3bde254f77cd)]

### Version 0.50.0 - 20 August 2026
- Automated release of [eeacms/cca-frontend:4.11.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`526b52bd`](https://github.com/eea/helm-charts/commit/526b52bd4595a7c7eb2ce0850f5dc9df0e827ee5)]

### Version 0.49.3 - 19 August 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.32](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`40ba0d31`](https://github.com/eea/helm-charts/commit/40ba0d31f4630204933bac1475ed947160886da3)]

### Version 0.49.2 - 19 August 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.31](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`ca6a4372`](https://github.com/eea/helm-charts/commit/ca6a4372a2f0e10936e6b1d40386c38861095cf1)]

### Version 0.49.0 - 18 August 2026
- Automated release of [eeacms/cca-frontend:4.10.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`ee6e65da`](https://github.com/eea/helm-charts/commit/ee6e65dacaf673faf645d222542ef9306ef3f45d)]

### Version 0.48.2 - 18 August 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.29](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`e5a10edb`](https://github.com/eea/helm-charts/commit/e5a10edb70c47f56549cb424ff758a0e16aeb896)]

### Version 0.48.0 - 17 August 2026
- Automated release of [eeacms/cca-frontend:4.9.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`f731aa5d`](https://github.com/eea/helm-charts/commit/f731aa5dcb40b52f5876fafa8f14ff0676f61531)]

### Version 0.47.0 - 17 August 2026
- Automated release of [eeacms/cca-frontend:4.8.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`c1c732d5`](https://github.com/eea/helm-charts/commit/c1c732d55790374114ed710d7bca9f5e3de49181)]

### Version 0.46.0 - 11 August 2026
- Automated release of [eeacms/cca-frontend:4.7.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`aea561a9`](https://github.com/eea/helm-charts/commit/aea561a9c48cfe5361c8a65b2803f9f8cf40e55d)]

### Version 0.45.4 - 04 August 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.26](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`b41e0d15`](https://github.com/eea/helm-charts/commit/b41e0d15985a7d29b9ff8c471913270268f45821)]

### Version 0.45.3 - 04 August 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.25](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`b983bc11`](https://github.com/eea/helm-charts/commit/b983bc11dd1877e3b6604fb4154eb5eb14b6a9bb)]

### Version 0.45.2 - 03 August 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.24](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`ee13a87a`](https://github.com/eea/helm-charts/commit/ee13a87a48d51955384062bc71626b2a2c48da02)]

### Version 0.45.1 - 03 August 2026
- 4.0.0-alpha.23 [GhitaB - [`e24ecea2`](https://github.com/eea/helm-charts/commit/e24ecea2c5c852b4dfbf14a5131f66d1061254ac)]

### Version 0.44.0 - 30 July 2026
- Automated release of [eeacms/cca-frontend:4.6.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`839d2d98`](https://github.com/eea/helm-charts/commit/839d2d98709462097741289fab2b745272ab5657)]

### Version 0.43.0 - 29 July 2026
- Automated release of [eeacms/cca-frontend:4.5.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`3dfa7932`](https://github.com/eea/helm-charts/commit/3dfa7932b052408ebe544407362f09ea79437bdd)]

### Version 0.41.0 - 23 July 2026
- Automated release of [eeacms/cca-frontend:4.4.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`6208011c`](https://github.com/eea/helm-charts/commit/6208011ccf91efc9e51b33b8cdda1e0bf72e8f3e)]

### Version 0.40.0 - 21 July 2026
- Automated release of [eeacms/cca-frontend:4.3.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`ff216a73`](https://github.com/eea/helm-charts/commit/ff216a7392fabc6dfeec57462262b4cc51ba386c)]

### Version 0.38.0 - 20 iulie 2026
- update nginx values [Tiberiu Ichim - [`347fd6c7`](https://github.com/eea/helm-charts/commit/347fd6c7437804007fd5a64d10350cf44bbd14ea)]

### Version 0.36.0 - 13 iulie 2026
- use cca-frontend 4.2.0 [Tiberiu Ichim - [`fb1ce23e`](https://github.com/eea/helm-charts/commit/fb1ce23e19fdafc8f19b520b109374f140635cc4)]

### Version 0.35.12 - 13 iulie 2026
- implement protection for _admin [Tiberiu Ichim - [`5be78f22`](https://github.com/eea/helm-charts/commit/5be78f2291dbd7472f451771aedf67b0480498ca)]

### Version 0.35.10 - 13 July 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.20](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`143a2460`](https://github.com/eea/helm-charts/commit/143a2460bf366a354795572eaa847641dbde9a79)]

### Version 0.35.9 - 10 July 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.19](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`7d9025e2`](https://github.com/eea/helm-charts/commit/7d9025e24919e3d43ee0e449d9070993f642d81c)]

### Version 0.35.8 - 10 July 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.18](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`f5b00727`](https://github.com/eea/helm-charts/commit/f5b00727f67a3174078782dc554bcf8957c7a6c9)]

### Version 0.35.7 - 08 July 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.17](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`1e8a2be4`](https://github.com/eea/helm-charts/commit/1e8a2be466bf91b22fccd339b2ec77671fe9af18)]

### Version 0.35.3 - 07 July 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.13](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`0aa9eeec`](https://github.com/eea/helm-charts/commit/0aa9eeec0a1ef6630792585424f7794afc029678)]

### Version 0.35.1 - 21 June 2026
- 4.2.0 [Tiberiu Ichim - [`bab42148`](https://github.com/eea/helm-charts/commit/bab42148eb3c5c4c3a6a2c95b0cacca9882c3152)]

### Version 0.35.0 - 19 June 2026
- Automated release of [eeacms/cca-frontend:4.1.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`512581b7`](https://github.com/eea/helm-charts/commit/512581b787f57828d0b5f3249172eec135f6550e)]

### Version 0.34.0 - 12 June 2026
- Automated release of [eeacms/cca-frontend:4.0.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`072ee033`](https://github.com/eea/helm-charts/commit/072ee0333ef1e4d96ad3292ec00a61566e07390e)]

### Version 0.33.6 - 08 June 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.11](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`0a846f65`](https://github.com/eea/helm-charts/commit/0a846f65446d5c02af3f1d1c9a8fac2344b76d9b)]

### Version 0.33.5 - 08 June 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.10](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`322411d6`](https://github.com/eea/helm-charts/commit/322411d66f88380396947622a120c03221ea1160)]

### Version 0.33.4 - 08 June 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.9](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`02d19013`](https://github.com/eea/helm-charts/commit/02d19013871fdc4adcd103fb8d51a792ad536741)]

### Version 0.33.3 - 04 June 2026
- fix __admin [Dobricean Ioan Dorian - [`70e2eb43`](https://github.com/eea/helm-charts/commit/70e2eb43d88ee1bf621135dccf03a15dd7723cd0)]

### Version 0.33.2 - 04 June 2026
- modify nginx configmap [Dobricean Ioan Dorian - [`cba65ccb`](https://github.com/eea/helm-charts/commit/cba65ccbc1b365da12a720aebdfd482791348b3f)]

### Version 0.33.0 - 03 June 2026
- Automated release of [eeacms/cca-frontend:3.62.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`59e6d96b`](https://github.com/eea/helm-charts/commit/59e6d96b8d1aa67ae9041e19b2470bcc0dedc8d4)]

### Version 0.32.1 - 03 June 2026
- Update nginx to latest - Refs [#304237](https://taskman.eionet.europa.eu/issues/304237) [valentinab25 - [`ead8e19b`](https://github.com/eea/helm-charts/commit/ead8e19b8058e4d56e74c225bb769466b0988389)]

### Version 0.32.0 - 27 May 2026
- Upgrade to 3.61.0 [Tiberiu Ichim - [`9f3a9d44`](https://github.com/eea/helm-charts/commit/9f3a9d44a2dffc49c908f3aa0040caf1a329a538)]

### Version 0.31.0 - 26 May 2026
- Release 3.36.0 frontend [Tiberiu Ichim - [`bb7776fe`](https://github.com/eea/helm-charts/commit/bb7776fe432f133993a85ab40d578b70b6006e4e)]

### Version 0.30.0 - 25 May 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.8](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`fd3a1532`](https://github.com/eea/helm-charts/commit/fd3a1532be022072ecab6aa21697e55706a37b17)]

### Version 0.29.0 - 25 May 2026
- Snapshot for upgrade to Rancher 2 [Tiberiu Ichim - [`1d8ab0d9`](https://github.com/eea/helm-charts/commit/1d8ab0d90007ad899655e6400164d3c04de74fe3)]

### Version 0.27.0 - 25 May 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.7](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`2c4a5bb3`](https://github.com/eea/helm-charts/commit/2c4a5bb3b751d9e2f242d5b173b65212572f18ce)]

### Version 0.26.0 - 20 May 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.5](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`5bc92fd8`](https://github.com/eea/helm-charts/commit/5bc92fd83445160c8f6cb8c4ffb8cc5b01c7750c)]

### Version 0.25.0 - 20 May 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.2](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`1cf2b27e`](https://github.com/eea/helm-charts/commit/1cf2b27e520c6cbbd1ac30d041c24624302be666)]

### Version 0.24.0 - 19 May 2026
- Automated release of [eeacms/cca-frontend:4.0.0-alpha.1](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`a1bb0887`](https://github.com/eea/helm-charts/commit/a1bb0887c60e0c32dc2bf89b6f6d285d0e058bb9)]

### Version 0.23.0 - 12 May 2026
- Automated release of [eeacms/cca-frontend:3.58.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`2fe3079c`](https://github.com/eea/helm-charts/commit/2fe3079c535fb08df1ab6715ceea9a300270d8ba)]

### Version 0.22.0 - 11 May 2026
- Automated release of [eeacms/cca-frontend:3.57.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`f10283b0`](https://github.com/eea/helm-charts/commit/f10283b0598ff03ee44b3f9c3b430b6911b3575a)]

### Version 0.21.0 - 08 May 2026
- Automated release of [eeacms/cca-frontend:3.56.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`0c36a630`](https://github.com/eea/helm-charts/commit/0c36a63040ef38cb3716d3550bf3fede427e0c05)]

### Version 0.20.0 - 07 May 2026
- Automated release of [eeacms/cca-frontend:3.55.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`988d64e9`](https://github.com/eea/helm-charts/commit/988d64e906de9b62de4cc1455e9f5a5fdf2380fc)]

### Version 0.19.0 - 30 April 2026
- Automated release of [eeacms/cca-frontend:3.54.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`3177db98`](https://github.com/eea/helm-charts/commit/3177db984eac90350b2ed35962e83cadcafd2b1e)]

### Version 0.18.0 - 30 April 2026
- Automated release of [eeacms/cca-frontend:3.53.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`56951015`](https://github.com/eea/helm-charts/commit/56951015951df90fdea0679939c329f9a2cb78be)]

### Version 0.17.0 - 29 April 2026
- Automated release of [eeacms/cca-frontend:3.52.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`7e45e9fd`](https://github.com/eea/helm-charts/commit/7e45e9fd9d643c1cd15e2916accbef53e09a3e53)]

### Version 0.16.0 - 28 April 2026
- Automated release of [eeacms/cca-frontend:3.51.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`ecdea79e`](https://github.com/eea/helm-charts/commit/ecdea79ed8cee855be3c8ac27e9776c73dced910)]

### Version 0.15.0 - 27 April 2026
- Automated release of [eeacms/cca-frontend:3.50.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`3754bbb2`](https://github.com/eea/helm-charts/commit/3754bbb2f47a4791f2d5b7f62400c668fa38d7d3)]

### Version 0.14.0 - 27 April 2026
- Automated release of [eeacms/cca-frontend:3.49.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`05bcd0bc`](https://github.com/eea/helm-charts/commit/05bcd0bc8b223c199c990e59f522c9b60c02a2d8)]

### Version 0.13.0 - 21 April 2026
- Automated release of [eeacms/cca-frontend:3.48.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`ebaa9fbd`](https://github.com/eea/helm-charts/commit/ebaa9fbd6c4e3938f14e3856aec03d52e590c1f4)]

### Version 0.12.0 - 20 April 2026
- Automated release of [eeacms/cca-frontend:3.47.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`b39a0870`](https://github.com/eea/helm-charts/commit/b39a08709f57d4080c06ef444e486a9424c9c675)]

### Version 0.11.0 - 16 April 2026
- Automated release of [eeacms/cca-frontend:3.46.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`ec3a6ae7`](https://github.com/eea/helm-charts/commit/ec3a6ae75e1cbb7e13bd6be63b7121ad3429318e)]

### Version 0.10.0 - 14 April 2026
- Automated release of [eeacms/cca-frontend:3.45.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`c4c39c12`](https://github.com/eea/helm-charts/commit/c4c39c12dbd68583e533348fa7de79e3e78be034)]

### Version 0.9.0 - 09 April 2026
- Automated release of [eeacms/cca-frontend:3.44.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`68d85117`](https://github.com/eea/helm-charts/commit/68d8511770b730c6eb7001c3609cfb27b46896f1)]

### Version 0.8.0 - 08 April 2026
- Automated release of [eeacms/cca-frontend:3.43.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`14bff176`](https://github.com/eea/helm-charts/commit/14bff1764df18cf664319a210631c1774ace377d)]

### Version 0.7.2 - 02 April 2026
- remove hardcoded image [Dobricean Ioan Dorian - [`b1e0a605`](https://github.com/eea/helm-charts/commit/b1e0a605b45f58eca43afc5ffb672cb4fcdbb7a5)]

### Version 0.7.1 - 02 April 2026
- remove _admin [Dobricean Ioan Dorian - [`20e32b37`](https://github.com/eea/helm-charts/commit/20e32b37f611d5e8bf660480646aacacce0cdbae)]

### Version 0.7.0 - 01 April 2026
- Automated release of [eeacms/cca-frontend:3.42.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`24347710`](https://github.com/eea/helm-charts/commit/243477103b87f649fa7a9a3d392583927ee67b94)]

### Version 0.6.0 - 31 March 2026
- Automated release of [eeacms/cca-frontend:3.41.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`66329cf0`](https://github.com/eea/helm-charts/commit/66329cf05f665969da6469a9e5c8e6a953e0b56d)]

### Version 0.5.0 - 30 March 2026
- Automated release of [eeacms/cca-frontend:3.40.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`f7b88243`](https://github.com/eea/helm-charts/commit/f7b8824322eef89305589ee8ea1b04e72f37328b)]

### Version 0.4.13 - 27 March 2026
- add nginx in front [Dobricean Ioan Dorian - [`c97fca08`](https://github.com/eea/helm-charts/commit/c97fca08d500b2bf6782093fcba50227d5dff72e)]

### Version 0.4.8 - 27 March 2026
- fi ingress [Dobricean Ioan Dorian - [`24cad991`](https://github.com/eea/helm-charts/commit/24cad991e9a9765ebcc2b46c3275b79575b75022)]

### Version 0.4.6 - 27 March 2026
- fix backend issue [Dobricean Ioan Dorian - [`97379b14`](https://github.com/eea/helm-charts/commit/97379b149083429e93cedb0f3449adee8bcf6314)]

### Version 0.4.4 - 27 March 2026
- remove apache [Dobricean Ioan Dorian - [`e3b599bb`](https://github.com/eea/helm-charts/commit/e3b599bb2f46146f84e073e75738783ebdf0ca02)]

### Version 0.4.2 - 26 March 2026
- fix varnish deployment [Dobricean Ioan Dorian - [`58eaf33d`](https://github.com/eea/helm-charts/commit/58eaf33dc3155e1bf551d6445319f15b08004384)]

### Version 0.4.0 - 20 March 2026
- Automated release of [eeacms/cca-frontend:3.39.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`1754e657`](https://github.com/eea/helm-charts/commit/1754e657753cff7535e01434fc84d0ea44bdbcfc)]

### Version 0.3.0 - 19 March 2026
- Automated release of [eeacms/cca-frontend:3.38.0](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`7a746be9`](https://github.com/eea/helm-charts/commit/7a746be9d2abc1c516a7b03230628d9d9a778e9a)]

### Version 0.2.0 - 17 March 2026
- Automated release of [eeacms/cca-frontend:3.28.1-alpha.15](https://github.com/eea/cca-frontend/releases) [EEA Jenkins - [`d2eab61f`](https://github.com/eea/helm-charts/commit/d2eab61f74fba8f15e58f1ea4ce863f702a7130c)]

### Version 0.1.1 - 13 March 2026
- add questions [Dobricean Ioan Dorian - [`43f14405`](https://github.com/eea/helm-charts/commit/43f144055b47dddc298a8b8a5d0a15eda0dbce22)]

