## Releases

### Version 1.45.0 - 03 September 2026
- Automated release of [eeacms/clms-backend:6.0.15-165](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`79db8794`](https://github.com/eea/helm-charts/commit/79db8794446e869b769cbfbc10d59f7da7045664)]

### Version 1.44.0 - 11 August 2026
- Automated release of [eeacms/clms-backend:6.0.15-164](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`8b5e7d59`](https://github.com/eea/helm-charts/commit/8b5e7d593426935c631189061fddfd4614482722)]

### Version 1.43.0 - 10 August 2026
- Automated release of [eeacms/clms-backend:6.0.15-163](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`edd680e0`](https://github.com/eea/helm-charts/commit/edd680e09a2acfa46f57af76e68d036c752efd39)]

### Version 1.42.0 - 07 August 2026
- Automated release of [eeacms/clms-backend:6.0.15-162](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`1bb23f2b`](https://github.com/eea/helm-charts/commit/1bb23f2b7c9d3115c929c881e17b743c13db2edc)]

### Version 1.41.0 - 22 July 2026
- Automated release of [eeacms/clms-backend:6.0.15-161](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`8dadc1c0`](https://github.com/eea/helm-charts/commit/8dadc1c0d299b336d2cb86fc57547c764cee9a2a)]

### Version 1.40.0 - 22 July 2026
- Automated release of [eeacms/clms-backend:6.0.15-160](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`b13e5d5b`](https://github.com/eea/helm-charts/commit/b13e5d5b3038bd662137b456f34a76e6cd2cddf4)]

### Version 1.39.0 - 20 July 2026
- Automated release of [eeacms/clms-backend:6.0.15-159](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`8b8caed1`](https://github.com/eea/helm-charts/commit/8b8caed1fc63879d479fcb10f4c77944001d5269)]

### Version 1.38.0 - 27 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-157](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`1c491a1f`](https://github.com/eea/helm-charts/commit/1c491a1f837bc8e740276ac560695a335e734086)]

### Version 1.37.0 - 25 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-156](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`c87d5032`](https://github.com/eea/helm-charts/commit/c87d50327d1c9d90386b34083f8aead1eb259604)]

### Version 1.36.0 - 22 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-155](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`ec3eac86`](https://github.com/eea/helm-charts/commit/ec3eac8604f21c9c7683badc91080686d14721aa)]

### Version 1.35.0 - 19 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-154](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`38d486b0`](https://github.com/eea/helm-charts/commit/38d486b07a2c55af5abee9c2639835cc1c8dc31a)]

### Version 1.34.0 - 15 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-153](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`601ad7f9`](https://github.com/eea/helm-charts/commit/601ad7f92da4662561dc642445089f9e9eff5529)]

### Version 1.33.0 - 13 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-152](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`af30ba50`](https://github.com/eea/helm-charts/commit/af30ba50b4543093082c71c3eeae802f91109eb2)]

### Version 1.32.0 - 12 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-151](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`1a49c82b`](https://github.com/eea/helm-charts/commit/1a49c82b1d5fbb876bae4460ae02995443d61243)]

### Version 1.31.0 - 12 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-150](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`bbd630db`](https://github.com/eea/helm-charts/commit/bbd630dba438d109aa2046db5eb6112c9bc88e14)]

### Version 1.30.0 - 29 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-149](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`e1d8ad03`](https://github.com/eea/helm-charts/commit/e1d8ad03fb7b249b8ebe35cd95079249a98ce06c)]

### Version 1.29.0 - 22 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-148](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`6c622b70`](https://github.com/eea/helm-charts/commit/6c622b70c99fe5adec296db79378c1b38492a74c)]

### Version 1.28.0 - 20 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-147](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`acb26069`](https://github.com/eea/helm-charts/commit/acb26069c557496f088e9d95b8349fae5fa950e8)]

### Version 1.27.0 - 20 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-146](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`c72b46db`](https://github.com/eea/helm-charts/commit/c72b46db10922a73d120ef76646365e39852679d)]

### Version 1.26.0 - 17 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-145](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`ec71b640`](https://github.com/eea/helm-charts/commit/ec71b640499e1756ac105d7efbdc079087286e3a)]

### Version 1.25.0 - 17 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-144](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`089734c3`](https://github.com/eea/helm-charts/commit/089734c3f146b671392a0de1c8007aaad00926c5)]

### Version 1.24.0 - 16 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-143](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`07244b76`](https://github.com/eea/helm-charts/commit/07244b765dca3b39555f0847c91c4f6476aae03d)]

### Version 1.23.0 - 15 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-142](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`3af504af`](https://github.com/eea/helm-charts/commit/3af504af137b0486d8416036b33b459e84c74721)]

### Version 1.22.0 - 01 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-141](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`0bfe670f`](https://github.com/eea/helm-charts/commit/0bfe670fa7a24a8978474b869e6ab10943f6d6a2)]

### Version 1.21.0 - 30 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-139](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`1a768030`](https://github.com/eea/helm-charts/commit/1a768030153e372ed56314988d894b57da0fc625)]

### Version 1.20.0 - 26 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-138](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`00cc7b5a`](https://github.com/eea/helm-charts/commit/00cc7b5af590d872994a3999426a898872416a1e)]

### Version 1.19.0 - 25 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-137](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`6857c892`](https://github.com/eea/helm-charts/commit/6857c89290d10fef72ec7227718c0bb10d75ecbe)]

### Version 1.18.0 - 24 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-136](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`098e1e89`](https://github.com/eea/helm-charts/commit/098e1e8969eb78d9f1326d350b1bc71eeea6375c)]

### Version 1.17.0 - 18 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-134](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`479c4662`](https://github.com/eea/helm-charts/commit/479c4662155e170c82579d2a51c9b607b04920ab)]

### Version 1.16.0 - 17 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-133](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`66286eb0`](https://github.com/eea/helm-charts/commit/66286eb0a49ead168b1ccbe251732bbd18c819be)]

### Version 1.15.0 - 10 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-132](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`d5d049b9`](https://github.com/eea/helm-charts/commit/d5d049b931a24aaf9f0be33a1e75115dcdebfd7f)]

### Version 1.14.0 - 05 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-131](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`45a5ed2e`](https://github.com/eea/helm-charts/commit/45a5ed2ed68e9fb940ba905dd55f4c1745d5e087)]

### Version 1.13.0 - 02 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-130](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`b5ff6c4c`](https://github.com/eea/helm-charts/commit/b5ff6c4cc3fedac6efbf1de1612fbaff2a19d4a6)]

### Version 1.12.0 - 27 February 2026
- Automated release of [eeacms/clms-backend:6.0.15-129](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`cf9f84e7`](https://github.com/eea/helm-charts/commit/cf9f84e74d2b08cd2630502e05ac4b32e1bd3c84)]

### Version 1.11.0 - 19 February 2026
- Automated release of [eeacms/clms-backend:6.0.15-128](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`9a85ebab`](https://github.com/eea/helm-charts/commit/9a85ebabf87dc018aab7106c2109e3dfb92db00d)]

### Version 1.10.0 - 18 February 2026
- Automated release of [eeacms/clms-backend:6.0.15-127](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`efd0e283`](https://github.com/eea/helm-charts/commit/efd0e283a645f016f60f6eb2676b3323135b806c)]

### Version 1.9.0 - 11 February 2026
- Automated release of [eeacms/clms-backend:6.0.15-126](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`e47f14db`](https://github.com/eea/helm-charts/commit/e47f14dba4aba2214f5a77c43926e0896e3f04af)]

### Version 1.8.0 - 10 February 2026
- Automated release of [eeacms/clms-backend:6.0.15-125](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`c364bad0`](https://github.com/eea/helm-charts/commit/c364bad0bdd2f6485f3f7b7fa63b189ad60e1535)]

### Version 1.7.0 - 27 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-124](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`f394fe6d`](https://github.com/eea/helm-charts/commit/f394fe6dda287335e25a266e2c8d0600a60c9e87)]

### Version 1.6.0 - 21 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-123](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`60d4b704`](https://github.com/eea/helm-charts/commit/60d4b70477ad87feffdab0b0079401473e0e0862)]

### Version 1.5.0 - 20 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-122](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`50c8686e`](https://github.com/eea/helm-charts/commit/50c8686e9e0bbc1181e41117c76a939c02e89d67)]

### Version 1.4.0 - 20 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-121](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`4323be7b`](https://github.com/eea/helm-charts/commit/4323be7b47287e276588526dad8942c9664a4f03)]

### Version 1.3.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`753769af`](https://github.com/eea/helm-charts/commit/753769af9d029773c34705f36d8661634b55f86c)]

### Version 1.3.0 - 19 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-120](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`5a4dccf9`](https://github.com/eea/helm-charts/commit/5a4dccf97e10b850fa49c8db0259cd86f9cc3b0d)]

### Version 1.2.0 - 19 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-119](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`7858606e`](https://github.com/eea/helm-charts/commit/7858606e5ebee57d7f76850c7e6ec2e208b112d3)]

### Version 1.1.0 - 16 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-118](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`dfc234fe`](https://github.com/eea/helm-charts/commit/dfc234fe8cfd30b79bdd22003ae6edcc1be75f2f)]

### Version 1.0.3 - 09 January 2026
- fix ingres [Dobricean Ioan Dorian - [`de011fd2`](https://github.com/eea/helm-charts/commit/de011fd2bd30f55d3f8eced2d733538891645727)]

### Version 1.0.2 - 09 January 2026
- fix ingress api [Dobricean Ioan Dorian - [`132dab89`](https://github.com/eea/helm-charts/commit/132dab8925813bd4df09c9c60e016d6af038f7df)]

### Version 1.0.1 - 09 January 2026
- fix version [Dobricean Ioan Dorian - [`3b03a524`](https://github.com/eea/helm-charts/commit/3b03a524826a510210466d021e78fd47a96c0399)]

