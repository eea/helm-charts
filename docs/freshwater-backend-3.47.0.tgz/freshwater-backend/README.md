# Wise Freshwater backend - Plone 6

## Releases

### Version 3.47.0 - 20 August 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-49](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`11363bb6`](https://github.com/eea/helm-charts/commit/11363bb6865c8da95aa82eda233e0885d44de5f5)]

### Version 3.46.0 - 19 August 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-48](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`d28e94fe`](https://github.com/eea/helm-charts/commit/d28e94fe53d0f5d9f6b9a4c04934e0d0f1003355)]

### Version 3.45.0 - 09 August 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-47](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`cfed5288`](https://github.com/eea/helm-charts/commit/cfed528832a012983a821603d58a1a00e05929f0)]

### Version 3.44.0 - 07 August 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-46](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`6066b79c`](https://github.com/eea/helm-charts/commit/6066b79c99ed88c8b44a091d113bd0f1e2f2848a)]

### Version 3.43.0 - 06 August 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-45](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`fbef4d05`](https://github.com/eea/helm-charts/commit/fbef4d05333b48216380542cb56fe39dc486b1b9)]

### Version 3.42.0 - 30 July 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-44](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`208c37fd`](https://github.com/eea/helm-charts/commit/208c37fd035b7524001a3a4e80628cba45d4c367)]

### Version 3.41.0 - 15 July 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-43](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`1f4ee985`](https://github.com/eea/helm-charts/commit/1f4ee9855698440580caa4e680ba1980d5e264a4)]

### Version 3.40.0 - 14 July 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-42](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`9181a14e`](https://github.com/eea/helm-charts/commit/9181a14e6584c68278ba6110e3ce36fc713c8708)]

### Version 3.39.0 - 12 July 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-41](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`e0c6ee21`](https://github.com/eea/helm-charts/commit/e0c6ee21e763bdd256e3f860dc8b9fac1a64ed9d)]

### Version 3.38.0 - 10 July 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-40](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`a298666f`](https://github.com/eea/helm-charts/commit/a298666f178675917e4db2fd1aa9ff62e2b39a39)]

### Version 3.37.2 - 10 July 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-39.beta.05](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`4d0d2451`](https://github.com/eea/helm-charts/commit/4d0d2451a64022873f75473c3916d2d387e8e8e5)]

### Version 3.37.1 - 10 July 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-39.beta.02](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`31a5655b`](https://github.com/eea/helm-charts/commit/31a5655bef717abb82b982f86f88bceadd5a925a)]

### Version 3.37.0 - 07 July 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-38](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`070add96`](https://github.com/eea/helm-charts/commit/070add962c7ff2992a9cfe6cd8a80d58708e3908)]

### Version 3.36.0 - 06 July 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-37](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`c826d3b7`](https://github.com/eea/helm-charts/commit/c826d3b74c9d35cb680d66bb0bb266a162c854c7)]

### Version 3.35.0 - 26 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-35](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`6c1e018c`](https://github.com/eea/helm-charts/commit/6c1e018c4aa3f9b4bf29e2717ffe6ef064824e95)]

### Version 3.34.0 - 23 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-34](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`5e89f49e`](https://github.com/eea/helm-charts/commit/5e89f49e89f4ff293dedcf70f291ca376801da63)]

### Version 3.33.0 - 23 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-33](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`b1eae9c3`](https://github.com/eea/helm-charts/commit/b1eae9c329b694e759aa229e7e3a2bc7af4e44e2)]

### Version 3.32.0 - 22 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-32](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`e879187a`](https://github.com/eea/helm-charts/commit/e879187aab87d01a3bcf4e3a4ee79fe4a3001d1e)]

### Version 3.31.0 - 21 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-31](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`4f9acafa`](https://github.com/eea/helm-charts/commit/4f9acafaf70a0c4991674c5c82a920b1eec586fd)]

### Version 3.30.0 - 19 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-30](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`e832a841`](https://github.com/eea/helm-charts/commit/e832a8417776afb1e89a95f358132cb096623575)]

### Version 3.29.0 - 19 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-29](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`b11b5c26`](https://github.com/eea/helm-charts/commit/b11b5c269fcc09140e3c2f011eea19db280dfa34)]

### Version 3.28.0 - 18 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-28](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`b67bfdb3`](https://github.com/eea/helm-charts/commit/b67bfdb30c6705df88b55bf4bd8aed7eda679e46)]

### Version 3.27.0 - 17 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-24](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`1d63bb4e`](https://github.com/eea/helm-charts/commit/1d63bb4e3b46e17a3c2e4e69b1a80c4beaa334bd)]

### Version 3.26.1 - 16 June 2026
- increase cpu for cronjobs [Dobricean Ioan Dorian - [`0dfd4119`](https://github.com/eea/helm-charts/commit/0dfd41192dceac6eca6993f873256d134ae974d1)]

### Version 3.26.0 - 12 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-23](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`3744d348`](https://github.com/eea/helm-charts/commit/3744d34852cac5dc5192a1a9c9db0566350ccaaa)]

### Version 3.25.0 - 11 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-22](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`00b6c351`](https://github.com/eea/helm-charts/commit/00b6c35166de7edca695fa062ad1c63cba7f0a65)]

### Version 3.24.0 - 10 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-21](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`b38a866d`](https://github.com/eea/helm-charts/commit/b38a866d45d1d0adef0a1d1398c7fc293204c00c)]

### Version 3.23.0 - 08 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-19](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`8fb2694d`](https://github.com/eea/helm-charts/commit/8fb2694d2f064b7a4ad0ae1db655aeb5f12975b8)]

### Version 3.22.0 - 07 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-18](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`6206bfd1`](https://github.com/eea/helm-charts/commit/6206bfd1edabc40638f656997f884f23e6c87d6d)]

### Version 3.21.0 - 06 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-17](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`795f455e`](https://github.com/eea/helm-charts/commit/795f455e598710c6631e90f874af33304855d488)]

### Version 3.20.0 - 05 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-16](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`6fa88840`](https://github.com/eea/helm-charts/commit/6fa888409408e96a50834a1f5037801e127d9f1e)]

### Version 3.19.0 - 04 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-15](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`4cc7785a`](https://github.com/eea/helm-charts/commit/4cc7785afc04fb93162f7e0c96494ec3fca89345)]

### Version 3.18.0 - 03 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-14](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`08441417`](https://github.com/eea/helm-charts/commit/084414179a6f105185a8fcd9092ee3b9129f89eb)]

### Version 3.17.0 - 02 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-13](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`29be9c2d`](https://github.com/eea/helm-charts/commit/29be9c2d9b06f5282eae705510d107efabf7a20e)]

### Version 3.16.0 - 01 June 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-12](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`bc990cba`](https://github.com/eea/helm-charts/commit/bc990cba9c2e17a7a9c20a83f303570249fddf8f)]

### Version 3.15.0 - 31 May 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-11](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`4ba05267`](https://github.com/eea/helm-charts/commit/4ba0526725b3be2c35b2ea857ea290962b7188de)]

### Version 3.14.0 - 30 May 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-10](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`3a7aab0f`](https://github.com/eea/helm-charts/commit/3a7aab0f6833c90ccb21b7e16dc21b444403a29d)]

### Version 3.13.0 - 29 May 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-9](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`81816d68`](https://github.com/eea/helm-charts/commit/81816d680433c16c444b90df649974572c67efb4)]

### Version 3.12.0 - 28 May 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-8](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`298f97b9`](https://github.com/eea/helm-charts/commit/298f97b9e01c9c3c28eab15c29ee2bc007068d74)]

### Version 3.11.2 - 28 May 2026
- bump [Dobricean Ioan Dorian - [`a2612e17`](https://github.com/eea/helm-charts/commit/a2612e17152aa00904f4367ee5d5f675fc4146af)]

### Version 3.11.0 - 25 May 2026
- Automated release of [eeacms/freshwater-backend:6.2.0-1](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`7657dcf9`](https://github.com/eea/helm-charts/commit/7657dcf947ceb5bbf515d3f7d8761035a39cf2ca)]

### Version 3.10.0 - 08 May 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-3](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`38bc38bb`](https://github.com/eea/helm-charts/commit/38bc38bbda731d9dda09a644a45f73b5551b496f)]

### Version 3.9.0 - 29 April 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-2](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`9e5bc26e`](https://github.com/eea/helm-charts/commit/9e5bc26e44a587c334c224a2557defbc7af410dd)]

### Version 3.8.0 - 29 April 2026
- Automated release of [eeacms/freshwater-backend:6.1.4-1](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`a39217e4`](https://github.com/eea/helm-charts/commit/a39217e4bd0326d4bb36e5da81d60f4642157532)]

### Version 3.7.0 - 22 April 2026
- Automated release of [eeacms/freshwater-backend:6.1.3-22](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`e083cef5`](https://github.com/eea/helm-charts/commit/e083cef577126f474d4869ad37aa28b6bf1c3063)]

### Version 3.6.0 - 17 April 2026
- Automated release of [eeacms/freshwater-backend:6.1.3-20](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`21ed6eaa`](https://github.com/eea/helm-charts/commit/21ed6eaadcc8b64e80ad17684b1d7538901df1f5)]

### Version 3.5.0 - 16 April 2026
- Automated release of [eeacms/freshwater-backend:6.1.3-19](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`5b5b0524`](https://github.com/eea/helm-charts/commit/5b5b05240f2fa2ecad47268d1db16b5eb4f31180)]

### Version 3.4.0 - 15 April 2026
- Automated release of [eeacms/freshwater-backend:6.1.3-18](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`ac5f3c34`](https://github.com/eea/helm-charts/commit/ac5f3c344320ad93e63b07e80af3e8ed5145d212)]

### Version 3.3.2 - 07 March 2026
- add missing variables [Dobricean Ioan Dorian - [`e84a36e4`](https://github.com/eea/helm-charts/commit/e84a36e4616471dc2d259c05053262e821a725df)]

### Version 3.3.1 - 07 March 2026
- add postgres services [Dobricean Ioan Dorian - [`9e066d11`](https://github.com/eea/helm-charts/commit/9e066d1120c14b4d2ec7fbbd35f24385ea053463)]

### Version 3.3.0 - 07 March 2026
- Automated release of [eeacms/freshwater-backend:6.1.3-16](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`8e49fbf3`](https://github.com/eea/helm-charts/commit/8e49fbf3a80abcbd14a41bed2b8e7ef814a1f5ec)]

### Version 3.2.0 - 05 March 2026
- Automated release of [eeacms/freshwater-backend:6.1.3-15](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`acf16479`](https://github.com/eea/helm-charts/commit/acf164799642082c31c59281c1203e332966bc1f)]

### Version 3.1.0 - 02 March 2026
- Automated release of [eeacms/freshwater-backend:6.1.3-14](https://github.com/eea/freshwater-backend/releases) [EEA Jenkins - [`a46d4865`](https://github.com/eea/helm-charts/commit/a46d486566ecab734816706220648a926fe311d8)]

### Version 3.0.4 - 10 February 2026
- change image backend [Dobricean Ioan Dorian - [`7ef73cb6`](https://github.com/eea/helm-charts/commit/7ef73cb65a1912365ab03d1bd38c802789f97baf)]

### Version 3.0.3 - 09 February 2026
- fix ingress [Dobricean Ioan Dorian - [`4ff47e7f`](https://github.com/eea/helm-charts/commit/4ff47e7f416effc96607f6ca095face1afc09367)]

### Version 3.0.1 - 09 February 2026
- fix version image [Dobricean Ioan Dorian - [`a1df35dd`](https://github.com/eea/helm-charts/commit/a1df35dda2754faa1eb9067d3a94aa156afefb5a)]

### Version 3.0.0 - 09 February 2026
- fix freshwater backend [Dobricean Ioan Dorian - [`2cf9f47c`](https://github.com/eea/helm-charts/commit/2cf9f47c70f1da444cb24193f06c6b11269b4673)]

### Version 2.0.0 - 09 February 2026
- fix [Dobricean Ioan Dorian - [`309059a9`](https://github.com/eea/helm-charts/commit/309059a91e02f4480e7687c5b814f3eef1a395d1)]

### Version 1.0.2 - 09 February 2026
- fix memcached [Dobricean Ioan Dorian - [`f3e6eca8`](https://github.com/eea/helm-charts/commit/f3e6eca8bc5109e74c9b9796002d64083683876d)]

### Version 1.0.0

- Initial release based on marine-backend chart
