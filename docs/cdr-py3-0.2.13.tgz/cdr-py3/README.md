# Reportnet CDR on python 3

The Central Data Repository is part of the Reportnet architecture. The Central Data Repository is like a bookshelf, with data reports on the environment as submitted to international clients.

This chart is almost configured for production use.

## Network Security Policies

This Helm chart deploys Kubernetes Network Policies to enhance the security of the CDR application. If `defaultNetworkPolicyDeny` is enabled, these policies enforce a **whitelist** approach, meaning that network traffic is only allowed if explicitly permitted.

**Key Network Policy Configurations:**

*   **Instance Pod Egress (`instance.networkPolicy.egress` in `values.yaml`):**  Configures outbound traffic from the `cdr-instance` pods. You can configure egress rules in two ways:

    1. Using `ipBlockRules`: Define IP-based rules with specific ports for each CIDR block:
    ```yaml
    instance:
      networkPolicy:
        egress:
          ipBlockRules:
            - cidr: 10.50.4.0/24  # Legacy service network
              ports:
                - protocol: TCP
                  port: 443     # HTTPS
                - protocol: TCP
                  port: 80      # HTTP
            - cidr: 10.50.5.0/24  # Another network
              ports:
                - protocol: TCP
                  port: 5432    # PostgreSQL
    ```

    2. Using `rawRules`: For more complex scenarios, define individual egress rules using the full power of Kubernetes NetworkPolicy `to` specifications:
    ```yaml
    instance:
      networkPolicy:
        egress:
          rawRules:
            - to:
                - namespaceSelector:
                    matchLabels:
                      kubernetes.io/metadata.name: other-namespace
                  podSelector:
                    matchLabels:
                      app.kubernetes.io/name: service-name
              ports:
                - port: 8080
                  protocol: TCP
    ```

    You can use `rawRules` to define:
    *   **IP Block Rules:** Target egress traffic to specific IP address ranges
    *   **Namespace Selector Rules:** Target pods in other namespaces based on namespace labels and pod labels
    *   **Pod Selector Rules:** Target pods within the same namespace based on pod labels
    *   **Service Account Selector Rules (Advanced):** Target pods based on their service accounts


*   **Varnish Pod Network Policy (`varnish.networkPolicy` in `values.yaml`):** Defines additional ingress and egress rules for the `cdr-varnish` pods.  You can use `varnish.networkPolicy.additionalIngress` and `varnish.networkPolicy.additionalEgress` in `values.yaml` to add custom rules on top of the base policy defined in the templates.

*   **Default Deny Policies:** The chart includes deny Network Policies (`netsecpol-ingress-default.yaml` and `netsecpol-egress-default.yaml`) that, when enabled with `defaultNetworkPolicyDeny.enabled: true`, block all ingress and egress traffic unless overridden by more specific policies. This ensures a secure starting point and encourages explicit definition of allowed traffic.

    Under default-deny, the chart auto-deploys ingress allows for the in-cluster `valkey` and `memcached` pods (when enabled), permitting traffic from any pod in the same release — no extra rules needed.

**Modifying Network Policies:**

To customize the network policies, you should modify the `instance.networkPolicy.egress` and `varnish.networkPolicy` sections within your `values.yaml` file.  Refer to the Kubernetes Network Policy documentation for details on how to define rules using `ipBlock`, `namespaceSelector`, `podSelector`, ports, and protocols.

## Shared Blob Storage

By default, every Zope instance pod streams blobs over the ZEO wire and caches
them locally in a per-pod `emptyDir` (`instance.env.blobStorageCacheVolumeEnabled`).
For deployments where the cluster has a `ReadWriteMany` storage class available
(e.g. `nfs-client` via `nfs-subdir-external-provisioner`), the chart can instead
have the **ZEO server's own PVC** be `ReadWriteMany` and have every instance
pod mount that same PVC at `/opt/zope/var/blobstorage` (subPath: `blobstorage`).
The base image's entrypoint sets `shared-blob-dir on` in `zodb.conf` so Zope
clients read blobs directly off the shared filesystem instead of streaming.


### Values

```yaml
zeoserver:
  accessMode: ReadWriteMany              # default ReadWriteOnce; must be RWX

instance:
  env:
    zeoSharedBlobDir: "on"               # default "off"
    blobStorageCacheVolumeEnabled: false # mutually exclusive with shared mode
```

Constraints (enforced via `helm template`-time fail-fast):

- `instance.env.zeoSharedBlobDir: on` requires `zeoserver.accessMode: ReadWriteMany`.
- `instance.env.zeoSharedBlobDir: on` requires `instance.env.blobStorageCacheVolumeEnabled: false`.
- `instance.env.zeoSharedBlobDir: on` requires `zeoserver.zeoUid: 1000` and
  `zeoserver.zeoGid: 1000` (the instance pod's hardcoded UID). The ZEO server
  and instance pods share the same filesystem, so their UIDs must match.

When `zeoSharedBlobDir: on`, the instance Deployment mounts the StatefulSet's
PVC by computed name: `<zeoserver.storageName>-<Release.Name>-zeoserver-0`.

### Enabling on a fresh deployment

If you're deploying for the first time:

1. Set the values above before the first `helm install`.
2. Make sure your storage class supports `ReadWriteMany` (the chart only
   declares the access mode; the cluster must back it).


## LDAP cache (memcached)

The Zope instances use memcached as a backend cache for LDAP lookups via the
`LDAP_MEMCACHED_SERVERS` env var (comma-separated `host:port`). To deploy an
in-cluster memcached and wire it up:

```yaml
memcached:
  enabled: true                          # deploys memcached + Service on TCP/11211

instance:
  env:
    ldapMemcachedServers: "cdr-py3-memcached:11211"
```

When `ldapMemcachedServers` is empty the env var is omitted entirely.

## Releases

### Version 0.2.13 - 13 November 2026
- Automated release of [eeacms/reportek-cdr:6.3-7](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`bd44f6de8`](https://github.com/eea/helm-charts/commit/bd44f6de809e3a1a4c68d1432a56de4d0658f8fe)]

### Version 0.2.12 - 12 November 2026
- Release of dependent chart rn-varnish:0.9.0 [EEA Jenkins - [`ec737ccee`](https://github.com/eea/helm-charts/commit/ec737cceeba67cc2cd74592047ac554439547029)]

### Version 0.2.11 - 11 November 2026
- Automated release of [eeacms/reportek-cdr:6.3-6](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`ba8052fcb`](https://github.com/eea/helm-charts/commit/ba8052fcb6e0878313553bdf540518a8561cc732)]

### Version 0.2.10 - 11 November 2026
- Updated varnish healthcheck [Olimpiu Rob - [`2d5db19dc`](https://github.com/eea/helm-charts/commit/2d5db19dc0e36eef8c309141087a8576a5e0bfdf)]

### Version 0.2.9 - 11 November 2026
- Release of dependent chart rn-varnish:0.8.0 [EEA Jenkins - [`4d0bd4923`](https://github.com/eea/helm-charts/commit/4d0bd4923bdf8a37dab3dfc05ef5bdb6410ed237)]

### Version 0.2.8 - 11 November 2026
- Added zodbCacheSize, zodbCacheSizeBytes and zopeSecurityPolicy envs [Olimpiu Rob - [`49c0dabb1`](https://github.com/eea/helm-charts/commit/49c0dabb1b29b04bbd8874fc03fefc1f7c2f9c7a)]

### Version 0.2.7 - 11 November 2026
- Automated release of [eeacms/reportek-cdr:6.3-5](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`57487a05b`](https://github.com/eea/helm-charts/commit/57487a05bf2df681c369fe4e39692d33c5c4b5c8)]

### Version 0.2.6 - 10 November 2026
- Release of dependent chart rn-varnish:0.7.0 [EEA Jenkins - [`1c7eb6c5b`](https://github.com/eea/helm-charts/commit/1c7eb6c5bc9b51066c4e4fab640ad94ef540dbcc)]

### Version 0.2.5 - 06 November 2026
- Automated release of [eeacms/reportek-cdr:6.3-4](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`d64b5e0c4`](https://github.com/eea/helm-charts/commit/d64b5e0c499371e197ea306898a8c41e4b0185fc)]

### Version 0.2.4 - 04 November 2026
- Automated release of [eeacms/reportek-cdr:6.3-3](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`50c6c440b`](https://github.com/eea/helm-charts/commit/50c6c440b2310c16246175a6ca05d9baa3d961b6)]

### Version 0.2.3 - 04 November 2026
- Automated release of [eeacms/reportek-cdr:6.3-2](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`b4393bc98`](https://github.com/eea/helm-charts/commit/b4393bc9828cf4fcdaadb94b5d31792b08b7c18c)]

### Version 0.2.2 - 03 November 2026
- Fallback to default zeoserver image tag in cronzeopack if not overriden [Olimpiu Rob - [`7f8263ba0`](https://github.com/eea/helm-charts/commit/7f8263ba099a19170310fe2abc77729569849fb2)]

### Version 0.2.1 - 03 November 2026
- Removed tag from zeoserver in values [Olimpiu Rob - [`acf59653c`](https://github.com/eea/helm-charts/commit/acf59653c68bf6cca932b7be6f2c7cff01a1fbf4)]

### Version 0.2.0 - 03 November 2026
- Updated rn-zeoserver to 0.3.0 [Olimpiu Rob - [`21474285c`](https://github.com/eea/helm-charts/commit/21474285c40613b1d166d4297c0f64ef714745d4)]

### Version 0.1.59 - 03 November 2026
- Automated release of [eeacms/reportek-cdr:6.3-1](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`44d6c66da`](https://github.com/eea/helm-charts/commit/44d6c66da44109392ebfdef3bf285b7161f0ea6b)]

### Version 0.1.58 - 02 November 2026
- Automated release of [eeacms/reportek-cdr:5.14-11](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`6dd17b033`](https://github.com/eea/helm-charts/commit/6dd17b033661a358ce593d8d371b1db76b10d2de)]

### Version 0.1.57 - 30 October 2026
- Automated release of [eeacms/reportek-cdr:5.14-10](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`fc1c3d875`](https://github.com/eea/helm-charts/commit/fc1c3d875de181aeb2205437241216b2dafcdc45)]

### Version 0.1.56 - 30 October 2026
- Automated release of [eeacms/reportek-cdr:5.14-9](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`43fab21ca`](https://github.com/eea/helm-charts/commit/43fab21ca726088e8b49ec338320de988d04ac5b)]

### Version 0.1.55 - 30 October 2026
- Automated release of [eeacms/reportek-cdr:5.14-8](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`54e93ec18`](https://github.com/eea/helm-charts/commit/54e93ec18176d683fa723b68698bee6572196b94)]

### Version 0.1.54 - 29 October 2026
- Automated release of [eeacms/reportek-cdr:5.14-7](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`e7533045d`](https://github.com/eea/helm-charts/commit/e7533045dbc931039749f1740c75ab3984dc3d7e)]

### Version 0.1.53 - 29 October 2026
- Automated release of [eeacms/reportek-cdr:5.14-6](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`069708be8`](https://github.com/eea/helm-charts/commit/069708be803624c97742eb00c21cb15034012aab)]

### Version 0.1.52 - 28 October 2026
- Automated release of [eeacms/reportek-cdr:5.14-5](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`1b5544652`](https://github.com/eea/helm-charts/commit/1b554465267011034b708f6f26cbd01bab651705)]

### Version 0.1.51 - 28 October 2026
- Updated appVersion to 5.14-4 [Olimpiu Rob - [`c3c1777ad`](https://github.com/eea/helm-charts/commit/c3c1777ad566e85bc2ec013fe3e794957e31a9f6)]

### Version 0.1.50 - 01 October 2026
- Updated appVersion to z5-1.48 [Olimpiu Rob - [`e639e020`](https://github.com/eea/helm-charts/commit/e639e020b42eb635bdd13381f1b9be434ef77396)]

### Version 0.1.49 - 30 September 2026
- Updated appVersion to z5-1.47 [Olimpiu Rob - [`bfc3174e`](https://github.com/eea/helm-charts/commit/bfc3174e57a319fb93fad708a0781584ca855054)]

### Version 0.1.48 - 29 September 2026
- Updated appVersion to z5-1.46 [Olimpiu Rob - [`d95cbb4f`](https://github.com/eea/helm-charts/commit/d95cbb4f12467f5f989a00c8616d386f7227b387)]

### Version 0.1.47 - 28 September 2026
- Updated appVersion to z5-1.45 [Olimpiu Rob - [`356786d9`](https://github.com/eea/helm-charts/commit/356786d94643908275ff2807daf5db089d6deb0b)]

### Version 0.1.46 - 25 September 2026
- Updated appVersion to z5-1.44 [Olimpiu Rob - [`4d402052`](https://github.com/eea/helm-charts/commit/4d40205288c1dfd767ecb19fb5e4da6c0bb45f0f)]

### Version 0.1.45 - 24 September 2026
- Updated appVersion to z5-1.43 [Olimpiu Rob - [`55f2a0c9`](https://github.com/eea/helm-charts/commit/55f2a0c96432979b7e2ea278ec1c08fcfc6b33ce)]

### Version 0.1.44 - 24 September 2026
- Updated appVersion to z5-1.42 [Olimpiu Rob - [`b04e2cd0`](https://github.com/eea/helm-charts/commit/b04e2cd05132c453855b5e6d74c66754dd9acfe6)]

### Version 0.1.43 - 21 September 2026
- Updated appVersion to z5-1.41 [Olimpiu Rob - [`c0fbdc98`](https://github.com/eea/helm-charts/commit/c0fbdc986b02a52943d87d686208f0ec92f4a2e0)]

### Version 0.1.42 - 18 September 2026
- Updated appVersion to z5-1.40 [Olimpiu Rob - [`6ff8f87b`](https://github.com/eea/helm-charts/commit/6ff8f87b6784838755a5aac0e04b71a340dc4ff2)]

### Version 0.1.41 - 17 September 2026
- Updated appVersion to z5-1.39 [Olimpiu Rob - [`32eae07a`](https://github.com/eea/helm-charts/commit/32eae07a20f58e9556967977281845f51364de90)]

### Version 0.1.40 - 15 September 2026
- Updated appVersion to z5-1.38 [Olimpiu Rob - [`fde964a9`](https://github.com/eea/helm-charts/commit/fde964a9cc33e38d9bd095fee900068efc0f7c37)]

### Version 0.1.39 - 07 September 2026
- Updated appVersion to z5-1.37 [Olimpiu Rob - [`db86c194`](https://github.com/eea/helm-charts/commit/db86c1948ed6b95a8b5d93fe1b99f25e579d6433)]

### Version 0.1.38 - 04 September 2026
- Updated appVersion to z5-1.36 [Olimpiu Rob - [`29b93dd9`](https://github.com/eea/helm-charts/commit/29b93dd96471b5c987dee81ba06dc9707c6d1fda)]

### Version 0.1.37 - 27 August 2026
- Upgraded appVersion to z5-1.35 [Olimpiu Rob - [`ddcb4d8f`](https://github.com/eea/helm-charts/commit/ddcb4d8f85c7b1c28142e9d8db467b1a1ab27725)]

### Version 0.1.36 - 26 August 2026
- Updated appVersion to z5-1.34 [Olimpiu Rob - [`234aff58`](https://github.com/eea/helm-charts/commit/234aff58cb50091e2a866b3a4d6b2b1304a7c2af)]

### Version 0.1.35 - 26 August 2026
- Upgraded appVersion to z5-1.33 [Olimpiu Rob - [`1a5cc12a`](https://github.com/eea/helm-charts/commit/1a5cc12a2c6b9a18598cfc8d895927e546246e9e)]

### Version 0.1.34 - 12 August 2026
- Updated appVersion to z5-1.32 [Olimpiu Rob - [`60098004`](https://github.com/eea/helm-charts/commit/600980046f6fc689042df36ad975b5c725cca048)]

### Version 0.1.33 - 12 August 2026
- Updated appVersion to z5-1.31 [Olimpiu Rob - [`d42604c8`](https://github.com/eea/helm-charts/commit/d42604c868f4c98a64a97c0d34525c003d9035e3)]

### Version 0.1.32 - 28 July 2026
- Updated appVersion to z5-1.26 [Olimpiu Rob - [`a3799524`](https://github.com/eea/helm-charts/commit/a379952435963b0da36f8dc242932caae2dc4fd2)]

### Version 0.1.31 - 22 July 2026
- Renamed beakerSecret to sessionSecret, added session cookie opts [Olimpiu Rob - [`be765f99`](https://github.com/eea/helm-charts/commit/be765f993a7f14207c6c659701078e1d60caca68)]

### Version 0.1.30 - 16 July 2026
- Updated appVersion to z5-1.25 [Olimpiu Rob - [`e0621f0d`](https://github.com/eea/helm-charts/commit/e0621f0d4ade6d731e69dd0aeec16111776a9f7b)]

### Version 0.1.29 - 10 July 2026
- Added tolerations and affinity for webforms-proxy [Olimpiu Rob - [`0d6c8a5c`](https://github.com/eea/helm-charts/commit/0d6c8a5c89418a2c0a48b41afc3e43385c96e0af)]

### Version 0.1.28 - 08 July 2026
- Updated rn-varnish to 0.6.2 [Olimpiu Rob - [`82be4220`](https://github.com/eea/helm-charts/commit/82be42204846f6f0f66be85ad7642087278e69fb)]

### Version 0.1.27 - 06 July 2026
- Updated rn-varnish to 0.6.1 [Olimpiu Rob - [`e883c028`](https://github.com/eea/helm-charts/commit/e883c028dab1aa465c3397fe7165d6d9c835fd05)]

### Version 0.1.26 - 06 July 2026
- Release of dependent chart rn-varnish:0.6.0 [EEA Jenkins - [`d927293d`](https://github.com/eea/helm-charts/commit/d927293d402286823b59a4a4201e1993a5483299)]

### Version 0.1.25 - 04 July 2026
- Updated appVersion to z5-1.24 [Olimpiu Rob - [`e19049ff`](https://github.com/eea/helm-charts/commit/e19049ff2e6e3d4e6c3852ba27941f40d87fc8d4)]

### Version 0.1.24 - 01 July 2026
- Updated appVersion to z5-1.23 [Olimpiu Rob - [`4840372f`](https://github.com/eea/helm-charts/commit/4840372ffcbb1454bc12c4bd21351612b5cc0dbb)]

### Version 0.1.23 - 01 July 2026
- Updated appVersion to z5-1.22 [Olimpiu Rob - [`bf1e3b69`](https://github.com/eea/helm-charts/commit/bf1e3b69c1e7cf50f7c09428796b1fe17cfbc15e)]

### Version 0.1.22 - 26 June 2026
- Updated appVersion to z5-1.21 [Olimpiu Rob - [`9e39264a`](https://github.com/eea/helm-charts/commit/9e39264a4d7ff7439a019ecd81feaf7ad6c6f9c9)]

### Version 0.1.21 - 25 June 2026
- Bumped rn-local-converters to 0.1.13 [Olimpiu Rob - [`71311bb3`](https://github.com/eea/helm-charts/commit/71311bb313aee95191ac22bb95a5af493ce93fe6)]

### Version 0.1.20 - 25 June 2026
- Updated rn-local-converters to 0.1.12 [Olimpiu Rob - [`3bed6043`](https://github.com/eea/helm-charts/commit/3bed6043b95214aaf82ee33fce91b2d0c4db91a6)]

### Version 0.1.19 - 24 June 2026
- Bumped rn-local-converters to 0.1.11 [Olimpiu Rob - [`5c0c3e51`](https://github.com/eea/helm-charts/commit/5c0c3e519288b608406c0932fee05a62008fbf15)]

### Version 0.1.18 - 23 June 2026
- Updated rn-local-converters to 0.1.10 [Olimpiu Rob - [`904e77f8`](https://github.com/eea/helm-charts/commit/904e77f82a8bd80251d49d7c83cfee33fb07dafe)]

### Version 0.1.17 - 23 June 2026
- Updated rn-local-converters to 0.1.9 [Olimpiu Rob - [`2b27389e`](https://github.com/eea/helm-charts/commit/2b27389e7b0b17848b7d8ee36498755adfd70ef2)]

### Version 0.1.16 - 23 June 2026
- Updated rn-local-converters to 0.1.8 [Olimpiu Rob - [`96f83bf2`](https://github.com/eea/helm-charts/commit/96f83bf2144489932e087fd87019154cc19c7cf9)]

### Version 0.1.15 - 23 June 2026
- Updated rn-local-converters to 0.1.7 [Olimpiu Rob - [`45884344`](https://github.com/eea/helm-charts/commit/458843446f9398db1fdd308633d23d1f4bd5ba25)]

### Version 0.1.14 - 22 June 2026
- Updated appVersion to z5-1.19 [Olimpiu Rob - [`0e823bf0`](https://github.com/eea/helm-charts/commit/0e823bf0d7c959ff5b081a751ca66a74e091c6b2)]

### Version 0.1.13 - 20 June 2026
- Updated appVersion to z5-1.18 [Olimpiu Rob - [`974e7287`](https://github.com/eea/helm-charts/commit/974e72876896e37ba32eb8a7dd68ff4e60a4262f)]

### Version 0.1.12 - 15 June 2026
- Updated appVersion to z5-1.17 [Olimpiu Rob - [`9d7cb891`](https://github.com/eea/helm-charts/commit/9d7cb891cdcf13b31b35df759667c8efc7207280)]

### Version 0.1.11 - 12 June 2026
- Updated appVersion to z5-1.16 [Olimpiu Rob - [`0e13ba7a`](https://github.com/eea/helm-charts/commit/0e13ba7ae2f127ff19c26b7eee92f7cf27b8d9db)]

### Version 0.1.10 - 10 June 2026
- Updated appVersion to z5-1.15 [Olimpiu Rob - [`ef21d534`](https://github.com/eea/helm-charts/commit/ef21d5340c99708879ab1c202d0b8ecc057af173)]

### Version 0.1.9 - 10 June 2026
- Updated appVersion to z5-1.14 [Olimpiu Rob - [`d78fdb42`](https://github.com/eea/helm-charts/commit/d78fdb426a927f5ffd97646b0fc437e09e218431)]

### Version 0.1.8 - 04 June 2026
- Updated appVersion to z5-1.13 [Olimpiu Rob - [`a9a004de`](https://github.com/eea/helm-charts/commit/a9a004dea80ce94a71ec806d417adec2b165f88b)]

### Version 0.1.7 - 04 June 2026
- Updated appVersion to z5-1.12 [Olimpiu Rob - [`5a9c0d7f`](https://github.com/eea/helm-charts/commit/5a9c0d7fea7ab285b02786b119f1261530cf406d)]

### Version 0.1.6 - 03 June 2026
- Changed webforms proxy image tag to: 1.31.1-alpine [Olimpiu Rob - [`2c7ddad7`](https://github.com/eea/helm-charts/commit/2c7ddad7f05300c8b58538abb124fcafb9a4bac9)]

### Version 0.1.5 - 03 June 2026
- Updated appVersion to z5-1.11 [Olimpiu Rob - [`2cf6ed8d`](https://github.com/eea/helm-charts/commit/2cf6ed8dc137000ab9b69f596f0604c9d3209dc2)]

### Version 0.1.4 - 25 May 2026
- Updated appVersion to z5-1.10 [Olimpiu Rob - [`37517d1a`](https://github.com/eea/helm-charts/commit/37517d1ae4b7ccbc23171f65422b18b623767d26)]

### Version 0.1.3 - 21 May 2026
- Updated appVersion to z5-1.9 and added LDAP memcached deployment [Olimpiu Rob - [`d530fffb`](https://github.com/eea/helm-charts/commit/d530fffbad33b017485b067b05f38a4421191658)]

### Version 0.1.2 - 20 May 2026
- Set zeoserver image tag to z5-1.0 [Olimpiu Rob - [`7b728abb`](https://github.com/eea/helm-charts/commit/7b728abb1ea31d6e60de9bceaa9633920878ebcc)]

### Version 0.1.1 - 19 May 2026
- Fixed webforms proxy [Olimpiu Rob - [`de19303d`](https://github.com/eea/helm-charts/commit/de19303dce02ca717056182de12be9179741d6d4)]

### Version 0.1.0 - 18 May 2026
- Initial release.
