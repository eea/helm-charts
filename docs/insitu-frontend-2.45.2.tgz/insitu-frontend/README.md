# COPERNICUS IN-SITU COMPONENT frontend - Plone 6

This chart deployes the COPERNICUS IN-SITU COMPONENT frontend app 

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| links.backend | string | NAME.NAMESPACE | Service name for varnish for backend instance, followed by the namespace. |

## Releases

### Version 2.45.2 - 12 November 2026
- Automated release of [eeacms/plone-varnish:9.1-1.0](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`9051ea92f`](https://github.com/eea/helm-charts/commit/9051ea92f3124f917486875533eceabcecdf119a)]

### Version 2.45.1 - 11 November 2026
- Automated release of [eeacms/plone-varnish:8.0-1.0](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`08e1842c4`](https://github.com/eea/helm-charts/commit/08e1842c40346cd380335bd1b01730eb519e505b)]

### Version 2.45.0 - 28 October 2026
- Automated release of [eeacms/insitu-frontend:2.47.0](https://github.com/eea/insitu-frontend/releases) [EEA Jenkins - [`518b01d31`](https://github.com/eea/helm-charts/commit/518b01d31b9e44973736357b29ec6d2f20804500)]

### Version 2.44.0 - 24 August 2026
- Automated release of [eeacms/insitu-frontend:2.45.0](https://github.com/eea/insitu-frontend/releases) [EEA Jenkins - [`f9dbe5ad`](https://github.com/eea/helm-charts/commit/f9dbe5ad1e336e49d1876dbb14d657234dfe5b8b)]

### Version 2.43.0 - 11 August 2026
- Automated release of [eeacms/insitu-frontend:2.44.0](https://github.com/eea/insitu-frontend/releases) [EEA Jenkins - [`37edfdce`](https://github.com/eea/helm-charts/commit/37edfdce1ea303977e4fa35896ecccabdc0ea03a)]

### Version 2.42.0 - 01 July 2026
- Automated release of [eeacms/insitu-frontend:2.43.0](https://github.com/eea/insitu-frontend/releases) [EEA Jenkins - [`5f286667`](https://github.com/eea/helm-charts/commit/5f286667ee360531957379de98dd266dfeea903a)]

### Version 2.41.0 - 26 June 2026
- Automated release of [eeacms/insitu-frontend:2.42.0](https://github.com/eea/insitu-frontend/releases) [EEA Jenkins - [`6afa327e`](https://github.com/eea/helm-charts/commit/6afa327e611b361aa05941c629c84042f46c7c7a)]

### Version 2.40.0 - 25 June 2026
- Automated release of [eeacms/insitu-frontend:2.41.0](https://github.com/eea/insitu-frontend/releases) [EEA Jenkins - [`109bd81c`](https://github.com/eea/helm-charts/commit/109bd81cb74254005f3fc911836f6bcd0ace29ba)]

### Version 2.39.0 - 17 June 2026
- Automated release of [eeacms/insitu-frontend:2.40.0](https://github.com/eea/insitu-frontend/releases) [EEA Jenkins - [`03863764`](https://github.com/eea/helm-charts/commit/038637640d2a619377df230b02b38d6042fa3e23)]

### Version 2.38.0 - 05 June 2026
- Automated release of [eeacms/insitu-frontend:2.39.0](https://github.com/eea/insitu-frontend/releases) [EEA Jenkins - [`ba555aed`](https://github.com/eea/helm-charts/commit/ba555aed6c04a278a078bcc120f88d2c69c053f5)]

### Version 2.37.0 - 04 February 2026
- Automated release of [eeacms/insitu-frontend:2.38.0](https://github.com/eea/insitu-frontend/releases) [EEA Jenkins - [`f824c85f`](https://github.com/eea/helm-charts/commit/f824c85f400339ad4a3b7dfe06f942236f6dbb0d)]

### Version 2.35.0 - 30 January 2026
- Automated release of [eeacms/insitu-frontend:2.37.0](https://github.com/eea/insitu-frontend/releases) [EEA Jenkins - [`bfea9834`](https://github.com/eea/helm-charts/commit/bfea9834fd77f560bf81cd3dfed50d4cde058418)]

### Version 2.34.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`78def35e`](https://github.com/eea/helm-charts/commit/78def35e8bc77c9c0c0e233014fefc48cc5ff575)]

### Version 2.31.1 - 01 August 2025
- Automated release of [eeacms/plone-varnish:7.7-1.1](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`884743bb`](https://github.com/eea/helm-charts/commit/884743bb1b61b9c03420f5036f0164f870dcc438)]

### Version 1.0.0
- Initial release. 
