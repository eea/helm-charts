# Reportnet BDR on python 3

The Business Data Repository is part of the Reportnet architecture. The Business Data Repository is like a bookshelf, with data reports on the environment as submitted to international clients.

This chart is almost configured for production use.

## Network Security Policies

This Helm chart deploys Kubernetes Network Policies to enhance the security of the BDR application. If `defaultNetworkPolicyDeny` is enabled, these policies enforce a **whitelist** approach, meaning that network traffic is only allowed if explicitly permitted.

**Key Network Policy Configurations:**

*   **Instance Pod Egress (`instance.networkPolicy.egress` in `values.yaml`):**  Configures outbound traffic from the `bdr-instance` pods. You can configure egress rules in two ways:

    1. Using `ipBlockRules`: Define IP-based rules with specific ports for each CIDR block:
    ```yaml
    instance:
      networkPolicy:
        egress:
          ipBlockRules:
            - cidr: 10.50.4.0/24  # Legacy service network
              ports:
                - protocol: TCP
                  port: 443     # HTTPS
                - protocol: TCP
                  port: 80      # HTTP
            - cidr: 10.50.5.0/24  # Another network
              ports:
                - protocol: TCP
                  port: 5432    # PostgreSQL
    ```

    2. Using `rawRules`: For more complex scenarios, define individual egress rules using the full power of Kubernetes NetworkPolicy `to` specifications:
    ```yaml
    instance:
      networkPolicy:
        egress:
          rawRules:
            - to:
                - namespaceSelector:
                    matchLabels:
                      kubernetes.io/metadata.name: other-namespace
                  podSelector:
                    matchLabels:
                      app.kubernetes.io/name: service-name
              ports:
                - port: 8080
                  protocol: TCP
    ```

    You can use `rawRules` to define:
    *   **IP Block Rules:** Target egress traffic to specific IP address ranges
    *   **Namespace Selector Rules:** Target pods in other namespaces based on namespace labels and pod labels
    *   **Pod Selector Rules:** Target pods within the same namespace based on pod labels
    *   **Service Account Selector Rules (Advanced):** Target pods based on their service accounts



*   **Default Deny Policies:** The chart includes deny Network Policies (`netsecpol-ingress-default.yaml` and `netsecpol-egress-default.yaml`) that, when enabled with `defaultNetworkPolicyDeny.enabled: true`, block all ingress and egress traffic unless overridden by more specific policies. This ensures a secure starting point and encourages explicit definition of allowed traffic.

    Under default-deny, the chart auto-deploys ingress allows for the in-cluster `valkey` and `memcached` pods (when enabled), permitting traffic from any pod in the same release — no extra rules needed.

**Modifying Network Policies:**


## Shared Blob Storage

By default, every Zope instance pod streams blobs over the ZEO wire and caches
them locally in a per-pod `emptyDir` (`instance.env.blobStorageCacheVolumeEnabled`).
For deployments where the cluster has a `ReadWriteMany` storage class available
(e.g. `nfs-client` via `nfs-subdir-external-provisioner`), the chart can instead
have the **ZEO server's own PVC** be `ReadWriteMany` and have every instance
pod mount that same PVC at `/opt/zope/var/blobstorage` (subPath: `blobstorage`).
The base image's entrypoint sets `shared-blob-dir on` in `zodb.conf` so Zope
clients read blobs directly off the shared filesystem instead of streaming.


### Values

```yaml
zeoserver:
  accessMode: ReadWriteMany              # default ReadWriteOnce; must be RWX

instance:
  env:
    zeoSharedBlobDir: "on"               # default "off"
    blobStorageCacheVolumeEnabled: false # mutually exclusive with shared mode
```

Constraints (enforced via `helm template`-time fail-fast):

- `instance.env.zeoSharedBlobDir: on` requires `zeoserver.accessMode: ReadWriteMany`.
- `instance.env.zeoSharedBlobDir: on` requires `instance.env.blobStorageCacheVolumeEnabled: false`.
- `instance.env.zeoSharedBlobDir: on` requires `zeoserver.zeoUid: 1000` and
  `zeoserver.zeoGid: 1000` (the instance pod's hardcoded UID). The ZEO server
  and instance pods share the same filesystem, so their UIDs must match.

When `zeoSharedBlobDir: on`, the instance Deployment mounts the StatefulSet's
PVC by computed name: `<zeoserver.storageName>-<Release.Name>-zeoserver-0`.

### Enabling on a fresh deployment

If you're deploying for the first time:

1. Set the values above before the first `helm install`.
2. Make sure your storage class supports `ReadWriteMany` (the chart only
   declares the access mode; the cluster must back it).


## LDAP cache (memcached)

The Zope instances use memcached as a backend cache for LDAP lookups via the
`LDAP_MEMCACHED_SERVERS` env var (comma-separated `host:port`). To deploy an
in-cluster memcached and wire it up:

```yaml
memcached:
  enabled: true                          # deploys memcached + Service on TCP/11211

instance:
  env:
    ldapMemcachedServers: "bdr-py3-memcached:11211"
```

When `ldapMemcachedServers` is empty the env var is omitted entirely.

## Secret handling

The instance supports either:

- `instance.existingSecret`, containing `BEAKER_SECRET`, `SESSION_SECRET`,
  `RABBITMQ_PASS`, and `SENTRY_DSN`; or
- an inline `instance.env.sessionSecret` injected at deployment time.

No credential placeholders are shipped. Inline Secret changes alter the pod
checksum and roll the instance Deployment. For an external Secret, changing the
Secret name rolls the Deployment; changing only its contents requires a
reloader controller or an explicit rollout.

PostgreSQL supports `postgresql.auth.existingSecret` with the configured
`postgres-password`, `password`, and `replication-password` keys. Admin ingress
auth similarly accepts `apache.adminAuth.existingSecret` with `auth` (nginx)
and `users` (Traefik) keys, or a deploy-time `htpasswd` value.

## Sync CronJob credentials and deadlines

When `cron.tokenSecretName` is empty, the chart renders
`templates/cron-sync-secret.yaml` as the `bdr-py3-sync-tokens` Secret in the
release namespace. Each enabled job contributes its `token` under the key set
by `tokenSecretKey`:

```yaml
cron:
  tokenSecretName: ""

synccronjobs:
  - name: sync-fgases
    enabled: true
    schedule: "2-59/5 * * * *"
    tokenSecretKey: sync-fgases
    token: "" # inject at deployment time; never commit a production token
    syncURL: https://example.invalid/sync
    backoffLimit: 1
    resources:
      requests:
        memory: 16Mi
      limits:
        memory: 16Mi
```

Alternatively, set `cron.tokenSecretName` to a caller-managed Secret containing
those keys; the chart will not render its own sync token Secret. Inline token
values are stored both in the Kubernetes Secret and in Helm release state, like
other chart-managed Secret values.

Curl runs directly without a shell and has connect/request timeouts. Job and
schedule deadlines prevent a hung job from blocking future executions under
`concurrencyPolicy: Forbid`.

## Releases

### Version 0.2.19 - 26 November 2026
- Automated release of nginx:1.31.10 [Valentina Balan - [`05e9ed39b`](https://github.com/eea/helm-charts/commit/05e9ed39b5c14bdd94a77ff1f5c893930550c86f)]

### Version 0.2.18 - 19 November 2026
- Bumped webforms proxy image to nginx:1.31.9-alpine [Olimpiu Rob - [`63ab7115f`](https://github.com/eea/helm-charts/commit/63ab7115f493befb2107438f481045ecdad20a63)]

### Version 0.2.17 - 18 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-14](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`4a7f07d82`](https://github.com/eea/helm-charts/commit/4a7f07d829721ba0dd92e13505e8e58f2dfd3400)]

### Version 0.2.16 - 17 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-13](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`f3650c5ee`](https://github.com/eea/helm-charts/commit/f3650c5ee6dae66374744f261f879ef0a8e5a3ab)]

### Version 0.2.15 - 17 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-12](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`be1af1e62`](https://github.com/eea/helm-charts/commit/be1af1e623b97d6cb7069859e3e054c34545f094)]

### Version 0.2.14 - 16 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-11](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`70dc0ee88`](https://github.com/eea/helm-charts/commit/70dc0ee8816e7a79c5c07019de561df19e63ccee)]

### Version 0.2.13 - 16 November 2026
- Added registrySharedCache [Olimpiu Rob - [`b793b9049`](https://github.com/eea/helm-charts/commit/b793b9049a668ddf50722ef32c445b8fec4ba3d9)]

### Version 0.2.12 - 13 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-9](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`a918be02a`](https://github.com/eea/helm-charts/commit/a918be02ae5399f620d3bb590ed5d4b178871d0f)]

### Version 0.2.11 - 13 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-8](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`83159b518`](https://github.com/eea/helm-charts/commit/83159b518a1b751fc2b8d5551527cea97ae159f6)]

### Version 0.2.10 - 13 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-7](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`ad5d6a02f`](https://github.com/eea/helm-charts/commit/ad5d6a02f99b01bcc52f0c57188cd646550bea68)]

### Version 0.2.9 - 12 November 2026
- Updated rn-bdr-european-registry to 1.0.6 [Diana Boiangiu - [`0a49bc227`](https://github.com/eea/helm-charts/commit/0a49bc227d2dce7ef0a36929b34773d8eb5dad7c)]

### Version 0.2.8 - 11 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-6](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`4c602216f`](https://github.com/eea/helm-charts/commit/4c602216fe27cd51c7ebcc204ffdc1b732a60604)]

### Version 0.2.7 - 11 November 2026
- Added zodbCacheSize, zodbCacheSizeBytes and zopeSecurityPolicy envs [Olimpiu Rob - [`3f0894c67`](https://github.com/eea/helm-charts/commit/3f0894c675466371144f579cb7f0b1cdbb1dca05)]

### Version 0.2.6 - 11 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-5](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`7de17c697`](https://github.com/eea/helm-charts/commit/7de17c69751da4c77f6532df00e05b77639eed96)]

### Version 0.2.5 - 06 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-4](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`02938bfc6`](https://github.com/eea/helm-charts/commit/02938bfc61682249b02d2eb7d4ad998cf6b5a00d)]

### Version 0.2.4 - 04 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-3](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`0272ce631`](https://github.com/eea/helm-charts/commit/0272ce631d6355bc1e1984c45bcc5a384bf2f873)]

### Version 0.2.3 - 04 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-2](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`e0433fc37`](https://github.com/eea/helm-charts/commit/e0433fc37b364ca82505405617f4c134ea32f832)]

### Version 0.2.2 - 03 November 2026
- Fallback to default zeoserver image tag in cronzeopack if not overriden [Olimpiu Rob - [`30c24fa9e`](https://github.com/eea/helm-charts/commit/30c24fa9e9d5c74f4131c8a145f13edf0fa0d4c2)]

### Version 0.2.1 - 03 November 2026
- Removed tag from cronzeopack in values [Olimpiu Rob - [`e42c94811`](https://github.com/eea/helm-charts/commit/e42c9481111ee86dedb65316c2b8ca94b1e15c81)]

### Version 0.2.0 - 03 November 2026
- Updated rn-zeoserver to 0.3.0 [Olimpiu Rob - [`0110266bf`](https://github.com/eea/helm-charts/commit/0110266bfd042bbc1a9f0aba07755b6597f95b60)]

### Version 0.1.31 - 03 November 2026
- Automated release of [eeacms/reportek-bdr:6.3-1](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`3279d50e2`](https://github.com/eea/helm-charts/commit/3279d50e2db48c5b055b727261cfa8c24ee13154)]

### Version 0.1.30 - 02 November 2026
- Automated release of [eeacms/reportek-bdr:5.14-11](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`a9bdc2e25`](https://github.com/eea/helm-charts/commit/a9bdc2e2520c7bfa1434d06d506315e8f201407c)]

### Version 0.1.29 - 30 October 2026
- Automated release of [eeacms/reportek-bdr:5.14-10](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`7aa886f81`](https://github.com/eea/helm-charts/commit/7aa886f81a88659eb7ddad515b57395b1c802c4c)]

### Version 0.1.28 - 30 October 2026
- Automated release of [eeacms/reportek-bdr:5.14-9](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`cb8b6d931`](https://github.com/eea/helm-charts/commit/cb8b6d931e87664f4954058525b609bdec6c3b88)]

### Version 0.1.27 - 30 October 2026
- Automated release of [eeacms/reportek-bdr:5.14-8](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`5de242bbd`](https://github.com/eea/helm-charts/commit/5de242bbd59e13f3d07a033d3d652a659136d382)]

### Version 0.1.26 - 29 October 2026
- Automated release of [eeacms/reportek-bdr:5.14-7](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`b04a0dca3`](https://github.com/eea/helm-charts/commit/b04a0dca32cdcea3b2dcd4af9d44dde44ba90928)]

### Version 0.1.25 - 29 October 2026
- Automated release of [eeacms/reportek-bdr:5.14-6](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`08b823122`](https://github.com/eea/helm-charts/commit/08b823122a3e6a9d2303a553b1c5fad282cb5d90)]

### Version 0.1.24 - 28 October 2026
- Automated release of [eeacms/reportek-bdr:5.14-5](https://github.com/eea/eea.docker.reportek.bdr-instance/releases) [EEA Jenkins - [`792dcdd08`](https://github.com/eea/helm-charts/commit/792dcdd0811f2f622bc24c7a0dbfcd0971f83a5f)]

### Version 0.1.23 - 28 October 2026
- Updated appVersion to 5.14-4 [Olimpiu Rob - [`05da0f45b`](https://github.com/eea/helm-charts/commit/05da0f45b1505d14a9167205870a13cabcd77e91)]

### Version 0.1.22 - 27 October 2026
- Release of dependent chart rn-apache:0.3.0 [EEA Jenkins - [`aab3bc452`](https://github.com/eea/helm-charts/commit/aab3bc452d3953e450fcb602317da3480e162292)]

### Version 0.1.21 - 01 October 2026
- Updated appVersion to z5-1.23 [Olimpiu Rob - [`c208f28d`](https://github.com/eea/helm-charts/commit/c208f28de255473167d992f7126ba23c91323bd4)]

### Version 0.1.20 - 30 September 2026
- Updated appVersion to z5-1.22 [Olimpiu Rob - [`2f71211a`](https://github.com/eea/helm-charts/commit/2f71211a9a47c37e755bfabed27a1eea74626d38)]

### Version 0.1.19 - 29 September 2026
- Updated appVersion to z5-1.21 [Olimpiu Rob - [`3eb376a9`](https://github.com/eea/helm-charts/commit/3eb376a93dc043ac6785be9f3b289209cf64a613)]

### Version 0.1.18 - 28 September 2026
- Updated appVersion to z5-1.20 [Olimpiu Rob - [`db7ec894`](https://github.com/eea/helm-charts/commit/db7ec894f6fe67009e7c6a4f5f309483bf9819c5)]

### Version 0.1.17 - 25 September 2026
- Updated appVersion to z5-1.19 [Olimpiu Rob - [`85189eb1`](https://github.com/eea/helm-charts/commit/85189eb1ab4fb746ae5257ffca40657c2312ac04)]

### Version 0.1.16 - 24 September 2026
- Updated appVersion to z5-1.18 [Olimpiu Rob - [`c7ef1dfe`](https://github.com/eea/helm-charts/commit/c7ef1dfe39433e77185e09557e1cc1c3931b48ec)]

### Version 0.1.15 - 24 September 2026
- Updated appVersion to z5-1.17 [Olimpiu Rob - [`65427554`](https://github.com/eea/helm-charts/commit/654275544ccfa7fac158f5d8e50c11647328791c)]

### Version 0.1.14 - 21 September 2026
- Updated appVersion to z5-1.16 [Olimpiu Rob - [`3b2724d7`](https://github.com/eea/helm-charts/commit/3b2724d7685518ec83d0fb84743eaf93709a5464)]

### Version 0.1.13 - 18 September 2026
- Updated appVersion to z5-1.15 [Olimpiu Rob - [`14758c2a`](https://github.com/eea/helm-charts/commit/14758c2aa0be43c1784a25fba238df86616475d9)]

### Version 0.1.12 - 17 September 2026
- Updated appVersion to z5-1.14 [Olimpiu Rob - [`6f116498`](https://github.com/eea/helm-charts/commit/6f1164981c3bc9e0587bfe32b767471b6bfbfe4f)]

### Version 0.1.11 - 15 September 2026
- Updated appVersion to z5-1.13 [Olimpiu Rob - [`a05bec36`](https://github.com/eea/helm-charts/commit/a05bec36e67cc69004660d3d6eac96ef7b45245e)]

### Version 0.1.10 - 10 September 2026
- Updated sync-cronjobs shared settings, updated questions [Olimpiu Rob - [`eec3071c`](https://github.com/eea/helm-charts/commit/eec3071ce3713252493538154cc929bc186a36d3)]

### Version 0.1.9 - 09 September 2026
- Updated registries versions and added configmaps and secrets for their envs [Olimpiu Rob - [`b9aaa0a6`](https://github.com/eea/helm-charts/commit/b9aaa0a6a9d7616cd1e2137cb1d4f9817bd33b8a)]

### Version 0.1.8 - 07 September 2026
- Updated appVersion to z5-1.12 [Olimpiu Rob - [`ff9d1126`](https://github.com/eea/helm-charts/commit/ff9d112639d459b6cb8c447994aa8717d62153d6)]

### Version 0.1.7 - 04 September 2026
- Updated appVersion to z5-1.11 [Olimpiu Rob - [`c52e46ee`](https://github.com/eea/helm-charts/commit/c52e46eec58cd69e8ee2b86af0947dfaa2817911)]

### Version 0.1.6 - 27 August 2026
- Updated appVersion to z5-1.10 [Olimpiu Rob - [`9cf3781f`](https://github.com/eea/helm-charts/commit/9cf3781fdc53ff9cd3fee63d4f2aab26bb1f897c)]

### Version 0.1.5 - 26 August 2026
- Updated appVersion to z5-1.9 [Olimpiu Rob - [`526ed93d`](https://github.com/eea/helm-charts/commit/526ed93d7d5e02c93f55270b461999b602262cdd)]

### Version 0.1.4 - 26 August 2026
- Upgraded appVersion to z5-1.8 [Olimpiu Rob - [`f29f241d`](https://github.com/eea/helm-charts/commit/f29f241db05c47b87e92d2e1fc5add3eacf9a82a)]

### Version 0.1.3 - 12 August 2026
- Updated appVersion to z5-1.7 [Olimpiu Rob - [`72c360f7`](https://github.com/eea/helm-charts/commit/72c360f74a08ed2c76dc7361f9e973c5185b795a)]

### Version 0.1.2 - 12 August 2026
- Updated appVersion to z5-1.6 [Olimpiu Rob - [`215a1636`](https://github.com/eea/helm-charts/commit/215a16361c6cc9fbb9c54b9f6f3827d1fcc14937)]

### Version 0.1.1 - 11 August 2026
- Added betterleaks:allow to suppress false positives [Olimpiu Rob - [`df1c2bdb`](https://github.com/eea/helm-charts/commit/df1c2bdb2f4e34f1f492c219bc7949e3f5b0a36a)]

### Version 0.1.0 - 10 Aug 2026
- Initial release.
