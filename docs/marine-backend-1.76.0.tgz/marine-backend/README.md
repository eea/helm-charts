# Wise Marine backend - Plone 6

## Releases

### Version 1.76.0 - 08 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-24](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`cfc138ad`](https://github.com/eea/helm-charts/commit/cfc138ada1babe5f496945e12898221f4c57d9c0)]

### Version 1.75.0 - 05 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-23](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`4b2928f9`](https://github.com/eea/helm-charts/commit/4b2928f95bfd9908fcb73298faa172de0a94adad)]

### Version 1.74.0 - 01 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-22](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`168cf57d`](https://github.com/eea/helm-charts/commit/168cf57d77acb3fc319dd75402b5dd2f3bf526b5)]

### Version 1.73.1 - 26 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-21.beta.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`265fa5d3`](https://github.com/eea/helm-charts/commit/265fa5d38e4ffef1f3bb86c17b74427dcf4f7b77)]

### Version 1.73.0 - 26 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-21](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`d2de411c`](https://github.com/eea/helm-charts/commit/d2de411ca5b61641b37a9b5673f62e82e4d0abab)]

### Version 1.72.0 - 24 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-20](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`609c1e1e`](https://github.com/eea/helm-charts/commit/609c1e1eacad8b5fdbdbda14624adc761e14d759)]

### Version 1.71.0 - 18 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-19](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`fb63c842`](https://github.com/eea/helm-charts/commit/fb63c842f3388d60ea64e643daed06204580eb17)]

### Version 1.70.4 - 16 June 2026
- increase cpu for cronjobs [Dobricean Ioan Dorian - [`00702b52`](https://github.com/eea/helm-charts/commit/00702b524b8295cdcce63a42c3b931eb017686aa)]

### Version 1.70.3 - 15 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-18.beta.03](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`57e306e7`](https://github.com/eea/helm-charts/commit/57e306e7f9ee030d362893a370e0b56ce3f04cbf)]

### Version 1.70.2 - 12 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-18.beta.02](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`76ef0f7e`](https://github.com/eea/helm-charts/commit/76ef0f7efeae12dd3e02b4b80c263ef204e1dbce)]

### Version 1.70.1 - 12 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-18.beta.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`3d481dd4`](https://github.com/eea/helm-charts/commit/3d481dd495373ccd480ad61da2d1c72abf3487ad)]

### Version 1.70.0 - 12 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-18](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`5d8e2f95`](https://github.com/eea/helm-charts/commit/5d8e2f95cd0b9ce6a23790d39232cfc8929e0e8a)]

### Version 1.69.0 - 12 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-17](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`9c6dc968`](https://github.com/eea/helm-charts/commit/9c6dc96801db095b96f2f0c2d17ed5b4e6c87d73)]

### Version 1.68.0 - 11 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-16](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`93e7018e`](https://github.com/eea/helm-charts/commit/93e7018ed6b519f8d0f9749ac3bc48cfb90c4fc7)]

### Version 1.67.0 - 10 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-15](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`e73312fe`](https://github.com/eea/helm-charts/commit/e73312fe3ea274e1e4ce015360dead8bb327dbe6)]

### Version 1.66.0 - 04 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-13](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`47276182`](https://github.com/eea/helm-charts/commit/47276182c303d36755e5fe32773ce4ebf62814cf)]

### Version 1.65.0 - 04 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-12](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`86a9dc13`](https://github.com/eea/helm-charts/commit/86a9dc138e05b5ae0090ed0daf333b29af96bbe3)]

### Version 1.64.0 - 03 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-11](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`50e1037a`](https://github.com/eea/helm-charts/commit/50e1037a3733dabe4837ddced13be80bc003caef)]

### Version 1.63.0 - 03 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-10](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`167ffdda`](https://github.com/eea/helm-charts/commit/167ffdda7908e064320fba23790acc947086fe9b)]

### Version 1.62.0 - 29 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-9](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`f00c9b48`](https://github.com/eea/helm-charts/commit/f00c9b48ec932f8d2ea1bd5d3f6ed2d18100b8d1)]

### Version 1.61.0 - 28 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-8](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`dcbd8222`](https://github.com/eea/helm-charts/commit/dcbd82229f510bc98706126855cd199f21e20d4b)]

### Version 1.60.0 - 22 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-7](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`1e421035`](https://github.com/eea/helm-charts/commit/1e421035a84410f71053c9be9468040c47663d0f)]

### Version 1.59.0 - 16 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-6](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`8705d5e1`](https://github.com/eea/helm-charts/commit/8705d5e1c26d3bc23e5435b792ed65774d47cd67)]

### Version 1.58.0 - 09 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-4](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`4f49571b`](https://github.com/eea/helm-charts/commit/4f49571b7a48b19d7d82109dbfb0c559929ccb05)]

### Version 1.57.0 - 06 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-3](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`154733cb`](https://github.com/eea/helm-charts/commit/154733cb25b4999ec00c2a8f362eeb4ad1375a6d)]

### Version 1.56.0 - 29 April 2026
- Automated release of [eeacms/marine-backend:6.1.4-2](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`e1446990`](https://github.com/eea/helm-charts/commit/e14469906524d31b64c2850b201b2135036c908a)]

### Version 1.55.0 - 29 April 2026
- Automated release of [eeacms/marine-backend:6.1.4-1](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`5f19b56a`](https://github.com/eea/helm-charts/commit/5f19b56a7999501f62eaaa56088fe2f01676b176)]

### Version 1.54.0 - 22 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-25](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`ff3262e4`](https://github.com/eea/helm-charts/commit/ff3262e4d178b2c47a3b5087224a160187bc3d3c)]

### Version 1.53.0 - 18 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-24](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`4dfbd709`](https://github.com/eea/helm-charts/commit/4dfbd70964d48b4f5655c06954675da215a204cd)]

### Version 1.52.0 - 18 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-23](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`23e4fef1`](https://github.com/eea/helm-charts/commit/23e4fef173b9769d4f8f95e7e71ad6e02806f2e7)]

### Version 1.51.0 - 17 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-22](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`611b2795`](https://github.com/eea/helm-charts/commit/611b2795aef215c61916f2080b148c1a8a5f6b04)]

### Version 1.50.0 - 16 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-21](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`5b93e18e`](https://github.com/eea/helm-charts/commit/5b93e18ef21393e6b1fcfa25f876040d2a682ce8)]

### Version 1.49.0 - 15 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-20](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`cb1beab3`](https://github.com/eea/helm-charts/commit/cb1beab307ba3e56f7ef71a7b97714e75d0b57bd)]

### Version 1.48.0 - 14 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-19](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a0abd2c1`](https://github.com/eea/helm-charts/commit/a0abd2c1ef991926920897912cee86e9fc3df2ca)]

### Version 1.47.0 - 13 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-18](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`fd47f610`](https://github.com/eea/helm-charts/commit/fd47f610ded18dcaf44d20f1df81304e16bb8886)]

### Version 1.46.0 - 11 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-17](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`14acc86b`](https://github.com/eea/helm-charts/commit/14acc86bde34fdb28a864d8a88186a4d390be42d)]

### Version 1.45.0 - 10 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-16](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`d375bc31`](https://github.com/eea/helm-charts/commit/d375bc31abf1e58749d1073625508fe035ddbf59)]

### Version 1.44.0 - 10 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-15](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`1d7a3762`](https://github.com/eea/helm-charts/commit/1d7a3762f437a542e5ef7da44059470c7389212f)]

### Version 1.43.0 - 08 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-14](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`6aa2c1c4`](https://github.com/eea/helm-charts/commit/6aa2c1c4c04ac661b98c16db656c459f10a58510)]

### Version 1.42.0 - 07 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-13](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`f9fe2fc1`](https://github.com/eea/helm-charts/commit/f9fe2fc104e278e9d7a228450e5214be5b10e213)]

### Version 1.41.0 - 07 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-12](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`74b76e2c`](https://github.com/eea/helm-charts/commit/74b76e2c45b9ed0dcac5a106b1cf3a125c56d5ad)]

### Version 1.40.0 - 06 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-11](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a726c2af`](https://github.com/eea/helm-charts/commit/a726c2aff1c1ea116f2404c488d649be15de93d1)]

### Version 1.39.0 - 06 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-10](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`0a4c301d`](https://github.com/eea/helm-charts/commit/0a4c301d8b69df0908e1162c4bf572141c532363)]

### Version 1.38.0 - 04 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-9](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`6a800cf9`](https://github.com/eea/helm-charts/commit/6a800cf96b59cda6e27bd345c8daba9ae0d7f043)]

### Version 1.37.0 - 03 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-8](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`8d932d4b`](https://github.com/eea/helm-charts/commit/8d932d4b92d994d2fb01833f37c08ed4a4423e40)]

### Version 1.36.0 - 02 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-7](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`c7bae737`](https://github.com/eea/helm-charts/commit/c7bae737494cfb85faf49e3fa47ee25f9417b296)]

### Version 1.35.0 - 01 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-6](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a1eb4f26`](https://github.com/eea/helm-charts/commit/a1eb4f2674d458cdb91cd3ea97c9146a19c26c21)]

### Version 1.34.0 - 01 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-5](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`2973dcf0`](https://github.com/eea/helm-charts/commit/2973dcf03c6bde4dc96db4b6c6dc1212e23bbdbe)]

### Version 1.33.0 - 01 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-4](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`58a139f4`](https://github.com/eea/helm-charts/commit/58a139f474a292182d4ed4accb295f684f2f6105)]

### Version 1.32.0 - 19 March 2026
- Automated release of [eeacms/marine-backend:6.1.3-x03](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`4202ae70`](https://github.com/eea/helm-charts/commit/4202ae708586f4d996ce1d0555611fb749454010)]

### Version 1.31.0 - 19 March 2026
- Automated release of [eeacms/marine-backend:6.1.3-x02](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`2c30de27`](https://github.com/eea/helm-charts/commit/2c30de27ae3f886d03d528d0d62b9ecc4d3f4282)]

### Version 1.30.0 - 19 March 2026
- Automated release of [eeacms/marine-backend:6.1.3-x01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`99f06747`](https://github.com/eea/helm-charts/commit/99f06747ce28dc4dbe9b0f03bce195111b5f8694)]

### Version 1.29.0 - 09 March 2026
- Automated release of [eeacms/marine-backend:6.1.3-prod.02](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`3f00030a`](https://github.com/eea/helm-charts/commit/3f00030a312e2020eaa019ffb3f1ad15d485f665)]

### Version 1.28.6 - 09 March 2026
- fix error [Dobricean Ioan Dorian - [`898b83fe`](https://github.com/eea/helm-charts/commit/898b83fe1a393cf78049cc3ccec03fdff5c425c2)]

### Version 1.28.4 - 06 March 2026
- fix ingress marine [Dobricean Ioan Dorian - [`d225ca6e`](https://github.com/eea/helm-charts/commit/d225ca6e18da1bfae4c74b9ab978510222922a44)]

### Version 1.28.3 - 05 March 2026
- fix [Dobricean Ioan Dorian - [`fa9f280d`](https://github.com/eea/helm-charts/commit/fa9f280d91a96f46983ac937d82f3b77fed0313a)]

### Version 1.28.1 - 05 March 2026
- devel image [Dobricean Ioan Dorian - [`a8b9795f`](https://github.com/eea/helm-charts/commit/a8b9795ffaf202d58e323211cac6b0fdeeb0c343)]

### Version 1.28.0 - 05 March 2026
- modify database connection [Dobricean Ioan Dorian - [`7dc66b7d`](https://github.com/eea/helm-charts/commit/7dc66b7dbb97042acca41e94cc5a308be78603f6)]

### Version 1.27.0 - 25 February 2026
- Automated release of [eeacms/marine-backend:6.1.3-demo](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`5ff2fa67`](https://github.com/eea/helm-charts/commit/5ff2fa6754db4f16d10ef326b25a8d9f41bb4f66)]

### Version 1.26.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`3fb339e0`](https://github.com/eea/helm-charts/commit/3fb339e046bb39480f8f5f04500c53c4828d53d0)]

### Version 1.26.0 - 09 January 2026
- Automated release of [eeacms/marine-backend:6.0.15-22](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`02a7f65e`](https://github.com/eea/helm-charts/commit/02a7f65efac7bdd891c3d6b0f25aa21724fbd0eb)]

### Version 1.25.6 - 28 December 2025
- fix ingress [Dobricean Ioan Dorian - [`f0431ca3`](https://github.com/eea/helm-charts/commit/f0431ca340af932b1d0d05328ffc8d77c001133f)]

### Version 1.25.4 - 19 December 2025
- add missing vars" [Dobricean Ioan Dorian - [`b4c790f4`](https://github.com/eea/helm-charts/commit/b4c790f411d30f17db64b8bc9574fa37309d8da1)]

### Version 1.25.3 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`1df2d5ee`](https://github.com/eea/helm-charts/commit/1df2d5eec51e5f37509c1e8f2be6ce4fe5f734c6)]
