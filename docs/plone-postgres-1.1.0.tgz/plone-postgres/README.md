# Plone-postgres

Postgres for plone Apps.

## Releases

### Version 1.1.0 - 07 September 2026
- Upgrade versions of postgres [valentinab25 - [`67588a58`](https://github.com/eea/helm-charts/commit/67588a58b13f03df49084fed494d930ac7f33686)]

### Version 1.0.15 - 01 September 2026
- Fix spacing [valentinab25 - [`5f247aff`](https://github.com/eea/helm-charts/commit/5f247affcf2122462975b2eba3d9cf99c048fc68)]

### Version 1.0.14 - 01 September 2026
- fix spacing [valentinab25 - [`be3a898a`](https://github.com/eea/helm-charts/commit/be3a898a83f9622cd3ded984191773243461012f)]

### Version 1.0.13 - 01 September 2026
- Add external service [valentinab25 - [`b59dbadc`](https://github.com/eea/helm-charts/commit/b59dbadcc029ed7b1c3df93d3c19a3673e94440d)]

### Version 1.0.10 - 18 September 2025
- Cleanup unused postgres-admin.yaml [Alin Voinea - [`55acc49d`](https://github.com/eea/helm-charts/commit/55acc49d9bdd304296b3662617b5e02ed7ddee40)]

### Version 1.0.9 - 17 September 2025
- Update new versions of postgres [valentinab25 - [`40f3d71b`](https://github.com/eea/helm-charts/commit/40f3d71b1beaefa2072c14e8e973016eb4eed7b5)]

### Version 1.0.8 - 25 August 2025
- Mount postgresql-backup to /backup [Alin Voinea - [`b56532d5`](https://github.com/eea/helm-charts/commit/b56532d5f96661a6a96a6d25140dbae692187956)]

### Version 1.0.7 - 25 August 2025
- Mount admin volume [valentinab25 - [`b6de5923`](https://github.com/eea/helm-charts/commit/b6de59238a01b5f3d89b53ea7729b77b7e17f0ba)]

### Version 1.0.6 - 25 August 2025
- Set postgresql-backup as name for admin volume [valentinab25 - [`6940d874`](https://github.com/eea/helm-charts/commit/6940d8749e39a3b03b0b760e6cc5444541ab55ea)]

### Version 1.0.5 - 22 August 2025
- Add serviceName [valentinab25 - [`19e5bc6d`](https://github.com/eea/helm-charts/commit/19e5bc6db1f23e1b1c5c67a410cabe53ba1ee573)]

### Version 1.0.4 - 22 August 2025
- fix resources [valentinab25 - [`34776523`](https://github.com/eea/helm-charts/commit/34776523793d1e808c884d2f02c667152c53264d)]

### Version 1.0.3 - 22 August 2025
- Fix variable name [valentinab25 - [`0cf16495`](https://github.com/eea/helm-charts/commit/0cf16495ce31008c1a705166249ea0a2d59aa545)]

### Version 1.0.2 - 22 August 2025
- Add admin to external postgres with storage [valentinab25 - [`fffe33d2`](https://github.com/eea/helm-charts/commit/fffe33d25b32d158a5cca392a9737e90418fac6e)]


### Version 1.0.1
- Add questions, simplify names.

### Version 1.0.0
- First production release of sqlservice.

