# Reportnet Varnish

Varnish for Reportek.

[See more](https://github.com/eea/eea.docker.varnish-reportek)

## Configuration

- `timezone` - Time zone.
- `varnishHTTPPort` - Port for HTTP traffic.
- `varnishHTTPSPort` - Port for HTTPS traffic.
- `varnishSize` - Size of the varnish cache.
- `autoKillCron` - Auto kill cron.
- `varnishCFGContent` - Content of the configuration file.
- `varnishBackend` - Backend to use.
- `varnishBackendPort` - Port of the backend.
- `varnishDNSTTL` - TTL for DNS.
- `varnishBERESPTTL` - TTL for BERESP.
- `varnishStaticTTL` - TTL for STATIC. Default 6h.
- `varnishBERESPGrace` - Grace period for BERESP.
- `varnishBERESPKeep` - Keep period for BERESP.
- `networkPolicy.enabled` - Enable network policy. Defaults to false.
- `networkPolicy.additionalIngress` - Additional ingress rules to be added to the default ones. Defaults to [].
- `networkPolicy.additionalEgress` - Additional egress rules to be added to the default ones. Defaults to [].
- `networkPolicy.spec` - Additional network policy specifications to be merged with the policy. **Note**: Defining `ingress` or `egress` in spec will completely override the default rules and `additional*` rules. Defaults to {}.
- `backendSelectorLabels` - Labels to select the backend pods.

Default network policy includes:
- Ingress:
  - Allow access from ingress-nginx in kube-system namespace
  - Allow access from same namespace
- Egress:
  - Allow DNS resolution (kube-dns/coredns in kube-system namespace)
  - Allow access to the backend pods. These need to be defined in the backendSelectorLabels.

Example using additionalIngress/Egress (adds to defaults):
```yaml
networkPolicy:
  additionalIngress:
    - from:
        - podSelector:
            matchLabels:
              app: frontend
  additionalEgress:
    - to:
        - podSelector:
            matchLabels:
              app: backend
```

Example using spec (overrides defaults):
```yaml
networkPolicy:
  spec:
    ingress:
      - from:
          - podSelector:
              matchLabels:
                app: custom-frontend
    egress:
      - to:
          - podSelector:
              matchLabels:
                app: custom-backend
```

Example in parent chart's `values.yaml`:

Assuming your parent chart defines a backend service whose pods have the labels `app: my-backend-app` and `component: backend`, you would configure your parent chart's `values.yaml` like this:

```yaml
rn-varnish: # Assuming you named your rn-varnish subchart "rn-varnish"
  networkPolicy:
    enabled: true
    backendSelectorLabels:
      app: my-backend-app
      component: backend
  varnishBackend: my-backend-service # Name of your backend service in the parent chart
  varnishBackendPort: 8080
```

## Releases

### Version 0.6.2 - 08 July 2026
- Allow ingress to varnish port from anywhere in network policy [Olimpiu Rob - [`b4d3160e`](https://github.com/eea/helm-charts/commit/b4d3160e8cc97be7b731ac3510dac8c189981b2f)]

### Version 0.6.1 - 06 July 2026
- Added varnishStaticTTL env [Olimpiu Rob - [`0d057e1f`](https://github.com/eea/helm-charts/commit/0d057e1fe4970ba3e099d9e8c2db04641066d29b)]

### Version 0.6.0 - 06 July 2026
- Automated release of [eeacms/reportek-varnish:8.0-1.1](https://github.com/eea/eea.docker.varnish-reportek/releases) [EEA Jenkins - [`85206d91`](https://github.com/eea/helm-charts/commit/85206d91a89be654e581108b9ac22be33f880a94)]

### Version 0.5.0 - 03 October 2025
- Automated release of [eeacms/reportek-varnish:7.7-1.2](https://github.com/eea/eea.docker.varnish-reportek/releases) [EEA Jenkins - [`1b77220e`](https://github.com/eea/helm-charts/commit/1b77220eee42084348bf106a267e2e4d9eef995f)]

### Version 0.4.0 - 01 September 2025
- Automated release of [eeacms/reportek-varnish:7.7-1.1](https://github.com/eea/eea.docker.varnish-reportek/releases) [EEA Jenkins - [`09553f75`](https://github.com/eea/helm-charts/commit/09553f75cf5a54e93b74ccac3d03d6f33704fbcd)]

### Version 0.3.0 - 21 May 2025
- Automated release of [eeacms/reportek-varnish:7.7-1.0](https://github.com/eea/eea.docker.varnish-reportek/releases) [EEA Jenkins - [`a751543`](https://github.com/eea/helm-charts/commit/a75154391e2ff9f874c1b62af800441cd0b7bb9d)]

### Version 0.2.0 - 14 March 2025
- Automated release of [eeacms/reportek-varnish:7.6-1.0](https://github.com/eea/eea.docker.varnish-reportek/releases) [EEA Jenkins - [`4df4331`](https://github.com/eea/helm-charts/commit/4df433174ed03a473195b47e34a19d3c178b775e)]

### Version 0.1.10
- Fixed nintend for backendSelectorLabels in networkpolicy template.

### Version 0.1.9
- Set networkPolicy enabled to false by default.
- Added backendSelectorLabels to select the backend pods.

### Version 0.1.8
- Renamed network policy metadata component label to network-policy.

### Version 0.1.7
- Added additional ingress/egress rules support

### Version 0.1.6
- Added NetworkPolicy support

### Version 0.1.5
- Updated appVersion to 7.5-1.0

### Version 0.1.4
- Some refactoring and added component labels

### Version 0.1.3
- Removed autoKillCron variable since, using it, causes varnish to no longer respond

### Version 0.1.2
- Changed default port to 8080

### Version 0.1.1
- Added enabled flag

### Version 0.1.0
- Initial release
