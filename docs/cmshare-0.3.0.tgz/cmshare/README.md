# Cm-share Chart

A Nextcloud instance for sharing files.

## Releases

### Version 0.3.0 - 23 July 2026
- Upgrade to 32.0.12-fpm [valentinab25 - [`e517b457`](https://github.com/eea/helm-charts/commit/e517b4571e4fb03c6576ce4f33253d8bbd052506)]

### Version 0.2.1 - 23 July 2026
- Add healthchecks [valentinab25 - [`cecf6fb8`](https://github.com/eea/helm-charts/commit/cecf6fb8edc7ecba8db449196a575f406e005100)]

### Version 0.2.0 - 05 June 2026
- Upgrade to 31.0.14 [valentinab25 - [`8753f4d0`](https://github.com/eea/helm-charts/commit/8753f4d0142696afbd6bea86e5ae9f2d409f9f8c)]

### Version 0.1.9 - 03 June 2026
- Update nginx to 1.31.1 - Refs [#304237](https://taskman.eionet.europa.eu/issues/304237) [valentinab25 - [`145a1102`](https://github.com/eea/helm-charts/commit/145a11020040a92549b55a82c383b24dee26d907)]

### Version 0.1.8 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`503f99c6`](https://github.com/eea/helm-charts/commit/503f99c640ea017ddf693abd257563e6271c6aae)]

### Version 0.1.7 - 25 November 2025
- Release of dependent chart postfix:3.1.2 [valentinab25 - [`56731dff`](https://github.com/eea/helm-charts/commit/56731dff9ae4718ebfc1648cbbac256954ef8321)]

### Version 0.1.6 - 03 October 2025
- 31.0.9-fpm-alpine update [Silviu - [`deec3808`](https://github.com/eea/helm-charts/commit/deec38085ee116477cccc524bceb5f4742bb0230)]

### Version 0.1.5 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`fc63311c`](https://github.com/eea/helm-charts/commit/fc63311ca08a41abfea27fa1dcde3a48279e99e7)]


### Version 0.1.0
- Initial version.



