# Climate Advisory Board backend - Plone 6

This chart deployes the Climate Advisory Board backend app 


## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| debug.enabled | bool | false | Activate the Plone debug instance |

## Releases

### Version 1.35.0 - 08 March 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-10](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`9678edfd`](https://github.com/eea/helm-charts/commit/9678edfd6967186d7a9a34df18aa66dac35d4e50)]

### Version 1.34.0 - 05 March 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-9](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`9acb967a`](https://github.com/eea/helm-charts/commit/9acb967ae00ababa2674ab3a4840f9dd1b1198c3)]

### Version 1.33.0 - 25 February 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-8](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`49ff1ada`](https://github.com/eea/helm-charts/commit/49ff1adae249167bb681927c47b70b81e7e68324)]

### Version 1.32.0 - 19 February 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-7](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`87c697e8`](https://github.com/eea/helm-charts/commit/87c697e8a83a360ec3624c92edbfc3eafd99c353)]

### Version 1.31.0 - 06 February 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-6](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`1003e9bf`](https://github.com/eea/helm-charts/commit/1003e9bfc8880e7ab19f0cdfd22e26729d199b54)]

### Version 1.30.0 - 28 January 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-5](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`9ab6821a`](https://github.com/eea/helm-charts/commit/9ab6821a779e3c22fb1b6d2aaee89d90c266b427)]

### Version 1.29.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`9bf07072`](https://github.com/eea/helm-charts/commit/9bf07072437a66f6baf1057fcab7bcee605ab580)]

### Version 1.29.0 - 23 December 2025
- Automated release of [eeacms/advisory-board-backend:6.1.3-4](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`a98cb5b9`](https://github.com/eea/helm-charts/commit/a98cb5b90d0e8f40b79aa743906c4f351e78b551)]

### Version 1.28.0 - 22 December 2025
- Automated release of [eeacms/advisory-board-backend:6.1.3-3](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`beb2b675`](https://github.com/eea/helm-charts/commit/beb2b675e9bfc2fb5bb1e26c3271276d8f113888)]

### Version 1.27.0 - 22 December 2025
- Automated release of [eeacms/advisory-board-backend:6.1.3-2](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`e5e920cc`](https://github.com/eea/helm-charts/commit/e5e920cc3490bfb8e4fa06c82dbc9eeb8c48939a)]

### Version 1.26.0 - 20 December 2025
- Automated release of [eeacms/advisory-board-backend:6.1.3-1](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`38346088`](https://github.com/eea/helm-charts/commit/383460884d7028e2f511b2dcf144e390479a19fc)]

### Version 1.25.2 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`2e3c5a12`](https://github.com/eea/helm-charts/commit/2e3c5a128c610825d7f50941df33c8a286803bfd)]

### Version 1.25.1 - 24 November 2025
- Release of dependent chart postfix:3.1.2 [valentinab25 - [`b6751f8b`](https://github.com/eea/helm-charts/commit/b6751f8b5b4a5018edf5f9447939f19b9c18fec3)]

### Version 1.25.0 - 25 October 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-22](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`09cad013`](https://github.com/eea/helm-charts/commit/09cad0136d9540498e1a20e8af4a7fd998f9e4b9)]

### Version 1.24.0 - 24 October 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-21](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`f35e2181`](https://github.com/eea/helm-charts/commit/f35e218186c9bc579d6e98a76508b622b63e75c0)]

### Version 1.23.0 - 08 October 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-20](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`8e413c83`](https://github.com/eea/helm-charts/commit/8e413c83dd9df704e905db595532dd7015d346b7)]

### Version 1.22.1 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`c17a2391`](https://github.com/eea/helm-charts/commit/c17a2391fc050caa61886dea3a90fc9e7168144e)]

### Version 1.22.0 - 20 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-19](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`43aa9770`](https://github.com/eea/helm-charts/commit/43aa97709cb9f88a2c75586a3de872ee1c90b9e0)]

### Version 1.21.0 - 20 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-18](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`3d99aa5f`](https://github.com/eea/helm-charts/commit/3d99aa5ffa1fbd3bb5b405037f297e8c3197eb0e)]

### Version 1.20.0 - 11 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-17](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`4ec1b395`](https://github.com/eea/helm-charts/commit/4ec1b395915bc3d81e1118846a02b6923c1a1a85)]

### Version 1.19.0 - 05 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-16](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`dfc7e5e5`](https://github.com/eea/helm-charts/commit/dfc7e5e516abf6f7471605a0e21110e4326da40d)]

### Version 1.18.0 - 05 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-15](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`44501ce7`](https://github.com/eea/helm-charts/commit/44501ce701ef1f999845aec2f078ae80d2d18a35)]

### Version 1.17.0 - 01 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-14](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`11d9232e`](https://github.com/eea/helm-charts/commit/11d9232eadb868a4e40a2fd9890f684c8f49d1e8)]

### Version 1.16.1 - 01 August 2025
- Automated release of [eeacms/plone-varnish:7.7-1.1](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`25f49f9e`](https://github.com/eea/helm-charts/commit/25f49f9e689b1646bd458dc9d8e390d823a335b1)]

### Version 1.16.0 - 29 July 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-13](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`b2667f63`](https://github.com/eea/helm-charts/commit/b2667f630be4098852829da258257e0c24975ed3)]

### Version 1.15.0 - 23 July 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-12](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`37f2e6cb`](https://github.com/eea/helm-charts/commit/37f2e6cb25a9426d755cae5a8490eb929bc96677)]

### Version 1.14.0 - 03 June 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-10](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`3cd7df1`](https://github.com/eea/helm-charts/commit/3cd7df11a6e2f57378d965910401dd47c609a66b)]

### Version 1.13.0 - 28 May 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-9](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`32d8946`](https://github.com/eea/helm-charts/commit/32d8946a351960a7fe23a3170c7a43c28fd27188)]

### Version 1.12.0 - 21 May 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-8](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`4a4cd21`](https://github.com/eea/helm-charts/commit/4a4cd211a5923f2e205dcce828562afeaeb58c5a)]

### Version 1.11.1 - 21 May 2025
- Automated release of [eeacms/plone-varnish:7.7-1.0](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`ddfb2a9`](https://github.com/eea/helm-charts/commit/ddfb2a9924ac131d6a9973b54456a3e9f0b8e98c)]

### Version 1.11.0 - 20 May 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-7](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`3eab84b`](https://github.com/eea/helm-charts/commit/3eab84bce7cbb8c41f1990b5958a331a651b0846)]

### Version 1.10.3 - 20 May 2025
- Add zodbpack cronjob [valentinab25 - [`0ccb5d1`](https://github.com/eea/helm-charts/commit/0ccb5d190004a0a3b555ba595f4020bada7aac90)]

### Version 1.10.2 - 20 May 2025
- Fix cronjob args [valentinab25 - [`b8a90ff`](https://github.com/eea/helm-charts/commit/b8a90ff4b92826760cff933751921ec378bcdef9)]

### Version 1.10.1 - 20 May 2025
- Add entrasync CronJob [valentinab25 - [`1d66430`](https://github.com/eea/helm-charts/commit/1d66430e40c481cf4237a5c94b97a787a930dc81)]

### Version 1.10.0 - 30 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-6](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`220c7eb`](https://github.com/eea/helm-charts/commit/220c7ebed149f6bf5dd112e10c0c2515129e4894)]

### Version 1.9.0 - 28 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-5](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`7a412ba`](https://github.com/eea/helm-charts/commit/7a412ba6f5691e73557736519082efba26161a71)]

### Version 1.8.0 - 25 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-4](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`966fab1`](https://github.com/eea/helm-charts/commit/966fab179ce7618f37968fc27582d76ede319bf0)]

### Version 1.7.0 - 13 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-3](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`afad03c`](https://github.com/eea/helm-charts/commit/afad03c088b6eb266def3beee31aba28906441e2)]

### Version 1.6.0 - 11 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-2](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`6474bd9`](https://github.com/eea/helm-charts/commit/6474bd97699a064d3bf3492151e4400f638ed8e4)]

### Version 1.5.0 - 09 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.14-1](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`354b4df`](https://github.com/eea/helm-charts/commit/354b4dfaaf743ec4349c2907a2f461a4eac13639)]

### Version 1.4.2 - 09 April 2025
- Added plone.googleUrl variable, separated google ingress [valentinab25 - [`77ad0aa`](https://github.com/eea/helm-charts/commit/77ad0aaa595cbfc4fdd538954992b7897af5a3dd)]

### Version 1.4.1 - 08 April 2025
- Add ingress.tls, plone.site variables, rewrite api-ingress [valentinab25 - [`af3acea`](https://github.com/eea/helm-charts/commit/af3acea1f7d28816aa66ed3cf2813bc5962c7597)]

### Version 1.4.0 - 01 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.13-17](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`dc92069`](https://github.com/eea/helm-charts/commit/dc920696e09d97e7dd6ba56c1753c6748dbced4f)]

### Version 1.3.0 - 13 March 2025
- Automated release of [eeacms/advisory-board-backend:6.0.13-16](https://github.com/eea/advisory-board-backend/releases)

### Version 1.2.1 - 12 March 2025
- Automated release of [eeacms/plone-varnish:7.6-1.0](https://github.com/eea/plone-varnish/releases)

### Version 1.2.0 - 25 February 2025
- Automated release of [eeacms/advisory-board-backend:6.0.13-14](https://github.com/eea/advisory-board-backend/releases)


### Version 1.1.1
- Release of dependent chart postfix:3.0.6
- :warning: Breaking changes - manually remove the postix deployment before upgrade

### Version 1.0.3
- Added `SENTRY_ENVIRONMENT` variable

### Version 1.0.2
- Rename components to backend- 

### Version 1.0.1
- Questions update

### Version 1.0.0
- Initial release. Version matching Rancher 1 catalog version.

