# Logcentral Opensearch 1

This Helm chart deploys Opensearch 1 for the Graylog centralized logging solution based on the Docker Compose template for Rancher 1.

## Releases

### Version 3.1.1 - 06 October 2026
- fix warning [valentinab25 - [`bb8f9042`](https://github.com/eea/helm-charts/commit/bb8f9042961eabc186ebbe939dbd55ecee23ff14)]

### Version 3.1.0 - 06 October 2026
- Upgrade to v2 [valentinab25 - [`670ddccb`](https://github.com/eea/helm-charts/commit/670ddccbdfe36735f76f024a03da16748a6fc7f0)]

### Version 3.0.1 - 04 September 2026
- Fix values file with new format [valentinab25 - [`fb03f7ea`](https://github.com/eea/helm-charts/commit/fb03f7eac3f715628cd0976a49ab058e00cae1f9)]

### Version 3.0.0 - 04 September 2026
- Upgrade to 1.3.20, helm chart 1.35.1 [valentinab25 - [`f3cecc35`](https://github.com/eea/helm-charts/commit/f3cecc358ba63eabc3ba245b073ce04ab069ab11)]
