# MSFD Marine backend

## Releases

### Version 0.98.0 - 30 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-63](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`e48e49b7`](https://github.com/eea/helm-charts/commit/e48e49b7e3e63a9089f55daf3395c33538725485)]

### Version 0.97.0 - 26 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-62](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`f95fcdf7`](https://github.com/eea/helm-charts/commit/f95fcdf79dfc7089ec082fe5eee19e0cddb6aea0)]

### Version 0.96.0 - 18 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-61](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`7c6958cb`](https://github.com/eea/helm-charts/commit/7c6958cb1eb6f0af56a2e55a8166c323fa278dd5)]

### Version 0.95.0 - 11 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-60](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`e0f8c208`](https://github.com/eea/helm-charts/commit/e0f8c208da58106368f1287afa9169b5b8744ba6)]

### Version 0.94.0 - 11 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-59](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`1b2ddfb7`](https://github.com/eea/helm-charts/commit/1b2ddfb70d2d6ee5cf120fe0e7fe36b877fb5d8f)]

### Version 0.93.2 - 10 September 2026
- trigger new release [laszlocseh - [`a9d1e414`](https://github.com/eea/helm-charts/commit/a9d1e4147e455c633388ade8ba5f74c016db6315)]

### Version 0.93.0 - 10 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-58](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`027ec0c4`](https://github.com/eea/helm-charts/commit/027ec0c41d51a5786c36287bd0a137f190c770fa)]

### Version 0.92.0 - 09 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-57](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`59a528af`](https://github.com/eea/helm-charts/commit/59a528af86ee7455a1a53c72c396e04a92b178a1)]

### Version 0.91.0 - 09 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-56](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`7bd803d7`](https://github.com/eea/helm-charts/commit/7bd803d7734d4e4d943fadb1c1229a3fb2483ef3)]

### Version 0.90.1 - 04 September 2026
- chore: Refs [#305742](https://taskman.eionet.europa.eu/issues/305742) - reduce kept failed cronjob pods from 5 to 1 [Claudia Ifrim - [`049b0d5a`](https://github.com/eea/helm-charts/commit/049b0d5abf6f6de98e59141e52e2da252c558c16)]

### Version 0.90.0 - 02 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-55](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`3564c34b`](https://github.com/eea/helm-charts/commit/3564c34bbe003d8290756acccc9029e6abe805ca)]

### Version 0.89.4 - 02 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-54.beta.03](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`1f650196`](https://github.com/eea/helm-charts/commit/1f65019688ccf87a28522c7d142e7b19406ba5fd)]

### Version 0.89.3 - 01 September 2026
- Add eTranslation v2 env variables [laszlocseh - [`69dcb26f`](https://github.com/eea/helm-charts/commit/69dcb26f262dd892f08c095ff7a1e53b8978016c)]

### Version 0.89.2 - 01 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-54.beta.02](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`911eb79c`](https://github.com/eea/helm-charts/commit/911eb79ccbda00697f329464d47eee3d0e381752)]

### Version 0.89.1 - 01 September 2026
- Automated release of [eeacms/msfd-backend:6.1.4-54.beta.01](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`978e1818`](https://github.com/eea/helm-charts/commit/978e1818fe247fd3357dd049dce32abfd09102ef)]

### Version 0.89.0 - 27 August 2026
- Automated release of [eeacms/msfd-backend:6.1.4-54](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5f762b36`](https://github.com/eea/helm-charts/commit/5f762b3642ac1cd301245e2861b733fb88b3de1a)]

### Version 0.88.0 - 26 August 2026
- Automated release of [eeacms/msfd-backend:6.1.4-53](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`1949cc93`](https://github.com/eea/helm-charts/commit/1949cc933b90deb3017ef4b55c2ff125b09186b3)]

### Version 0.87.0 - 22 August 2026
- Automated release of [eeacms/msfd-backend:6.1.4-52](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`19c18dd5`](https://github.com/eea/helm-charts/commit/19c18dd5540b504bbf31ac1fa49a2452b7c3fa5b)]

### Version 0.86.0 - 20 August 2026
- Automated release of [eeacms/msfd-backend:6.1.4-51](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`ce13a4ff`](https://github.com/eea/helm-charts/commit/ce13a4ff138914758dfedbb5cc0b45a5438b65b7)]

### Version 0.85.0 - 14 August 2026
- Automated release of [eeacms/msfd-backend:6.1.4-50](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`495e7440`](https://github.com/eea/helm-charts/commit/495e74406a50f65575f05115c3b858bee2d511e2)]

### Version 0.84.0 - 11 August 2026
- Automated release of [eeacms/msfd-backend:6.1.4-49](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`e864496e`](https://github.com/eea/helm-charts/commit/e864496e70c27f3213a91abe0423df2fab09f715)]

### Version 0.83.0 - 10 August 2026
- Automated release of [eeacms/msfd-backend:6.1.4-48](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`257acd1b`](https://github.com/eea/helm-charts/commit/257acd1b3a89476f683120bf24b14f9fd731dc8d)]

### Version 0.82.0 - 08 August 2026
- Automated release of [eeacms/msfd-backend:6.1.4-47](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`d0dc078b`](https://github.com/eea/helm-charts/commit/d0dc078b3eb93205b3edd704d703813c94fad180)]

### Version 0.81.0 - 07 August 2026
- Automated release of [eeacms/msfd-backend:6.1.4-46](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`51a482f9`](https://github.com/eea/helm-charts/commit/51a482f96279150dec2eef2cfbf2cc3481bd4c63)]

### Version 0.80.0 - 07 August 2026
- Automated release of [eeacms/msfd-backend:6.1.4-45](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`3e12a8d1`](https://github.com/eea/helm-charts/commit/3e12a8d1be19e6c404c63c260b480cc2c9337b5c)]

### Version 0.79.0 - 06 August 2026
- Automated release of [eeacms/msfd-backend:6.1.4-43](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`d1e61847`](https://github.com/eea/helm-charts/commit/d1e61847c342abbc98f411a1059f623f07fc9699)]

### Version 0.78.0 - 30 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-42](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`08905e75`](https://github.com/eea/helm-charts/commit/08905e75b0c2592a1c13c19946809ad9bcd31789)]

### Version 0.77.0 - 29 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-41](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`67a0db2a`](https://github.com/eea/helm-charts/commit/67a0db2a790e293677ecb36a54c70d6697df82ff)]

### Version 0.76.0 - 29 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-40](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`18d6bedc`](https://github.com/eea/helm-charts/commit/18d6bedc9ee4fce1f1a5c2ef9c28bc39c534a120)]

### Version 0.75.0 - 24 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-39](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`d03fc0c3`](https://github.com/eea/helm-charts/commit/d03fc0c3bfca5b7862a7f8f6bb72b4566a5d86c6)]

### Version 0.74.0 - 24 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-38](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`76a15e41`](https://github.com/eea/helm-charts/commit/76a15e410c33fa1e2544e376a471cbc19ebde1d9)]

### Version 0.73.0 - 22 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-37](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`ff8e69ab`](https://github.com/eea/helm-charts/commit/ff8e69ab22e924f76cb8d44feb91cd7e8eb86ba5)]

### Version 0.72.0 - 21 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-36](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`3b53f1ba`](https://github.com/eea/helm-charts/commit/3b53f1bacebc505a9cd88f933418fde9b2e6ffca)]

### Version 0.71.0 - 21 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-35](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5684119b`](https://github.com/eea/helm-charts/commit/5684119b30eaeee685051beb7d871c850ef4ec00)]

### Version 0.70.0 - 20 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-34](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`0be539f0`](https://github.com/eea/helm-charts/commit/0be539f0ddb24f75d5b17ad7ce06f0337486dac3)]

### Version 0.69.0 - 17 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-33](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5f52be37`](https://github.com/eea/helm-charts/commit/5f52be370b2934e04b3f3ce45c56a0f226d16c41)]

### Version 0.68.0 - 16 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-32](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`613cb182`](https://github.com/eea/helm-charts/commit/613cb182f4f7935f8d470caa8d397d4ae673e095)]

### Version 0.67.0 - 16 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-31](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`4dd97041`](https://github.com/eea/helm-charts/commit/4dd970416dd82de84c0c93ee58c68b1516b1fee8)]

### Version 0.66.0 - 14 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-30](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`2535f4d5`](https://github.com/eea/helm-charts/commit/2535f4d58655c0766ca21f1a30d033d73eb19cd0)]

### Version 0.65.0 - 12 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-29](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`4884cf2e`](https://github.com/eea/helm-charts/commit/4884cf2e27381fb057d6dd47dc2274d0b310b7f3)]

### Version 0.64.0 - 10 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-28](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`033a26c7`](https://github.com/eea/helm-charts/commit/033a26c7a41e280f3575db574769823a970c96d9)]

### Version 0.63.0 - 08 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-27](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`ba7f148c`](https://github.com/eea/helm-charts/commit/ba7f148c8c059c8a51e60720ca1c4abd9ee98ce8)]

### Version 0.62.0 - 02 July 2026
- Automated release of [eeacms/msfd-backend:6.1.4-24](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`a41676d3`](https://github.com/eea/helm-charts/commit/a41676d3ca6774e4e268365863b6a54f9025bb6e)]

### Version 0.61.0 - 25 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-23](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`0ffce839`](https://github.com/eea/helm-charts/commit/0ffce839bb694e1721e855533f7c1c8f41ff43be)]

### Version 0.60.0 - 24 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-22](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`519b8502`](https://github.com/eea/helm-charts/commit/519b8502bb0ab0aa6c7515909a3f4f3b7d2b7bcc)]

### Version 0.59.2 - 22 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-21.beta.02](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`0dd09555`](https://github.com/eea/helm-charts/commit/0dd09555cbc379663af8a72c7b2928042b2bcf6f)]

### Version 0.59.1 - 19 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-21.beta.01](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`8c96c74a`](https://github.com/eea/helm-charts/commit/8c96c74a6f45b6dbf8fcc3de4ba6c94373c9d03f)]

### Version 0.59.0 - 18 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-21](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`ed19abe8`](https://github.com/eea/helm-charts/commit/ed19abe8e9b694ad8f36713339e4f2ba4af193e1)]

### Version 0.58.0 - 13 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-20](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`c6baaf65`](https://github.com/eea/helm-charts/commit/c6baaf65f92f8ac910bb0604440d58ceff872e1c)]

### Version 0.57.0 - 11 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-18](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5826a584`](https://github.com/eea/helm-charts/commit/5826a5841d189abfb8a1d5c28e1cd26644c46d0b)]

### Version 0.56.0 - 10 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-17](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`6c534b9c`](https://github.com/eea/helm-charts/commit/6c534b9cc6ef25616bd5cf1567e86fef5d9b80dd)]

### Version 0.55.0 - 04 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-16](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`848c0e82`](https://github.com/eea/helm-charts/commit/848c0e82ba0d3aa691e4bbdb37ae3abc96697484)]

### Version 0.54.0 - 03 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-14](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`8dc66b0c`](https://github.com/eea/helm-charts/commit/8dc66b0cb88c7c2af574aa0733bab9c233da4438)]

### Version 0.53.0 - 03 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-13](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`ddabc992`](https://github.com/eea/helm-charts/commit/ddabc992bf27c6ff32ec3130203a00843a331767)]

### Version 0.52.0 - 02 June 2026
- Automated release of [eeacms/msfd-backend:6.1.4-12](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`6184ca11`](https://github.com/eea/helm-charts/commit/6184ca11dcdedc6433dfb8db5f3cb4dc1a6444fb)]

### Version 0.51.0 - 29 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-11](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`4b88d40e`](https://github.com/eea/helm-charts/commit/4b88d40eb3a265a9a7e07cfc8291cb670110f7ab)]

### Version 0.50.0 - 28 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-10](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5f1828e2`](https://github.com/eea/helm-charts/commit/5f1828e2316fe0990264eea32b8fe0e8647c3d5e)]

### Version 0.49.0 - 26 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-9](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`a07930ee`](https://github.com/eea/helm-charts/commit/a07930eee71aa6b8019e8b074efda2fc542a4079)]

### Version 0.48.0 - 22 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-8](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`22416fe1`](https://github.com/eea/helm-charts/commit/22416fe18289733ea7b8da1c069e8aa59b45c24f)]

### Version 0.47.0 - 19 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-7](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`eff30fc6`](https://github.com/eea/helm-charts/commit/eff30fc62e574df251862ca69ee08228acfc3e5d)]

### Version 0.46.0 - 15 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-6](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`1216801b`](https://github.com/eea/helm-charts/commit/1216801bc5846c16ad80b0268bafb5f04243f033)]

### Version 0.45.0 - 14 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.11](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`623f2f87`](https://github.com/eea/helm-charts/commit/623f2f87f46436992eb416c888453227cc13bb3e)]

### Version 0.44.0 - 14 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.10](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`35427b2f`](https://github.com/eea/helm-charts/commit/35427b2ff8920bb24a1006cef6a6412be77aab6c)]

### Version 0.43.0 - 13 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.09](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`9a72a45b`](https://github.com/eea/helm-charts/commit/9a72a45b7b54f8a877e4727a9f1e7a21752081db)]

### Version 0.42.2 - 13 May 2026
- fix [Dobricean Ioan Dorian - [`16afad62`](https://github.com/eea/helm-charts/commit/16afad62a25c5fb32680fe9d66b10212f47be234)]

### Version 0.42.1 - 13 May 2026
- fix entrasync [Dobricean Ioan Dorian - [`43a0f5e5`](https://github.com/eea/helm-charts/commit/43a0f5e59d443cd7cee73bffe7963651056ac927)]

### Version 0.42.0 - 13 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.08](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`dce238c2`](https://github.com/eea/helm-charts/commit/dce238c258c3bf86f999ba324f02636fea36233b)]

### Version 0.41.3 - 13 May 2026
- fix [Dobricean Ioan Dorian - [`d4d55399`](https://github.com/eea/helm-charts/commit/d4d55399ab1ded09c14d80701c18f006f9f37152)]

### Version 0.41.2 - 13 May 2026
- fix entrasync cron [Dobricean Ioan Dorian - [`2096f928`](https://github.com/eea/helm-charts/commit/2096f928455bdc9f475a54adcda979095bc91308)]

### Version 0.41.1 - 13 May 2026
- fix entrasync [Dobricean Ioan Dorian - [`15dc6ebd`](https://github.com/eea/helm-charts/commit/15dc6ebd5e3706ed33cbdd42988e49af91a1fa3d)]

### Version 0.41.0 - 13 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.07](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`b9d96e01`](https://github.com/eea/helm-charts/commit/b9d96e012ee5d73ad4d125b5545c8a4fb4939684)]

### Version 0.40.0 - 13 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.06](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`772a4fbc`](https://github.com/eea/helm-charts/commit/772a4fbcbbcd927248168b4b57caf6c32a732dbe)]

### Version 0.39.0 - 12 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.05](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`2e4f2daa`](https://github.com/eea/helm-charts/commit/2e4f2daa156fc98e87523cfad190ab091b26a36f)]

### Version 0.38.0 - 11 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.04](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`70ee582f`](https://github.com/eea/helm-charts/commit/70ee582f5b38b63b41aaf802e3f03831ed93d30f)]

### Version 0.37.0 - 11 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.03](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`a4c480ff`](https://github.com/eea/helm-charts/commit/a4c480ff9a17550c4dad469b96fcaea9c29910f0)]

### Version 0.36.0 - 11 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.02](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`251e4d60`](https://github.com/eea/helm-charts/commit/251e4d6096fa85cec37e709aad3e663ec08b6661)]

### Version 0.35.1 - 11 May 2026
- fix ingress [Dobricean Ioan Dorian - [`84bb475d`](https://github.com/eea/helm-charts/commit/84bb475d3bd4bb6073f91734e50d130adfa82316)]

### Version 0.35.0 - 11 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.01](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5a1e9768`](https://github.com/eea/helm-charts/commit/5a1e9768ee5a6c2bc52a84a4a85e2d08ba321d0d)]

### Version 0.34.0 - 11 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`941fdbb6`](https://github.com/eea/helm-charts/commit/941fdbb6d8f554a05ec29ef9a4d820032ee947da)]

### Version 0.33.0 - 08 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-4](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5480673d`](https://github.com/eea/helm-charts/commit/5480673dc1831c1044616c05f60693d6d3420bbb)]

### Version 0.32.0 - 08 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-3.entraId.01](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`a44f08bd`](https://github.com/eea/helm-charts/commit/a44f08bdcd7a3ac23c6801d6fde48cde28691c06)]

### Version 0.31.4 - 06 May 2026
- fix ingresses [Dobricean Ioan Dorian - [`632e382a`](https://github.com/eea/helm-charts/commit/632e382a133af3ea4ac891ec4bf3fd387e65bb71)]

### Version 0.31.3 - 06 May 2026
- fix ingresses [Dobricean Ioan Dorian - [`4aed3af4`](https://github.com/eea/helm-charts/commit/4aed3af460f04352e3473cf88f9e710e601c64a3)]

### Version 0.31.2 - 06 May 2026
- add more exceptions [Dobricean Ioan Dorian - [`4882d941`](https://github.com/eea/helm-charts/commit/4882d94111889aa530192e575197367185dbbba5)]

### Version 0.31.1 - 06 May 2026
- fix ingress msfd [Dobricean Ioan Dorian - [`3ef45746`](https://github.com/eea/helm-charts/commit/3ef4574611430ec362e88f73f36d965206364af0)]

### Version 0.31.0 - 06 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-3](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`591d60e4`](https://github.com/eea/helm-charts/commit/591d60e4dcc866773dea0a0c2cd0d6d29b504dfb)]

### Version 0.30.0 - 29 April 2026
- Automated release of [eeacms/msfd-backend:6.1.4-2](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`19dbdc55`](https://github.com/eea/helm-charts/commit/19dbdc55684852dded475cc90a15683fb400f433)]

### Version 0.29.0 - 29 April 2026
- Automated release of [eeacms/msfd-backend:6.1.4-1](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5c48bf83`](https://github.com/eea/helm-charts/commit/5c48bf8395cf0a7fe532fa7d88ee5fd2e0f5f8d2)]

### Version 0.28.0 - 22 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-20](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`50f8d7f4`](https://github.com/eea/helm-charts/commit/50f8d7f4f0270644b358f3fbf7caac487156e266)]

### Version 0.27.0 - 18 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-19](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`c2f54c1b`](https://github.com/eea/helm-charts/commit/c2f54c1b7e7243e580eac078ebfc2d714904d15f)]

### Version 0.26.0 - 17 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-18](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`f0a8e4f5`](https://github.com/eea/helm-charts/commit/f0a8e4f56b9187ec4c50391db050b0ff40ffe65c)]

### Version 0.25.0 - 16 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-17](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`53cb6e0d`](https://github.com/eea/helm-charts/commit/53cb6e0ded7c3d419231eaa3a5e9b15c829822e9)]

### Version 0.24.0 - 15 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-16](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`37fdd4ea`](https://github.com/eea/helm-charts/commit/37fdd4eae4df6ec1536677ed56122bb2ad7f1bfc)]

### Version 0.23.1 - 14 April 2026
- add plone registry yaml [Dobricean Ioan Dorian - [`af314e3b`](https://github.com/eea/helm-charts/commit/af314e3b4f76789ac24cab9d527bc76b19d6394b)]

### Version 0.23.0 - 14 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-15](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`068a141f`](https://github.com/eea/helm-charts/commit/068a141f161dc199bc4885180cf08e08466b22b3)]

### Version 0.22.0 - 02 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-14](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`84fcb7d6`](https://github.com/eea/helm-charts/commit/84fcb7d6559e11f332bd6798e59ddcedb6f1a04c)]

### Version 0.21.0 - 01 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-13](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`38b34165`](https://github.com/eea/helm-charts/commit/38b341653c5fc91c2c7e5e37ff8305e8a39a41ec)]

### Version 0.20.0 - 01 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-12.entraId.02](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`8821cf93`](https://github.com/eea/helm-charts/commit/8821cf93960fa7ea8757744a2219a9cc36f537ee)]

### Version 0.19.3 - 30 March 2026
- make for zeo [Dobricean Ioan Dorian - [`48a2c612`](https://github.com/eea/helm-charts/commit/48a2c612fbce86ec90d730920b8be804d3a50d2c)]

### Version 0.19.2 - 30 March 2026
- fix entrasync [Dobricean Ioan Dorian - [`a66e6bfb`](https://github.com/eea/helm-charts/commit/a66e6bfb1b615ce39e67f2796546a2b75342f0e1)]

### Version 0.19.1 - 30 March 2026
- cronjob entrasync [Dobricean Ioan Dorian - [`09e8ea66`](https://github.com/eea/helm-charts/commit/09e8ea66186a41d56c15fed315debd6e1ed315ad)]

### Version 0.18.0 - 18 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-12](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`f1c136e6`](https://github.com/eea/helm-charts/commit/f1c136e66068327aa4931925f4bb8dd2d00630b2)]

### Version 0.17.0 - 18 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-11](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`70a71015`](https://github.com/eea/helm-charts/commit/70a7101538eeadd01ef93d61e77c40dfa990426b)]

### Version 0.16.0 - 16 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-10](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`8a174aad`](https://github.com/eea/helm-charts/commit/8a174aad5fe5419bcf17a082c56c5f5ad90ad0a9)]

### Version 0.15.0 - 12 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-7](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`bbaa8564`](https://github.com/eea/helm-charts/commit/bbaa85647046fb6727beeafb504d95663726ea4f)]

### Version 0.14.0 - 12 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-6](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`3c548623`](https://github.com/eea/helm-charts/commit/3c5486232a486e7cd54c87293e0bd8187cbf87a7)]

### Version 0.13.1 - 11 March 2026
- fix command and port [Dobricean Ioan Dorian - [`7d7e2890`](https://github.com/eea/helm-charts/commit/7d7e289063d2f1922fa1b58a7e5f002bafc968be)]

### Version 0.13.0 - 11 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-5](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`357e76b2`](https://github.com/eea/helm-charts/commit/357e76b254c0a2ffde280698214e1fe9b91ea5f0)]

### Version 0.12.0 - 11 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-4](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`c712c9bc`](https://github.com/eea/helm-charts/commit/c712c9bc7aaf8ae887eb84869252e3354a482335)]

### Version 0.11.1 - 11 March 2026
- change zeo iamge [Dobricean Ioan Dorian - [`3b7f4c11`](https://github.com/eea/helm-charts/commit/3b7f4c11eab1631e04a82b7dff5d7ecdc00aedc0)]

### Version 0.11.0 - 10 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-2](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`806a9fb0`](https://github.com/eea/helm-charts/commit/806a9fb0c21fc29434f44f4b9b656a13f524184a)]

### Version 0.10.0 - 09 March 2026
- update  msfd image [Dobricean Ioan Dorian - [`75bf6490`](https://github.com/eea/helm-charts/commit/75bf6490c0461042378e31aefec97996e7860a3a)]

### Version 0.9.1 - 08 March 2026
- choose storage [Dobricean Ioan Dorian - [`935ca6fb`](https://github.com/eea/helm-charts/commit/935ca6fbd759bf485da414d97dc346ad6c245100)]

### Version 0.9.0 - 02 March 2026
- Automated release of [eeacms/msfd-backend:5.2.13-14](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5e0748c8`](https://github.com/eea/helm-charts/commit/5e0748c8b92c128dec6a7484bfd9de8ad130d4c0)]

### Version 0.8.0 - 26 February 2026
- Automated release of [eeacms/msfd-backend:5.2.13-11](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`bb62a9c2`](https://github.com/eea/helm-charts/commit/bb62a9c205ce5410c46552300d1544aff307af75)]

### Version 0.7.0 - 11 February 2026
- Automated release of [eeacms/msfd-backend:5.2.13-9](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`cdb8baca`](https://github.com/eea/helm-charts/commit/cdb8baca2248e3263c4a87030643ab8d58e0fe48)]

### Version 0.6.0 - 04 February 2026
- Automated release of [eeacms/msfd-backend:5.2.13-8](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`240a241f`](https://github.com/eea/helm-charts/commit/240a241f9b665b6fa6ac0acf3cdcda1f7b8cc199)]

### Version 0.5.0 - 04 February 2026
- Automated release of [eeacms/msfd-backend:5.2.13-7](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`7da487d5`](https://github.com/eea/helm-charts/commit/7da487d539a473976b06ca09c13e599a7497eb42)]

### Version 0.4.0 - 04 February 2026
- Automated release of [eeacms/msfd-backend:5.2.13-6](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`89297e76`](https://github.com/eea/helm-charts/commit/89297e76a9fce303ae5f22a6a963f4121a2a77aa)]

### Version 0.3.0 - 30 January 2026
- Automated release of [eeacms/msfd-backend:5.2.13-5](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`f453f435`](https://github.com/eea/helm-charts/commit/f453f4350043a4bbc829821eadcdf0e15dc2b69e)]

### Version 0.2.0 - 29 January 2026
- Automated release of [eeacms/msfd-backend:5.2.13-4](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`26db93d1`](https://github.com/eea/helm-charts/commit/26db93d12c5d8a6d77e8736b29e44a735f7c5f92)]

### Version 0.1.47 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`5ce7488a`](https://github.com/eea/helm-charts/commit/5ce7488a023979ad9929f5b0d4a4e2beb85130b8)]

### Version 0.1.46 - 15 January 2026
- fix plone cache [Dobricean Ioan Dorian - [`6c2593c0`](https://github.com/eea/helm-charts/commit/6c2593c019c9fadbc85671cc8eb7c95159a58b66)]

### Version 0.1.44 - 15 January 2026
- fix pvc [Dobricean Ioan Dorian - [`c3332461`](https://github.com/eea/helm-charts/commit/c333246137162c6b44764f518149812dcafa4d6c)]

### Version 0.1.42 - 15 January 2026
- fix pvc claims [Dobricean Ioan Dorian - [`d9b7f71c`](https://github.com/eea/helm-charts/commit/d9b7f71c5e01e85bcf375b405d78d733900f8a14)]

### Version 0.1.40 - 14 January 2026
- fix ingress [Dobricean Ioan Dorian - [`cc3fcbee`](https://github.com/eea/helm-charts/commit/cc3fcbee46ff344a12e599f170c5d1478a06cc9b)]

### Version 0.1.38 - 30 December 2025
- change varnish image [Dobricean Ioan Dorian - [`7e9c99e0`](https://github.com/eea/helm-charts/commit/7e9c99e04b50859d6a0441ab29cdb2ce365b053f)]

### Version 0.1.22 - 28 December 2025
- fix ingress [Dobricean Ioan Dorian - [`8996367e`](https://github.com/eea/helm-charts/commit/8996367eaeb97ad21e000fb6418b2eb894621e84)]

### Version 0.1.20 - 28 December 2025
- fix theme ingress [Dobricean Ioan Dorian - [`852b2234`](https://github.com/eea/helm-charts/commit/852b2234f0364cc0ce26e0812f914c66a7a4a677)]

### Version 0.1.18 - 24 December 2025
- fix [Dobricean Ioan Dorian - [`53fa8c57`](https://github.com/eea/helm-charts/commit/53fa8c5761884b82f20f60bb1d303663950b777b)]

### Version 0.1.17 - 24 December 2025
- fix [Dobricean Ioan Dorian - [`0c6fc14c`](https://github.com/eea/helm-charts/commit/0c6fc14c53ce41bff05ac93d7bcd615f62b01222)]

### Version 0.1.16 - 23 December 2025
- fix memcached [Dobricean Ioan Dorian - [`2616a7af`](https://github.com/eea/helm-charts/commit/2616a7af6a0140c5b6268a94321da73dbc169f44)]

### Version 0.1.15 - 23 December 2025
- fix [Dobricean Ioan Dorian - [`a64a1b68`](https://github.com/eea/helm-charts/commit/a64a1b68e7622ae8378b9741cfef5d2e96efe83a)]

### Version 0.1.14 - 23 December 2025
- fix command [Dobricean Ioan Dorian - [`4145f9a6`](https://github.com/eea/helm-charts/commit/4145f9a64057466df4aa79a393ee31fe20538fba)]

### Version 0.1.13 - 23 December 2025
- fix zeo command [Dobricean Ioan Dorian - [`c4ce68dc`](https://github.com/eea/helm-charts/commit/c4ce68dc80fffbec43268d3b7cb39bea5e23c93d)]

### Version 0.1.12 - 23 December 2025
- fix zeo image [Dobricean Ioan Dorian - [`ce92b508`](https://github.com/eea/helm-charts/commit/ce92b5088e1e50254000020e9668782c5d8012d1)]

### Version 0.1.11 - 23 December 2025
- exterlname [Dobricean Ioan Dorian - [`8811a5db`](https://github.com/eea/helm-charts/commit/8811a5dbed8563300428d72dc555837e4a970392)]

### Version 0.1.10 - 22 December 2025
- fix service name [Dobricean Ioan Dorian - [`6ae338f4`](https://github.com/eea/helm-charts/commit/6ae338f42b2b39051c811048ce16496861727619)]

### Version 0.1.9 - 22 December 2025
- fix backend msfd [Dobricean Ioan Dorian - [`eb552570`](https://github.com/eea/helm-charts/commit/eb5525702191d620f30e5941e039ed2e8de36399)]

### Version 0.1.8 - 22 December 2025
- fix port [Dobricean Ioan Dorian - [`45c33604`](https://github.com/eea/helm-charts/commit/45c33604f12cfc6947884d390b7b59ad79386024)]

### Version 0.1.7 - 22 December 2025
- fix [Dobricean Ioan Dorian - [`c072beae`](https://github.com/eea/helm-charts/commit/c072beae84d4b4c085138b1e2a34d78a6bf1de3e)]

### Version 0.1.6 - 22 December 2025
- remove zeo command [Dobricean Ioan Dorian - [`7c238c75`](https://github.com/eea/helm-charts/commit/7c238c7544c86c40c37b461bd4f74cc901c01f60)]

### Version 0.1.5 - 22 December 2025
- fix marine zeo [Dobricean Ioan Dorian - [`a2f27804`](https://github.com/eea/helm-charts/commit/a2f27804e67e277a3b05fe57dda4576cc549ee35)]

### Version 0.1.4 - 22 December 2025
- fix [Dobricean Ioan Dorian - [`a65aacbd`](https://github.com/eea/helm-charts/commit/a65aacbdc417a8c460ef5f90da2144b80b17f85d)]

### Version 0.1.3 - 22 December 2025
- change zeo mode in zeoserver [Dobricean Ioan Dorian - [`b5c70c0e`](https://github.com/eea/helm-charts/commit/b5c70c0ee4c6661c02fcfe0a9df8419a0988eec3)]

### Version 0.1.2 - 22 December 2025
- fix memchached zeo [Dobricean Ioan Dorian - [`1dd12f44`](https://github.com/eea/helm-charts/commit/1dd12f4476795b9fbbaceeef02ed3aeb02f0e8b1)]

### Version 0.1.1 - 22 December 2025
- zeo configuration [Dobricean Ioan Dorian - [`1aab59ab`](https://github.com/eea/helm-charts/commit/1aab59ab931ea298da794b85220b7426a5fa2363)]

### Version 0.1.0 - 22 December 2025
- Initial release based on marine-backend chart
- Configured for /marine/assessment-module path
