# Wise Marine backend - Plone 6

## Releases

### Version 1.28.0 - 05 March 2026
- modify database connection [Dobricean Ioan Dorian - [`7dc66b7d`](https://github.com/eea/helm-charts/commit/7dc66b7dbb97042acca41e94cc5a308be78603f6)]

### Version 1.27.0 - 25 February 2026
- Automated release of [eeacms/marine-backend:6.1.3-demo](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`5ff2fa67`](https://github.com/eea/helm-charts/commit/5ff2fa6754db4f16d10ef326b25a8d9f41bb4f66)]

### Version 1.26.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`3fb339e0`](https://github.com/eea/helm-charts/commit/3fb339e046bb39480f8f5f04500c53c4828d53d0)]

### Version 1.26.0 - 09 January 2026
- Automated release of [eeacms/marine-backend:6.0.15-22](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`02a7f65e`](https://github.com/eea/helm-charts/commit/02a7f65efac7bdd891c3d6b0f25aa21724fbd0eb)]

### Version 1.25.6 - 28 December 2025
- fix ingress [Dobricean Ioan Dorian - [`f0431ca3`](https://github.com/eea/helm-charts/commit/f0431ca340af932b1d0d05328ffc8d77c001133f)]

### Version 1.25.4 - 19 December 2025
- add missing vars" [Dobricean Ioan Dorian - [`b4c790f4`](https://github.com/eea/helm-charts/commit/b4c790f411d30f17db64b8bc9574fa37309d8da1)]

### Version 1.25.3 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`1df2d5ee`](https://github.com/eea/helm-charts/commit/1df2d5eec51e5f37509c1e8f2be6ce4fe5f734c6)]
