# Wise Marine backend - Plone 6

## Releases

### Version 1.105.1 - 08 October 2026
- Automated release of [eeacms/marine-backend:6.1.4-53.beta.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`6aae4be0`](https://github.com/eea/helm-charts/commit/6aae4be0a659ba143a12dc1222fb3c6601c0e7c0)]

### Version 1.105.0 - 02 October 2026
- Automated release of [eeacms/marine-backend:6.1.4-53](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`def691a8`](https://github.com/eea/helm-charts/commit/def691a8053ea89f7a389ff1f9ddb3e234771438)]

### Version 1.104.0 - 30 September 2026
- Automated release of [eeacms/marine-backend:6.1.4-52](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`c15aaaff`](https://github.com/eea/helm-charts/commit/c15aaaff8327af65543a0b01b8c39b99d032befa)]

### Version 1.103.0 - 27 September 2026
- Automated release of [eeacms/marine-backend:6.1.4-51](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`867a8381`](https://github.com/eea/helm-charts/commit/867a83815fc53a9fd17ca73d930ae576456f5682)]

### Version 1.102.0 - 19 September 2026
- Automated release of [eeacms/marine-backend:6.1.4-50](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`fa3d976a`](https://github.com/eea/helm-charts/commit/fa3d976a1007bc5f76807ecc6a6dca22a2c0604d)]

### Version 1.101.0 - 12 September 2026
- Automated release of [eeacms/marine-backend:6.1.4-49](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a1c662c2`](https://github.com/eea/helm-charts/commit/a1c662c214ba31e10eee431f34a1bb1603e54c77)]

### Version 1.100.0 - 11 September 2026
- Automated release of [eeacms/marine-backend:6.1.4-48](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`f7c4e31c`](https://github.com/eea/helm-charts/commit/f7c4e31c71ea41e8c7e5fcf78551949fa8767b85)]

### Version 1.99.0 - 10 September 2026
- Automated release of [eeacms/marine-backend:6.1.4-47](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a2078b28`](https://github.com/eea/helm-charts/commit/a2078b280cd100524fed22bd5a232eb449b0cff7)]

### Version 1.98.0 - 09 September 2026
- Automated release of [eeacms/marine-backend:6.1.4-46](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`d14c1e8a`](https://github.com/eea/helm-charts/commit/d14c1e8acdc35f02c336babeb1f68802aa5da5cc)]

### Version 1.97.0 - 04 September 2026
- Automated release of [eeacms/marine-backend:6.1.4-45.demo.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`28a5ee85`](https://github.com/eea/helm-charts/commit/28a5ee853a2a5cfba883d67e5028993c6c0a9a37)]

### Version 1.96.1 - 04 September 2026
- chore: Refs [#305742](https://taskman.eionet.europa.eu/issues/305742) - reduce kept failed cronjob pods from 5 to 1 [Claudia Ifrim - [`9ad28aa1`](https://github.com/eea/helm-charts/commit/9ad28aa12c78f076274aef3bed2153087e7b15e3)]

### Version 1.96.0 - 03 September 2026
- Automated release of [eeacms/marine-backend:6.1.4-45](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a088fe02`](https://github.com/eea/helm-charts/commit/a088fe02e5521f6965ba64c556597f2aa0295075)]

### Version 1.95.0 - 28 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-44](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`338e073a`](https://github.com/eea/helm-charts/commit/338e073a801d0f44db4f491e9a2a43b58e3f4d96)]

### Version 1.94.0 - 25 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-43](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`6f34f8c4`](https://github.com/eea/helm-charts/commit/6f34f8c46dc2118aacc60eed9c517ff0c537cb64)]

### Version 1.93.0 - 22 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-42](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`d3ccf9b6`](https://github.com/eea/helm-charts/commit/d3ccf9b6a9b40b9d3cce2e2b1c72d524a240289a)]

### Version 1.92.0 - 21 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-41](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`9af10ffd`](https://github.com/eea/helm-charts/commit/9af10ffd2214acf90c57b8da368ac726f43603de)]

### Version 1.91.1 - 20 August 2026
- Add INTERNAL_URL_PREFIXES env var for eea.volto.policy safety net [Claudia Ifrim - [`c54a3f51`](https://github.com/eea/helm-charts/commit/c54a3f513598bb9edeabcb454a5d7169b83b3c69)]

### Version 1.91.0 - 15 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-40](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`1ebde146`](https://github.com/eea/helm-charts/commit/1ebde146db5def6297e374d1b142635358bc3ce4)]

### Version 1.90.0 - 12 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-39](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`fd90fb85`](https://github.com/eea/helm-charts/commit/fd90fb85290ee217e530775ac146da27c11ac3a1)]

### Version 1.89.1 - 11 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-38.beta.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`48f69626`](https://github.com/eea/helm-charts/commit/48f6962619a0abceb1f938464632acd6527d7801)]

### Version 1.89.0 - 11 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-38](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`78042587`](https://github.com/eea/helm-charts/commit/780425875e3e94e576cc9938a305fadd469251aa)]

### Version 1.88.5 - 10 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-37.beta.05](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`53e5fb21`](https://github.com/eea/helm-charts/commit/53e5fb219e16f9d7bf197ca66491452de8a19f05)]

### Version 1.88.4 - 10 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-37.beta.04](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`951df806`](https://github.com/eea/helm-charts/commit/951df80643b772f2ff777973632867ed70a86fd8)]

### Version 1.88.3 - 10 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-37.beta.03](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`3b8d2af2`](https://github.com/eea/helm-charts/commit/3b8d2af2426a7dfac03c8a4dd133fb653c5e85b5)]

### Version 1.88.2 - 10 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-37.beta.02](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a31b0685`](https://github.com/eea/helm-charts/commit/a31b06859ffc797bdd972836a0b961e5b757e4d6)]

### Version 1.88.1 - 10 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-37.beta.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`0479744f`](https://github.com/eea/helm-charts/commit/0479744fbfad541fa4c3321cff6015437fde9cee)]

### Version 1.88.0 - 09 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-37](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`87e29b98`](https://github.com/eea/helm-charts/commit/87e29b98ddeb3647387b9efbde5f46f7a8dd7a5f)]

### Version 1.87.0 - 07 August 2026
- Automated release of [eeacms/marine-backend:6.1.4-36](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`8e16ecea`](https://github.com/eea/helm-charts/commit/8e16ecead707f9a5af88081650f77e9de32f7cc5)]

### Version 1.86.1 - 30 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-35.beta.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`e066682e`](https://github.com/eea/helm-charts/commit/e066682e32ca745e3939ebbe4585c80b0761eaf8)]

### Version 1.86.0 - 30 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-35](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a1f5a4ef`](https://github.com/eea/helm-charts/commit/a1f5a4ef4d058c5f4564e73e9f83003114595a08)]

### Version 1.85.0 - 29 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-34](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`71aee502`](https://github.com/eea/helm-charts/commit/71aee5027502e4c5f75639ab37ebd3577b16dfa6)]

### Version 1.84.1 - 27 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-33.beta.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`aba2eace`](https://github.com/eea/helm-charts/commit/aba2eace89d4b6a38eb8f49f02fe8326be678e04)]

### Version 1.84.0 - 24 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-33](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`e5500100`](https://github.com/eea/helm-charts/commit/e5500100e5308a8b8a6c6fce85fc21b20f76c65d)]

### Version 1.83.2 - 24 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-32.beta.03](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`055a3dca`](https://github.com/eea/helm-charts/commit/055a3dcaaccce0986fd5a122cb310a9ef4c6801b)]

### Version 1.83.1 - 24 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-32.beta.02](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`45345d69`](https://github.com/eea/helm-charts/commit/45345d69c8a94c9673d747dfc91c6d021f7b669b)]

### Version 1.83.0 - 24 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-32](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`5c82ffba`](https://github.com/eea/helm-charts/commit/5c82ffbaef42a15850ba234c67d8c3254ba01633)]

### Version 1.82.0 - 22 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-31](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a4b576c7`](https://github.com/eea/helm-charts/commit/a4b576c7d279273c4171843ad77aab11193c2cee)]

### Version 1.81.0 - 20 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-30](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`24a86931`](https://github.com/eea/helm-charts/commit/24a86931b7b162b8259d0a41dede76d89a6443bc)]

### Version 1.80.0 - 17 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-29](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`94d6b3cb`](https://github.com/eea/helm-charts/commit/94d6b3cbdee0fdf9664f2742c91611047fadbecd)]

### Version 1.79.1 - 17 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-28.beta.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`1a4411fe`](https://github.com/eea/helm-charts/commit/1a4411fea81f68b7fee9c0e211fb68a318183788)]

### Version 1.79.0 - 15 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-27](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`de61ab3c`](https://github.com/eea/helm-charts/commit/de61ab3cf59fda83ea13f4d9e8896349fab51015)]

### Version 1.78.1 - 14 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-26.beta.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`1ecc7ece`](https://github.com/eea/helm-charts/commit/1ecc7eceb42eca52d1af131dda0131cc07f3317c)]

### Version 1.78.0 - 14 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-26](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`74b6e7d9`](https://github.com/eea/helm-charts/commit/74b6e7d9d4ccea4ef2c10ce5601d55e470cf6fb9)]

### Version 1.77.0 - 12 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-25](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`6a49d157`](https://github.com/eea/helm-charts/commit/6a49d157342db4dc00e654ae75f3d2f24824c30d)]

### Version 1.76.0 - 08 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-24](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`cfc138ad`](https://github.com/eea/helm-charts/commit/cfc138ada1babe5f496945e12898221f4c57d9c0)]

### Version 1.75.0 - 05 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-23](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`4b2928f9`](https://github.com/eea/helm-charts/commit/4b2928f95bfd9908fcb73298faa172de0a94adad)]

### Version 1.74.0 - 01 July 2026
- Automated release of [eeacms/marine-backend:6.1.4-22](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`168cf57d`](https://github.com/eea/helm-charts/commit/168cf57d77acb3fc319dd75402b5dd2f3bf526b5)]

### Version 1.73.1 - 26 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-21.beta.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`265fa5d3`](https://github.com/eea/helm-charts/commit/265fa5d38e4ffef1f3bb86c17b74427dcf4f7b77)]

### Version 1.73.0 - 26 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-21](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`d2de411c`](https://github.com/eea/helm-charts/commit/d2de411ca5b61641b37a9b5673f62e82e4d0abab)]

### Version 1.72.0 - 24 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-20](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`609c1e1e`](https://github.com/eea/helm-charts/commit/609c1e1eacad8b5fdbdbda14624adc761e14d759)]

### Version 1.71.0 - 18 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-19](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`fb63c842`](https://github.com/eea/helm-charts/commit/fb63c842f3388d60ea64e643daed06204580eb17)]

### Version 1.70.4 - 16 June 2026
- increase cpu for cronjobs [Dobricean Ioan Dorian - [`00702b52`](https://github.com/eea/helm-charts/commit/00702b524b8295cdcce63a42c3b931eb017686aa)]

### Version 1.70.3 - 15 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-18.beta.03](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`57e306e7`](https://github.com/eea/helm-charts/commit/57e306e7f9ee030d362893a370e0b56ce3f04cbf)]

### Version 1.70.2 - 12 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-18.beta.02](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`76ef0f7e`](https://github.com/eea/helm-charts/commit/76ef0f7efeae12dd3e02b4b80c263ef204e1dbce)]

### Version 1.70.1 - 12 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-18.beta.01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`3d481dd4`](https://github.com/eea/helm-charts/commit/3d481dd495373ccd480ad61da2d1c72abf3487ad)]

### Version 1.70.0 - 12 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-18](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`5d8e2f95`](https://github.com/eea/helm-charts/commit/5d8e2f95cd0b9ce6a23790d39232cfc8929e0e8a)]

### Version 1.69.0 - 12 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-17](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`9c6dc968`](https://github.com/eea/helm-charts/commit/9c6dc96801db095b96f2f0c2d17ed5b4e6c87d73)]

### Version 1.68.0 - 11 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-16](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`93e7018e`](https://github.com/eea/helm-charts/commit/93e7018ed6b519f8d0f9749ac3bc48cfb90c4fc7)]

### Version 1.67.0 - 10 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-15](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`e73312fe`](https://github.com/eea/helm-charts/commit/e73312fe3ea274e1e4ce015360dead8bb327dbe6)]

### Version 1.66.0 - 04 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-13](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`47276182`](https://github.com/eea/helm-charts/commit/47276182c303d36755e5fe32773ce4ebf62814cf)]

### Version 1.65.0 - 04 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-12](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`86a9dc13`](https://github.com/eea/helm-charts/commit/86a9dc138e05b5ae0090ed0daf333b29af96bbe3)]

### Version 1.64.0 - 03 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-11](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`50e1037a`](https://github.com/eea/helm-charts/commit/50e1037a3733dabe4837ddced13be80bc003caef)]

### Version 1.63.0 - 03 June 2026
- Automated release of [eeacms/marine-backend:6.1.4-10](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`167ffdda`](https://github.com/eea/helm-charts/commit/167ffdda7908e064320fba23790acc947086fe9b)]

### Version 1.62.0 - 29 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-9](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`f00c9b48`](https://github.com/eea/helm-charts/commit/f00c9b48ec932f8d2ea1bd5d3f6ed2d18100b8d1)]

### Version 1.61.0 - 28 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-8](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`dcbd8222`](https://github.com/eea/helm-charts/commit/dcbd82229f510bc98706126855cd199f21e20d4b)]

### Version 1.60.0 - 22 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-7](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`1e421035`](https://github.com/eea/helm-charts/commit/1e421035a84410f71053c9be9468040c47663d0f)]

### Version 1.59.0 - 16 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-6](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`8705d5e1`](https://github.com/eea/helm-charts/commit/8705d5e1c26d3bc23e5435b792ed65774d47cd67)]

### Version 1.58.0 - 09 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-4](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`4f49571b`](https://github.com/eea/helm-charts/commit/4f49571b7a48b19d7d82109dbfb0c559929ccb05)]

### Version 1.57.0 - 06 May 2026
- Automated release of [eeacms/marine-backend:6.1.4-3](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`154733cb`](https://github.com/eea/helm-charts/commit/154733cb25b4999ec00c2a8f362eeb4ad1375a6d)]

### Version 1.56.0 - 29 April 2026
- Automated release of [eeacms/marine-backend:6.1.4-2](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`e1446990`](https://github.com/eea/helm-charts/commit/e14469906524d31b64c2850b201b2135036c908a)]

### Version 1.55.0 - 29 April 2026
- Automated release of [eeacms/marine-backend:6.1.4-1](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`5f19b56a`](https://github.com/eea/helm-charts/commit/5f19b56a7999501f62eaaa56088fe2f01676b176)]

### Version 1.54.0 - 22 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-25](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`ff3262e4`](https://github.com/eea/helm-charts/commit/ff3262e4d178b2c47a3b5087224a160187bc3d3c)]

### Version 1.53.0 - 18 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-24](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`4dfbd709`](https://github.com/eea/helm-charts/commit/4dfbd70964d48b4f5655c06954675da215a204cd)]

### Version 1.52.0 - 18 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-23](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`23e4fef1`](https://github.com/eea/helm-charts/commit/23e4fef173b9769d4f8f95e7e71ad6e02806f2e7)]

### Version 1.51.0 - 17 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-22](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`611b2795`](https://github.com/eea/helm-charts/commit/611b2795aef215c61916f2080b148c1a8a5f6b04)]

### Version 1.50.0 - 16 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-21](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`5b93e18e`](https://github.com/eea/helm-charts/commit/5b93e18ef21393e6b1fcfa25f876040d2a682ce8)]

### Version 1.49.0 - 15 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-20](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`cb1beab3`](https://github.com/eea/helm-charts/commit/cb1beab307ba3e56f7ef71a7b97714e75d0b57bd)]

### Version 1.48.0 - 14 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-19](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a0abd2c1`](https://github.com/eea/helm-charts/commit/a0abd2c1ef991926920897912cee86e9fc3df2ca)]

### Version 1.47.0 - 13 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-18](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`fd47f610`](https://github.com/eea/helm-charts/commit/fd47f610ded18dcaf44d20f1df81304e16bb8886)]

### Version 1.46.0 - 11 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-17](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`14acc86b`](https://github.com/eea/helm-charts/commit/14acc86bde34fdb28a864d8a88186a4d390be42d)]

### Version 1.45.0 - 10 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-16](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`d375bc31`](https://github.com/eea/helm-charts/commit/d375bc31abf1e58749d1073625508fe035ddbf59)]

### Version 1.44.0 - 10 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-15](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`1d7a3762`](https://github.com/eea/helm-charts/commit/1d7a3762f437a542e5ef7da44059470c7389212f)]

### Version 1.43.0 - 08 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-14](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`6aa2c1c4`](https://github.com/eea/helm-charts/commit/6aa2c1c4c04ac661b98c16db656c459f10a58510)]

### Version 1.42.0 - 07 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-13](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`f9fe2fc1`](https://github.com/eea/helm-charts/commit/f9fe2fc104e278e9d7a228450e5214be5b10e213)]

### Version 1.41.0 - 07 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-12](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`74b76e2c`](https://github.com/eea/helm-charts/commit/74b76e2c45b9ed0dcac5a106b1cf3a125c56d5ad)]

### Version 1.40.0 - 06 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-11](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a726c2af`](https://github.com/eea/helm-charts/commit/a726c2aff1c1ea116f2404c488d649be15de93d1)]

### Version 1.39.0 - 06 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-10](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`0a4c301d`](https://github.com/eea/helm-charts/commit/0a4c301d8b69df0908e1162c4bf572141c532363)]

### Version 1.38.0 - 04 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-9](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`6a800cf9`](https://github.com/eea/helm-charts/commit/6a800cf96b59cda6e27bd345c8daba9ae0d7f043)]

### Version 1.37.0 - 03 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-8](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`8d932d4b`](https://github.com/eea/helm-charts/commit/8d932d4b92d994d2fb01833f37c08ed4a4423e40)]

### Version 1.36.0 - 02 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-7](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`c7bae737`](https://github.com/eea/helm-charts/commit/c7bae737494cfb85faf49e3fa47ee25f9417b296)]

### Version 1.35.0 - 01 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-6](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`a1eb4f26`](https://github.com/eea/helm-charts/commit/a1eb4f2674d458cdb91cd3ea97c9146a19c26c21)]

### Version 1.34.0 - 01 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-5](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`2973dcf0`](https://github.com/eea/helm-charts/commit/2973dcf03c6bde4dc96db4b6c6dc1212e23bbdbe)]

### Version 1.33.0 - 01 April 2026
- Automated release of [eeacms/marine-backend:6.1.3-4](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`58a139f4`](https://github.com/eea/helm-charts/commit/58a139f474a292182d4ed4accb295f684f2f6105)]

### Version 1.32.0 - 19 March 2026
- Automated release of [eeacms/marine-backend:6.1.3-x03](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`4202ae70`](https://github.com/eea/helm-charts/commit/4202ae708586f4d996ce1d0555611fb749454010)]

### Version 1.31.0 - 19 March 2026
- Automated release of [eeacms/marine-backend:6.1.3-x02](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`2c30de27`](https://github.com/eea/helm-charts/commit/2c30de27ae3f886d03d528d0d62b9ecc4d3f4282)]

### Version 1.30.0 - 19 March 2026
- Automated release of [eeacms/marine-backend:6.1.3-x01](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`99f06747`](https://github.com/eea/helm-charts/commit/99f06747ce28dc4dbe9b0f03bce195111b5f8694)]

### Version 1.29.0 - 09 March 2026
- Automated release of [eeacms/marine-backend:6.1.3-prod.02](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`3f00030a`](https://github.com/eea/helm-charts/commit/3f00030a312e2020eaa019ffb3f1ad15d485f665)]

### Version 1.28.6 - 09 March 2026
- fix error [Dobricean Ioan Dorian - [`898b83fe`](https://github.com/eea/helm-charts/commit/898b83fe1a393cf78049cc3ccec03fdff5c425c2)]

### Version 1.28.4 - 06 March 2026
- fix ingress marine [Dobricean Ioan Dorian - [`d225ca6e`](https://github.com/eea/helm-charts/commit/d225ca6e18da1bfae4c74b9ab978510222922a44)]

### Version 1.28.3 - 05 March 2026
- fix [Dobricean Ioan Dorian - [`fa9f280d`](https://github.com/eea/helm-charts/commit/fa9f280d91a96f46983ac937d82f3b77fed0313a)]

### Version 1.28.1 - 05 March 2026
- devel image [Dobricean Ioan Dorian - [`a8b9795f`](https://github.com/eea/helm-charts/commit/a8b9795ffaf202d58e323211cac6b0fdeeb0c343)]

### Version 1.28.0 - 05 March 2026
- modify database connection [Dobricean Ioan Dorian - [`7dc66b7d`](https://github.com/eea/helm-charts/commit/7dc66b7dbb97042acca41e94cc5a308be78603f6)]

### Version 1.27.0 - 25 February 2026
- Automated release of [eeacms/marine-backend:6.1.3-demo](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`5ff2fa67`](https://github.com/eea/helm-charts/commit/5ff2fa6754db4f16d10ef326b25a8d9f41bb4f66)]

### Version 1.26.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`3fb339e0`](https://github.com/eea/helm-charts/commit/3fb339e046bb39480f8f5f04500c53c4828d53d0)]

### Version 1.26.0 - 09 January 2026
- Automated release of [eeacms/marine-backend:6.0.15-22](https://github.com/eea/marine-backend/releases) [EEA Jenkins - [`02a7f65e`](https://github.com/eea/helm-charts/commit/02a7f65efac7bdd891c3d6b0f25aa21724fbd0eb)]

### Version 1.25.6 - 28 December 2025
- fix ingress [Dobricean Ioan Dorian - [`f0431ca3`](https://github.com/eea/helm-charts/commit/f0431ca340af932b1d0d05328ffc8d77c001133f)]

### Version 1.25.4 - 19 December 2025
- add missing vars" [Dobricean Ioan Dorian - [`b4c790f4`](https://github.com/eea/helm-charts/commit/b4c790f411d30f17db64b8bc9574fa37309d8da1)]

### Version 1.25.3 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`1df2d5ee`](https://github.com/eea/helm-charts/commit/1df2d5eec51e5f37509c1e8f2be6ce4fe5f734c6)]
