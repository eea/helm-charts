# Releases

### Version 0.29.0 - 11 June 2026
- Automated release of [eeacms/jenkins-master:2.568](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`e5e9695d`](https://github.com/eea/helm-charts/commit/e5e9695db34931a26a17439fcb910b4f4b1f2aa4)]

### Version 0.28.0 - 02 June 2026
- Automated release of [eeacms/jenkins-master:2.567](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`c67c3863`](https://github.com/eea/helm-charts/commit/c67c38636e0526d3bc0f952bb312df8ba186c1d2)]

### Version 0.27.0 - 26 May 2026
- Automated release of [eeacms/jenkins-master:2.566](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`31fbe921`](https://github.com/eea/helm-charts/commit/31fbe921c96aaa30e2089c813c4ef4dcf598fd93)]

### Version 0.26.0 - 19 May 2026
- Automated release of [eeacms/jenkins-master:2.565](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`05f54832`](https://github.com/eea/helm-charts/commit/05f54832e1edab15bfce39edfb0c6b96520850f8)]

### Version 0.25.0 - 13 May 2026
- Automated release of [eeacms/jenkins-master:2.564](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`9e18259d`](https://github.com/eea/helm-charts/commit/9e18259db3a3c0b66b23b45cb9cc689c5c38447c)]

### Version 0.24.0 - 06 May 2026
- Automated release of [eeacms/jenkins-master:2.563](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`9dd6d7a0`](https://github.com/eea/helm-charts/commit/9dd6d7a01b6fc793588fab6f64709e14df1b1d43)]

### Version 0.23.0 - 28 April 2026
- Automated release of [eeacms/jenkins-master:2.562](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`09cf6789`](https://github.com/eea/helm-charts/commit/09cf6789ce0ec5bc22e8e1cedde1eb3301d4048c)]

### Version 0.22.0 - 15 April 2026
- Automated release of [eeacms/jenkins-master:2.559](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`7810dbcb`](https://github.com/eea/helm-charts/commit/7810dbcba70477e43e3cb5c1086a913e2aa923a7)]

### Version 0.21.0 - 07 April 2026
- Automated release of [eeacms/jenkins-master:2.558](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`89036d24`](https://github.com/eea/helm-charts/commit/89036d24ce9484a5835b68455f416efef965ac87)]

### Version 0.20.0 - 30 March 2026
- Automated release of [eeacms/jenkins-master:2.556](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`90d3a078`](https://github.com/eea/helm-charts/commit/90d3a0786327c06c2fc0cb69319f23e6867077d8)]

### Version 0.19.0 - 19 March 2026
- Automated release of [eeacms/jenkins-master:2.555](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`ecfb59c0`](https://github.com/eea/helm-charts/commit/ecfb59c0bf9eb2c5f298d291a382196ae3cd3c8c)]

### Version 0.18.0 - 13 March 2026
- Automated release of [eeacms/jenkins-master:2.554](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`8d77a467`](https://github.com/eea/helm-charts/commit/8d77a46783cf0d3674b011568c61998af9468138)]

### Version 0.17.0 - 03 March 2026
- Automated release of [eeacms/jenkins-master:2.553](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`e4697a5f`](https://github.com/eea/helm-charts/commit/e4697a5fad43817db522521dcb63ffe961b0f97c)]

### Version 0.16.0 - 19 February 2026
- Automated release of [eeacms/jenkins-master:2.551](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`87031653`](https://github.com/eea/helm-charts/commit/870316530e83e8e33f1f3fc43f6e982178baa220)]

### Version 0.15.0 - 06 February 2026
- Automated release of [eeacms/jenkins-master:2.549](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`77e083e6`](https://github.com/eea/helm-charts/commit/77e083e6acff702b8dd05fbbd1751d361ef38bfb)]

### Version 0.14.0 - 28 January 2026
- Automated release of [eeacms/jenkins-master:2.548](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`7fe01642`](https://github.com/eea/helm-charts/commit/7fe016428f9d9237a50bcfb7121684d7a081174e)]

### Version 0.13.0 - 26 January 2026
- Automated release of [eeacms/jenkins-master:2.547](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`b4912dde`](https://github.com/eea/helm-charts/commit/b4912dde78ca1c646f209632fd0d2da5554a96ee)]

### Version 0.12.0 - 13 January 2026
- Automated release of [eeacms/jenkins-master:2.546](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`2bdd3560`](https://github.com/eea/helm-charts/commit/2bdd3560dcee4fcd5fad3fead263a7b10610bce6)]

### Version 0.11.0 - 12 January 2026
- Automated release of [eeacms/jenkins-master:2.545](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`d253e6b9`](https://github.com/eea/helm-charts/commit/d253e6b9d5272fd01fc08c4fdd8be3d9e0207f45)]

### Version 0.10.0 - 30 December 2025
- Automated release of [eeacms/jenkins-master:2.544](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`3e9706a6`](https://github.com/eea/helm-charts/commit/3e9706a6c7d5e33d469a6a395bcf6455ae368a21)]

### Version 0.9.0 - 29 December 2025
- Automated release of [eeacms/jenkins-master:2.543](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`d4ff2738`](https://github.com/eea/helm-charts/commit/d4ff2738940bf7baa0647f0d25940836a06cd86f)]

### Version 0.8.0 - 19 December 2025
- Automated release of [eeacms/jenkins-master:2.542](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`80009556`](https://github.com/eea/helm-charts/commit/800095560f6544be43fa1e8822543fc47e097fd3)]

### Version 0.7.0 - 04 December 2025
- Automated release of [eeacms/jenkins-master:2.540](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`3530695c`](https://github.com/eea/helm-charts/commit/3530695c77ce984652cd52532c2cd4d0d8a0eae6)]

### Version 0.6.0 - 18 November 2025
- Automated release of [eeacms/jenkins-master:2.537](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`23c6d51c`](https://github.com/eea/helm-charts/commit/23c6d51c33357696b0a4ef803c194ea7803cd1bb)]

### Version 0.5.0 - 29 October 2025
- Automated release of [eeacms/jenkins-master:2.534](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`eba05207`](https://github.com/eea/helm-charts/commit/eba0520778eab559a11a707092d3c795cc9bd4fb)]

### Version 0.4.0 - 09 October 2025
- Automated release of [eeacms/jenkins-master:2.531](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`9a7ec3bd`](https://github.com/eea/helm-charts/commit/9a7ec3bd795c574589ab33b24ba8a7aa63d802e8)]

### Version 0.3.0 - 25 September 2025
- Automated release of [eeacms/jenkins-master:2.529](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`0a6a4491`](https://github.com/eea/helm-charts/commit/0a6a44917966dc101e49fdefa49224c60381bb4f)]

### Version 0.2.0 - 19 September 2025
- Automated release of [eeacms/jenkins-master:2.528](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`4a89bdb2`](https://github.com/eea/helm-charts/commit/4a89bdb20ee508b23ef46b662a2c276687a621e2)]

### Version 0.1.0 - 30 July 2025
- Automated release of [eeacms/jenkins-master:2.521](https://github.com/eea/eea.docker.jenkins.master/releases) [EEA Jenkins - [`5741e87d`](https://github.com/eea/helm-charts/commit/5741e87dcb6ad15e422ef9c33a20c9fc2e751cc5)]

### Version 0.0.4 - 23 July 2025
- upgrade jenkins to 2.519 [Silviu - [`5986202d`](https://github.com/eea/helm-charts/commit/5986202df63605c5f81214222e7bd5c54a8c1245)]

### Version 0.0.3 - 22 May 2025
- add postfix dependency [Silviu - [`d290348`](https://github.com/eea/helm-charts/commit/d290348d66326caa0fe5e974db98726e33f3c56c)]

### Version 0.0.2 - 21 May 2025
- parch helm package nameing [Silviu - [`cf47ee3`](https://github.com/eea/helm-charts/commit/cf47ee3d735aa6ad46aa3ea2aa2fe08b2718f524)]
