RDFData
=======

The RDFData site is the website where we generate RDF out of Eurostat SDMX files. We also store RDF files that don't belong anywhere else to be able to harvest them from CR or SDS.

There is a script that runs every Saturday to download new Eurostat files and create RDF. Some of these are then harvested by the Semantic Data Service.

## Releases

<dl>
  <dt>Version 1.0.6 - 02 Sept. 2026</dt>
  <dd>Upgrade Apache to version 2.4.68-alpine3.24.</dd>

  <dt>Version 1.0.5</dt>
  <dd>Upgrade Apache to version 2.4.63-alpine3.21.</dd>

  <dt>Version 1.0.4</dt>
  <dd>Upgrade Apache to version 2.4.58-alpine3.19.</dd>

  <dt>Version 1.0.3</dt>
  <dd>Make buildsw optional.
      Upgrade Apache to version 2.4.58.</dd>

</dl>
