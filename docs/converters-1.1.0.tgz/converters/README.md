# Converters

This chart is configured for production use.

## Releases

<dl>
  <dt>Version 1.1.0</dt>
  <dd>Job executor Java 17 upgrade.</dd>

  <dt>Version 1.0.0</dt>
  <dd>FME Flow REST API V4 migration.</dd>

  <dt>Version 0.3.2</dt>
  <dd>Tomcat 10MB max post size.</dd>

  <dt>Version 0.3.1</dt>
  <dd>Job executor logging pattern update.</dd>

  <dt>Version 0.3.0</dt>
  <dd>Remove dependency on Eionet portal stylesheets, remove GELF logging, remove heart beat logging meant for other worker.</dd>

  <dt>Version 0.2.3</dt>
  <dd>Scheduled task deletes stuck workers from Rancher and database.</dd>

  <dt>Version 0.2.2</dt>
  <dd>Job executor manual ACK.</dd>

  <dt>Version 0.2.1</dt>
  <dd>Transactional cron job.</dd>

  <dt>Version 0.2.0</dt>
  <dd>Delete stuck workers cron job, delete heart beat queue on app shutdown</dd>

  <dt>Version 0.1.13</dt>
  <dd>httpServletRequest is not exposed in new thymeleaf version fix.</dd>

  <dt>Version 0.1.12</dt>
  <dd>Deprecated th:include attribute, formatting fixes.</dd>

  <dt>Version 0.1.11</dt>
  <dd>Thymeleaf, log4j upgrades, invalid property fix.</dd>

  <dt>Version 0.1.10</dt>
  <dd>Send message to rabbitmq after transaction is committed, sonarqube update use of branches</dd>

  <dt>Version 0.1.9</dt>
  <dd>Libraries and tomcat upgrades.</dd>

  <dt>Version 0.1.8</dt>
  <dd>Libraries upgrades.</dd>

  <dt>Version 0.1.7</dt>
  <dd>Job not found check.</dd>

  <dt>Version 0.1.6</dt>
  <dd>Use token instead of basic auth for FME communication.</dd>

  <dt>Version 0.1.5</dt>
  <dd>Graylog config.</dd>

  <dt>Version 0.1.4</dt>
  <dd>Java 17 upgrade.</dd>

  <dt>Version 0.1.3</dt>
  <dd>Tomcat/libraries upgrades.</dd>

  <dt>Version 0.1.2</dt>
  <dd>Missing env variable.</dd>

  <dt>Version 0.1.1</dt>
  <dd>Asyncfme database upgrade.</dd>

  <dt>Version 0.1.0</dt>
  <dd>Initial version.</dd>

</dl>

