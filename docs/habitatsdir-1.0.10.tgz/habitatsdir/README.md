# Nature Directives expert review tool

This chart is configured to require little or no configuration for development and test usage.

If you need to modify, then create a new .yaml file with the modifications.

For the database password, use the default values, or if you already have an existing database,
set the values in the database section.

## Production

It is assumed you have done helm add repo eea-charts https://eea.github.io/helm-charts/

To set the app up for Article 17 do:
    Use a private repository for the production configuration.
    Then copy art17-values.yaml from the sources and add the passwords etc.
    helm install art17 habitatsdir -f art17-values.yaml

To set the app up for Article 12 do:
    Use a private repository for the production configuration.
    Then copy art12-values.yaml from the sources and add the passwords etc.
    helm install art17 habitatsdir -f art12-values.yaml

## Releases

### Version 1.0.10 - 13 August 2026
- Upgraded eeacms/art17-consultation:4.0.12 [Olimpiu Rob - [`3cb6e4ff`](https://github.com/eea/helm-charts/commit/3cb6e4ffea2f9d6318f41695f35d71288554a04d)]

### Version 1.0.9 - 31 July 2026
- Upgraded eeacms/art17-consultation:4.0.11 [Diana Boiangiu - [`8ab113ab`](https://github.com/eea/helm-charts/commit/8ab113ab3a7964de649e8e235df79a611ba43814)]

### Version 1.0.8 - 27 July 2026
- Upgraded eeacms/art17-consultation:4.0.10 [Diana Boiangiu - [`7d6e0207`](https://github.com/eea/helm-charts/commit/7d6e02070ca4e106fec586d8e18caa675836a661)]

### Version 1.0.7 - 11 June 2026
- Upgraded eeacms/art17-consultation:4.0.8 [Diana Boiangiu - [`a29a32c6`](https://github.com/eea/helm-charts/commit/a29a32c6de72c89c120a88f29de33cbc17c56116)]

### Version 1.0.6 - 03 June 2026
- Update nginx to 1.31.1 - Refs [#304237](https://taskman.eionet.europa.eu/issues/304237) [valentinab25 - [`10c3152a`](https://github.com/eea/helm-charts/commit/10c3152a6999ef8fefceab5ff6db2b8813211a75)]

### Version 1.0.5 - 27 May 2026
- Upgraded eeacms/art17-consultation:4.0.7 [Diana Boiangiu - [`9cfdffe9`](https://github.com/eea/helm-charts/commit/9cfdffe98fedab039ec2e38733d85d0a9a1ed57c)]

### Version 1.0.4 - 13 May 2026
- Upgraded eeacms/art17-consultation [Diana Boiangiu - [`0885442a`](https://github.com/eea/helm-charts/commit/0885442a01c18151366f38b04aea4d007c3f79ac)]

### Version 1.0.3 - 07 May 2026
- Upgraded eeacms/art17-consultation [Diana Boiangiu - [`d3d741c9`](https://github.com/eea/helm-charts/commit/d3d741c9a4a87bd90340f40c1abe67921319f673)]

### Version 1.0.2 - 07 May 2026
- Upgraded eeacms/art17-consultation [Diana Boiangiu - [`220ddf10`](https://github.com/eea/helm-charts/commit/220ddf10d2936faae34d932ece83211467827812)]

### Version 1.0.1 - 07 May 2026
- Upgraded eeacms/eeacms/art17-consultation  [Diana Boiangiu - [`769d9f14`](https://github.com/eea/helm-charts/commit/769d9f14f166dedcb47726cb1fb7663964ad4656)]

### Version 1.0.0 - 24 April 2026
- Upgraded eeacms/eeacms/art17-consultation [Diana Boiangiu - [`f3311cb6`](https://github.com/eea/helm-charts/commit/f3311cb6c737f3b68ce061956242b0913093e6bc)]

### Version 0.4.13 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`231ba58c`](https://github.com/eea/helm-charts/commit/231ba58c2cc9e2b3e1e8619d8943f1bfb82e5d93)]

### Version 0.4.12 - 06 October 2025
- Update habitatsdir art17-values.yaml file [Diana Boiangiu - [`4f266e5f`](https://github.com/eea/helm-charts/commit/4f266e5fc85b80559a86287175663fd121cc151a)]

### Version 0.4.11 - 06 October 2025
- Update habitatsdir art12-values.yaml file [Diana Boiangiu - [`a1305c15`](https://github.com/eea/helm-charts/commit/a1305c150621d0fa0ef40ef1becbc334cebbe7b4)]

### Version 0.4.10 - 29 September 2025
- Release on habitatsdir version 0.4.10 [Diana Boiangiu - [`bd7adc9e`](https://github.com/eea/helm-charts/commit/bd7adc9ea7e68c9bd961f11b76100c9fe65efb27)]

### Version 0.4.9 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`d8254400`](https://github.com/eea/helm-charts/commit/d8254400f6daf9436a933c38d5033fad6264b5a1)]


### Version 0.4.8 - 24 February 2025
- Remove unused mysql service

### Version 0.4.7 - 03 February 2025
- Upgraded eeacms/eeacms/art17-consultation

### Version 0.4.6 - 15 November 2024
- Upgraded eeacms/eeacms/art17-consultation

### Version 0.4.5 - 13 November 2024
- Upgraded eeacms/art12-viewer

### Version 0.4.4 - 30 October 2024
- Upgraded eeacms/art12-viewer

### Version 0.4.3 - 3 September 2024
- Reverted incorrect use of values.yaml file. Updated version of postfix subchart to 2.0.0.

### Version 0.4.2
- Upgraded art17 ingress.

### Version 0.4.1
  <dd>Update eeacms/art17-consultation and eeacms/art12-viewer<dd>

### Version 0.4.0
- Replace mailfwd with postfix subchart.

### Version 0.3.3
- Hardwire versions of mariadb and postgresql.

### Version 0.3.2
- Also allow ingress to reach static resources.

### Version 0.3.1
- More network security policies for ingress.

### Version 0.3.0
- Added network security policy to prevent egress from database pods.


