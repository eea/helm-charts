# Climate Advisory Board backend - Plone 6

This chart deployes the Climate Advisory Board backend app 


## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| debug.enabled | bool | false | Activate the Plone debug instance |

## Releases

### Version 1.64.0 - 02 October 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-24](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`a929ee28`](https://github.com/eea/helm-charts/commit/a929ee286e7953642aab8315da9258b77f58e25a)]

### Version 1.63.0 - 01 October 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-23](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`be9be804`](https://github.com/eea/helm-charts/commit/be9be804155eafd8dfafbab23cd27f348a6cdfe2)]

### Version 1.62.0 - 29 September 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-22](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`66d00bbc`](https://github.com/eea/helm-charts/commit/66d00bbc5b17ccd72fae363d6fed9a4389c7f0be)]

### Version 1.61.0 - 26 September 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-21](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`a1c537ae`](https://github.com/eea/helm-charts/commit/a1c537ae7a864123208738fcdc04bbe9dd7fce55)]

### Version 1.60.0 - 18 September 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-20](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`021ca834`](https://github.com/eea/helm-charts/commit/021ca83467638efacc1f22be5c2b072d79ab934d)]

### Version 1.59.0 - 20 August 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-19](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`b38a74c2`](https://github.com/eea/helm-charts/commit/b38a74c2810e5a6bde03f0c53735995f512bd956)]

### Version 1.58.0 - 19 August 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-18](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`7c8bfa37`](https://github.com/eea/helm-charts/commit/7c8bfa37d07f93c34f13a07b4f5e33564b048a09)]

### Version 1.57.0 - 08 August 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-17](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`c665be11`](https://github.com/eea/helm-charts/commit/c665be1187310467462f6a330a95e222534c4655)]

### Version 1.56.0 - 07 August 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-16](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`82f83a11`](https://github.com/eea/helm-charts/commit/82f83a118d5d988df2b3380021448a1d4604a2e1)]

### Version 1.55.0 - 06 August 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-15](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`4ef20ec9`](https://github.com/eea/helm-charts/commit/4ef20ec9f188c5040cc466119b3d7e91b8854e51)]

### Version 1.54.0 - 29 July 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-14](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`3133296d`](https://github.com/eea/helm-charts/commit/3133296d5f937b11de7999412b5254b71effe56f)]

### Version 1.53.0 - 14 July 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-13](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`c6c2297e`](https://github.com/eea/helm-charts/commit/c6c2297ea1ee4efa06307892132b38bf4af4eecd)]

### Version 1.52.0 - 14 July 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-12](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`c95236fb`](https://github.com/eea/helm-charts/commit/c95236fb3332c675941b931df7b7424ea32a6c3d)]

### Version 1.51.0 - 11 July 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-11](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`1dfdce41`](https://github.com/eea/helm-charts/commit/1dfdce41487617a9d2bc27339930064f24977184)]

### Version 1.50.0 - 07 July 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-10](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`2b5f6215`](https://github.com/eea/helm-charts/commit/2b5f62159c08e8d4a2510aa833d7b9988c89751b)]

### Version 1.49.0 - 05 July 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-9](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`157ccc43`](https://github.com/eea/helm-charts/commit/157ccc431dd077565885f0931d6783ac4c9c71cc)]

### Version 1.48.0 - 25 June 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-8](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`403a5e89`](https://github.com/eea/helm-charts/commit/403a5e89e87eda30e31da3fd54ee23ef94679615)]

### Version 1.47.0 - 18 June 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-7](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`c0ad60c6`](https://github.com/eea/helm-charts/commit/c0ad60c6834b8fb4cb649abcc4de8e36f252d87d)]

### Version 1.46.0 - 18 June 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-6](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`24cc3e10`](https://github.com/eea/helm-charts/commit/24cc3e10a7e7f474800d2e86030edc7898932ef9)]

### Version 1.45.6 - 15 June 2026
- secure email [Dobricean Ioan Dorian - [`dba22525`](https://github.com/eea/helm-charts/commit/dba22525772e7821fe33b02ba002407aed1777fe)]

### Version 1.45.5 - 15 June 2026
- Blocked /++api++/@email-send and /++api++/@email-notification

### Version 1.45.4 - 14 June 2026
- basic auth [Dobricean Ioan Dorian - [`8430089f`](https://github.com/eea/helm-charts/commit/8430089f2032cddaeb374a71dcc68003c963a315)]

### Version 1.45.3 - 14 June 2026
- Added basic auth to /admin

### Version 1.45.2 - 14 June 2026
- fix cronjob [Dobricean Ioan Dorian - [`c161978f`](https://github.com/eea/helm-charts/commit/c161978ff83ec1dcedfd324fd00e2f000dada624)]

### Version 1.45.1 - 14 June 2026
- Increase zodbpack and entrasync CronJob CPU resources and add entrasync timeout

### Version 1.45.0 - 04 June 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-5](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`21d0934b`](https://github.com/eea/helm-charts/commit/21d0934bc97e6e8e68a17fc831ebc319a45aec91)]

### Version 1.44.0 - 27 May 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-4](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`e90c5e51`](https://github.com/eea/helm-charts/commit/e90c5e515f638c57d1224b04e743f14bd0030358)]

### Version 1.43.0 - 22 May 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-3](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`379ae6f9`](https://github.com/eea/helm-charts/commit/379ae6f922b4ee671cad248d53e2fe02045a5893)]

### Version 1.42.0 - 29 April 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-2](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`105b14b3`](https://github.com/eea/helm-charts/commit/105b14b32895a1bb16ef0ba6610d169aa3da8daf)]

### Version 1.41.0 - 29 April 2026
- Automated release of [eeacms/advisory-board-backend:6.1.4-1](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`ae92d550`](https://github.com/eea/helm-charts/commit/ae92d55064fe2c3365ec2b29fa81213aedb2a06d)]

### Version 1.40.0 - 22 April 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-16](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`77abad52`](https://github.com/eea/helm-charts/commit/77abad52d603ab35ef05e47fa0e66eeae727ef71)]

### Version 1.39.0 - 18 April 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-15](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`6a3bd18c`](https://github.com/eea/helm-charts/commit/6a3bd18c3d0f7ff0956fb7d05f26f4996bf16fdf)]

### Version 1.38.0 - 17 April 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-14](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`cc8a7f9a`](https://github.com/eea/helm-charts/commit/cc8a7f9ad76f84ddcb5d96504f7ac4d36014c16c)]

### Version 1.37.0 - 15 April 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-12](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`7c34ad49`](https://github.com/eea/helm-charts/commit/7c34ad49a3218d57ec4d92b0070c7d543631be2b)]

### Version 1.36.0 - 26 March 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-11](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`2c780b79`](https://github.com/eea/helm-charts/commit/2c780b79b33e11cb0d67a3d424165f77972855e6)]

### Version 1.35.0 - 08 March 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-10](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`9678edfd`](https://github.com/eea/helm-charts/commit/9678edfd6967186d7a9a34df18aa66dac35d4e50)]

### Version 1.34.0 - 05 March 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-9](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`9acb967a`](https://github.com/eea/helm-charts/commit/9acb967ae00ababa2674ab3a4840f9dd1b1198c3)]

### Version 1.33.0 - 25 February 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-8](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`49ff1ada`](https://github.com/eea/helm-charts/commit/49ff1adae249167bb681927c47b70b81e7e68324)]

### Version 1.32.0 - 19 February 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-7](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`87c697e8`](https://github.com/eea/helm-charts/commit/87c697e8a83a360ec3624c92edbfc3eafd99c353)]

### Version 1.31.0 - 06 February 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-6](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`1003e9bf`](https://github.com/eea/helm-charts/commit/1003e9bfc8880e7ab19f0cdfd22e26729d199b54)]

### Version 1.30.0 - 28 January 2026
- Automated release of [eeacms/advisory-board-backend:6.1.3-5](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`9ab6821a`](https://github.com/eea/helm-charts/commit/9ab6821a779e3c22fb1b6d2aaee89d90c266b427)]

### Version 1.29.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`9bf07072`](https://github.com/eea/helm-charts/commit/9bf07072437a66f6baf1057fcab7bcee605ab580)]

### Version 1.29.0 - 23 December 2025
- Automated release of [eeacms/advisory-board-backend:6.1.3-4](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`a98cb5b9`](https://github.com/eea/helm-charts/commit/a98cb5b90d0e8f40b79aa743906c4f351e78b551)]

### Version 1.28.0 - 22 December 2025
- Automated release of [eeacms/advisory-board-backend:6.1.3-3](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`beb2b675`](https://github.com/eea/helm-charts/commit/beb2b675e9bfc2fb5bb1e26c3271276d8f113888)]

### Version 1.27.0 - 22 December 2025
- Automated release of [eeacms/advisory-board-backend:6.1.3-2](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`e5e920cc`](https://github.com/eea/helm-charts/commit/e5e920cc3490bfb8e4fa06c82dbc9eeb8c48939a)]

### Version 1.26.0 - 20 December 2025
- Automated release of [eeacms/advisory-board-backend:6.1.3-1](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`38346088`](https://github.com/eea/helm-charts/commit/383460884d7028e2f511b2dcf144e390479a19fc)]

### Version 1.25.2 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`2e3c5a12`](https://github.com/eea/helm-charts/commit/2e3c5a128c610825d7f50941df33c8a286803bfd)]

### Version 1.25.1 - 24 November 2025
- Release of dependent chart postfix:3.1.2 [valentinab25 - [`b6751f8b`](https://github.com/eea/helm-charts/commit/b6751f8b5b4a5018edf5f9447939f19b9c18fec3)]

### Version 1.25.0 - 25 October 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-22](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`09cad013`](https://github.com/eea/helm-charts/commit/09cad0136d9540498e1a20e8af4a7fd998f9e4b9)]

### Version 1.24.0 - 24 October 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-21](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`f35e2181`](https://github.com/eea/helm-charts/commit/f35e218186c9bc579d6e98a76508b622b63e75c0)]

### Version 1.23.0 - 08 October 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-20](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`8e413c83`](https://github.com/eea/helm-charts/commit/8e413c83dd9df704e905db595532dd7015d346b7)]

### Version 1.22.1 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`c17a2391`](https://github.com/eea/helm-charts/commit/c17a2391fc050caa61886dea3a90fc9e7168144e)]

### Version 1.22.0 - 20 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-19](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`43aa9770`](https://github.com/eea/helm-charts/commit/43aa97709cb9f88a2c75586a3de872ee1c90b9e0)]

### Version 1.21.0 - 20 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-18](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`3d99aa5f`](https://github.com/eea/helm-charts/commit/3d99aa5ffa1fbd3bb5b405037f297e8c3197eb0e)]

### Version 1.20.0 - 11 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-17](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`4ec1b395`](https://github.com/eea/helm-charts/commit/4ec1b395915bc3d81e1118846a02b6923c1a1a85)]

### Version 1.19.0 - 05 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-16](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`dfc7e5e5`](https://github.com/eea/helm-charts/commit/dfc7e5e516abf6f7471605a0e21110e4326da40d)]

### Version 1.18.0 - 05 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-15](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`44501ce7`](https://github.com/eea/helm-charts/commit/44501ce701ef1f999845aec2f078ae80d2d18a35)]

### Version 1.17.0 - 01 August 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-14](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`11d9232e`](https://github.com/eea/helm-charts/commit/11d9232eadb868a4e40a2fd9890f684c8f49d1e8)]

### Version 1.16.1 - 01 August 2025
- Automated release of [eeacms/plone-varnish:7.7-1.1](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`25f49f9e`](https://github.com/eea/helm-charts/commit/25f49f9e689b1646bd458dc9d8e390d823a335b1)]

### Version 1.16.0 - 29 July 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-13](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`b2667f63`](https://github.com/eea/helm-charts/commit/b2667f630be4098852829da258257e0c24975ed3)]

### Version 1.15.0 - 23 July 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-12](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`37f2e6cb`](https://github.com/eea/helm-charts/commit/37f2e6cb25a9426d755cae5a8490eb929bc96677)]

### Version 1.14.0 - 03 June 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-10](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`3cd7df1`](https://github.com/eea/helm-charts/commit/3cd7df11a6e2f57378d965910401dd47c609a66b)]

### Version 1.13.0 - 28 May 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-9](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`32d8946`](https://github.com/eea/helm-charts/commit/32d8946a351960a7fe23a3170c7a43c28fd27188)]

### Version 1.12.0 - 21 May 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-8](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`4a4cd21`](https://github.com/eea/helm-charts/commit/4a4cd211a5923f2e205dcce828562afeaeb58c5a)]

### Version 1.11.1 - 21 May 2025
- Automated release of [eeacms/plone-varnish:7.7-1.0](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`ddfb2a9`](https://github.com/eea/helm-charts/commit/ddfb2a9924ac131d6a9973b54456a3e9f0b8e98c)]

### Version 1.11.0 - 20 May 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-7](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`3eab84b`](https://github.com/eea/helm-charts/commit/3eab84bce7cbb8c41f1990b5958a331a651b0846)]

### Version 1.10.3 - 20 May 2025
- Add zodbpack cronjob [valentinab25 - [`0ccb5d1`](https://github.com/eea/helm-charts/commit/0ccb5d190004a0a3b555ba595f4020bada7aac90)]

### Version 1.10.2 - 20 May 2025
- Fix cronjob args [valentinab25 - [`b8a90ff`](https://github.com/eea/helm-charts/commit/b8a90ff4b92826760cff933751921ec378bcdef9)]

### Version 1.10.1 - 20 May 2025
- Add entrasync CronJob [valentinab25 - [`1d66430`](https://github.com/eea/helm-charts/commit/1d66430e40c481cf4237a5c94b97a787a930dc81)]

### Version 1.10.0 - 30 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-6](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`220c7eb`](https://github.com/eea/helm-charts/commit/220c7ebed149f6bf5dd112e10c0c2515129e4894)]

### Version 1.9.0 - 28 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-5](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`7a412ba`](https://github.com/eea/helm-charts/commit/7a412ba6f5691e73557736519082efba26161a71)]

### Version 1.8.0 - 25 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-4](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`966fab1`](https://github.com/eea/helm-charts/commit/966fab179ce7618f37968fc27582d76ede319bf0)]

### Version 1.7.0 - 13 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-3](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`afad03c`](https://github.com/eea/helm-charts/commit/afad03c088b6eb266def3beee31aba28906441e2)]

### Version 1.6.0 - 11 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.15-2](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`6474bd9`](https://github.com/eea/helm-charts/commit/6474bd97699a064d3bf3492151e4400f638ed8e4)]

### Version 1.5.0 - 09 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.14-1](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`354b4df`](https://github.com/eea/helm-charts/commit/354b4dfaaf743ec4349c2907a2f461a4eac13639)]

### Version 1.4.2 - 09 April 2025
- Added plone.googleUrl variable, separated google ingress [valentinab25 - [`77ad0aa`](https://github.com/eea/helm-charts/commit/77ad0aaa595cbfc4fdd538954992b7897af5a3dd)]

### Version 1.4.1 - 08 April 2025
- Add ingress.tls, plone.site variables, rewrite api-ingress [valentinab25 - [`af3acea`](https://github.com/eea/helm-charts/commit/af3acea1f7d28816aa66ed3cf2813bc5962c7597)]

### Version 1.4.0 - 01 April 2025
- Automated release of [eeacms/advisory-board-backend:6.0.13-17](https://github.com/eea/advisory-board-backend/releases) [EEA Jenkins - [`dc92069`](https://github.com/eea/helm-charts/commit/dc920696e09d97e7dd6ba56c1753c6748dbced4f)]

### Version 1.3.0 - 13 March 2025
- Automated release of [eeacms/advisory-board-backend:6.0.13-16](https://github.com/eea/advisory-board-backend/releases)

### Version 1.2.1 - 12 March 2025
- Automated release of [eeacms/plone-varnish:7.6-1.0](https://github.com/eea/plone-varnish/releases)

### Version 1.2.0 - 25 February 2025
- Automated release of [eeacms/advisory-board-backend:6.0.13-14](https://github.com/eea/advisory-board-backend/releases)


### Version 1.1.1
- Release of dependent chart postfix:3.0.6
- :warning: Breaking changes - manually remove the postix deployment before upgrade

### Version 1.0.3
- Added `SENTRY_ENVIRONMENT` variable

### Version 1.0.2
- Rename components to backend- 

### Version 1.0.1
- Questions update

### Version 1.0.0
- Initial release. Version matching Rancher 1 catalog version.
