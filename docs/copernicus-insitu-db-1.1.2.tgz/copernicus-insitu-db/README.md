# copernicus-insitu-db

Helm chart for the Copernicus In-Situ DB stack.
## Releases

### Version 1.1.2 - 02 March 2026
- fix nginx [Dobricean Ioan Dorian - [`2e7c3418`](https://github.com/eea/helm-charts/commit/2e7c341861274556d65977c205eb0d6315d67a07)]

### Version 1.1.1 - 27 February 2026
- ingress [Dobricean Ioan Dorian - [`82eaf01e`](https://github.com/eea/helm-charts/commit/82eaf01e89c4c38acc6d9fe12b508a48f03775de)]

### Version 1.1.0 - 27 February 2026
- cleanup [Dobricean Ioan Dorian - [`61dbc289`](https://github.com/eea/helm-charts/commit/61dbc289994ba8c48aa5fd3fe6cca6335515ad47)]

### Version 1.0.0 - 27 February 2026
- remove unneeded services [Dobricean Ioan Dorian - [`204fc9c7`](https://github.com/eea/helm-charts/commit/204fc9c726a581a5763da1fe86cfb55aca4c85cd)]

### Version 0.2.0 - 27 February 2026
- change vars [Dobricean Ioan Dorian - [`9703d771`](https://github.com/eea/helm-charts/commit/9703d771f481fdf0d67b48c85a10ae9924dea404)]

### Version 0.1.1 - 27 February 2026
- fix ingres [Dobricean Ioan Dorian - [`956d42ab`](https://github.com/eea/helm-charts/commit/956d42abcfe84268a175b67e8f5d78762ef90e9b)]

