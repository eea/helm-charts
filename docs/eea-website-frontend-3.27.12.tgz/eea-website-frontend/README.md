# EEA Main Website frontend - Plone 6

This chart deploys the EEA Main Website frontend app


## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| links.backend | string | NAME.NAMESPACE | Service name for varnish for backend instance, followed by the namespace. |

## Releases

### Version 3.27.12 - 14 September 2026
- Automated release of [eeacms/eea-website-frontend:6.8.1-beta.11](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`9cfa67ac`](https://github.com/eea/helm-charts/commit/9cfa67acd3e7fe3204ca208fe552515de31a5da4)]

### Version 3.27.11 - 11 September 2026
- Automated release of [eeacms/eea-website-frontend:6.8.1-beta.10](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`b6f2bc13`](https://github.com/eea/helm-charts/commit/b6f2bc13129021b22f6708bb44de435100cd302f)]

### Version 3.27.10 - 07 September 2026
- Automated release of [eeacms/eea-website-frontend:6.8.1-beta.9](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`be62d71f`](https://github.com/eea/helm-charts/commit/be62d71f2fc67465d851d8c7f313652c705b656f)]

### Version 3.27.9 - 07 September 2026
- Automated release of [eeacms/eea-website-frontend:6.8.1-beta.8](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`079f9b73`](https://github.com/eea/helm-charts/commit/079f9b735716639e88fc1838ae75af5bce7b44d5)]

### Version 3.27.8 - 07 September 2026
- Automated release of [eeacms/eea-website-frontend:6.8.1-beta.7](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`703e4fb7`](https://github.com/eea/helm-charts/commit/703e4fb71a10cb1afc0f966ae3ade59f4d7ffeab)]

### Version 3.27.7 - 01 September 2026
- Automated release of [eeacms/eea-website-frontend:6.8.1-beta.6](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`ce27a360`](https://github.com/eea/helm-charts/commit/ce27a3607f0cbc6ecb2462c5f699f141e78a2254)]

### Version 3.27.6 - 01 September 2026
- Automated release of [eeacms/eea-website-frontend:6.8.1-beta.5](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`db82c376`](https://github.com/eea/helm-charts/commit/db82c376e2a3dd619f6508dc8d465f999e476963)]

### Version 3.27.5 - 01 September 2026
- Automated release of [eeacms/eea-website-frontend:6.8.1-beta.4](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`74840823`](https://github.com/eea/helm-charts/commit/748408239733ceaec51f20244305f072efb43186)]

### Version 3.27.4 - 01 September 2026
- Automated release of [eeacms/eea-website-frontend:6.8.1-beta.3](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`565428bb`](https://github.com/eea/helm-charts/commit/565428bb47b25415b6b89ac664c8671ded361f6d)]

### Version 3.27.3 - 01 September 2026
- Automated release of [eeacms/eea-website-frontend:6.8.1-beta.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`64da8132`](https://github.com/eea/helm-charts/commit/64da8132afd9a9917bb0530de9b07038142cc7b5)]

### Version 3.27.2 - 31 August 2026
- Automated release of [eeacms/eea-website-frontend:6.8.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`77d105f4`](https://github.com/eea/helm-charts/commit/77d105f49838d4bbc451d64d89d21c088aab1bfb)]

### Version 3.27.1 - 31 August 2026
- Automated release of [eeacms/eea-website-frontend:6.7.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`65de61fa`](https://github.com/eea/helm-charts/commit/65de61fad744e7805fd73a01982f8c0fd17533e8)]

### Version 3.27.0 - 28 August 2026
- Automated release of [eeacms/eea-website-frontend:6.7.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`917c695d`](https://github.com/eea/helm-charts/commit/917c695d6f96a33c64577954343fb7c429aacc96)]

### Version 3.26.7 - 28 August 2026
- Automated release of [eeacms/eea-website-frontend:6.6.3-beta.9](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`cf612fff`](https://github.com/eea/helm-charts/commit/cf612fffcd57abb54dfbfb5706ad40cc7ba2e2a4)]

### Version 3.26.6 - 28 August 2026
- Automated release of [eeacms/eea-website-frontend:6.6.3-beta.8](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`93638ea8`](https://github.com/eea/helm-charts/commit/93638ea8c67235568270ff833165598a4086e1a4)]

### Version 3.26.5 - 28 August 2026
- Automated release of [eeacms/eea-website-frontend:6.6.3-beta.7](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`52ddbb60`](https://github.com/eea/helm-charts/commit/52ddbb60c789b41a0f2a647f4b2de625039f7817)]

### Version 3.26.4 - 26 August 2026
- Automated release of [eeacms/eea-website-frontend:6.6.3-beta.6](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`241b044e`](https://github.com/eea/helm-charts/commit/241b044eafab30a866456ac17799599b42e544ba)]

### Version 3.26.3 - 26 August 2026
- Automated release of [eeacms/eea-website-frontend:6.6.3-beta.5](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`28486be3`](https://github.com/eea/helm-charts/commit/28486be3db897ea9340ecc667cb7e2acb8b57d94)]

### Version 3.26.2 - 25 August 2026
- Automated release of [eeacms/eea-website-frontend:6.6.3-beta.4](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`e8e2a810`](https://github.com/eea/helm-charts/commit/e8e2a810dfbedc5acdb8fd778c369e7610c59534)]

### Version 3.26.1 - 13 August 2026
- Automated release of [eeacms/eea-website-frontend:6.6.2-beta.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`fb093761`](https://github.com/eea/helm-charts/commit/fb093761328b4983601306aba97c60e2518b4af5)]

### Version 3.26.0 - 12 August 2026
- Automated release of [eeacms/eea-website-frontend:6.6.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`4e0287d9`](https://github.com/eea/helm-charts/commit/4e0287d9bb928eb88e8fe8436ddbf090bd5088c3)]

### Version 3.25.0 - 07 August 2026
- Automated release of [eeacms/eea-website-frontend:6.6.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`ef671c73`](https://github.com/eea/helm-charts/commit/ef671c730095c886bd51f01f8423886b1f476f72)]

### Version 3.24.1 - 27 July 2026
- Automated release of [eeacms/eea-website-frontend:6.5.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`5a8ccc3b`](https://github.com/eea/helm-charts/commit/5a8ccc3b55abb415947ab8feaa1f5e66e34c7db2)]

### Version 3.24.0 - 16 July 2026
- Automated release of [eeacms/eea-website-frontend:6.5.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`ce1fddf3`](https://github.com/eea/helm-charts/commit/ce1fddf37cfcde322b0c970792a52250e48610f6)]

### Version 3.23.0 - 16 July 2026
- Automated release of [eeacms/eea-website-frontend:6.4.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`e6e86c9a`](https://github.com/eea/helm-charts/commit/e6e86c9adc61f9eff2e16a8b77b9241efe2c22f0)]

### Version 3.22.1 - 30 June 2026
- Automated release of [eeacms/eea-website-frontend:6.3.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`755578db`](https://github.com/eea/helm-charts/commit/755578db72ee4126a219ff5a482ec447fad53aa7)]

### Version 3.22.0 - 30 June 2026
- Automated release of [eeacms/eea-website-frontend:6.3.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`ff0094bd`](https://github.com/eea/helm-charts/commit/ff0094bdb58bb31b7e64612ef41ed75e9a3bbda8)]

### Version 3.21.1 - 25 June 2026
- Automated release of [eeacms/eea-website-frontend:6.2.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`d11daa7c`](https://github.com/eea/helm-charts/commit/d11daa7cdf6a8a8bad845715b2b4bf12f0b37cb4)]

### Version 3.21.0 - 24 June 2026
- Automated release of [eeacms/eea-website-frontend:6.2.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`12708929`](https://github.com/eea/helm-charts/commit/127089299e913b279b1aded45fe4faf365cac465)]

### Version 3.20.0 - 24 June 2026
- Automated release of [eeacms/eea-website-frontend:6.1.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`75de8ad6`](https://github.com/eea/helm-charts/commit/75de8ad606dace89a42f2889c46ecf96343b1ecf)]

### Version 3.19.1 - 21 June 2026
- Automated release of [eeacms/eea-website-frontend:6.0.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`585d53a9`](https://github.com/eea/helm-charts/commit/585d53a9c9f449722f6a10e7353922ab46b2a091)]

### Version 3.19.0 - 21 June 2026
- Automated release of [eeacms/eea-website-frontend:6.0.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`7c2c3dc1`](https://github.com/eea/helm-charts/commit/7c2c3dc1a2c39459b3e04bb3ede50dd6e93b9bd0)]

### Version 3.18.0 - 11 June 2026
- Automated release of [eeacms/eea-website-frontend:5.7.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`0a3d22f1`](https://github.com/eea/helm-charts/commit/0a3d22f1e1a3d304b5ae0917a96bde2668221989)]

### Version 3.17.0 - 07 June 2026
- Automated release of [eeacms/eea-website-frontend:5.6.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`5015a391`](https://github.com/eea/helm-charts/commit/5015a3911fbf1e5f3c70c758975d584d2271ff45)]

### Version 3.16.1 - 03 June 2026
- Update nginx to 1.31.1 - Refs [#304237](https://taskman.eionet.europa.eu/issues/304237) [valentinab25 - [`283620f6`](https://github.com/eea/helm-charts/commit/283620f66fdd40f415cf928c92d1c49aaa0c40ef)]

### Version 3.16.0 - 28 May 2026
- Automated release of [eeacms/eea-website-frontend:5.5.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`8fb8ccee`](https://github.com/eea/helm-charts/commit/8fb8cceec1364d8f79156d1f913ff7f0b05d75ba)]

### Version 3.15.0 - 27 May 2026
- Automated release of [eeacms/eea-website-frontend:5.4.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`100acb02`](https://github.com/eea/helm-charts/commit/100acb02eda7285c300beee758cb81bcb4c230c6)]

### Version 3.14.0 - 25 May 2026
- Automated release of [eeacms/eea-website-frontend:5.3.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`2862d863`](https://github.com/eea/helm-charts/commit/2862d8635bda121e838f6bcc9d8c1f41ef34c57f)]

### Version 3.13.3 - 22 May 2026
- Automated release of [eeacms/eea-website-frontend:5.2.1-beta.3](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`02c86dc3`](https://github.com/eea/helm-charts/commit/02c86dc338fa3447bbcbdf48dca81b49f5b587c4)]

### Version 3.13.2 - 20 May 2026
- Automated release of [eeacms/eea-website-frontend:5.2.1-beta.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`d5a29b12`](https://github.com/eea/helm-charts/commit/d5a29b12678d8cd3d99b94fd39701c7487b55929)]

### Version 3.13.1 - 18 May 2026
- Automated release of [eeacms/eea-website-frontend:5.2.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`e5e2f019`](https://github.com/eea/helm-charts/commit/e5e2f01908f81a161d39696c92bd9f7932027ee2)]

### Version 3.13.0 - 15 May 2026
- Automated release of [eeacms/eea-website-frontend:5.2.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`ca9d1313`](https://github.com/eea/helm-charts/commit/ca9d1313159f5e8bec96efa1de43effd8d5fa56f)]

### Version 3.12.2 - 05 May 2026
- Automated release of [eeacms/eea-website-frontend:5.1.1-beta.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`d74b2620`](https://github.com/eea/helm-charts/commit/d74b26204fc398c2114652eb0cd7f43ce31f71a3)]

### Version 3.12.1 - 05 May 2026
- Automated release of [eeacms/eea-website-frontend:5.1.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`2186fba8`](https://github.com/eea/helm-charts/commit/2186fba89a0a7df75a4a0f652b506f7ca0e0fa3f)]

### Version 3.12.0 - 28 April 2026
- Automated release of [eeacms/eea-website-frontend:5.1.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`519a9c74`](https://github.com/eea/helm-charts/commit/519a9c74be143b5b4077d0a31e9c5c45aa9d6595)]

### Version 3.11.0 - 24 April 2026
- Automated release of [eeacms/eea-website-frontend:5.0.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`ea93ca32`](https://github.com/eea/helm-charts/commit/ea93ca321fade2f6373a3bd5107ef678c0d938c0)]

### Version 3.10.9 - 23 April 2026
- Automated release of [eeacms/eea-website-frontend:4.1.1-beta.10](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`b7a78860`](https://github.com/eea/helm-charts/commit/b7a788604fb116c67cc3687a113cb7d36829b130)]

### Version 3.10.8 - 23 April 2026
- Automated release of [eeacms/eea-website-frontend:4.1.1-beta.9](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`50c09435`](https://github.com/eea/helm-charts/commit/50c0943599c13f4218a2fdb9242ca82f221c3a7f)]

### Version 3.10.7 - 21 April 2026
- Automated release of [eeacms/eea-website-frontend:4.1.1-beta.8](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`b08f476b`](https://github.com/eea/helm-charts/commit/b08f476b5a4147c676881a1cdbcc33b6127c2717)]

### Version 3.10.6 - 20 April 2026
- Automated release of [eeacms/eea-website-frontend:4.1.1-beta.7](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`e9c62a9a`](https://github.com/eea/helm-charts/commit/e9c62a9a8eb692b78d2bdfaffb3971e2b439260d)]

### Version 3.10.5 - 20 April 2026
- Automated release of [eeacms/eea-website-frontend:4.1.1-beta.6](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`6ab7101b`](https://github.com/eea/helm-charts/commit/6ab7101b1da3701b15e96efed23c1bfc7172f70a)]

### Version 3.10.4 - 26 March 2026
- Automated release of [eeacms/eea-website-frontend:4.1.1-beta.4](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`29d27147`](https://github.com/eea/helm-charts/commit/29d271472df0750fd0974026ec1635f136196372)]

### Version 3.10.3 - 17 March 2026
- Automated release of [eeacms/eea-website-frontend:4.1.1-beta.3](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`e4efd022`](https://github.com/eea/helm-charts/commit/e4efd02218db4aee382eca6bdb1d2922aff78c57)]

### Version 3.10.2 - 06 March 2026
- Automated release of [eeacms/eea-website-frontend:4.1.1-beta.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`c4e34654`](https://github.com/eea/helm-charts/commit/c4e346546914026dbd8f569d33629f093de2dbec)]

### Version 3.10.1 - 23 February 2026
- Automated release of [eeacms/eea-website-frontend:4.1.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`ce39f047`](https://github.com/eea/helm-charts/commit/ce39f0471a0e89bbbfb3e35bef171a03b3ed6e3e)]

### Version 3.10.0 - 20 February 2026
- Automated release of [eeacms/eea-website-frontend:4.1.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`990eff3f`](https://github.com/eea/helm-charts/commit/990eff3f1a0a8ba7f52bf1054fc230ebb494ef94)]

### Version 3.9.0 - 20 February 2026
- Automated release of [eeacms/eea-website-frontend:4.0.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`cd370736`](https://github.com/eea/helm-charts/commit/cd3707364b1216411891df3c0ccc483da2b67c48)]

### Version 3.8.0 - 12 February 2026
- Automated release of [eeacms/eea-website-frontend:3.3.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`b6fc2f40`](https://github.com/eea/helm-charts/commit/b6fc2f40fb95f3c3426b4d0ab7e96fb2bef79542)]

### Version 3.7.6 - 11 February 2026
- Automated release of [eeacms/eea-website-frontend:3.2.1-beta.8](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`dece5812`](https://github.com/eea/helm-charts/commit/dece58122b6d514181225cf834483514afc17ce9)]

### Version 3.7.5 - 09 February 2026
- Automated release of [eeacms/eea-website-frontend:3.2.1-beta.7](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`5fe13dc4`](https://github.com/eea/helm-charts/commit/5fe13dc48c456d93b9a605bba5eb902887dbc109)]

### Version 3.7.4 - 27 January 2026
- Automated release of [eeacms/eea-website-frontend:3.2.1-beta.6](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`a667e927`](https://github.com/eea/helm-charts/commit/a667e92719ce388d977ad1dca133b62355512119)]

### Version 3.7.3 - 27 January 2026
- Automated release of [eeacms/eea-website-frontend:3.2.1-beta.5](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`39476823`](https://github.com/eea/helm-charts/commit/394768233f559656321f00ce53dd26024ed459a7)]

### Version 3.7.2 - 27 January 2026
- Automated release of [eeacms/eea-website-frontend:3.2.1-beta.4](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`8638b48e`](https://github.com/eea/helm-charts/commit/8638b48eaf321bdfb201fa94f98a25ee9cb813d1)]

### Version 3.7.1 - 26 January 2026
- Automated release of [eeacms/eea-website-frontend:3.2.1-beta.3](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`800fd20d`](https://github.com/eea/helm-charts/commit/800fd20de434c1b838c4d0cf8b440423bff107c5)]

### Version 3.7.0 - 21 January 2026
- Automated release of [eeacms/eea-website-frontend:3.2.1-beta.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`8ef05e00`](https://github.com/eea/helm-charts/commit/8ef05e0046448b9b94c57861b14853e9908c8fcd)]

### Version 3.6.0 - 20 January 2026
- Automated release of [eeacms/eea-website-frontend:3.2.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`a8655cfe`](https://github.com/eea/helm-charts/commit/a8655cfe49b7cee0103a049a0f0121ee931c2c47)]

### Version 3.5.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`1cbfdc2d`](https://github.com/eea/helm-charts/commit/1cbfdc2d7c5c42c1a246d7d7d917e88163a8ee11)]

### Version 3.5.0 - 18 January 2026
- Automated release of [eeacms/eea-website-frontend:3.1.1-beta.3](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`24a70d82`](https://github.com/eea/helm-charts/commit/24a70d824b7e3193a5fda281f4c88c09c56b0e11)]

### Version 3.4.0 - 15 January 2026
- Automated release of [eeacms/eea-website-frontend:3.1.1-beta.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`ed6d0a54`](https://github.com/eea/helm-charts/commit/ed6d0a54f584bbf32ee6d504b5c0f670e3361d10)]

### Version 3.3.0 - 13 January 2026
- Automated release of [eeacms/eea-website-frontend:3.1.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`05d2989a`](https://github.com/eea/helm-charts/commit/05d2989a90b2fbc3a146e4931a9aa671aa5f3e5d)]

### Version 3.2.0 - 12 January 2026
- Automated release of [eeacms/eea-website-frontend:3.1.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`ef968c11`](https://github.com/eea/helm-charts/commit/ef968c11451c42313c18179e476903e62fe59991)]

### Version 3.1.0 - 08 January 2026
- Automated release of [eeacms/eea-website-frontend:3.0.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`309f15bb`](https://github.com/eea/helm-charts/commit/309f15bb79e217d33b86e1c5a88c5ca759d3708d)]

### Version 3.0.0 - 23 December 2025
- Release eeacms/eea-website-frontend:3.0.0 [Alin Voinea - [`1607155e`](https://github.com/eea/helm-charts/commit/1607155e19c2d27847a896b1ef6bdf0ba85206aa)]

### Version 1.52.0 - 21 December 2025
- Automated release of [eeacms/eea-website-frontend:2.56.5-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`c2369919`](https://github.com/eea/helm-charts/commit/c23699193cac41d620212494b3849f5ebb91eccf)]

### Version 1.51.0 - 08 December 2025
- Automated release of [eeacms/eea-website-frontend:2.56.4](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`5692eddf`](https://github.com/eea/helm-charts/commit/5692eddfa4d2ff697a050b7f9a8cfdfcb2b49fd7)]

### Version 1.50.0 - 05 December 2025
- Automated release of [eeacms/eea-website-frontend:2.56.3](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`976571f3`](https://github.com/eea/helm-charts/commit/976571f34a4205c93c6b720f2375eedd18ee6c46)]

### Version 1.49.0 - 05 December 2025
- Automated release of [eeacms/eea-website-frontend:2.56.2-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`3ca7eecf`](https://github.com/eea/helm-charts/commit/3ca7eecf20271b50805309582e738b9dffd89279)]

### Version 1.48.0 - 04 December 2025
- Automated release of [eeacms/eea-website-frontend:2.56.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`e59aca20`](https://github.com/eea/helm-charts/commit/e59aca2001b89f6013f8a541dbaaeae4dd0df33d)]

### Version 1.47.0 - 28 November 2025
- Automated release of [eeacms/eea-website-frontend:2.54.1-beta.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`2d5ade9b`](https://github.com/eea/helm-charts/commit/2d5ade9b4487acd71b78e339ee00c7a8ebd3b5cf)]

### Version 1.46.0 - 25 November 2025
- Automated release of [eeacms/eea-website-frontend:2.54.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`3d182b98`](https://github.com/eea/helm-charts/commit/3d182b98fb69a392186170a0b35c585cd9af4e19)]

### Version 1.45.0 - 25 November 2025
- Automated release of [eeacms/eea-website-frontend:2.25.4-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`d90514f7`](https://github.com/eea/helm-charts/commit/d90514f7ee25d97297a436edb2e8983b6b3784e4)]

### Version 1.44.0 - 24 November 2025
- Automated release of [eeacms/eea-website-frontend:2.54.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`95b909f3`](https://github.com/eea/helm-charts/commit/95b909f3be67b57557905edf021ce6d3a94e7195)]

### Version 1.43.0 - 18 November 2025
- Automated release of [eeacms/eea-website-frontend:2.53.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`9639164b`](https://github.com/eea/helm-charts/commit/9639164bdffe24e39e98065b3ab6ee75b7160c4b)]

### Version 1.42.0 - 18 November 2025
- Automated release of [eeacms/eea-website-frontend:2.52.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`aac347c8`](https://github.com/eea/helm-charts/commit/aac347c859be44cadc6a35ce79d6fe426d494caa)]

### Version 1.41.0 - 13 November 2025
- Automated release of [eeacms/eea-website-frontend:2.51.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`8e6f3f84`](https://github.com/eea/helm-charts/commit/8e6f3f8459cde0436836c96f15c09669950c1dad)]

### Version 1.40.0 - 06 November 2025
- Automated release of [eeacms/eea-website-frontend:2.51.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`e53e2742`](https://github.com/eea/helm-charts/commit/e53e27425530c0affafcc6e4f2d8cb516e33d7d8)]

### Version 1.39.0 - 04 November 2025
- Automated release of [eeacms/eea-website-frontend:2.50.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`5ba0ae42`](https://github.com/eea/helm-charts/commit/5ba0ae42360a98b16652eb72fdab7d63cf33265e)]

### Version 1.38.0 - 06 October 2025
- Automated release of [eeacms/eea-website-frontend:2.49.1-beta.4](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`7e7f4366`](https://github.com/eea/helm-charts/commit/7e7f43661f46fd6d31c890768917a78451e779b8)]

### Version 1.37.0 - 01 October 2025
- Automated release of [eeacms/eea-website-frontend:2.49.1-beta.3](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`50322141`](https://github.com/eea/helm-charts/commit/50322141ff86597b527fde49131a08c39cd33eeb)]

### Version 1.36.0 - 01 October 2025
- Automated release of [eeacms/eea-website-frontend:2.49.1-beta.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`54af0979`](https://github.com/eea/helm-charts/commit/54af0979b043da53aa6cff8eb7379005b60ffb9b)]

### Version 1.35.0 - 01 October 2025
- Automated release of [eeacms/eea-website-frontend:2.49.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`91207ea3`](https://github.com/eea/helm-charts/commit/91207ea363c38f6fd7d8dd06d7e2bc1872408bd0)]

### Version 1.34.0 - 29 September 2025
- Automated release of [eeacms/eea-website-frontend:2.49.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`44df48f6`](https://github.com/eea/helm-charts/commit/44df48f6fef4fb92aa6a25dc2fe0b64891b4569d)]

### Version 1.33.0 - 27 September 2025
- Automated release of [eeacms/eea-website-frontend:2.48.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`0e1280ac`](https://github.com/eea/helm-charts/commit/0e1280ac95b227f8c06ce621603bfbe86d3008ce)]

### Version 1.32.0 - 26 September 2025
- Automated release of [eeacms/eea-website-frontend:2.47.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`d987dcff`](https://github.com/eea/helm-charts/commit/d987dcffd3da811e729f6f68b9ee00b55a56cacc)]

### Version 1.31.0 - 26 September 2025
- Automated release of [eeacms/eea-website-frontend:2.47.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`a51777a9`](https://github.com/eea/helm-charts/commit/a51777a9fd571d61bcb7f2307b7d3bc9f9d93c7f)]

### Version 1.30.1 - 26 September 2025
- Fix nginx conf when debug is disabled [Alin Voinea - [`dd2686c6`](https://github.com/eea/helm-charts/commit/dd2686c634e29c0695cd6d69a0414fa1b82a56bb)]

### Version 1.30.0 - 25 September 2025
- Automated release of [eeacms/eea-website-frontend:2.47.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`799cac02`](https://github.com/eea/helm-charts/commit/799cac02292dc1d8ad7494bf815d0b103328bb41)]

### Version 1.29.0 - 25 September 2025
- Automated release of [eeacms/eea-website-frontend:2.46.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`54aa66d0`](https://github.com/eea/helm-charts/commit/54aa66d0a2e98521b23dd1f9647a12c8dc1b64ca)]

### Version 1.28.1 - 23 September 2025
- Add possibility to deploy debug_frontend [Alin Voinea - [`7956f177`](https://github.com/eea/helm-charts/commit/7956f1770d991c035252d0a17a4d234147e84025)]

### Version 1.28.0 - 22 September 2025
- Automated release of [eeacms/eea-website-frontend:2.46.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`1e0508c7`](https://github.com/eea/helm-charts/commit/1e0508c7c180f6a494c1abbd53b631a45b3172c0)]

### Version 1.27.0 - 15 September 2025
- Automated release of [eeacms/eea-website-frontend:2.45.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`eb5895fd`](https://github.com/eea/helm-charts/commit/eb5895fd99a26f18b58cbb16c1b0c97de9ca8ed4)]

### Version 1.26.0 - 15 September 2025
- Automated release of [eeacms/eea-website-frontend:2.45.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`93fcca68`](https://github.com/eea/helm-charts/commit/93fcca681e609d5bb895c4a252167da67ec2fc11)]

### Version 1.25.0 - 13 September 2025
- Automated release of [eeacms/eea-website-frontend:2.44.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`f4587054`](https://github.com/eea/helm-charts/commit/f45870542cc14ab91100ce323e98218b6a5bdb18)]

### Version 1.24.0 - 10 September 2025
- Automated release of [eeacms/eea-website-frontend:2.43.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`b2573c65`](https://github.com/eea/helm-charts/commit/b2573c65c683eca49861db7b85d2896b93c93a18)]

### Version 1.23.0 - 10 September 2025
- Automated release of [eeacms/eea-website-frontend:2.43.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`f9624822`](https://github.com/eea/helm-charts/commit/f9624822f6b00fe65dd60c9473fdf1de6bcfabcd)]

### Version 1.22.0 - 09 September 2025
- Automated release of [eeacms/eea-website-frontend:2.42.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`451a31a5`](https://github.com/eea/helm-charts/commit/451a31a55a2077422a367ad2df6ceb3c644fca4f)]

### Version 1.21.1 - 28 August 2025
- Add producton ingress settings [Alin Voinea - [`1db28c25`](https://github.com/eea/helm-charts/commit/1db28c25cd9a0560978579bd9db6d7ca890688bc)]

### Version 1.21.0 - 27 August 2025
- Automated release of [eeacms/eea-website-frontend:2.41.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`68b757c8`](https://github.com/eea/helm-charts/commit/68b757c8d3221b4c7aa38f65af0b95345a088e5c)]

### Version 1.20.1 - 27 August 2025
- Fix deployments/scale.apps volto not found [Alin Voinea - [`c1f6ee3e`](https://github.com/eea/helm-charts/commit/c1f6ee3e5cb6ee059e077898dfa4c612933226e3)]

### Version 1.20.0 - 21 August 2025
- Automated release of [eeacms/eea-website-frontend:2.40.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`c4444983`](https://github.com/eea/helm-charts/commit/c444498322185346c65176eac7239f52c264be7f)]

### Version 1.19.0 - 21 August 2025
- Automated release of [eeacms/eea-website-frontend:2.39.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`da858b78`](https://github.com/eea/helm-charts/commit/da858b78e66dcab07f39a00ad6f008b065768e6d)]

### Version 1.18.0 - 20 August 2025
- Automated release of [eeacms/eea-website-frontend:2.38.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`16f22c19`](https://github.com/eea/helm-charts/commit/16f22c19803c5fd229be1bfda5eb8cb5863d85f8)]

### Version 1.17.9 - 20 August 2025
- add ingress pathType as a value [Silviu - [`df4f0fc8`](https://github.com/eea/helm-charts/commit/df4f0fc84940386611a1a85c113133045f27019f)]

### Version 1.17.8 - 20 August 2025
- Remove CSP as its not needed [valentinab25 - [`cad2c579`](https://github.com/eea/helm-charts/commit/cad2c5790cb10ae87b7eb2b4f766ba2fcb627eea)]

### Version 1.17.7 - 19 August 2025
- update default values [Silviu - [`8c4d15b2`](https://github.com/eea/helm-charts/commit/8c4d15b2319f0e5dbc429ad8326ba6740695055e)]

### Version 1.17.6 - 14 August 2025
- add storage accessmode var [valentinab25 - [`56767b15`](https://github.com/eea/helm-charts/commit/56767b15aa73846f538c5faa9ebbb3680811be45)]

### Version 1.17.5 - 14 August 2025
- Add storageclass, allow ingress backend redirect [valentinab25 - [`4dc2a2ea`](https://github.com/eea/helm-charts/commit/4dc2a2eaefba690b9c12719d37d0a527df5abf10)]

### Version 1.17.4 - 13 August 2025
- add default nginx logs to stdout [Silviu - [`14660f60`](https://github.com/eea/helm-charts/commit/14660f60499ec6d054d59a96cb86796447e0f16b)]

### Version 1.17.3 - 13 August 2025
- fix selector labels nginx [valentinab25 - [`aefd42e0`](https://github.com/eea/helm-charts/commit/aefd42e0c9bd6fb1ecc19f0310c92e0f6e97279f)]

### Version 1.17.2 - 13 August 2025
- Use ingress class in configuration [valentinab25 - [`43b18ff1`](https://github.com/eea/helm-charts/commit/43b18ff13263d7298bc0e44e46cec3a6d22e3288)]

### Version 1.17.1 - 13 August 2025
- Add ingress classname [valentinab25 - [`11e7f584`](https://github.com/eea/helm-charts/commit/11e7f584796ea48eb2640fa15e931cdc5edaed7a)]

### Version 1.17.0 - 04 August 2025
- Automated release of [eeacms/eea-website-frontend:2.36.1-beta.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`08f3e227`](https://github.com/eea/helm-charts/commit/08f3e22702e0d56ea293976b6cf79f463cf9bd6a)]

### Version 1.16.1 - 01 August 2025
- Automated release of [eeacms/plone-varnish:7.7-1.1](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`9899531b`](https://github.com/eea/helm-charts/commit/9899531b493acc9fd072e1cf9e51f28edf7d5f47)]

### Version 1.16.0 - 30 July 2025
- Automated release of [eeacms/eea-website-frontend:2.36.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`9ad2a939`](https://github.com/eea/helm-charts/commit/9ad2a939672d71c0653e90d9b8c97720f7c563eb)]

### Version 1.15.0 - 30 July 2025
- Automated release of [eeacms/eea-website-frontend:2.35.1-beta.4](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`1a2c0f25`](https://github.com/eea/helm-charts/commit/1a2c0f256e1878e6a42c9d77bc6699302028cc1e)]

### Version 1.14.0 - 30 July 2025
- Automated release of [eeacms/eea-website-frontend:2.35.1-beta.3](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`89c5f320`](https://github.com/eea/helm-charts/commit/89c5f320cd0a44119276310db8a2dc82b555acae)]

### Version 1.13.0 - 28 July 2025
- Automated release of [eeacms/eea-website-frontend:2.35.1-beta.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`aece0e10`](https://github.com/eea/helm-charts/commit/aece0e1018a9505258d506b5ebcb25b4e7e33990)]

### Version 1.12.0 - 25 July 2025
- Automated release of [eeacms/eea-website-frontend:2.35.1-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`1ec7d7ff`](https://github.com/eea/helm-charts/commit/1ec7d7ffcf0b7decd432158b5272f3834a1643ac)]

### Version 1.11.0 - 25 July 2025
- Automated release of [eeacms/eea-website-frontend:2.35.1-beta.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`f3d722f6`](https://github.com/eea/helm-charts/commit/f3d722f697a4913779277773ada71dc29ac25cc2)]

### Version 1.10.0 - 24 July 2025
- Automated release of [eeacms/eea-website-frontend:2.35.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`86f938b7`](https://github.com/eea/helm-charts/commit/86f938b78ad2b77011a4afaf2796b72691c613df)]

### Version 1.9.0 - 23 July 2025
- Automated release of [eeacms/eea-website-frontend:2.34.2-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`c68d9563`](https://github.com/eea/helm-charts/commit/c68d9563c07ab7a791cec071528b36a9a5198071)]

### Version 1.8.0 - 23 July 2025
- Automated release of [eeacms/eea-website-frontend:2.34.2-beta.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`77f38af2`](https://github.com/eea/helm-charts/commit/77f38af26f07238f14f9a360dcb8eede9ec41785)]

### Version 1.7.0 - 18 July 2025
- Automated release of [eeacms/eea-website-frontend:2.34.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`4a6335ad`](https://github.com/eea/helm-charts/commit/4a6335ad4ccf41dda3693f2c0199239001650423)]

### Version 1.6.0 - 15 July 2025
- Automated release of [eeacms/eea-website-frontend:2.34.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`d5c19b7c`](https://github.com/eea/helm-charts/commit/d5c19b7c832563feea093fc746100da07d0cbd50)]

### Version 1.5.0 - 07 July 2025
- Automated release of [eeacms/eea-website-frontend:2.33.0-beta.2](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`aa414136`](https://github.com/eea/helm-charts/commit/aa414136f07c99d62e4d4e6a45317b2c6b50e2e9)]

### Version 1.4.0 - 07 July 2025
- Automated release of [eeacms/eea-website-frontend:2.33.0-beta.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`b9181a0c`](https://github.com/eea/helm-charts/commit/b9181a0ce9871725e1f5f6ca0290b34537bdfa6f)]

### Version 1.3.0 - 03 July 2025
- Automated release of [eeacms/eea-website-frontend:2.32.1](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`8db15509`](https://github.com/eea/helm-charts/commit/8db155096518846ffb98818e02a83a41107f2304)]

### Version 1.2.0 - 02 July 2025
- Automated release of [eeacms/eea-website-frontend:2.32.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`e3db4560`](https://github.com/eea/helm-charts/commit/e3db456001a7e9ecd70a9365888692b75c5c3c82)]

### Version 1.1.5 - 11 June 2025
- update nginx defaults [Silviu - [`5969310`](https://github.com/eea/helm-charts/commit/59693107b1af30d0ac0967d552689ef55b7d23f0)]

### Version 1.1.4 - 11 June 2025
- update default values [Silviu - [`e169f75`](https://github.com/eea/helm-charts/commit/e169f75ae27b6ccfdc6b3901668b142345d8eacd)]

### Version 1.1.3 - 11 June 2025
- update question to multiline [Silviu - [`44913ba`](https://github.com/eea/helm-charts/commit/44913ba9549eff0ebb16a31136bd9cee3349fc26)]

### Version 1.1.2 - 11 June 2025
- update nginx default config [Silviu - [`b022ea4`](https://github.com/eea/helm-charts/commit/b022ea4bc421473b239c034ecadb536213ec39e6)]

### Version 1.1.1 - 10 June 2025
- add nginx [Silviu - [`b0a9a78`](https://github.com/eea/helm-charts/commit/b0a9a78c2d850925107676b207666218785c55a2)]

### Version 1.1.0 - 06 June 2025
- Automated release of [eeacms/eea-website-frontend:2.31.0](https://github.com/eea/eea-website-frontend/releases) [EEA Jenkins - [`da9ee48`](https://github.com/eea/helm-charts/commit/da9ee4821aa9e15a8fc36b7380aeb524890e7c7c)]

### Version 1.0.0
- Initial release. Version matching Rancher 1 catalog version.
