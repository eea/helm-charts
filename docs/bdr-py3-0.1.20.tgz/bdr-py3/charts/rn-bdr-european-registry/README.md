# Reportnet BDR European Registry

BDR European Registry Service Chart for BDR

Network Policy:
- `networkPolicy.enabled` - Enable network policy. Defaults to false.
- `networkPolicy.additionalIngress` - Additional ingress rules to be added to the default ones. Defaults to [].
- `networkPolicy.additionalEgress` - Additional egress rules to be added to the default ones. Defaults to [].
- `networkPolicy.spec` - Additional network policy specifications to be merged with the policy. **Note**: Defining `ingress` or `egress` in spec will completely override the default rules and `additional*` rules. Defaults to {}.

External configuration:
- `envFrom` - Extra `envFrom` sources (ConfigMap/Secret references) added to the container. Kubernetes applies them in order, so later entries override earlier ones. Defaults to [].
- `inlineEnv` - Render the per-key application settings from this chart's values as inline `env` entries. Defaults to true, which preserves the previous behaviour.

Set `inlineEnv: false` when the application settings are supplied entirely
through `envFrom`. Kubernetes gives inline `env` precedence over `envFrom`,
and this chart ships non-empty defaults of its own:

```yaml
dbHost: postgres
dbName: ecr
dbUser: ecr
mailServer: postfix
```

Leaving `inlineEnv` enabled would let those silently mask the values coming
from your ConfigMap/Secret.

`PORT` is derived from `service.port` and is always rendered inline,
regardless of `inlineEnv`.

Example - all settings from an external ConfigMap and Secret:

```yaml
inlineEnv: false
envFrom:
  - configMapRef:
      name: my-european-registry-env
  - secretRef:
      name: my-european-registry-secrets
```

Because a parent chart cannot template a sub-chart's values, the referenced
names have to be written out in full here. Keeping the names fixed also means
the wiring does not change when the Secret is later supplied by an external
controller such as External Secrets or SealedSecrets.

## Releases

### Version 1.0.5 - 08 September 2026
- Added support for envFrom to be used in parent charts [Olimpiu Rob - [`a08eb9f4`](https://github.com/eea/helm-charts/commit/a08eb9f4aa5d95cc7f83f5337f467b101019caa8)]

### Version 1.0.4 - 13 July 2026
- Updated appVersion to 3.0.5 [Diana Boiangiu - [`3c9ed49b`](https://github.com/eea/helm-charts/commit/3c9ed49b09440d33ec34e9d0db49f55b49399c0f)]

### Version 1.0.3 - 25 March 2026
- Updated appVersion to 3.0.4 [Diana Boiangiu - [`0ba4c9e1`](https://github.com/eea/helm-charts/commit/0ba4c9e1e7b74ac15559e9c4076c15824a520fe0)]

### Version 1.0.2 - 24 March 2026
- Updated appVersion to 3.0.3 [Diana Boiangiu - [`88d7db53`](https://github.com/eea/helm-charts/commit/88d7db53c8d2957894ccf9bcbaa0c21036f03a7c)]

### Version 1.0.1 - 16 March 2026
- Updated appVersion to 3.0.2 [Diana Boiangiu - [`127e21d9`](https://github.com/eea/helm-charts/commit/127e21d9aae47be10ad5ff0b1a6d3c3ef29078d9)]

### Version 1.0.0 - 10 February 2026
- Updated appVersion to 3.0.0 [Diana Boiangiu - [`db7685da`](https://github.com/eea/helm-charts/commit/db7685da41b47d8440f5d603007a7cba0366bb47)]

### Version 0.1.17 - 02 February 2026
- Updated appVersion to 2.5.5 [Diana Boiangiu - [`010bb02b`](https://github.com/eea/helm-charts/commit/010bb02bd9cb45b99a6daa6cc31395cbc8639cd8)]

### Version 0.1.16 - 15 October 2025
- Updated appVersion to 2.5.4 [Diana Boiangiu - [`261dc5e2`](https://github.com/eea/helm-charts/commit/261dc5e24a14c6ec78ec440e3a034e742046d695)]

### Version 0.1.15 - 15 October 2025
- Updated appVersion to 2.5.3 [Diana Boiangiu - [`77513423`](https://github.com/eea/helm-charts/commit/77513423d0b3c60d1d6a8bdce593602550c784c5)]

### Version 0.1.14 - 28 April 2025
- Updated appVersion to 2.5.2 [Diana Boiangiu - [`df49391`](https://github.com/eea/helm-charts/commit/df493911e97c378e0683e57f9cedc28a78300c94)]

### Version 0.1.13 - 15 April 2025
- Updated appVersion to 2.5.1 [Diana Boiangiu - [`22b5ac8`](https://github.com/eea/helm-charts/commit/22b5ac89ca2180722ab177ebd60093ee74133aa9)]

### Version 0.1.12
- Updated appVersion to 2.5.0.

### Version 0.1.11
- Updated appVersion to 2.4.6.

### Version 0.1.10
- Updated appVersion to 2.4.5.

### Version 0.1.9
- Updated appVersion to 2.4.4.

### Version 0.1.8
- Updated appVersion to 2.4.3.

### Version 0.1.7
- Updated appVersion to 2.4.2.

### Version 0.1.6
- Updated appVersion to 2.4.1.

### Version 0.1.5
- Added network policy support.

### Version 0.1.4
- Updated appVersion to 2.4.0.

### Version 0.1.3
- Disabled liveness and readiness probes when debugTail is enabled.

### Version 0.1.2
- Fixed debugTail default flag.

### Version 0.1.1
- Added debugTail flag.

### Version 0.1.0
- Initial release.
