# Reportnet CDR

The Central Data Repository is part of the Reportnet architecture. The Central Data Repository is like a bookshelf, with data reports on the environment as submitted to international clients.

This chart is almost configured for production use.

## Network Security Policies

This Helm chart deploys Kubernetes Network Policies to enhance the security of the CDR application. If `defaultNetworkPolicyDeny` is enabled, these policies enforce a **whitelist** approach, meaning that network traffic is only allowed if explicitly permitted.

**Key Network Policy Configurations:**

*   **Instance Pod Egress (`instance.networkPolicy.egress` in `values.yaml`):**  Configures outbound traffic from the `cdr-instance` pods. You can configure egress rules in two ways:

    1. Using `ipBlockRules`: Define IP-based rules with specific ports for each CIDR block:
    ```yaml
    instance:
      networkPolicy:
        egress:
          ipBlockRules:
            - cidr: 10.50.4.0/24  # Legacy service network
              ports:
                - protocol: TCP
                  port: 443     # HTTPS
                - protocol: TCP
                  port: 80      # HTTP
            - cidr: 10.50.5.0/24  # Another network
              ports:
                - protocol: TCP
                  port: 5432    # PostgreSQL
    ```

    2. Using `rawRules`: For more complex scenarios, define individual egress rules using the full power of Kubernetes NetworkPolicy `to` specifications:
    ```yaml
    instance:
      networkPolicy:
        egress:
          rawRules:
            - to:
                - namespaceSelector:
                    matchLabels:
                      kubernetes.io/metadata.name: other-namespace
                  podSelector:
                    matchLabels:
                      app.kubernetes.io/name: service-name
              ports:
                - port: 8080
                  protocol: TCP
    ```

    You can use `rawRules` to define:
    *   **IP Block Rules:** Target egress traffic to specific IP address ranges
    *   **Namespace Selector Rules:** Target pods in other namespaces based on namespace labels and pod labels
    *   **Pod Selector Rules:** Target pods within the same namespace based on pod labels
    *   **Service Account Selector Rules (Advanced):** Target pods based on their service accounts


*   **Varnish Pod Network Policy (`varnish.networkPolicy` in `values.yaml`):** Defines additional ingress and egress rules for the `cdr-varnish` pods.  You can use `varnish.networkPolicy.additionalIngress` and `varnish.networkPolicy.additionalEgress` in `values.yaml` to add custom rules on top of the base policy defined in the templates.

*   **Default Deny Policies:** The chart includes deny Network Policies (`netsecpol-ingress-default.yaml` and `netsecpol-egress-default.yaml`) that, when enabled with `defaultNetworkPolicyDeny.enabled: true`, block all ingress and egress traffic unless overridden by more specific policies. This ensures a secure starting point and encourages explicit definition of allowed traffic.

**Modifying Network Policies:**

To customize the network policies, you should modify the `instance.networkPolicy.egress` and `varnish.networkPolicy` sections within your `values.yaml` file.  Refer to the Kubernetes Network Policy documentation for details on how to define rules using `ipBlock`, `namespaceSelector`, `podSelector`, ports, and protocols.

## Releases

### Version 0.82.1 - 10 November 2026
- Release of dependent chart rn-varnish:0.7.0 [EEA Jenkins - [`ca108d901`](https://github.com/eea/helm-charts/commit/ca108d9016f439770950cd862b3350f666f3e616)]

### Version 0.82.0 - 07 August 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-295](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`c9420d41`](https://github.com/eea/helm-charts/commit/c9420d416cc21bb3682f3ffc11ffe8e0909c5ffc)]

### Version 0.81.3 - 08 July 2026
- Updated rn-varnish to 0.6.2 [Olimpiu Rob - [`f9b9ae26`](https://github.com/eea/helm-charts/commit/f9b9ae26726975b604867273db517406e837ad42)]

### Version 0.81.2 - 06 July 2026
- Updated rn-varnish to 0.6.1 [Olimpiu Rob - [`1d7d5f40`](https://github.com/eea/helm-charts/commit/1d7d5f40f4eadc1da6fa980ff9a9d6fb8d9fade3)]

### Version 0.81.1 - 06 July 2026
- Release of dependent chart rn-varnish:0.6.0 [EEA Jenkins - [`c1677041`](https://github.com/eea/helm-charts/commit/c1677041d9f65f88bfa5a94f8efbb8de25f57848)]

### Version 0.81.0 - 01 July 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-294](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`855342ff`](https://github.com/eea/helm-charts/commit/855342ff8daa41fd7740486ff970ecbf0d88d164)]

### Version 0.80.0 - 29 June 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-293](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`2d5414e0`](https://github.com/eea/helm-charts/commit/2d5414e021cbb2d5f756b687cc6b374dbad8f653)]

### Version 0.79.0 - 25 June 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-292](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`d4f71ac6`](https://github.com/eea/helm-charts/commit/d4f71ac6fcb1677516558a4442fc1f641e08b083)]

### Version 0.78.7 - 25 June 2026
- Bumped rn-local-converters to 0.1.13 [Olimpiu Rob - [`3fef61a7`](https://github.com/eea/helm-charts/commit/3fef61a74445168348871049c850ede08ffc9f40)]

### Version 0.78.6 - 25 June 2026
- Updated rn-local-converters to 0.1.12 [Olimpiu Rob - [`6b20ba9b`](https://github.com/eea/helm-charts/commit/6b20ba9b4ac64a9e2b7fe23c28be5f787a27437e)]

### Version 0.78.5 - 24 June 2026
- Bumped rn-local-converters to 0.1.11 [Olimpiu Rob - [`f7d22852`](https://github.com/eea/helm-charts/commit/f7d22852127b853c76523fe660d9a0328fa3914c)]

### Version 0.78.4 - 23 June 2026
- Updated rn-local-converters to 0.1.10 [Olimpiu Rob - [`66be9132`](https://github.com/eea/helm-charts/commit/66be91328642d7908e8cbe14f5af26d81e422708)]

### Version 0.78.3 - 23 June 2026
- Updated rn-local-converters to 0.1.9 [Olimpiu Rob - [`6d7cceeb`](https://github.com/eea/helm-charts/commit/6d7cceebb86e39c6fc083cee7fcfb5bd26bd90b5)]

### Version 0.78.2 - 23 June 2026
- Updated rn-local-converters to 0.1.8 [Olimpiu Rob - [`263ac369`](https://github.com/eea/helm-charts/commit/263ac3697e8fbe1460ed22d5165eeb59bd7264cb)]

### Version 0.78.1 - 23 June 2026
- Updated rn-local-converters to 0.1.7 [Olimpiu Rob - [`1b8bfe4d`](https://github.com/eea/helm-charts/commit/1b8bfe4d5df1cb730414baf428a6be42dcf13104)]

### Version 0.78.0 - 22 June 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-291](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`b129bf1a`](https://github.com/eea/helm-charts/commit/b129bf1a8e232e8bc66cf39df0d82882775d91e8)]

### Version 0.77.0 - 19 June 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-290](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`b2a56b16`](https://github.com/eea/helm-charts/commit/b2a56b1648c778cd605c39d6bba403fe61fafcde)]

### Version 0.76.0 - 19 June 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-289](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`fe985140`](https://github.com/eea/helm-charts/commit/fe985140dd07c8f65d602fa3b31d072c7170e463)]

### Version 0.75.0 - 19 June 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-288](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`09098e81`](https://github.com/eea/helm-charts/commit/09098e816b9059fd1d309a5a80c425abdbd191fe)]

### Version 0.74.0 - 29 May 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-287](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`32a25fbf`](https://github.com/eea/helm-charts/commit/32a25fbf3384de09cb535c67381e0b38b8ba9349)]

### Version 0.73.0 - 22 May 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-286](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`94b461e1`](https://github.com/eea/helm-charts/commit/94b461e16ae1ae4f86e7ca9faf2076c06e572a79)]

### Version 0.72.0 - 22 May 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-285](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`b1f344ff`](https://github.com/eea/helm-charts/commit/b1f344ff67602ca4bed196ebe96e38747dd13702)]

### Version 0.71.0 - 22 May 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-284](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`695000db`](https://github.com/eea/helm-charts/commit/695000dbfded66182a2167f29f161e37f4d227ba)]

### Version 0.70.0 - 08 May 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-282](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`b0495c8f`](https://github.com/eea/helm-charts/commit/b0495c8fbe807e92eae464a83c5f9aa46a0dac2c)]

### Version 0.69.0 - 30 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-280](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`0fa25801`](https://github.com/eea/helm-charts/commit/0fa2580186cf0a100ca20c42d30126043ff8a956)]

### Version 0.68.0 - 27 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-279](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`5971d863`](https://github.com/eea/helm-charts/commit/5971d863e416393ca0e8ff663772b1fbaddea90c)]

### Version 0.67.0 - 24 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-278](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`3cb07731`](https://github.com/eea/helm-charts/commit/3cb077318c30ef98af71e9b5260c7dcc51e4da07)]

### Version 0.66.0 - 24 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-277](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`d09c3b98`](https://github.com/eea/helm-charts/commit/d09c3b984d8e4db30a10c117376e859fde1c2f19)]

### Version 0.65.0 - 23 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-276](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`706725af`](https://github.com/eea/helm-charts/commit/706725af6a76349a3f117d59d55d0f1d85ab5e43)]

### Version 0.64.0 - 22 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-275](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`85b2aa9c`](https://github.com/eea/helm-charts/commit/85b2aa9cc86e86f5837c97aa37f99362a82c770e)]

### Version 0.63.0 - 22 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-274](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`f46609ad`](https://github.com/eea/helm-charts/commit/f46609ad539c75794ef2c10786c8088e8a820a09)]

### Version 0.62.0 - 20 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-273](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`bada968d`](https://github.com/eea/helm-charts/commit/bada968d5dacf5b7fb4ebd5ad14cc3495e2f4942)]

### Version 0.61.0 - 17 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-272](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`cbc27038`](https://github.com/eea/helm-charts/commit/cbc27038f85ad66227fb45f75905c98d1112ca1e)]

### Version 0.60.0 - 16 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-271](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`1dde31ee`](https://github.com/eea/helm-charts/commit/1dde31eef2ef60ada7297190aab41e4dd3971875)]

### Version 0.59.0 - 15 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-269](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`f722fd56`](https://github.com/eea/helm-charts/commit/f722fd567dd34160b79bd9b4eb249533f984045c)]

### Version 0.58.0 - 08 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-268](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`b8f59e5e`](https://github.com/eea/helm-charts/commit/b8f59e5e5cac265de4ac1e599d9ea2039bca42fa)]

### Version 0.57.0 - 08 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-267](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`97da409c`](https://github.com/eea/helm-charts/commit/97da409c9765fd18d268c21f4cdc9246b30ccb27)]

### Version 0.56.0 - 08 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-266](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`3ebafdf3`](https://github.com/eea/helm-charts/commit/3ebafdf3489c0fd4aa04423db500e17f4f8ca2fe)]

### Version 0.55.0 - 02 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-265](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`36324855`](https://github.com/eea/helm-charts/commit/36324855bdbd994c8ea6c7e6068370bc49e1ac55)]

### Version 0.54.0 - 02 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-264](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`3de5caed`](https://github.com/eea/helm-charts/commit/3de5caed66426cebc54bf635e869ffb0a6a5c730)]

### Version 0.53.0 - 02 April 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-263](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`934d1994`](https://github.com/eea/helm-charts/commit/934d19947e7998d90dfcb25249e1585d487be67f)]

### Version 0.52.0 - 31 March 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-262](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`b9bd670d`](https://github.com/eea/helm-charts/commit/b9bd670d2e55fdf63804d07194d6fd518267a12b)]

### Version 0.51.0 - 31 March 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-261](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`9a87ae2b`](https://github.com/eea/helm-charts/commit/9a87ae2b1ef220e6825943651ca4d9479a8f3558)]

### Version 0.50.0 - 26 March 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-260](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`44bf0cb4`](https://github.com/eea/helm-charts/commit/44bf0cb4ece0c032ca896a981d1692ddf1887e8c)]

### Version 0.49.0 - 23 March 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-259](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`48f2037f`](https://github.com/eea/helm-charts/commit/48f2037fec789631957929337eed0b747b0917de)]

### Version 0.48.0 - 19 March 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-258](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`b1908108`](https://github.com/eea/helm-charts/commit/b190810879b709323bbbdb36379b255963c28c3e)]

### Version 0.47.0 - 03 March 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-257](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`7c943269`](https://github.com/eea/helm-charts/commit/7c9432695848ac9f4ac8b2d354ebfa294685a6ee)]

### Version 0.46.0 - 19 February 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-256](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`8460e676`](https://github.com/eea/helm-charts/commit/8460e67617175205a68cc7555b6b5af90c71c824)]

### Version 0.45.0 - 16 February 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-255](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`625bf556`](https://github.com/eea/helm-charts/commit/625bf556c358d5f57f5fa08669fa80798a6ae34e)]

### Version 0.44.0 - 12 February 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-254](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`01df9150`](https://github.com/eea/helm-charts/commit/01df91506f9fd39c3775694428cf794d49636016)]

### Version 0.43.0 - 12 February 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-253](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`3e97b759`](https://github.com/eea/helm-charts/commit/3e97b759b32d326bc70277191912bb8d24d182a4)]

### Version 0.42.0 - 10 February 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-252](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`1b162a1f`](https://github.com/eea/helm-charts/commit/1b162a1f38b3b4b15fba0628e1075ce979cc451d)]

### Version 0.41.0 - 10 February 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-251](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`4f46340f`](https://github.com/eea/helm-charts/commit/4f46340f927369c90ea3d0b72b731eac599f931c)]

### Version 0.40.0 - 05 February 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-250](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`17859c87`](https://github.com/eea/helm-charts/commit/17859c87b984a723d6a7005d4d9a107649f0fa40)]

### Version 0.39.0 - 05 February 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-249](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`a415610d`](https://github.com/eea/helm-charts/commit/a415610d9e751bc567c29d8d8f7b9b48e7fe4042)]

### Version 0.38.0 - 04 February 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-248](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`f1304684`](https://github.com/eea/helm-charts/commit/f13046847144422c5b1b3b20b05deccc7915e008)]

### Version 0.37.0 - 27 January 2026
- Automated release of [eeacms/reportek-cdr:6.7.3-247](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`7d65ae51`](https://github.com/eea/helm-charts/commit/7d65ae51cf66ce3b6935ce6191eb3b187bf7c2f9)]

### Version 0.36.1 - 05 November 2025
- Added DEPLOYMENT_HOST env to cron-auto-fallin-cronjob [Olimpiu Rob - [`3be4e020`](https://github.com/eea/helm-charts/commit/3be4e020b425b3348556c7d64c05bfb5d352280f)]

### Version 0.36.0 - 24 October 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-246](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`94b2aa07`](https://github.com/eea/helm-charts/commit/94b2aa073f150d299892027e80773624ffa8ea90)]

### Version 0.35.0 - 24 October 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-245](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`539c9ccb`](https://github.com/eea/helm-charts/commit/539c9ccbb3b97a285f0db37c19b16ff26f718ec4)]

### Version 0.34.1 - 15 October 2025
- Updated curl image tag [Olimpiu Rob - [`77ff1e34`](https://github.com/eea/helm-charts/commit/77ff1e34728dc54feee0414494667cba669369b0)]

### Version 0.34.0 - 08 October 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-244](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`bfbe6928`](https://github.com/eea/helm-charts/commit/bfbe69285c1c35ce1ffa10511b0cc012e9d46b3d)]

### Version 0.33.0 - 07 October 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-243](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`c8e17d24`](https://github.com/eea/helm-charts/commit/c8e17d246c85eaa4e246f432514a9aa335fda533)]

### Version 0.32.0 - 07 October 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-242](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`88a57956`](https://github.com/eea/helm-charts/commit/88a57956a40e38b55f2b06949719c8f2eafdcb05)]

### Version 0.31.1 - 03 October 2025
- Release of dependent chart rn-varnish:0.5.0 [EEA Jenkins - [`de87af36`](https://github.com/eea/helm-charts/commit/de87af361ff5632f7056066d16983aae54ad43f9)]

### Version 0.31.0 - 01 October 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-241](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`a0c63251`](https://github.com/eea/helm-charts/commit/a0c63251f2949e0006d387adcea1a6e86f4bea16)]

### Version 0.30.0 - 01 October 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-240](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`080b2e63`](https://github.com/eea/helm-charts/commit/080b2e63973a8e43c7076082f110db832f525c69)]

### Version 0.29.2 - 19 September 2025
- Fixed cronsessionscleanup cron expression and pinned busybox to 1.37.0 [Olimpiu Rob - [`a543faff`](https://github.com/eea/helm-charts/commit/a543faff34c5042953b72cefd9947e7b33ed3248)]

### Version 0.29.1 - 01 September 2025
- Release of dependent chart rn-varnish:0.4.0 [EEA Jenkins - [`d5e96fb8`](https://github.com/eea/helm-charts/commit/d5e96fb8de2394345a8fda6a7ab7053913aa4102)]

### Version 0.29.0 - 01 July 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-239](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`42daec73`](https://github.com/eea/helm-charts/commit/42daec73e7c6b0a5175097474a7f46efbe301709)]

### Version 0.28.0 - 01 July 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-238](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`35467fc8`](https://github.com/eea/helm-charts/commit/35467fc8a7b22b2d0164cf4fd14fabfe939372b2)]

### Version 0.27.1 - 21 May 2025
- Release of dependent chart rn-varnish:0.3.0 [EEA Jenkins - [`69ba39a`](https://github.com/eea/helm-charts/commit/69ba39a15cf9ba6197f23acb749272e1d5e92302)]

### Version 0.27.0 - 12 May 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-237](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`51f8919`](https://github.com/eea/helm-charts/commit/51f8919f887247a685f174007572f70f5804fa36)]

### Version 0.26.0 - 09 May 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-236](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`284b97a`](https://github.com/eea/helm-charts/commit/284b97a4ba3b4ad90862902c03f804464234361f)]

### Version 0.25.0 - 30 April 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-235](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`56b8e36`](https://github.com/eea/helm-charts/commit/56b8e36a5dc390b25e527020cc6e568d93faf858)]

### Version 0.24.0 - 28 April 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-234](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`d849ba5`](https://github.com/eea/helm-charts/commit/d849ba5d3407c1a8c6ea910b24937fe53cf97d0c)]

### Version 0.23.0 - 17 April 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-233](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`8ece20a`](https://github.com/eea/helm-charts/commit/8ece20a2af17c4d8baae5d64949b32b3c9013118)]

### Version 0.22.0 - 16 April 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-232](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`8ae1f34`](https://github.com/eea/helm-charts/commit/8ae1f3482dac80ff36f6f2e9d5d7e7e5c9ce8a55)]

### Version 0.21.0 - 16 April 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-231](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`61baa38`](https://github.com/eea/helm-charts/commit/61baa388172ac5c170a781ab1182ac17c0f673b5)]

### Version 0.20.0 - 15 April 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-230](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`754b90e`](https://github.com/eea/helm-charts/commit/754b90e105dc78011a06040c7ed5054b2a228062)]

### Version 0.19.0 - 15 April 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-229](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`73d5b40`](https://github.com/eea/helm-charts/commit/73d5b402220d67d41595ed59a22f596cbc7d1323)]

### Version 0.18.0 - 14 April 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-228](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`04a7ba9`](https://github.com/eea/helm-charts/commit/04a7ba991a431cff6c3591d14d0cea7fc88bce7b)]

### Version 0.17.0 - 11 April 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-227](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`c8261cf`](https://github.com/eea/helm-charts/commit/c8261cf95cdd4a952e62516d52d37ac58521c8da)]

### Version 0.16.0 - 10 April 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-226](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`9a4aaf7`](https://github.com/eea/helm-charts/commit/9a4aaf7c8b033b77cf90bc7c966777bb77bd8769)]

### Version 0.15.0 - 01 April 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-225](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`aa22bd3`](https://github.com/eea/helm-charts/commit/aa22bd3412cf96032d29eb0356fc4643a61d955b)]

### Version 0.14.0 - 31 March 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-224](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`6ca3871`](https://github.com/eea/helm-charts/commit/6ca38714decc7fbce9b488dd184b7de56e94cdc4)]

### Version 0.13.0 - 25 March 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-223](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`be62d43`](https://github.com/eea/helm-charts/commit/be62d4373ea2eed58725e7f645cd4305bffc6c10)]

### Version 0.12.0 - 25 March 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-222](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`472fc47`](https://github.com/eea/helm-charts/commit/472fc47ac1933759223c8159cbef75f621b40989)]

### Version 0.11.2 - 24 March 2025
- Added zeoClientCacheSize, zeoClientBlobCacheSize, sessionManagerTimeout env variables

### Version 0.11.1 - 24 March 2025
- Added blobstorage volume for blobcache

### Version 0.11.0 - 21 March 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-221](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`63e3356`](https://github.com/eea/helm-charts/commit/63e3356bee3e3531129535244c12e871aa1ab313)]

### Version 0.10.0 - 20 March 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-220](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`8bbffc9`](https://github.com/eea/helm-charts/commit/8bbffc9755feb8d0c662119dcacfd067f4b5d312)]

### Version 0.9.0 - 20 March 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-219](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`8b207f7`](https://github.com/eea/helm-charts/commit/8b207f74d391b808ad947202a9330c50e07083a2)]

### Version 0.8.0 - 20 March 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-218](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`17316a5`](https://github.com/eea/helm-charts/commit/17316a5a7c21368d37da6cbbf52cb5780213289d)]

### Version 0.7.0 - 19 March 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-217](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`afd357e`](https://github.com/eea/helm-charts/commit/afd357ebc5d802c0932a741cbdd65e335db1db47)]

### Version 0.6.0 - 18 March 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-216](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`577399f`](https://github.com/eea/helm-charts/commit/577399f1b7864e62c6c3dc6896006f78e4116a79)]

### Version 0.5.1 - 18 March 2025
- Removed most cpu limits except for clamav

### Version 0.5.0 - 17 March 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-215](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`103685a`](https://github.com/eea/helm-charts/commit/103685a6b143551e4472fa9751762d5f6c50c7d1)]

### Version 0.4.1 - 14 March 2025
- Release of dependent chart rn-varnish:0.2.0 [EEA Jenkins - [`2ce542a`](https://github.com/eea/helm-charts/commit/2ce542a4450495161ae638e29255f8edbc3afbc3)]

### Version 0.4.0 - 14 March 2025
- Automated release of [eeacms/reportek-cdr:6.7.3-214](https://github.com/eea/eea.docker.reportek.cdr-instance/releases) [EEA Jenkins - [`05172fd`](https://github.com/eea/helm-charts/commit/05172fd512faba5cbaf20823417d1b0f2c6209ea)]

### Version 0.3.41
- Updated appVersion to 6.7.3-211.

### Version 0.3.40
- Improved network policy configuration by allowing per-CIDR port specifications in ipBlockRules

### Version 0.3.33
- Fixed url in CSP header.

### Version 0.3.32
- Updated ingress's CSP header.

### Version 0.3.31
- Improved instance network security policy template to allow for more flexibility.

### Version 0.3.30
- Added network policies.
- Updated appVersion to 6.7.3-204.
- Updated rn-zeoserver to 0.1.9.
- Updated rn-varnish to 0.1.10.
- Updated rn-local-converters to 0.1.6.
- Updated rn-clamav to 0.1.8.

### Version 0.3.23
- Updated appVersion to 6.7.3-202.

### Version 0.3.22
- Updated appVersion to 6.7.3-201.

### Version 0.3.21
- Updated appVersion to 6.7.3-200.

### Version 0.3.20
- Added missing env variables for auto env cleanuo.

### Version 0.3.19
- Fixed cronjob command for auto fallin, auto env cleanup and auto cleanup.

### Version 0.3.18
- Updated rn-clamav chart to 0.1.5.

### Version 0.3.17
- Updated rn-zeoserver chart to 0.1.6.

### Version 0.3.16
- Fixed cronjob for auto cleanup.

### Version 0.3.15
- Added cronjob for auto cleanup.

### Version 0.3.14
- Updated appVersion to 6.7.3-199.

### Version 0.3.13
- Updated appVersion to 6.7.3-198.

### Version 0.3.12
- Updated appVersion to 6.7.3-197.

### Version 0.3.11
- Updated appVersion to 6.7.3-196.

### Version 0.3.10
- Updated appVersion to 6.7.3-195.

### Version 0.3.9
- Added computed sentry release

### Version 0.3.8
- Added sentrySite and sentryEnvironment variables.

### Version 0.3.7
- Conditionally create and mount zip_cache pvc/pv if zipCacheEnabled is true.

### Version 0.3.6
- Updated rn-clamav and rn-local-converters

### Version 0.3.5
- Converted template values to use single quotes to handle special characters.

### Version 0.3.4
- Removed repository and tag from instance in values.yaml.

### Version 0.3.3
- Added missing env variables for cronautofallin.

### Version 0.3.2
- Fixed values mix-up.

### Version 0.3.1
- Fixed the webforms related questions.

### Version 0.3.0
- Added webforms to the list of services.

### Version 0.2.15
- Updated rn-clamav chart to 0.1.3.
- Updated rn-varnish chart to 0.1.5.

### Version 0.2.14
- Updated appVersion to 6.7.3-194.

### Version 0.2.13
- questions.yaml updates.

### Version 0.2.12
- More updates to the questions.yaml related to ingress.

### Version 0.2.11
- Updated questions.yaml for ingress.

### Version 0.2.10
- Fixed SSRF on Converters/run_conversion.

### Version 0.2.9
- Added nginx server snippet to ingress to prevent SSRF on Converters/run_conversion.

### Version 0.2.8
- Added sentryDSN to questions.yaml.

### Version 0.2.7
- Added zeoAddress to questions.yaml and re-labeled ingress backend service name.

### Version 0.2.6
- Added varnish backend configuration in questions.yaml.

### Version 0.2.5
- Updated rn-zeoserver chart to 0.1.5.

### Version 0.2.4
- Added additional ingress configuration options in questions.yaml.

### Version 0.2.3
- More reorganization of questions.yaml.

### Version 0.2.2
- Reorganized questions.yaml and added more questions.

### Version 0.2.1
- Added questions.yaml.

### Version 0.2.0
- Updated rn-zeoserver chart to 0.1.2.

### Version 0.1.9
- Fixed liveness probe and readiness probe in deployment.

### Version 0.1.8
- Updated readme.
- Moved liveness probes out of the deployment.

### Version 0.1.7
- Refactoring and cleanup.
- Updated rn-varnish chart to 0.1.4.
- Updated rn-local-converters chart to 0.1.2.
- Updated rn-clamav chart to 0.1.2.
- Updated ingress.

### Version 0.1.6
- Refactored to be able to install multiple stacks in the same namespace. Due to the chart naming, we can't solely rely on appl.fullname for service naming.
- Dropped deployment since it's not needed, we can use RELEASE instead.
- Removed storage PVC since it's not needed.

### Version 0.1.5
- Added rabbitmq.create and rabbitmq.name. When create is true, the rabbitmq service will be created.

### Version 0.1.4
- Get the image and tag from image section.

### Version 0.1.3
- Changed rabbitmq to externalName.

### Version 0.1.2
- Updated rn-varnish chart to 0.1.3 and fix ingress path.

### Version 0.1.1
- Updated rn-varnish chart to 0.1.2.

### Version 0.1.0
- Initial release.
