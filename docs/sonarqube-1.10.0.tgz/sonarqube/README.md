# SonarQube

## What is inside SonarQube Stack?

* [SonarQube Server](http://www.sonarqube.org/)
* Postgres Database

## Installing Plugins Manually

* Go to [Plugin Library](http://docs.sonarqube.org/display/PLUG/Plugin+Library) and find your favourite plugins
* On the SonarQube container, go to /opt/sonarqube/extensions/plugins and put your plugins here
* Restart SonarQube container.

## First Start

* Use admin/admin to login to the SonarQube interface.

## Variables

* *SonarQube web jvm options* - used on SonarQube application
* *Sonarqube database name* - used by SonarQube
* *Sonarqube database user* - the user used by SonarQube to connect to the database
* *Sonarqube database password* - the password used by SonarQube to connect to the database
* *Postgres SuperUser*, *Postgres SuperUser Password* - the Postgres user credentials with administrative access
* *Schedule Sonarqube services on hosts with following host labels* - Comma separated list of host labels (e.g. key1=value1,key2=value2) to be used for scheduling Sonarqube
* *Schedule database on hosts with following host labels* - Comma separated list of host labels (e.g. key1=value1,key2=value2) to be used for scheduling Postgres
* *Database data volume driver* - default local
* *Database data volume driver options* - used in rancher_ebs volumes to set size
* *Sonarqube services volumes' driver* - default local
* *Sonarqube services volumes' driver options* -  used in rancher_ebs volumes to set size
* *Time zone* - default `Europe/Copenhagen`

### Postfix variables

* `SonarQube server name` - used in Postfix to send emails
* `Postfix relay` - Postfix SMTP relay
* `Postfix relay port` - Postfix SMTP relay port
* `Postfix user` - SMTP user
* `Postfix password` - SMTP user password

## Rancher LB

This service should be exposed in rancher lb:

* sonarqube:9000

## Upgrade

The official documentation is: <https://docs.sonarqube.org/latest/setup/upgrading/>
Because we are using docker, we only need to access <http://yourSonarQubeServerURL/setup>  to finish the upgrade.


## Releases

### Version 1.10.0 - 27 October 2026
- Automated release of sonarqube:2026.5.3-developer [EEA Jenkins - [`ec53c61eb`](https://github.com/eea/helm-charts/commit/ec53c61ebad10226217a01d423c66219539458df)]

### Version 1.9.1 - 16 October 2026
- fix version [valentinab25 - [`6d7906f3`](https://github.com/eea/helm-charts/commit/6d7906f375d4b2dba90a2b2df690853fdbacff88)]

### Version 1.9.0 - 20 July 2026
- Automated release of sonarqube:-developer [EEA Jenkins - [`967d2a13`](https://github.com/eea/helm-charts/commit/967d2a134be96efe0d3b0916f5ca3c01c0360d45)]

### Version 1.8.0 - 03 June 2026
- Automated release of sonarqube:2026.3.1-developer [EEA Jenkins - [`da018c79`](https://github.com/eea/helm-charts/commit/da018c79bd6e20e51c7babf87170987373c9f109)]

### Version 1.7.0 - 20 May 2026
- Automated release of sonarqube:2026.3.0-developer [EEA Jenkins - [`c95bf67e`](https://github.com/eea/helm-charts/commit/c95bf67e8242d923598eb9401400d23900a355f7)]

### Version 1.6.0 - 14 May 2026
- Automated release of sonarqube:2026.2.1-developer [EEA Jenkins - [`d5a509ca`](https://github.com/eea/helm-charts/commit/d5a509ca259725e25099dd90f4ff81dc6f927c92)]

### Version 1.5.0 - 14 May 2026
- Set the developer version as default [valentinab25 - [`bf9cf775`](https://github.com/eea/helm-charts/commit/bf9cf7751d75a04aedca7ace30bc786f9ce242ce)]

### Version 1.4.9 - 25 March 2026
- Add letsencrypt net sec policy [valentinab25 - [`f7837431`](https://github.com/eea/helm-charts/commit/f7837431eb8c50e21e5a2067eb7368218029b0a5)]

### Version 1.4.8 - 28 January 2026
- Upgrade eeacms/postgres:16.9-1 [EEA Jenkins - [`fa84737e`](https://github.com/eea/helm-charts/commit/fa84737e02b1a71731e649efe3d72c0c913f7c96)]

### Version 1.4.7 - 27 January 2026
- Add postfix exception [EEA Jenkins - [`1e55e157`](https://github.com/eea/helm-charts/commit/1e55e15794a4bf548c9d8fbd1a826eeb8af32c97)]

### Version 1.4.6 - 27 January 2026
- Fix egress security [EEA Jenkins - [`c57e457d`](https://github.com/eea/helm-charts/commit/c57e457d377a894f617d8b06ca8740cbb085d4d0)]

### Version 1.4.5 - 27 January 2026
- Add more security and details [EEA Jenkins - [`4250b493`](https://github.com/eea/helm-charts/commit/4250b493ae96d3cffaf6499755673c29130bbdda)]

### Version 1.4.4 - 26 January 2026
- use latest postfix update [EEA Jenkins - [`4c43cea7`](https://github.com/eea/helm-charts/commit/4c43cea75217c566d335795a0bc7915d9e479ca4)]

### Version 1.4.3 - 26 January 2026
- Fix spacing [EEA Jenkins - [`a5c3ba5b`](https://github.com/eea/helm-charts/commit/a5c3ba5b8a2129e737523de118d1378e905e7b92)]

### Version 1.4.2 - 26 January 2026
- fix spacing [EEA Jenkins - [`7e4a77c2`](https://github.com/eea/helm-charts/commit/7e4a77c209e5669dcf86ecfa2c7c8733c5f29882)]

### Version 1.4.1 - 26 January 2026
- Fix postgres policy, add postfix policy for mailtrap http [EEA Jenkins - [`338bf9c7`](https://github.com/eea/helm-charts/commit/338bf9c7d4ccc78592a16ce8fb727be91eff399e)]

### Version 1.4.0 - 26 January 2026
- Upgrade sonarqube, add security [EEA Jenkins - [`d91b3fcf`](https://github.com/eea/helm-charts/commit/d91b3fcf7378bbc2f5f466e213c4e3b04ec93ce6)]

### Version 1.3.1 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`7c3a1781`](https://github.com/eea/helm-charts/commit/7c3a1781fc525c95079ccbaaadb82f2f66ff4c46)]

### Version 1.3.0 - 28 November 2025
- Automated upgrade on sonarqube appVersion to 25.11.0.114957 [EEA Jenkins - [`7a3df078`](https://github.com/eea/helm-charts/commit/7a3df078ed4a77a6e20a2e3e58fb152314818fec)]

### Version 1.2.0 - 29 October 2025
- Upgrade sonarqube to 25.10.0 [valentinab25 - [`365d61eb`](https://github.com/eea/helm-charts/commit/365d61eb5b223160474e6c20d507fd46a80b83e8)]

### Version 1.1.1 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`bb6439ee`](https://github.com/eea/helm-charts/commit/bb6439eee50556705dd26a4952617f2bcc9ab810)]

### Version 1.1.0 - 13 June 2025
- Upgrade to 25.6.0.109173-community [valentinab25 - [`43a743b`](https://github.com/eea/helm-charts/commit/43a743b388c2b4389bc19da01f688b7b5278c53f)]

### Version 1.0.2 - 11 June 2025
- Fix healthcheck [valentinab25 - [`f623833`](https://github.com/eea/helm-charts/commit/f623833d27e17f185e7a5a6d0d3f31478cc23da0)]

### Version 1.0.1 - 11 June 2025
- Small question fixes [valentinab25 - [`5a7a1af`](https://github.com/eea/helm-charts/commit/5a7a1af5c1e0200a65ca5dbbae32579d70d439fd)]

### Version 1.0.0 - 10 June 2025
- First draft
