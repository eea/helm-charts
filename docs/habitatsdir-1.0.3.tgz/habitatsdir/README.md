# Nature Directives expert review tool

This chart is configured to require little or no configuration for development and test usage.

If you need to modify, then create a new .yaml file with the modifications.

For the database password, use the default values, or if you already have an existing database,
set the values in the database section.

## Production

It is assumed you have done helm add repo eea-charts https://eea.github.io/helm-charts/

To set the app up for Article 17 do:
    Use a private repository for the production configuration.
    Then copy art17-values.yaml from the sources and add the passwords etc.
    helm install art17 habitatsdir -f art17-values.yaml

To set the app up for Article 12 do:
    Use a private repository for the production configuration.
    Then copy art12-values.yaml from the sources and add the passwords etc.
    helm install art17 habitatsdir -f art12-values.yaml

## Releases

### Version 1.0.3 - 07 May 2026
- Upgraded eeacms/art17-consultation [Diana Boiangiu - [`d3d741c9`](https://github.com/eea/helm-charts/commit/d3d741c9a4a87bd90340f40c1abe67921319f673)]

### Version 1.0.2 - 07 May 2026
- Upgraded eeacms/art17-consultation [Diana Boiangiu - [`220ddf10`](https://github.com/eea/helm-charts/commit/220ddf10d2936faae34d932ece83211467827812)]

### Version 1.0.1 - 07 May 2026
- Upgraded eeacms/eeacms/art17-consultation  [Diana Boiangiu - [`769d9f14`](https://github.com/eea/helm-charts/commit/769d9f14f166dedcb47726cb1fb7663964ad4656)]

### Version 1.0.0 - 24 April 2026
- Upgraded eeacms/eeacms/art17-consultation [Diana Boiangiu - [`f3311cb6`](https://github.com/eea/helm-charts/commit/f3311cb6c737f3b68ce061956242b0913093e6bc)]

### Version 0.4.13 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`231ba58c`](https://github.com/eea/helm-charts/commit/231ba58c2cc9e2b3e1e8619d8943f1bfb82e5d93)]

### Version 0.4.12 - 06 October 2025
- Update habitatsdir art17-values.yaml file [Diana Boiangiu - [`4f266e5f`](https://github.com/eea/helm-charts/commit/4f266e5fc85b80559a86287175663fd121cc151a)]

### Version 0.4.11 - 06 October 2025
- Update habitatsdir art12-values.yaml file [Diana Boiangiu - [`a1305c15`](https://github.com/eea/helm-charts/commit/a1305c150621d0fa0ef40ef1becbc334cebbe7b4)]

### Version 0.4.10 - 29 September 2025
- Release on habitatsdir version 0.4.10 [Diana Boiangiu - [`bd7adc9e`](https://github.com/eea/helm-charts/commit/bd7adc9ea7e68c9bd961f11b76100c9fe65efb27)]

### Version 0.4.9 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`d8254400`](https://github.com/eea/helm-charts/commit/d8254400f6daf9436a933c38d5033fad6264b5a1)]


### Version 0.4.8 - 24 February 2025
- Remove unused mysql service

### Version 0.4.7 - 03 February 2025
- Upgraded eeacms/eeacms/art17-consultation

### Version 0.4.6 - 15 November 2024
- Upgraded eeacms/eeacms/art17-consultation

### Version 0.4.5 - 13 November 2024
- Upgraded eeacms/art12-viewer

### Version 0.4.4 - 30 October 2024
- Upgraded eeacms/art12-viewer

### Version 0.4.3 - 3 September 2024
- Reverted incorrect use of values.yaml file. Updated version of postfix subchart to 2.0.0.

### Version 0.4.2
- Upgraded art17 ingress.

### Version 0.4.1
  <dd>Update eeacms/art17-consultation and eeacms/art12-viewer<dd>

### Version 0.4.0
- Replace mailfwd with postfix subchart.

### Version 0.3.3
- Hardwire versions of mariadb and postgresql.

### Version 0.3.2
- Also allow ingress to reach static resources.

### Version 0.3.1
- More network security policies for ingress.

### Version 0.3.0
- Added network security policy to prevent egress from database pods.


