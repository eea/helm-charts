# Copernicus Land Monitoring Service (CLMS) frontend - Plone 6

This chart deploys the Copernicus Land Monitoring Service (CLMS) frontend application using Volto.

## Architecture

The chart deploys a three-tier architecture:
- **Volto Frontend**: React-based frontend application
- **Varnish**: HTTP cache layer
- **Backend**: External Plone backend service

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| image.repository | string | eeacms/clms-frontend | Container image repository |
| image.tag | string | "" | Image tag (uses Chart.appVersion if empty) |
| links.backend | string | backend-varnish.clms | Service name for backend varnish instance |
| volto.hostname | string | dev-clms.copernicus.01dev.eea.europa.eu | Hostname for the application |
| volto.replicaCount | int | 1 | Number of frontend replicas |
| volto.environment.RAZZLE_BACKEND_NAME | string | eea.docker.plone.clms | Backend identifier |
| volto.environment.DANSWER_URL | string | "" | Danswer service URL |
| volto.environment.LLMGW_URL | string | "" | LLM Gateway URL |

## Releases

### Version 7.69.0 - 17 August 2026
- Automated release of [eeacms/clms-frontend:3.589.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`db8e07cf`](https://github.com/eea/helm-charts/commit/db8e07cfd9d3e9d7ee74999817d304e82bfd611b)]

### Version 7.68.0 - 17 August 2026
- Automated release of [eeacms/clms-frontend:3.588.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`78b3cf92`](https://github.com/eea/helm-charts/commit/78b3cf9281ec20832d3d7b970d8d80b38161d4c7)]

### Version 7.67.0 - 14 August 2026
- Automated release of [eeacms/clms-frontend:3.587.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`1bead578`](https://github.com/eea/helm-charts/commit/1bead57869e7171f4a121589df3e73c55ca67bdc)]

### Version 7.66.0 - 14 August 2026
- Automated release of [eeacms/clms-frontend:3.586.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`991d1116`](https://github.com/eea/helm-charts/commit/991d11163ea5edfb7a51ec40bd1ff0c7c1e9bd56)]

### Version 7.65.0 - 13 August 2026
- Automated release of [eeacms/clms-frontend:3.585.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`4db3b0ea`](https://github.com/eea/helm-charts/commit/4db3b0eacc848b8e09166a7e61bcfcd2afcaae68)]

### Version 7.64.0 - 12 August 2026
- Automated release of [eeacms/clms-frontend:3.584.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`0f851948`](https://github.com/eea/helm-charts/commit/0f8519486cf2c0b9c34b894f4d55910d73b03459)]

### Version 7.63.0 - 12 August 2026
- Automated release of [eeacms/clms-frontend:3.583.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`33db1c1a`](https://github.com/eea/helm-charts/commit/33db1c1ab21450ee81ffd4b46af0886f2f6b92e2)]

### Version 7.62.0 - 12 August 2026
- Automated release of [eeacms/clms-frontend:3.582.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`54cd9d13`](https://github.com/eea/helm-charts/commit/54cd9d13d436a34c95fb999500a82c75261bfa39)]

### Version 7.61.0 - 07 August 2026
- Automated release of [eeacms/clms-frontend:3.581.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`b20c968c`](https://github.com/eea/helm-charts/commit/b20c968c99c1f833f5eeeaa8b213e5b0f7539fe9)]

### Version 7.60.0 - 07 August 2026
- Automated release of [eeacms/clms-frontend:3.580.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f481e527`](https://github.com/eea/helm-charts/commit/f481e527bbedb1266056835f7badf4bc4b0e4d14)]

### Version 7.59.0 - 04 August 2026
- Automated release of [eeacms/clms-frontend:3.579.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f0dd7870`](https://github.com/eea/helm-charts/commit/f0dd78704831ca580230223ca0723b5564d8c3f0)]

### Version 7.58.0 - 16 July 2026
- Automated release of [eeacms/clms-frontend:3.578.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`c1a8a153`](https://github.com/eea/helm-charts/commit/c1a8a153815da51d66fd9962a324068bff29ccb4)]

### Version 7.57.0 - 15 July 2026
- Automated release of [eeacms/clms-frontend:3.577.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`cdffff99`](https://github.com/eea/helm-charts/commit/cdffff99518aa21741a3a44f64900554588e731a)]

### Version 7.56.2 - 15 July 2026
- minor fix [Dobricean Ioan Dorian - [`1a036598`](https://github.com/eea/helm-charts/commit/1a0365983771d7f8e56e8703e1189fee461f7be2)]

### Version 7.56.0 - 14 July 2026
- Automated release of [eeacms/clms-frontend:3.576.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`32bfb318`](https://github.com/eea/helm-charts/commit/32bfb31807e8686a27262395574bfb29337d92b1)]

### Version 7.55.0 - 02 July 2026
- Automated release of [eeacms/clms-frontend:3.575.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`8576df56`](https://github.com/eea/helm-charts/commit/8576df56e0c878f8c05abf977fcc5d7fd6ba9225)]

### Version 7.54.0 - 02 July 2026
- Automated release of [eeacms/clms-frontend:3.574.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`9500a2f5`](https://github.com/eea/helm-charts/commit/9500a2f56daffc6bf8637b52e84727788311a127)]

### Version 7.53.0 - 01 July 2026
- Automated release of [eeacms/clms-frontend:3.573.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`deae8146`](https://github.com/eea/helm-charts/commit/deae81467bdfd4be2b567266935609a45548d930)]

### Version 7.52.0 - 29 June 2026
- Automated release of [eeacms/clms-frontend:3.572.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`8192322f`](https://github.com/eea/helm-charts/commit/8192322f77d9f42b4c5f4d1dbb47f741f68ba21c)]

### Version 7.51.0 - 22 June 2026
- Automated release of [eeacms/clms-frontend:3.571.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`0d2935f3`](https://github.com/eea/helm-charts/commit/0d2935f358b76bd0d0fc0a95cba028e6328ba19d)]

### Version 7.50.0 - 11 June 2026
- Automated release of [eeacms/clms-frontend:3.570.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`8f49d78c`](https://github.com/eea/helm-charts/commit/8f49d78c253cfe93c75e5de33c332aaecddae9b0)]

### Version 7.49.1 - 10 June 2026
- Remove CSP from ingress [valentinab25 - [`528726d2`](https://github.com/eea/helm-charts/commit/528726d2091c5b7a86ebb53e5b58f70c0cdb775a)]

### Version 7.49.0 - 09 June 2026
- Automated release of [eeacms/clms-frontend:3.569.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f92c6729`](https://github.com/eea/helm-charts/commit/f92c67291a53bcf1b4a825736f2438529387e77d)]

### Version 7.48.0 - 08 June 2026
- Automated release of [eeacms/clms-frontend:3.568.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`9aac87b8`](https://github.com/eea/helm-charts/commit/9aac87b8279f7428f6b3be66a75c3f08087bed1a)]

### Version 7.47.0 - 05 June 2026
- Automated release of [eeacms/clms-frontend:3.567.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`d3976273`](https://github.com/eea/helm-charts/commit/d39762739cc90298694f52fc728486e55e99791a)]

### Version 7.46.0 - 05 June 2026
- Automated release of [eeacms/clms-frontend:3.566.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`d076d180`](https://github.com/eea/helm-charts/commit/d076d1801c05cbece455b607bfb79105516fe484)]

### Version 7.45.0 - 05 June 2026
- Automated release of [eeacms/clms-frontend:3.565.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`2a93b072`](https://github.com/eea/helm-charts/commit/2a93b072ccc1de11e94e825da961f91645849e16)]

### Version 7.44.0 - 03 June 2026
- Automated release of [eeacms/clms-frontend:3.564.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`78e32d1e`](https://github.com/eea/helm-charts/commit/78e32d1e925fbd50dc236a858c4a0f3d45ee1f09)]

### Version 7.43.0 - 02 June 2026
- Automated release of [eeacms/clms-frontend:3.563.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`4983bc6b`](https://github.com/eea/helm-charts/commit/4983bc6bab683d17317fae15b498dd58b268c2a9)]

### Version 7.42.2 - 02 June 2026
- fix apache [Dobricean Ioan Dorian - [`34c30dd3`](https://github.com/eea/helm-charts/commit/34c30dd38deb802608d4e3078d0967db9963af52)]

### Version 7.42.1 - 02 June 2026
- Move Apache VirtualHost config from the container environment into a mounted ConfigMap to avoid oversized process environments.

### Version 7.42.0 - 29 May 2026
- Automated release of [eeacms/clms-frontend:3.562.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f71a949e`](https://github.com/eea/helm-charts/commit/f71a949eaaf3b0f261341ea269024c7f0b5adf75)]

### Version 7.41.0 - 25 May 2026
- Automated release of [eeacms/clms-frontend:3.561.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`a8679bc3`](https://github.com/eea/helm-charts/commit/a8679bc3c7a95ebd5517772cb6606ca012eeb9fc)]

### Version 7.40.0 - 22 May 2026
- Automated release of [eeacms/clms-frontend:3.560.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`b96997b2`](https://github.com/eea/helm-charts/commit/b96997b2c19777ce47bd14c963e7565e05a3d5f4)]

### Version 7.39.1 - 22 May 2026
- Remove oauth ingress [valentinab25 - [`a1385ed0`](https://github.com/eea/helm-charts/commit/a1385ed06c37fc385e158a53ffb24ca788ff7984)]

### Version 7.39.0 - 22 May 2026
- Automated release of clms-frontend:3.559.0 [EEA Jenkins - [`d97e4ad3`](https://github.com/eea/helm-charts/commit/d97e4ad38af9c3156f2d206c86ebf845b1d2cdd7)]

### Version 7.38.3 - 21 May 2026
- Add ratelimiting for egms oauth api configuration [valentinab25 - [`819509e2`](https://github.com/eea/helm-charts/commit/819509e25173094af652b16503697acd4af9b9f6)]

### Version 7.38.2 - 21 May 2026
- test auto deploy [Dobricean Ioan Dorian - [`3c293aac`](https://github.com/eea/helm-charts/commit/3c293aace07d69d44c144de6ae1b97f98990a13f)]

### Version 7.38.0 - 21 May 2026
- Automated release of [eeacms/clms-frontend:3.558.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`b1ee20c0`](https://github.com/eea/helm-charts/commit/b1ee20c0c5dc23d5c6a9ed77cd34264f90b67477)]

### Version 7.37.0 - 19 May 2026
- Automated release of [eeacms/clms-frontend:3.557.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`bd839dcb`](https://github.com/eea/helm-charts/commit/bd839dcb24a02a3807b056072df7572c66da71dd)]

### Version 7.36.0 - 18 May 2026
- Automated release of [eeacms/clms-frontend:3.556.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`9a8265e9`](https://github.com/eea/helm-charts/commit/9a8265e97ef523d45f4833396d180d652192eb59)]

### Version 7.35.0 - 15 May 2026
- Automated release of [eeacms/clms-frontend:3.555.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`001d39d7`](https://github.com/eea/helm-charts/commit/001d39d72eac723467e697567b7c1026a25729fd)]

### Version 7.34.0 - 14 May 2026
- Automated release of [eeacms/clms-frontend:3.554.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`3bafdc18`](https://github.com/eea/helm-charts/commit/3bafdc18d5138d00fdc631ac91a167e4d483e517)]

### Version 7.33.0 - 13 May 2026
- Automated release of [eeacms/clms-frontend:3.553.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`4f11fc93`](https://github.com/eea/helm-charts/commit/4f11fc93264d9d0c9947798dbfa61c57da738903)]

### Version 7.32.0 - 13 May 2026
- Automated release of [eeacms/clms-frontend:3.552.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`b0714b84`](https://github.com/eea/helm-charts/commit/b0714b84ebacb0ef919a41ed56743023ffab64bb)]

### Version 7.31.0 - 12 May 2026
- Automated release of [eeacms/clms-frontend:3.551.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`3e03d496`](https://github.com/eea/helm-charts/commit/3e03d4965347b8938d6826cfaf5903deab22bbad)]

### Version 7.30.0 - 11 May 2026
- Automated release of [eeacms/clms-frontend:3.550.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`4a3f2fd6`](https://github.com/eea/helm-charts/commit/4a3f2fd64b72fe95a3f2f6dd9f4828e070c72575)]

### Version 7.29.1 - 11 May 2026
- fix csp [Dobricean Ioan Dorian - [`b4b02ba9`](https://github.com/eea/helm-charts/commit/b4b02ba9cb4b959fc222aa2553990ff6bb20d67e)]

### Version 7.29.0 - 08 May 2026
- Automated release of [eeacms/clms-frontend:3.549.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`be45d124`](https://github.com/eea/helm-charts/commit/be45d124f6dc49b9d6bdad92e317591238797112)]

### Version 7.28.0 - 08 May 2026
- Automated release of [eeacms/clms-frontend:3.548.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`c4072973`](https://github.com/eea/helm-charts/commit/c4072973f7e3bd68ffa059d7fd3ac4dfb6963aef)]

### Version 7.27.1 - 04 May 2026
- Use HTTP probes for Apache health checks.

### Version 7.27.0 - 04 May 2026
- Automated release of [eeacms/clms-frontend:3.547.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`657f5231`](https://github.com/eea/helm-charts/commit/657f5231d51af1fb8ab42f26dac2eb103d6bbbd7)]

### Version 7.26.0 - 28 April 2026
- Automated release of [eeacms/clms-frontend:3.546.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`b5082537`](https://github.com/eea/helm-charts/commit/b5082537418cdf8c99a571f095be35a3b233a1de)]

### Version 7.25.2 - 24 April 2026
- revert to old nginx [Dobricean Ioan Dorian - [`5f7446fa`](https://github.com/eea/helm-charts/commit/5f7446fa375a1bc76cc05145034b9ad100c49271)]

### Version 7.25.1 - 23 April 2026
- fix configuration snippets [Dobricean Ioan Dorian - [`7e544e6d`](https://github.com/eea/helm-charts/commit/7e544e6df30a0e87c40aa3647becf60f26e1a40a)]

### Version 7.25.0 - 17 April 2026
- Automated release of [eeacms/clms-frontend:3.545.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`a767411f`](https://github.com/eea/helm-charts/commit/a767411f087b6a3d24d898b8f4a60c3403ce2688)]

### Version 7.24.0 - 14 April 2026
- Automated release of [eeacms/clms-frontend:3.544.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`6c0e4993`](https://github.com/eea/helm-charts/commit/6c0e49937eccd9949a15d6227626d4fd071b7b5c)]

### Version 7.23.0 - 10 April 2026
- Automated release of [eeacms/clms-frontend:3.543.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`e7ad4ffc`](https://github.com/eea/helm-charts/commit/e7ad4ffc7c7fc3fab82a82ea1b68e86a4be68fa2)]

### Version 7.22.0 - 08 April 2026
- Automated release of [eeacms/clms-frontend:3.542.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`1d8a58c1`](https://github.com/eea/helm-charts/commit/1d8a58c134bbdf75711b1f8a95a45400be9de7ae)]

### Version 7.21.0 - 07 April 2026
- Automated release of [eeacms/clms-frontend:3.541.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`493a1472`](https://github.com/eea/helm-charts/commit/493a14729235eb59a36da8ae01fabb0c17cb1b6b)]

### Version 7.20.0 - 02 April 2026
- Automated release of [eeacms/clms-frontend:3.540.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`7649611a`](https://github.com/eea/helm-charts/commit/7649611ab682f977059dc3ff90d81a6e73b6546d)]

### Version 7.19.0 - 31 March 2026
- Automated release of [eeacms/clms-frontend:3.539.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`d0e3c9ee`](https://github.com/eea/helm-charts/commit/d0e3c9ee59d9f1fe6d433dd86bfe28c3c24aa063)]

### Version 7.18.0 - 26 March 2026
- Automated release of [eeacms/clms-frontend:3.538.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`085923a6`](https://github.com/eea/helm-charts/commit/085923a639d660ff517800c671b26252dced55f3)]

### Version 7.17.0 - 23 March 2026
- Automated release of [eeacms/clms-frontend:3.537.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`72e05ea3`](https://github.com/eea/helm-charts/commit/72e05ea3e11c843f714555d8a4d4f7ff293bb33e)]

### Version 7.16.0 - 20 March 2026
- Automated release of [eeacms/clms-frontend:3.536.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`fe7e494e`](https://github.com/eea/helm-charts/commit/fe7e494e8422a044c1bbcf21bbef054f05595d46)]

### Version 7.15.0 - 12 March 2026
- Automated release of [eeacms/clms-frontend:3.535.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`d8c42642`](https://github.com/eea/helm-charts/commit/d8c42642e2f08aef002ee5bdd1c2c477582a6dc5)]

### Version 7.14.0 - 12 March 2026
- Automated release of [eeacms/clms-frontend:3.534.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`2545a777`](https://github.com/eea/helm-charts/commit/2545a77759fc54b113a12eb43de19a871393b912)]

### Version 7.13.0 - 12 March 2026
- Automated release of [eeacms/clms-frontend:3.533.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`5293cedc`](https://github.com/eea/helm-charts/commit/5293cedcbbeed103caadcc1648fd1accd3aebc37)]

### Version 7.12.0 - 11 March 2026
- Automated release of [eeacms/clms-frontend:3.532.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`439c6062`](https://github.com/eea/helm-charts/commit/439c60625ddd8e8e037cb7f242869f1ae4b97584)]

### Version 7.11.0 - 10 March 2026
- Automated release of [eeacms/clms-frontend:3.531.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`eb77a6e2`](https://github.com/eea/helm-charts/commit/eb77a6e23b7dc0eb92113b8742aa0abbf9ef3c4e)]

### Version 7.10.0 - 10 March 2026
- Automated release of [eeacms/clms-frontend:3.530.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`a1b59f66`](https://github.com/eea/helm-charts/commit/a1b59f66b50618b4b5dab2f61cedcafa71f92645)]

### Version 7.9.0 - 09 March 2026
- Automated release of [eeacms/clms-frontend:3.529.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`79cf4f57`](https://github.com/eea/helm-charts/commit/79cf4f576179078ae131b2f284fb2c12683e47d4)]

### Version 7.8.0 - 04 March 2026
- Automated release of [eeacms/clms-frontend:3.528.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`0b8a2130`](https://github.com/eea/helm-charts/commit/0b8a213031670f82e577c4a3c7069ba8553190c7)]

### Version 7.7.0 - 03 March 2026
- Automated release of [eeacms/clms-frontend:3.527.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`dd0c8da9`](https://github.com/eea/helm-charts/commit/dd0c8da9e86136d29ad64b5aa4d9a18dc29f3805)]

### Version 7.6.0 - 02 March 2026
- Automated release of [eeacms/clms-frontend:3.526.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`1e203a13`](https://github.com/eea/helm-charts/commit/1e203a131e3b1e243ee9dd61ba4673811e5b78a4)]

### Version 7.5.0 - 26 February 2026
- Automated release of [eeacms/clms-frontend:3.525.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f7dc4c1c`](https://github.com/eea/helm-charts/commit/f7dc4c1c7802292c1251a3f21d6b5537b817e036)]

### Version 7.4.0 - 24 February 2026
- nginx [Dobricean Ioan Dorian - [`ec63785a`](https://github.com/eea/helm-charts/commit/ec63785acff9437a8351d3153b9f4bf0238db81c)]

### Version 7.3.0 - 23 February 2026
- Automated release of [eeacms/clms-frontend:3.524.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`95eec5d3`](https://github.com/eea/helm-charts/commit/95eec5d30dc6692172bcb37f09dc09e57b8ddaa8)]

### Version 7.2.1 - 21 February 2026
- fix ingress [Dobricean Ioan Dorian - [`12f5224b`](https://github.com/eea/helm-charts/commit/12f5224b4e61a7b013353cfcbb225342b95ad25a)]

### Version 7.2.0 - 19 February 2026
- Automated release of [eeacms/clms-frontend:3.523.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`a950ab56`](https://github.com/eea/helm-charts/commit/a950ab56c03fddfe12e2d18dd961c142e746d1b3)]

### Version 7.1.0 - 17 February 2026
- Automated release of [eeacms/clms-frontend:3.522.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`c1284a59`](https://github.com/eea/helm-charts/commit/c1284a5949fbe017caa21ed8b9efe9244ea134b0)]

### Version 7.0.0 - 16 February 2026
- add apache and static content [Dobricean Ioan Dorian - [`d4738ee5`](https://github.com/eea/helm-charts/commit/d4738ee51a7812490973c6fb09198466e698b0a0)]

### Version 6.0.0 - 15 February 2026
- fix ingresses and apache [Dobricean Ioan Dorian - [`fb31f9eb`](https://github.com/eea/helm-charts/commit/fb31f9eb2a26bbd3c5872eea1a80689711ef6757)]

### Version 5.0.0 - 15 February 2026
- apache [Dobricean Ioan Dorian - [`e9599a31`](https://github.com/eea/helm-charts/commit/e9599a31a93ddf0666616e4d989101b6a83a171d)]

### Version 4.0.0 - 15 February 2026
- apache [Dobricean Ioan Dorian - [`03e33fe9`](https://github.com/eea/helm-charts/commit/03e33fe985c70c05b4250d3f3a9c62e57e6df254)]

### Version 3.521.0 - 13 February 2026
- Automated release of [eeacms/clms-frontend:3.521.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`b4b9704b`](https://github.com/eea/helm-charts/commit/b4b9704bbb4475c8efb5475d5acfc9ad6c486df8)]

### Version 3.520.0 - 11 February 2026
- Automated release of [eeacms/clms-frontend:3.520.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`e662a2c6`](https://github.com/eea/helm-charts/commit/e662a2c68a17178f9577f8ddecf0241fd9a30796)]

### Version 3.519.0 - 10 February 2026
- Automated release of [eeacms/clms-frontend:3.519.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`b8794b0c`](https://github.com/eea/helm-charts/commit/b8794b0c2772c9b3bf58c77115d33b0e606fa39e)]

### Version 3.518.0 - 09 February 2026
- Automated release of [eeacms/clms-frontend:3.518.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`63cf3cef`](https://github.com/eea/helm-charts/commit/63cf3cefbc9637fed16dbb29a89a5c2411103a43)]

### Version 3.517.0 - 04 February 2026
- Automated release of [eeacms/clms-frontend:3.517.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`06a220e8`](https://github.com/eea/helm-charts/commit/06a220e8c8d4a01e6d9b8deacf33f01a8027ee45)]

### Version 3.516.0 - 02 February 2026
- Automated release of [eeacms/clms-frontend:3.516.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`43f4324f`](https://github.com/eea/helm-charts/commit/43f4324f250476e80ee03e000bb0c1f0541f842b)]

### Version 3.515.0 - 29 January 2026
- Automated release of [eeacms/clms-frontend:3.515.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`35c6ecc2`](https://github.com/eea/helm-charts/commit/35c6ecc28d8e4520bc0c906d8984867a6b96d0d0)]

### Version 3.514.0 - 29 January 2026
- Automated release of [eeacms/clms-frontend:3.514.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`976b4428`](https://github.com/eea/helm-charts/commit/976b4428330fc87b6ee0244f11e94c647e5d8cbf)]

### Version 3.513.0 - 28 January 2026
- Automated release of [eeacms/clms-frontend:3.513.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`789c6b9e`](https://github.com/eea/helm-charts/commit/789c6b9e43e345dc01480919abf70de7aec22bc6)]

### Version 3.512.0 - 27 January 2026
- Automated release of [eeacms/clms-frontend:3.512.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`d20c9293`](https://github.com/eea/helm-charts/commit/d20c9293ba6d2106523d42fd825a3d7d491c8fd8)]

### Version 3.511.0 - 27 January 2026
- Automated release of [eeacms/clms-frontend:3.511.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`1d66622d`](https://github.com/eea/helm-charts/commit/1d66622dae4ddabbfcf885594d78be812b4d173c)]

### Version 3.510.0 - 22 January 2026
- Automated release of [eeacms/clms-frontend:3.510.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`e28cb4a1`](https://github.com/eea/helm-charts/commit/e28cb4a1b3036994dd2e858aace76eba5ce26fc7)]

### Version 3.509.0 - 20 January 2026
- Automated release of [eeacms/clms-frontend:3.509.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`66726238`](https://github.com/eea/helm-charts/commit/66726238a696748961a65f8f82d856535c49fe05)]

### Version 3.508.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`48a3d11e`](https://github.com/eea/helm-charts/commit/48a3d11e418c65c9742887c6d61af97186cfb917)]

### Version 3.508.0 - 19 January 2026
- Automated release of [eeacms/clms-frontend:3.508.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f41b6805`](https://github.com/eea/helm-charts/commit/f41b6805826f3b8473fb6e0d96220a8a04239eae)]

### Version 3.507.0 - 16 January 2026
- Automated release of [eeacms/clms-frontend:3.507.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`a74a00da`](https://github.com/eea/helm-charts/commit/a74a00da1426227189affa06c75e3379a7b9a99b)]

### Version 3.506.0 - 14 January 2026
- Automated release of [eeacms/clms-frontend:3.506.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f3aea727`](https://github.com/eea/helm-charts/commit/f3aea727bd646f70a43cdce8866c9ebb35cd6af9)]

### Version 3.505.1 - 16 December 2025
- Add missing variables [Dobricean Ioan Dorian - [`40b235c7`](https://github.com/eea/helm-charts/commit/40b235c7fb4f8e191c82f3140adc60c5c05d9da9)]

### Version 3.505.0 - 16 December 2025
- Automated release of [eeacms/clms-frontend:3.505.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`c578bbc5`](https://github.com/eea/helm-charts/commit/c578bbc5716ce58c6a4116217ebedefad96981c3)]

### Version 3.504.0 - 11 December 2025
- Automated release of [eeacms/clms-frontend:3.504.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`8b4322e1`](https://github.com/eea/helm-charts/commit/8b4322e1dccc980a0b262f12ecac98f876a6e634)]

### Version 3.503.0 - 11 December 2025
- Automated release of [eeacms/clms-frontend:3.503.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`94ce75d8`](https://github.com/eea/helm-charts/commit/94ce75d8e01d11668c478f61b1228064ce6bfcd4)]

### Version 3.502.0 - 11 December 2025
- Automated release of [eeacms/clms-frontend:3.502.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`b53cdcef`](https://github.com/eea/helm-charts/commit/b53cdcef2d0fb06c111ecb8370444f331d68d4d8)]

### Version 3.501.1 - 10 December 2025
- Add nginx proxys [Dobricean Ioan Dorian - [`89341f82`](https://github.com/eea/helm-charts/commit/89341f8292cf3124d11a206e2f96c3d45411840d)]

### Version 3.501.0 - 09 December 2025
- Automated release of [eeacms/clms-frontend:3.501.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`62553b46`](https://github.com/eea/helm-charts/commit/62553b46b7f3411fceebfd15a5f96ecaf682d35f)]

### Version 3.500.3 - 08 December 2025
- remove cdse ingress [Dobricean Ioan Dorian - [`04dceae8`](https://github.com/eea/helm-charts/commit/04dceae837ed7e3b9d40651d21b4845926e99aa0)]

### Version 3.500.2 - 08 December 2025
- Move appache to ingress [Dobricean Ioan Dorian - [`578e1570`](https://github.com/eea/helm-charts/commit/578e15704b4ab5364f80a3605400b95f5e34151e)]

### Version 3.500.1 - 08 December 2025
- Add razzle public url [Dobricean Ioan Dorian - [`6ad17978`](https://github.com/eea/helm-charts/commit/6ad1797897158e5143cd05dd4a5edd78b5c8769d)]

### Version 3.500.0 - 08 December 2025
- Automated release of [eeacms/clms-frontend:3.500.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f0bec373`](https://github.com/eea/helm-charts/commit/f0bec373f8e2f116b0d6d948cf59005fe0382bb1)]

### Version 3.499.0 - 04 December 2025
- Automated release of [eeacms/clms-frontend:3.499.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`09642962`](https://github.com/eea/helm-charts/commit/09642962f459f28039542e82206acd894db55401)]

### Version 3.498.0 - 03 December 2025
- Automated release of [eeacms/clms-frontend:3.498.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`35e932b6`](https://github.com/eea/helm-charts/commit/35e932b62440cb592df6e4ff7991e8238735a2d6)]

### Version 3.497.0 - 02 December 2025
- Automated release of [eeacms/clms-frontend:3.497.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`cfc646ee`](https://github.com/eea/helm-charts/commit/cfc646ee031e5e32de982d91a883920ed12c59fa)]

### Version 3.496.0 - 27 November 2025
- Automated release of [eeacms/clms-frontend:3.496.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`fe93eefe`](https://github.com/eea/helm-charts/commit/fe93eefe953cccd8f123416f7f9f83538937a3b7)]

### Version 3.495.1 - 26 November 2025
- FIX redirect [Dobricean Ioan Dorian - [`b2242144`](https://github.com/eea/helm-charts/commit/b2242144d7ef866704305c834d5cfc9a5e8685a4)]

### Version 3.495.0 - 26 November 2025
- Automated release of [eeacms/clms-frontend:3.495.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`cce0bf42`](https://github.com/eea/helm-charts/commit/cce0bf4271a9438214277639c4b66e3c7dd0b270)]

### Version 3.494.1 - 26 November 2025
- Remove nginx [Dobricean Ioan Dorian - [`6c53dcc6`](https://github.com/eea/helm-charts/commit/6c53dcc6e944a1aa3fa465aaf7a8e3a727d73c1b)]

### Version 3.494.0 - 25 November 2025
- Automated release of [eeacms/clms-frontend:3.494.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`61f0f799`](https://github.com/eea/helm-charts/commit/61f0f7999851dfd886e99c3f8cb05b409adcf8f2)]

### Version 3.493.1 - 24 November 2025
- Adding nginx configuration [Dobricean Ioan Dorian - [`dc8e63c1`](https://github.com/eea/helm-charts/commit/dc8e63c15d323b60c8bce1423f576348ce24b9cc)]

### Version 3.493.0
- Initial CLMS frontend Helm chart release based on insitu-frontend structure 
