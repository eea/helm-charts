# CLMS backend - Plone 6

This chart deployes the CLMS backend app

## Values

| Key           | Type | Default | Description                       |
| ------------- | ---- | ------- | --------------------------------- |
| debug.enabled | bool | false   | Activate the Plone debug instance |

## Releases

### Version 2.51.0 - 12 November 2026
- Automated release of [eeacms/clms-backend:6.1.6-1](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`8c4218da9`](https://github.com/eea/helm-charts/commit/8c4218da94358e0c899696c3aba7bb569bde47ff)]

### Version 2.50.2 - 11 November 2026
- Automated release of [eeacms/plone-varnish:8.0-1.0](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`b08c80909`](https://github.com/eea/helm-charts/commit/b08c8090945f4e502b25bc6d698b8f7a6252a2fc)]

### Version 2.50.1 - 09 November 2026
- portal_modifier [GhitaB - [`5e06cddf0`](https://github.com/eea/helm-charts/commit/5e06cddf026a4bcbc2bdfb45bded3238b4c1653e)]

### Version 2.50.0 - 03 November 2026
- Automated release of [eeacms/clms-backend:6.0.15-175](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`25cd045d0`](https://github.com/eea/helm-charts/commit/25cd045d0f33b0d0e7ddec957c0ecca3f8ae3a15)]

### Version 2.49.0 - 20 October 2026
- Automated release of [eeacms/clms-backend:6.0.15-174](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`ab4b18ad9`](https://github.com/eea/helm-charts/commit/ab4b18ad92f9aa44f70f308df4e57de75c4afff0)]

### Version 2.48.0 - 20 October 2026
- Automated release of [eeacms/clms-backend:6.0.15-173](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`9c0aaa672`](https://github.com/eea/helm-charts/commit/9c0aaa672fb1aa26afe672887474526cfb08aca4)]

### Version 2.47.0 - 16 October 2026
- Automated release of [eeacms/clms-backend:6.0.15-172](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`fba7c31df`](https://github.com/eea/helm-charts/commit/fba7c31df8f029d2961e9c542de722490ec2a70f)]

### Version 2.46.1 - 13 October 2026
- Add deny on contact-info urls [valentinab25 - [`1ceb4cb3`](https://github.com/eea/helm-charts/commit/1ceb4cb3ca311919008b292d263d9fd5e1e8683d)]

### Version 2.46.0 - 29 September 2026
- Automated release of [eeacms/clms-backend:6.0.15-171](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`8552598d`](https://github.com/eea/helm-charts/commit/8552598debd8836b12ba7bd718d8859a1ac0939d)]

### Version 2.45.0 - 28 September 2026
- Automated release of [eeacms/clms-backend:6.0.15-170](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`ffab5c1e`](https://github.com/eea/helm-charts/commit/ffab5c1e7333a1d76f06bc2020cdfec7fbc97193)]

### Version 2.44.0 - 23 September 2026
- Automated release of [eeacms/clms-backend:6.0.15-169](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`8d9ecc23`](https://github.com/eea/helm-charts/commit/8d9ecc23947a0c8a3616e644462889ce984902d6)]

### Version 2.43.0 - 16 September 2026
- Automated release of [eeacms/clms-backend:6.0.15-168](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`85f935e2`](https://github.com/eea/helm-charts/commit/85f935e2bc8fdd81614162d28d32f941930df971)]

### Version 2.42.0 - 14 September 2026
- Automated release of [eeacms/clms-backend:6.0.15-167](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`255939ef`](https://github.com/eea/helm-charts/commit/255939ef88047366abfbcfb3657f1a3b54038c4d)]

### Version 2.41.0 - 04 September 2026
- Automated release of [eeacms/clms-backend:6.0.15-166](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`6b615ea9`](https://github.com/eea/helm-charts/commit/6b615ea9b873799e0eb7ff4f0bba44049ad1fbfb)]

### Version 2.40.0 - 03 September 2026
- Automated release of [eeacms/clms-backend:6.0.15-165](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`9f9aca47`](https://github.com/eea/helm-charts/commit/9f9aca4721fe07ec24aead3474b7c715a2432d6c)]

### Version 2.39.2 - 24 August 2026
- Automated release of [eeacms/clms-ogcproxy:1.0.3](https://github.com/eea/clms-ogcproxy/releases) [EEA Jenkins - [`73138a7b`](https://github.com/eea/helm-charts/commit/73138a7b8beed4268ff68f8841a7281502c9503a)]

### Version 2.39.1 - 24 August 2026
- Automated release of [eeacms/clms-ogcproxy:1.0.2](https://github.com/eea/clms-ogcproxy/releases) [EEA Jenkins - [`5e9acfd7`](https://github.com/eea/helm-charts/commit/5e9acfd7c0a55b63d05e2480a9f0310f22bccc09)]

### Version 2.39.0 - 11 August 2026
- Automated release of [eeacms/clms-backend:6.0.15-164](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`ca0dba6f`](https://github.com/eea/helm-charts/commit/ca0dba6f5f5eb2d5cab6dc19129c62552facc53f)]

### Version 2.38.0 - 10 August 2026
- Automated release of [eeacms/clms-backend:6.0.15-163](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`70852ad1`](https://github.com/eea/helm-charts/commit/70852ad160752b8a7f75285efd71ad0acfd040c8)]

### Version 2.37.0 - 07 August 2026
- Automated release of [eeacms/clms-backend:6.0.15-162](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`af43b412`](https://github.com/eea/helm-charts/commit/af43b412fe3be55e94edc1869b82299b0f8e5d2a)]

### Version 2.36.0 - 22 July 2026
- Automated release of [eeacms/clms-backend:6.0.15-161](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`08aa3450`](https://github.com/eea/helm-charts/commit/08aa3450def6234ef0a25be8e3de0e3952b34741)]

### Version 2.35.1 - 22 July 2026
- Add custom annotations values per ingress [valentinab25 - [`e36c8426`](https://github.com/eea/helm-charts/commit/e36c8426789891453ee0c07bb9dbfd9f2aae3b13)]

### Version 2.35.0 - 22 July 2026
- Automated release of [eeacms/clms-backend:6.0.15-160](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`62f25474`](https://github.com/eea/helm-charts/commit/62f254743e9b98247b05f9baf3c33a1bba48d104)]

### Version 2.34.0 - 20 July 2026
- Automated release of [eeacms/clms-backend:6.0.15-159](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`790c9baa`](https://github.com/eea/helm-charts/commit/790c9baaed68e2d927cd5fb69ac56df639cca484)]

### Version 2.33.8 - 15 July 2026
- minor [Dobricean Ioan Dorian - [`1b85a1be`](https://github.com/eea/helm-charts/commit/1b85a1be9a0b4ab55c242b70e0f7abecf2bd3f1a)]

### Version 2.33.6 - 10 July 2026
- fix [Dobricean Ioan Dorian - [`467916ca`](https://github.com/eea/helm-charts/commit/467916ca716e9c1caf02fefd60b15773dd4c039d)]

### Version 2.33.4 - 16 June 2026
- fix cronjobs [Dobricean Ioan Dorian - [`21765eb5`](https://github.com/eea/helm-charts/commit/21765eb56805042380f344f7e4aa1aeecc1e9541)]

### Version 2.33.3 - 11 June 2026
- Add ogc questions, add redis if ogc enabled [valentinab25 - [`0b31394a`](https://github.com/eea/helm-charts/commit/0b31394a5fc67ab89ef8b322d19cc4fa874f45f6)]

### Version 2.33.2 - 10 June 2026
- Automated release of [eeacms/clms-ogcproxy:1.0.1](https://github.com/eea/clms-ogcproxy/releases) [EEA Jenkins - [`8a5f1fdf`](https://github.com/eea/helm-charts/commit/8a5f1fdffc13f15333701d9df920a31066dbcda5)]

### Version 2.33.1 - 10 June 2026
- Prepare for jenkins release [valentinab25 - [`abff7001`](https://github.com/eea/helm-charts/commit/abff700177bc850e03168419e491c2d06d47becc)]

### Version 2.33.0 - 10 June 2026
- Add ogcproxy service [ana-oprea - [`98aded80`](https://github.com/eea/helm-charts/commit/98aded801566a62d585bb14520040d134820fdfe)]

### Version 2.32.0 - 27 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-157](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`179bac12`](https://github.com/eea/helm-charts/commit/179bac1270e8be210a73e1372989cbe59e1588f2)]

### Version 2.31.0 - 25 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-156](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`c95a4bbc`](https://github.com/eea/helm-charts/commit/c95a4bbcc8d3a37ff3b867af03841c6644b4ccff)]

### Version 2.30.1 - 22 May 2026
- Add validate ratelimitting [valentinab25 - [`d2a3b818`](https://github.com/eea/helm-charts/commit/d2a3b8180c2d843b75664fecb57e04fee0b46732)]

### Version 2.30.0 - 22 May 2026
- Automated release of clms-backend:6.0.15-155 [EEA Jenkins - [`0494e15d`](https://github.com/eea/helm-charts/commit/0494e15d13d121be8af8e834e0a66ffa52050e3c)]

### Version 2.29.1 - 22 May 2026
- Add ratelimiting configuration for egms validate [valentinab25 - [`3a3a46a9`](https://github.com/eea/helm-charts/commit/3a3a46a95e685479aa8c400ced3247d139a77d67)]

### Version 2.29.0 - 19 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-154](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`a272a1ed`](https://github.com/eea/helm-charts/commit/a272a1ed29aca1aa7b482bc7b26a049b5b0eaca2)]

### Version 2.28.0 - 15 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-153](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`62a9c329`](https://github.com/eea/helm-charts/commit/62a9c329271a012b69df22d5b509c142b7155a29)]

### Version 2.27.0 - 13 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-152](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`d973d3ba`](https://github.com/eea/helm-charts/commit/d973d3ba1b1991021e104eb0a9824aa55af01fed)]

### Version 2.26.1 - 12 May 2026
- remove cdse cron [Dobricean Ioan Dorian - [`22708292`](https://github.com/eea/helm-charts/commit/227082925989146653e84ffe0da90bd95909289c)]

### Version 2.26.0 - 12 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-151](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`18c007a4`](https://github.com/eea/helm-charts/commit/18c007a47e856db3e62e5d4c479fb71841a11e0f)]

### Version 2.25.0 - 12 May 2026
- Automated release of [eeacms/clms-backend:6.0.15-150](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`6d216d56`](https://github.com/eea/helm-charts/commit/6d216d56e83bdcbbfd05f21cc44e4f73af4514e4)]

### Version 2.24.3 - 10 May 2026
- change database [Dobricean Ioan Dorian - [`512a9858`](https://github.com/eea/helm-charts/commit/512a9858a8703893f140f1094827446ad01a64dd)]

### Version 2.24.2 - 10 May 2026
- rename ingresses [Dobricean Ioan Dorian - [`35556870`](https://github.com/eea/helm-charts/commit/35556870dcc99fdaabcde099ecce260d9ae351ea)]

### Version 2.24.0 - 29 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-149](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`69715507`](https://github.com/eea/helm-charts/commit/6971550751720ad020179db8e64eda8b6bea395d)]

### Version 2.23.1 - 22 April 2026
- add clms entrasync [Dobricean Ioan Dorian - [`bcfb655a`](https://github.com/eea/helm-charts/commit/bcfb655ad6af6eafc6f752fc0333d40465f44cbc)]

### Version 2.23.0 - 22 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-148](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`c505eac8`](https://github.com/eea/helm-charts/commit/c505eac8eda5d2c474182bb247e9ca2119cf0c09)]

### Version 2.22.0 - 20 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-147](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`7176d575`](https://github.com/eea/helm-charts/commit/7176d5757e72fd1703fa6cdd47c82341d186b95f)]

### Version 2.21.1 - 20 April 2026
- add new vars [Dobricean Ioan Dorian - [`4678c746`](https://github.com/eea/helm-charts/commit/4678c746fb74130adcf825eeb071dda2647bf6e1)]

### Version 2.21.0 - 20 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-146](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`7f9c82de`](https://github.com/eea/helm-charts/commit/7f9c82de7d11d92cc5ea785b686dd83e31ed21d5)]

### Version 2.20.0 - 17 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-145](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`34f6c478`](https://github.com/eea/helm-charts/commit/34f6c47872bb1f171ca758372b8ad8b9e33f18b6)]

### Version 2.19.0 - 17 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-144](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`e225c129`](https://github.com/eea/helm-charts/commit/e225c129c76735419fceb086125ba075620c5774)]

### Version 2.18.0 - 16 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-143](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`e3d9f737`](https://github.com/eea/helm-charts/commit/e3d9f737d86d182ceccd04d087474ece3c6495c1)]

### Version 2.17.0 - 15 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-142](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`d8abd8ec`](https://github.com/eea/helm-charts/commit/d8abd8ece9c95e685dd9cb06ba2329b02a53a002)]

### Version 2.16.0 - 01 April 2026
- Automated release of [eeacms/clms-backend:6.0.15-141](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`c01bea1a`](https://github.com/eea/helm-charts/commit/c01bea1aa0b4e6abe82cd35432900d3bb323e0ef)]

### Version 2.15.0 - 30 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-139](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`53de6529`](https://github.com/eea/helm-charts/commit/53de6529fb169b5749a7453a95b42e917f794ca4)]

### Version 2.14.0 - 26 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-138](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`f6557bd0`](https://github.com/eea/helm-charts/commit/f6557bd09ce6ccf373ecd7de73b5e576902bd935)]

### Version 2.13.0 - 25 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-137](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`c1106622`](https://github.com/eea/helm-charts/commit/c110662216aa93c7a16ba2d6e0863647cfbe0715)]

### Version 2.12.0 - 24 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-136](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`39ed9201`](https://github.com/eea/helm-charts/commit/39ed9201f98a849e250fc5f7d568a64eb64d99ab)]

### Version 2.11.0 - 18 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-134](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`f13b3f8f`](https://github.com/eea/helm-charts/commit/f13b3f8f791298749124e2df384f15e608c25639)]

### Version 2.10.0 - 17 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-133](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`7eb3c3e9`](https://github.com/eea/helm-charts/commit/7eb3c3e96a4ac143285526a66de14a56f839d6d2)]

### Version 2.9.1 - 11 March 2026
- add cronjob [Dobricean Ioan Dorian - [`8781d21f`](https://github.com/eea/helm-charts/commit/8781d21fdd22cbeca67a815ffdfd77f2e533f6eb)]

### Version 2.8.0 - 10 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-132](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`1af95c33`](https://github.com/eea/helm-charts/commit/1af95c333146926ed8621726b627c38ff04f52d5)]

### Version 2.7.0 - 05 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-131](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`ba48bbb6`](https://github.com/eea/helm-charts/commit/ba48bbb63d168588d38b3cdad5335ead89e741ae)]

### Version 2.6.0 - 02 March 2026
- Automated release of [eeacms/clms-backend:6.0.15-130](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`2ddd98fc`](https://github.com/eea/helm-charts/commit/2ddd98fcae6fd68cdc2da96f3ea75aa32e50995b)]

### Version 2.5.0 - 27 February 2026
- Automated release of [eeacms/clms-backend:6.0.15-129](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`a7296a61`](https://github.com/eea/helm-charts/commit/a7296a619b90369fb4fef8e4619391d1501cd847)]

### Version 2.4.0 - 22 February 2026
- fix [Dobricean Ioan Dorian - [`7c843a09`](https://github.com/eea/helm-charts/commit/7c843a09b9123e03497032ad954faf3f0db96bf7)]

### Version 2.3.0 - 22 February 2026
- add missing services [Dobricean Ioan Dorian - [`8b741626`](https://github.com/eea/helm-charts/commit/8b7416264202925ba29da932ce4d38975fd32960)]

### Version 2.2.1 - 22 February 2026
- fix limits [Dobricean Ioan Dorian - [`bf8d5cde`](https://github.com/eea/helm-charts/commit/bf8d5cde04b1433c5364899f251788d1d595b901)]

### Version 2.2.0 - 19 February 2026
- Automated release of [eeacms/clms-backend:6.0.15-128](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`9c0617c7`](https://github.com/eea/helm-charts/commit/9c0617c72bbd1b8e379819557e99d649fc428fcc)]

### Version 2.1.0 - 18 February 2026
- Automated release of [eeacms/clms-backend:6.0.15-127](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`e08c402f`](https://github.com/eea/helm-charts/commit/e08c402f866781420ff9f4adc23ec5631684b969)]

### Version 2.0.2 - 16 February 2026
- fix [Dobricean Ioan Dorian - [`643426a3`](https://github.com/eea/helm-charts/commit/643426a31eb1f557c484d2f43afc1b5a7443461b)]

### Version 2.0.1 - 16 February 2026
- remove unneeded servicecs [Dobricean Ioan Dorian - [`3ebe50ce`](https://github.com/eea/helm-charts/commit/3ebe50ce98ad6b1110b9ef6853373ad8f9bbeeaa)]

### Version 2.0.0 - 15 February 2026
- remove entrasync [Dobricean Ioan Dorian - [`7eec7b14`](https://github.com/eea/helm-charts/commit/7eec7b144b4588ade010accb13e312c1ce215f4e)]

### Version 1.27.0 - 11 February 2026
- Automated release of [eeacms/clms-backend:6.0.15-126](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`2a17beec`](https://github.com/eea/helm-charts/commit/2a17beecb9964577516068a51d2c08d3a716f688)]

### Version 1.26.0 - 10 February 2026
- Automated release of [eeacms/clms-backend:6.0.15-125](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`47cb2c13`](https://github.com/eea/helm-charts/commit/47cb2c13d2a61c2c94d649c3a2d6c1ff78914cf6)]

### Version 1.25.0 - 27 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-124](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`c7401fa5`](https://github.com/eea/helm-charts/commit/c7401fa591aec74a686eeb2a93535d7c15c9a37c)]

### Version 1.24.1 - 26 January 2026
- Fix ingress [Dobricean Ioan Dorian - [`32454998`](https://github.com/eea/helm-charts/commit/32454998aa91e9f16548e66e3ee52985c0d9d091)]

### Version 1.23.1 - 26 January 2026
- downloadtool [Dobricean Ioan Dorian - [`8f1781e3`](https://github.com/eea/helm-charts/commit/8f1781e3eaf6aed3de853659d65f4bcb495f4b65)]

### Version 1.23.0 - 21 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-123](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`2c69dbc0`](https://github.com/eea/helm-charts/commit/2c69dbc01131868a8509cf405f415d187977d4d8)]

### Version 1.22.0 - 20 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-122](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`0efd56e9`](https://github.com/eea/helm-charts/commit/0efd56e97b0741c9b2f72ac1c6f388cf9489571c)]

### Version 1.21.0 - 20 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-121](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`e8470d7d`](https://github.com/eea/helm-charts/commit/e8470d7df3e8d59c0887bd193e9b4560b649c6ae)]

### Version 1.20.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`12118250`](https://github.com/eea/helm-charts/commit/12118250a68cb35ee613287bdd30fc8039810e82)]

### Version 1.20.0 - 19 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-120](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`67857b3b`](https://github.com/eea/helm-charts/commit/67857b3b59552b68c924601b8c533bb30daf2d8f)]

### Version 1.19.0 - 19 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-119](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`5dac957f`](https://github.com/eea/helm-charts/commit/5dac957fff316fcabf87357b82c193d2ecd3297b)]

### Version 1.18.0 - 16 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-118](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`abf6157b`](https://github.com/eea/helm-charts/commit/abf6157bea8f09dce9c157d93535d180e6ec4581)]

### Version 1.17.0 - 08 January 2026
- Automated release of [eeacms/clms-backend:6.0.15-117](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`ce7d8da1`](https://github.com/eea/helm-charts/commit/ce7d8da1a579266eba7003f1146581cec659056a)]

### Version 1.16.0 - 23 December 2025
- Automated release of [eeacms/clms-backend:6.0.15-116](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`36871ba8`](https://github.com/eea/helm-charts/commit/36871ba84375ebba7b99d628b32f5a5e3ec4a69b)]

### Version 1.15.0 - 22 December 2025
- Automated release of [eeacms/clms-backend:6.0.15-115](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`208ca370`](https://github.com/eea/helm-charts/commit/208ca3703f3558958ae3e1d4bc59cd641a9c3e0f)]

### Version 1.14.4 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`4822eac9`](https://github.com/eea/helm-charts/commit/4822eac9a369a90323fc6d9d63706faee6037535)]

### Version 1.14.3 - 16 December 2025
- fix redis servoce [Dobricean Ioan Dorian - [`1df30213`](https://github.com/eea/helm-charts/commit/1df30213df2d1c723fa6c5ac7d60cb9f16549c37)]

### Version 1.14.2 - 16 December 2025
- add all the services [Dobricean Ioan Dorian - [`d54f5b65`](https://github.com/eea/helm-charts/commit/d54f5b657759d0023a1dba2161c3145a9fc1436c)]

### Version 1.14.1 - 16 December 2025
- fix backend variables [Dobricean Ioan Dorian - [`074fbea5`](https://github.com/eea/helm-charts/commit/074fbea5306e8782dc77085525ff67cbf27f10de)]

### Version 1.14.0 - 16 December 2025
- Automated release of [eeacms/clms-backend:6.0.15-114](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`9aa41a8e`](https://github.com/eea/helm-charts/commit/9aa41a8ec12aaa42d32a45e8448784543ce7a08a)]

### Version 1.13.0 - 12 December 2025
- Automated release of [eeacms/clms-backend:6.0.15-113](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`23e58314`](https://github.com/eea/helm-charts/commit/23e58314afcfd476c057a6ca60d13f809de14ea1)]

### Version 1.12.0 - 11 December 2025
- Automated release of [eeacms/clms-backend:6.0.15-112](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`09698600`](https://github.com/eea/helm-charts/commit/096986003ea6798ddc8a0219aea4195a78036f26)]

### Version 1.11.0 - 05 December 2025
- Automated release of [eeacms/clms-backend:6.0.15-111](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`11d4f49f`](https://github.com/eea/helm-charts/commit/11d4f49f401bb7f97309c20ecee5f75d27d9716c)]

### Version 1.10.0 - 04 December 2025
- Automated release of [eeacms/clms-backend:6.0.15-110](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`99a3b383`](https://github.com/eea/helm-charts/commit/99a3b383fcf020a9550d0668015152f7af9790df)]

### Version 1.9.0 - 04 December 2025
- Automated release of [eeacms/clms-backend:6.0.15-109](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`2c7cc0bb`](https://github.com/eea/helm-charts/commit/2c7cc0bb199410dec78b62ba49c60bfa01773d5e)]

### Version 1.8.0 - 04 December 2025
- Automated release of [eeacms/clms-backend:6.0.15-108](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`0d272258`](https://github.com/eea/helm-charts/commit/0d272258bfe43df22dc95f05496b7b374af79a54)]

### Version 1.7.0 - 03 December 2025
- Automated release of [eeacms/clms-backend:6.0.15-107](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`77113f04`](https://github.com/eea/helm-charts/commit/77113f0436b4f0b38aa642674cb719a195a8aa99)]

### Version 1.6.0 - 03 December 2025
- Automated release of [eeacms/clms-backend:6.0.15-106](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`9b853869`](https://github.com/eea/helm-charts/commit/9b8538695e0e4f9434b1e9fe3bd7377a53bf01eb)]

### Version 1.5.0 - 27 November 2025
- Automated release of [eeacms/clms-backend:6.0.15-104](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`7cda4252`](https://github.com/eea/helm-charts/commit/7cda4252a62f7183792ea067ffba4304c734aeb4)]

### Version 1.4.0 - 27 November 2025
- Automated release of [eeacms/clms-backend:6.0.15-103](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`17d4c25f`](https://github.com/eea/helm-charts/commit/17d4c25f0ca072a9ccd32a3c38535b8a9c7b890b)]

### Version 1.3.0 - 26 November 2025
- Automated release of [eeacms/clms-backend:6.0.15-102](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`bb720168`](https://github.com/eea/helm-charts/commit/bb7201685426a83f723f77295cf2014b0d0e058b)]

### Version 1.2.0 - 26 November 2025
- Automated release of [eeacms/clms-backend:6.0.15-101](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`668ca339`](https://github.com/eea/helm-charts/commit/668ca339213fd75c66670d4b5b88e206b8b1770f)]

### Version 1.1.0 - 26 November 2025
- Automated release of [eeacms/clms-backend:6.0.15-100](https://github.com/eea/clms-backend/releases) [EEA Jenkins - [`ed7d99d3`](https://github.com/eea/helm-charts/commit/ed7d99d3f47b14c5589a727a88b8539cdfc6c2d5)]

### Version 1.0.0 - 25 November 2025
- Initial release of CLMS backend based on BISE backend
