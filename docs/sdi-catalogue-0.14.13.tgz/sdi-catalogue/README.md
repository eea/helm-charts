# SDI catalogue

A csw service and front end application to search and find EEA GIS datasets.

## Cronjobs

Cronjobs have been removed since the update to GN 5/ GN 46 and the new folder structure.

## Values

| Key | Type | Default | Description |
| ----- | ------ | --------- | ------------- |
| serverName | string | sdi.eea.europa.eu | Name of the server |
| serverUrl | string | <https://sdi.eea.europa.eu:443> | URL of the server. The port is required. |
| gn5.image | string | 'eeacms/eea-geonetwork5:f422d582' | GN5 Docker image. Unset uses the default in `gn5-deployment.yaml` |
| gn46.image | string | 'eeacms/eea-geonetwork:eea-4.9.x-b4bb7fce' | GN46 Docker image. Unset uses the default in `gn46-deployment.yaml` |
| gn46.max_upload_size | integer | 100000000 | Max size in bytes of an uploaded attachment (`api.params.maxUploadSize`). The default is the GeoNetwork default (100 MB). Set it higher per environment for large files, for example `10737418240` (10 GiB) |
| gn46.tmpdir | string | '' | Java temp directory (`-Djava.io.tmpdir`) of GN46. Uploads are staged there before they go to the store. Empty keeps `/tmp` on the node disk. Set a subdirectory of `/var/local/gis_sdi/tmp/` (for example `/var/local/gis_sdi/tmp/gn46`) to use the shared volume for very large uploads. Other paths are rejected. An init container creates it. The init container also deletes files older than a day left by killed pods |
| gn46.resources | object | {} | Resource requests and limits of GN46. Large uploads are staged on the pod's disk, so set `ephemeral-storage` above `gn46.max_upload_size` (for example requests `3Gi` memory and `20Gi` ephemeral-storage, limits `4Gi` and `40Gi`) |
| gn46.opendal.enabled | boolean | false | Store GN46 record attachments and thumbnails with OpenDAL instead of `gn46.geonetwork_data_dir`. Needs an image that includes the OpenDAL data storage (eea-4.13.x from `8cb89f79` on) |
| gn46.opendal.scheme | string | 's3' | OpenDAL service (`s3`, `fs`, `webdav`, ...) |
| gn46.opendal.root | string | '/' | Folder inside the bucket. Use a different one per environment when they share a bucket |
| gn46.opendal.bucket | string | '' | Bucket name |
| gn46.opendal.region | string | '' | Bucket region, for example `eu-west-1` |
| gn46.opendal.endpoint | string | '' | Service endpoint. Leave empty for AWS, set it for other S3 compatible services |
| gn46.opendal.presignExpirySeconds | integer | 0 | Seconds a presigned download URL stays valid. `0` disables presigned URLs and GN46 streams the files itself. Keep it short (a few minutes), anyone with the URL can download until it expires |
| gn46.opendal.existingSecret | string | '' | Pre-created secret with the `access-key-id` and `secret-access-key` keys |
| elasticsearch.image | string | 'docker.elastic.co/elasticsearch/elasticsearch:8.14.3' | Elasticsearch Docker image, used by both `elasticsearch` and `elasticsearch-es02` |
| kibana.image | string | 'docker.elastic.co/kibana/kibana:8.14.3' | Kibana Docker image |
| gn5.proxy.enabled | boolean | false | Enable proxy support in GN5 (sets `geonetwork.proxy.enabled`) |
| gn5.maxFileSize | string | 10GB | Maximum file upload size in GeoNetowrk |
| gn5.security.provider | string | ldap | Local authentication provider for the GN5 sign-in form: `ldap` (EIONET directory), `database` (GeoNetwork user table) or `none` (only the OAuth2 providers). Sets `geonetwork.security.provider` |
| gn5.security.createdUser.group | string | eea_users | Group assigned to LDAP users created on first login |
| gn5.security.createdUser.profile | string | '' | Profile assigned to LDAP users created on first login. Omitted from the config when empty, GN5 then defaults to `Guest` |
| gn5.security.ldap.url | string | ldaps://ldap.eionet.europa.eu | LDAP server URL. Empty uses the embedded LDAP server. Only used when `gn5.security.provider` is `ldap` |
| gn5.security.ldap.base | string | o=EIONET,l=Europe | LDAP base DN |
| gn5.security.ldap.userSearchDn | string | ou=Users | DN, relative to the base, under which users are searched |
| gn5.security.ldap.userSearchFilter | string | (&(\|(objectclass=eionetAccount))(\|(uid={0})(\|(mailPrimaryAddress={0})(mail={0})))) | LDAP filter used to look up the user, `{0}` is the submitted login |
| gn5.security.ldap.attributes.username | string | uid | LDAP attribute holding the username |
| gn5.security.ldap.attributes.email | string | email | LDAP attribute holding the email address |
| gn5.security.ldap.attributes.name | string | givenName | LDAP attribute holding the first name |
| gn5.security.ldap.attributes.surname | string | sn | LDAP attribute holding the surname |
| gn5.oauth2.enabled | boolean | false | Enable OAuth2 authentication for GN5 |
| gn5.oauth2.clientId | string | '' | OAuth2 client ID |
| gn5.oauth2.clientSecret | string | '' | OAuth2 client secret (only for helm install via --set-string flag, NOT for values.yaml) |
| gn5.oauth2.existingSecret | string | '' | Name of existing Kubernetes secret containing the client secret |
| gn5.oauth2.existingSecretKey | string | 'client-secret' | Key in the existing secret containing the client secret |
| gn5.oauth2.issuerUri | string | '' | OAuth2 issuer URI (e.g., MS Entra ID tenant) |
| gn5.oauth2.redirectUri | string | '' | OAuth2 redirect URI (defaults to {geonetwork.url_with_context}/login/oauth2/code/eea if empty) |
| gn5.oauth2.scopes | string | 'openid,profile,email' | OAuth2 scopes |
| nextcloudRedis.enabled | boolean | true | Enable Redis for Nextcloud distributed caching and file locking |
| nextcloudRedis.image | string | 'redis:7-alpine' | Redis Docker image |
| nextcloudRedis.resources.requests.memory | string | '128Mi' | Redis memory request |
| nextcloudRedis.resources.limits.memory | string | '512Mi' | Redis memory limit |
| nextcloudRedis.storage | string | '100Mi' | Redis PVC storage size |
| nextcloud.maxUploadSize | string | '16G' | Nextcloud PHP upload limit (upload_max_filesize and post_max_size) |
| nextcloud.phpMemoryLimit | string | '512M' | Nextcloud PHP memory limit |
| apache.robotsTxt | string | 'User-agent: *\nDisallow: /' | Content of the /robots.txt file served at the site root. Set to '' to not deploy a robots.txt at all |
| validator.enabled | boolean | true | Enable the INSPIRE validator (Deployment, Service, ConfigMap, PVC and the `/validator` Apache proxy path) |
| datahub.enabled | boolean | false | Serve the Datahub UI at the site root (Deployment, Service and an Apache catch-all `ProxyPass /`). Leave it off where the root must keep serving the old site, such as sdi.eea.europa.eu |
| datahub.image | string | '' | Datahub Docker image. Required when `datahub.enabled` is true |
| datahub.resources | object | 32Mi request, 128Mi limit | Datahub container resources |

## Authentication providers

GN5 combines one *local* provider, selected with `gn5.security.provider`, with the OAuth2/OIDC
registrations configured under `gn5.oauth2`. The two are independent: changing the local provider
does not affect the Entra ID button on the sign-in page, and vice versa.

To authenticate against the EIONET directory (the default):

```yaml
gn5:
  security:
    provider: ldap
    createdUser:
      group: eea_users
```

To disable LDAP and rely on Entra ID, keeping local GeoNetwork accounts as a fallback:

```yaml
gn5:
  security:
    provider: database
```

## OAuth2 Configuration

To enable OAuth2 authentication with MS Entra ID for GN5, you have two options for managing the client secret:

### Option 1: Use an existing Kubernetes secret (Recommended)

First, create the secret manually:

```bash
kubectl create secret generic gn5-oauth2-credentials \
  --from-literal=client-secret='your-client-secret' \
  -n your-namespace
```

Then configure the chart:

```yaml
gn5:
  oauth2:
    enabled: true
    clientId: "your-client-id"
    existingSecret: "gn5-oauth2-credentials"
    existingSecretKey: "client-secret"
    issuerUri: "https://login.microsoftonline.com/YOUR_TENANT_ID/v2.0"
    scopes: "openid,profile,email"
```

### Option 2: Provide secret via command line

```bash
helm install sdi-catalogue eea-charts/sdi-catalogue \
  --set gn5.oauth2.enabled=true \
  --set gn5.oauth2.clientId="your-client-id" \
  --set-string gn5.oauth2.clientSecret="your-client-secret" \
  --set gn5.oauth2.issuerUri="https://login.microsoftonline.com/YOUR_TENANT_ID/v2.0"
```

**Important**: Never commit the `clientSecret` value to your values.yaml file or version control.

The OAuth2 client registration is named `eea` in the Spring Security configuration.

## GN46 S3 storage (OpenDAL)

GN46 can keep record attachments and thumbnails in an S3 bucket through the
[OpenDAL data storage](https://github.com/geonetwork/core-geonetwork/blob/main/datastorages/opendal/README.md).
Create a secret with the bucket keys first:

```bash
kubectl create secret generic gn46-s3 \
  --from-literal=access-key-id="your-access-key-id" \
  --from-literal=secret-access-key="your-secret-access-key"
```

Then enable it in values.yaml:

```yaml
gn46:
  opendal:
    enabled: true
    bucket: "your-bucket"
    region: "eu-west-1"
    root: "/datahub-dev"
    existingSecret: "gn46-s3"
```

Existing files in `gn46.geonetwork_data_dir` are not copied to the bucket, sync them before
enabling it. The attachments API under `/catalogue` is served by GN5, which still uses its
own filesystem store.

## Releases

### Version 0.14.13 - 17 November 2026
- Allow setting GN5 OAuth2 user groups and profiles from token claims (gn5.oauth2.userCreationRegistration) and restart GN5 when its configuration changes [Juan Luis Rodriguez Ponce - [`fd52e9962`](https://github.com/eea/helm-charts/commit/fd52e996212cd831d3b228bd950e366c216f2e06)]

### Version 0.14.12 - 12 November 2026
- Refuse changes through the GN5 attachment API and serve its reads from GN46 when gn46.opendal is enabled [Juan Luis Rodriguez Ponce - [`4fdc87d82`](https://github.com/eea/helm-charts/commit/4fdc87d824e5a89cecc1f2a63ec0499e3933c9ec)]

### Version 0.14.11 - 05 November 2026
- Update gn46 to eea-4.9.x-b4bb7fce [Juan Luis Rodriguez Ponce - [`3e35c1f4c`](https://github.com/eea/helm-charts/commit/3e35c1f4ce594fdb82fe43cd92e6eff23d94e2dd)]

### Version 0.14.10 - 05 November 2026
- Log the init-tmpdir steps (volume free space, entries before and after, deleted files) [Juan Luis Rodriguez Ponce - [`5110b9267`](https://github.com/eea/helm-charts/commit/5110b9267c46124722f60d5fd197c7817fd7c72a)]

### Version 0.14.9 - 05 November 2026
- Validate gn46 values with a schema, restrict gn46.tmpdir and clean old temp files in the init container [Juan Luis Rodriguez Ponce - [`ebdf6a704`](https://github.com/eea/helm-charts/commit/ebdf6a70497d737582d2cbd94bcf87d0417d1b3a)]

### Version 0.14.8 - 05 November 2026
- Add gn46.tmpdir to move the Java temp directory (large upload staging) to the gis-sdi volume [Juan Luis Rodriguez Ponce - [`cd90c6780`](https://github.com/eea/helm-charts/commit/cd90c6780fcb9d867f09f21f7a41a276d51409bf)]

### Version 0.14.7 - 05 November 2026
- Add gn46.opendal.presignExpirySeconds to enable presigned downloads [Juan Luis Rodriguez Ponce - [`8befd6cf6`](https://github.com/eea/helm-charts/commit/8befd6cf6a31b3acd8ba16377622ea5f9db5d85c)]

### Version 0.14.6 - 05 November 2026
- Make the gn46 max upload size configurable and add gn46 resources [Juan Luis Rodriguez Ponce - [`e1ea9cbed`](https://github.com/eea/helm-charts/commit/e1ea9cbed95c3a0d327b06fed02ab6f166801499)]

### Version 0.14.5 - 29 October 2026
- Set the GN5 record permalink to the datahub record page, or the GN4 HTML record view without datahub [Juan Luis Rodriguez Ponce - [`29a35a680`](https://github.com/eea/helm-charts/commit/29a35a6807a7491b7540c7ba8ee2ad60080f1b78)]

### Version 0.14.4 - 27 October 2026
- Update gn46 to eea-4.9.x-19e87b65 [Juan Luis Rodriguez Ponce - [`f09273f6f`](https://github.com/eea/helm-charts/commit/f09273f6f7625015b771eee367f3340ee2473e45)]

### Version 0.14.3 - 23 October 2026
- Pass Jetty form limits via JAVA_OPTS, the only variable the geonetwork image entrypoint uses [Juan Luis Rodriguez Ponce - [`fb4448923`](https://github.com/eea/helm-charts/commit/fb44489230f808641600c57cdf1e8bd4b77730e7)]

### Version 0.14.2 - 23 October 2026
- Make Jetty maxFormKeys and maxFormContentSize configurable via values [Juan Luis Rodriguez Ponce - [`2ec982735`](https://github.com/eea/helm-charts/commit/2ec9827356b8c9bcb0b8ad7a99d8e88ea73414b1)]

### Version 0.14.1 - 22 October 2026
- Bump Nextcloud image to 30.0.17-apache (PHP2Shell hardening) [Juan Luis Rodriguez Ponce - [`b8b42c635`](https://github.com/eea/helm-charts/commit/b8b42c635782bde97e4610118fcfdfab789f5f78)]

### Version 0.14.0 - 14 October 2026
- Add optional datahub UI served at the site root (datahub.enabled), restart Apache when its config changes and drop the /internal-catalogue redirect. Refs [#309613](https://taskman.eionet.europa.eu/issues/309613) [Juan Luis Rodriguez Ponce - [`b41e95aa8`](https://github.com/eea/helm-charts/commit/b41e95aa85c13d198fd559b3d2d4144c6ef89e88)]

### Version 0.13.0 - 02 October 2026
- Add optional gn46.opendal values to store GN46 attachments in S3 with OpenDAL [Juan Luis Rodriguez Ponce - [`8d9bd879`](https://github.com/eea/helm-charts/commit/8d9bd879a641a9a02a1e8310277ac0966498edab)]

### Version 0.12.4 - 02 October 2026
- Set GN5_BASE_URL and GN4_PROXY_BASE_URL on gn5 so OGC API Records links use the public site URL instead of localhost:7979 [Juan Luis Rodriguez Ponce - [`70ee5c09`](https://github.com/eea/helm-charts/commit/70ee5c097e0254367dea194cc5915d920647afed)]

### Version 0.12.3 - 02 October 2026
- Also skip the ogcapi configmap when ogcapi.enabled is false, and document the flag in values.yaml [Juan Luis Rodriguez Ponce - [`8240d169`](https://github.com/eea/helm-charts/commit/8240d169984ee7457c80c7a6e21649eb9145d6ba)]

### Version 0.12.2 - 02 October 2026
- Point the elasticsearch-es02 discovery seed at the elasticsearch node so both nodes can form a cluster whichever one is elected master [Juan Luis Rodriguez Ponce - [`bb3e421f`](https://github.com/eea/helm-charts/commit/bb3e421f4675393233b6c19b4eb4ae5f5e3a302c)]

### Version 0.12.1 - 02 October 2026
- Allow overriding the Elasticsearch and Kibana images from values.yaml, document image values in README and drop empty gn5 oauth2 block [Juan Luis Rodriguez Ponce - [`c109efe8`](https://github.com/eea/helm-charts/commit/c109efe81c9ea92a737e8fafe5e688da499282a2)]

### Version 0.12.0 - 02 October 2026

- Allow overriding the gn5 and gn46 images from values.yaml [Juan Luis Rodriguez Ponce - [`52ba5efc`](https://github.com/eea/helm-charts/commit/52ba5efc1896234b99d5e92e966b6d6d8151ab4c)]

### Version 0.11.0 - 01 October 2026

- Remove old nextcloud-db mysql server [Juan Luis Rodriguez Ponce - [`43807ef9`](https://github.com/eea/helm-charts/commit/43807ef98715c51eec2a159db1f214a77753b6c2)]

### Version 0.10.8 - 01 October 2026

- Update gn46 to eea-4.9.x-c7dcc38a [Juan Luis Rodriguez Ponce - [`6fe2c76f`](https://github.com/eea/helm-charts/commit/6fe2c76ffa9fbd144c2970332fe95c988948ebcf)]

### Version 0.10.7 - 23 September 2026

- Update gn46 to eea-4.9.x-62680a24 [Juan Luis Rodriguez Ponce - [`5b00a4c8`](https://github.com/eea/helm-charts/commit/5b00a4c8cfbc166c38f7e94543529bec0e0c15a6)]

### Version 0.10.6 - 15 September 2026

- Add validator.enabled switch to enable/disable the INSPIRE validator [Juan Luis Rodriguez Ponce - [`5e316417`](https://github.com/eea/helm-charts/commit/5e3164173ce6154d8d4d55390e183daf67b7f7c5)]

### Version 0.10.5 - 15 September 2026

- Bump gn46 to geonetwork-eea eea-4.9.x@51ba92c6 [Juan Luis Rodriguez Ponce - [`a342df09`](https://github.com/eea/helm-charts/commit/a342df09ddd43b6d50bad4d8781461ef4bd31fe8)]

### Version 0.10.4 - 15 September 2026

- Fix Nextcloud init container race on fresh PVCs and missing X-Forwarded-Proto header on the /catalogue proxy [Juan Luis Rodriguez Ponce - [`6ddb603c`](https://github.com/eea/helm-charts/commit/6ddb603c2634d6b3c7290674a7960b16df72df7c)]

### Version 0.10.3 - 14 September 2026

- Fix gn5 image, revert to build with removed missing application-gn4.yml import [Juan Luis Rodriguez Ponce - [`181558cd`](https://github.com/eea/helm-charts/commit/181558cd53eabdc92f0fca93b555ca7cca103330)]

### Version 0.10.2 - 14 September 2026

- Update gn46 image to eea-4.9.x-defaf423 [Juan Luis Rodriguez Ponce - [`e4d71241c`](https://github.com/eea/helm-charts/commit/e4d71241c0b0bdefa3aa795fd890ecf2d614a2ae)]

### Version 0.10.1 - 04 September 2026

- Update gn5 image tag to 459c2cc5 [Juan Luis Rodriguez Ponce - [`58a73b9d`](https://github.com/eea/helm-charts/commit/58a73b9d70a1308747a282699990f85d4de69464)]

### Version 0.10.0 - 03 September 2026

- Add pg_isready readiness probe to postgres-geonetwork and relax liveness probe thresholds [Juan Luis Rodriguez Ponce - [`77bc8f5d`](https://github.com/eea/helm-charts/commit/77bc8f5d9677b20bfe55919aa615451f0126ffa9)]

### Version 0.9.1 - 03 August 2026

- Document the new gn5.security.* values in the README [Juan Luis Rodriguez Ponce - [`db8b765b`](https://github.com/eea/helm-charts/commit/db8b765b129d152d9fbb5038b9d9cb0a45c43a76)]

### Version 0.9.0 - 03 August 2026

- gn5: make the local security provider configurable via gn5.security.* so LDAP can be disabled per environment [Juan Luis Rodriguez Ponce - [`d988bf71`](https://github.com/eea/helm-charts/commit/d988bf71035a27760eec3cc385b1454027a685f3)]

### Version 0.8.58 - 30 July 2026

- Add configurable robots.txt for the apache frontend [Juan Luis Rodriguez Ponce - [`bd0f600f`](https://github.com/eea/helm-charts/commit/bd0f600f060b2187ce3a275a3c7666f922e4acb8)]

### Version 0.8.57 - 15 July 2026

- Update gn5 image tag to 116bfffc [Juan Luis Rodriguez Ponce - [`4f71bdaf`](https://github.com/eea/helm-charts/commit/4f71bdaff4b9a7934a3ca9ec1863547808e4b594)]

### Version 0.8.56 - 15 July 2026

- Update gn5 image to 00837965 [Juan Luis Rodriguez Ponce - [`d9805915`](https://github.com/eea/helm-charts/commit/d9805915e4c2eaee7edd6177d49167cf80ccb9ad)]

### Version 0.8.55 - 08 July 2026

- Update gn46 and add a value to set the maxFileSize setting [Juan Luis Rodriguez Ponce - [`5fd2a8f5`](https://github.com/eea/helm-charts/commit/5fd2a8f565ccb4beadcdd26b418f4b27bd67db33)]

### Version 0.8.54 - 01 July 2026

- Update gn46 image to eea-4.9.x-02000e21 [Juan Luis Rodriguez Ponce - [`f32b8624`](https://github.com/eea/helm-charts/commit/f32b86245fd1cae241a738d1f0969b0692f27323)]

### Version 0.8.53 - 29 May 2026

- Update gn46 image to eea-4.9.x-377f4a1e [Juan Luis Rodriguez Ponce - [`9f724435`](https://github.com/eea/helm-charts/commit/9f724435dbf41df7ea4466e3998dd03a00b3f6d8)]

### Version 0.8.52 - 26 May 2026

- Update gn46 to eea-4.9.x-fca1ae32 [Juan Luis Rodriguez Ponce - [`b2be517a`](https://github.com/eea/helm-charts/commit/b2be517a7d2251de353de803b299139d9ed45676)]

### Version 0.8.51 - 19 May 2026

- Add gn5.proxy.enabled value to control GN5 proxy, defaults to false [Juan Luis Rodriguez Ponce - [`cc03ab4f`](https://github.com/eea/helm-charts/commit/cc03ab4fbab46fcfb7ca67b2bd2f9ccf93eb86ba)]

### Version 0.8.50 - 19 May 2026

- Update gn5 tag to 0ef2b6eb [Juan Luis Rodriguez Ponce - [`d0d188d4`](https://github.com/eea/helm-charts/commit/d0d188d4ec5bfb0151bdcf9b3aca6859b67c83a7)]

### Version 0.8.49 - 13 May 2026

- Update gn46 image to eea-4.9.x-bbe64162 [Juan Luis Rodriguez Ponce - [`9848fa44`](https://github.com/eea/helm-charts/commit/9848fa44ad852e02784088efab765afec20c840f)]

### Version 0.8.48 - 12 May 2026

- Update gn46 image to eea-4.9.x-cf508660 [Juan Luis Rodriguez Ponce - [`e18f883e`](https://github.com/eea/helm-charts/commit/e18f883e27f4496e39dcf8c15653a3ec17fe9f03)]

### Version 0.8.47 - 31 March 2026

- New version of GN [Juan Luis Rodriguez Ponce - [`81831edc`](https://github.com/eea/helm-charts/commit/81831edc2edd6f858b1e4ef800b1969c43fd0546)]

### Version 0.8.46 - 31 March 2026

- Fix Nextcloud large file uploads: increase limits to 40 GiB, add ProxyTimeout, templatize upload settings [Juan Luis Rodriguez Ponce - [`9804faf0`](https://github.com/eea/helm-charts/commit/9804faf0487c338b22dd5b05773056800d7b0409)]

### Version 0.8.45 - 3§ March 2026

- Update GN46 (`eea-4.9.x-29556785`).

### Version 0.8.44 - 30 March 2026

- Update GN46 (`eea-4.9.x-a14b65b6`) and GN5 (`f1c5f0df`). [Juan Luis Rodriguez Ponce - [`6c5aadac`](https://github.com/eea/helm-charts/commit/6c5aadac0a4182c3e56bdf228a8d2cb81abf7223)]

### Version 0.8.43 - 10 March 2026

- Configure Nextcloud max upload size to 16 GiB via `PHP_UPLOAD_LIMIT`, `PHP_MEMORY_LIMIT`, and `APACHE_BODY_LIMIT` env vars.

### Version 0.8.42 - 10 February 2026

- Update GN46 and GN5 [Juan Luis Rodriguez Ponce - [`966f2961`](https://github.com/eea/helm-charts/commit/966f2961026f3837798ef0633d0faa1382ad88c4)]

### Version 0.8.41 - 09 February 2026

- Annotations for loadbalancers.

### Version 0.8.40 - 01 February 2026

- Add Redis integration for Nextcloud distributed caching and file locking.
- New deployment and service for Redis (`nextcloud-redis`).
- Configure Nextcloud to use Redis for `memcache.distributed` and `memcache.locking`.
- Redis can be disabled via `nextcloudRedis.enabled: false`.

### Version 0.8.39 - 27 January 2026

- Remove Github provider and fix security config [Juan Luis Rodriguez Ponce - [`022b1f75`](https://github.com/eea/helm-charts/commit/022b1f7500ffbde03c0ff522f24e41d882f7f3fa)]

### Version 0.8.38 - 27 January 2026

- Update GN46 (`eea-4.9.x-1a3bd804`) and GN5 (`e9f56fb0`).

### Version 0.8.37 - 13 January 2026

- Update GN46 (`eea-4.9.x-2d350753`).

### Version 0.8.36 - 13 January 2026

- Increase `geonetworkdb` memory and CPU defaults.

### Version 0.8.35 - 13 January 2026

- Update GN46 (`eea-4.9.x-62171636`).

### Version 0.8.34 - 18 December 2025

- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`3e16bd0e`](https://github.com/eea/helm-charts/commit/3e16bd0e1b7cc3010d7804e4b54516a2e9f85558)]

### Version 0.8.33 - 05 December 2025

- Update GN46 (`eea-4.9.x-9f5c9e31`).

### Version 0.8.32 - 28 November 2025

- Update GN46 (`eea-4.9.x-34b0872a`).
  
### Version 0.8.31 - 20 November 2025

- Update GN46 (`eea-4.9.x-a9ed7c4c`).
  
### Version 0.8.30 - 20 November 2025

- Update GN46 (`eea-4.9.x-f4e97fe3`).

### Version 0.8.29 - 20 November 2025

- Update GN46 (`eea-4.9.x-7a654b0a`) and GN5 (`646d48e9`).
  
### Version 0.8.28 - 20 November 2025

- Update INSPIRE validator to v2025.1.1.

### Version 0.8.27 - 12 November 2025

- Update GN46 (`eea-4.9.x-25a2ba76`).

### Version 0.8.26 - 11 November 2025

- Update GN46 (`eea-4.9.x-3accec30`).
  
### Version 0.8.25 - 06 November 2025

- Update GN5 (`96743962`) / GN46 (`eea-4.9.x-30cd7285`).

### Version 0.8.24 - 31 October 2025

- Fix /gis_sdi/ from the datastore links.

### Version 0.8.23 - 31 October 2025

- Fix /datastore/internal links.

### Version 0.8.22 - 23 October 2025

- Fix Nextcloud /datastore/public links.
- Update GN 4 to `eea-4.9.x-a028bebf`

### Version 0.8.21 - 22 October 2025

- Update GN4 to `eea-4.9.x-78c94feb` and GN5 to `8407f847`.

### Version 0.8.20 - 20 October 2025

- Update GN5 to `987ecfb1`.

### Version 0.8.19 - 14 October 2025

- Fix typo in nextcloud configmap

### Version 0.8.18 - 14 October 2025

- Nextcloud localstorage.allowsymlinks setting.

### Version 0.8.17 - 14 October 2025

- Don't use a skeleton directory in Nextcloud.

### Version 0.8.16 - 09 October 2025

- Unprotect Nextcloud login.
  
### Version 0.8.15 - 09 October 2025

- Add shared links to values.yaml.

### Version 0.8.14 - 05 October 2025

- Update GN4 to eea-4.9.x-79b20ac4.
  
### Version 0.8.13 - 05 October 2025

- Update GN4 to eea-4.9.x-e079c02b.

### Version 0.8.12 - 05 October 2025

- Update GN4 to eea-4.9.x-3886b5a9.

### Version 0.8.11 - 02 October 2025

- Use a ConfigMap for GN5.
  
### Version 0.8.10 - 01 October 2025

- Update GN5 to 78febcf2.
  
### Version 0.8.9 - 01 October 2025

- Update GN46 to eea-4.9.x-78eeeac1.
  
### Version 0.8.8 - 30 September 2025

- Update GN46 to eea-4.9.x-4d2a7043.

### Version 0.8.7 - 29 September 2025

- Update GN46 and GN5.

### Version 0.8.6 - 29 September 2025

- Disable `/webdav/datastore/public` redirection and use a `Rewrite` directive instead because `Redirect`
  takes precedence over `Rewrite`.
- Disable the direct access to WebDAV access to `/var/lib/gis_sdi/public` folder.

### Version 0.8.5 - 29 September 2025

- Fix url parameter encoding.

### Version 0.8.4 - 29 September 2025

- Redirect `/webdav/datastore/public/<rest_of_path>` to `/datastore/public?path=%2F<rest_of_path>`.

### Version 0.8.3 - 29 September 2025

- Fix `/data` proxy pass to use gn46 context path instead of hardcoded `/geonetwork`.

### Version 0.8.2 - 26 September 2025

- Fix authentication prompt in GN5 metadata editor.
- Fix liveness probe of GN5 now using the web context from `values.yaml`.
  
### Version 0.8.1 - 25 September 2025

- Fix proxypass of /catalogue -> gn5:8080/catalogue

### Version 0.8.0 - 25 September 2025

- Remove old GN 4.
- Update GN46 and GN5 to use /catalogue instead of /geonework.

### Version 0.7.27 - 23 September 2025

- Trusted proxies and x-forwarded-for headers for Nextcloud.

### Version 0.7.26 - 23 September 2025

- Update GN46 to eea-4.9.x-1698c928.
  
### Version 0.7.25 - 10 September 2025

- Use GN5 image from eeacms/eea-geonetwork5.
- Revert Nextcloud to 30.0.2 because image for 30.0.3 doesn't exist.

### Version 0.7.24 - 10 September 2025

- Update Apache to 1.0.15 (httpd 2.4.65).
- Update Nextcloud to 30.0.3
- Remove nextcloud-redis deployment and service.
- Update Elasticsearch to 8.14.3
- Update Kibana to 8.14.3
- Revome webdav-nc and sync-nc-apche cron jobs.
- Disable samba contanier.

### Version 0.7.23 - 10 September 2025

- Fix GN5 user and group to match other containers.

### Version 0.7.22 - 09 September 2025

- Update GN46 with new docker tag format.

### Version 0.7.21 - 09 Septenber 2025

- Update GN46 to [`8568fc45`](https://github.com/eea/geonetwork-eea/commit/8568fc4557fd07857b12ee95101482f8b424b396) and GN5 to [`1a561dd7fb`](https://github.com/eea/geonetwork5-eea/commit/1a561dd7fb4df04c9e33ae0b0f239be5c0554d62).
  
### Version 0.7.20 - 25 August 2025

- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`ecdf5d88`](https://github.com/eea/helm-charts/commit/ecdf5d884a7aca9cc563bab1477f010314d332f2)]

### Version 0.7.19- 06 Aug 2025

- Update GN5.

### Version 0.7.18 - 01 Aug 2025

- Update GN46 and GN5. Add config map for security properties.

### Version 0.7.17 - 01 Jul 2025

- Update GN46.

### Version 0.7.16 - 26 Jun 2025

- Fix probes for validator.

### Version 0.7.15 - 26 Jun 2025

- Liveness probes for Nextcloud and Validator. Update validator to 2024.3.

### Version 0.7.14 - 26 Jun 2025

- Fix typo in Liveness paths for GN and GN46

### Version 0.7.13 - 26 Jun 2025

- Liveness and Readiness probes for GN, GN46 and GN5

### Version 0.7.12 - 26 Jun 2025

- New GN46 and GN5 versions.

### Version 0.7.11 - 11 Jun 2025

- New GN46 version. Fix /data proxypass.

### Version 0.7.10 - 10 Jun 2025

- Readiness probe for GN

### Version 0.7.9 - 10 Jun 2025

- Add health checks

### Version 0.7.8 - 10 Jun 2025

- Update GN46 and GN5

### Version 0.7.7 - 20 May 2025

- Add log directory to public-catalogue deployment

### Version 0.7.6 - 20 May 2025

- Update GN46 and GN5

### Version 0.7.5 - 25 April 2025

- Add apache redirections. Add symlinks to GN datastore. Events for updating the metadata file on metadata change. All running as www-data (33:33)

### Version 0.7.4 - 24 April 2025

- Externalise GN5 configuration yml file

### Version 0.7.3 - 24 April 2025

- Fix Nextcloud configmap values

### Version 0.7.2 - 24 April 2025

- Fix config map

### Version 0.7.1 - 24 April 2025

  <dd>Make Nextcloud's config.php not read-only. Add ConfigMap with Nextcloud config to
  /etc/nextcloud/config/config.php and a initcontainer that creates a symlink in /var/www/html/config/k8s.config.php to that file.
  This allow to have a read-only configuration file in a ConfigMap and Nextcloud doesn't complain about config.php read-only file.
  Remove nextcloud-db container as NC can use a postgres database instead.
  </dd>

### Version 0.7.0 - 22 April 2025

- Update Nextcloud to 30 and MariaDB to 10.11

### Version 0.6.38 - 22 April 2025

- GN5 updated to d287bcfc

### Version 0.6.37 - 01 April 2025

- GN5 updated to 6cbb0735

### Version 0.6.36 - 21 March 2025

- GN5 updated to a47ed08f

### Version 0.6.35 - 07 March 2025

- GN5 updated to 5eba5900

### Version 0.6.34 - 07 March 2025

- GN5 - Removed basic auth for GN5.

### Version 0.6.33 - 06 March 2025

- GN 4.6.x - Custom datastore rollback.

### Version 0.6.32 - 06 March 2025

- GN 4.6.x - Custom datastore.

### Version 0.6.31 - 04 March 2025

- Use a switch to enable/disable GN5/GN46x services.

### Version 0.6.30 - 04 March 2025

- Update GN to 5c376d1e.

### Version 0.6.29 - 03 March 2025

- Enable CORS for Nextcloud Share link download endpoint.

### Version 0.6.28 - 19 February 2025

- Troubleshooting with basic authentication.

### Version 0.6.27 - 18 February 2025

- Fixes for GN5 and GN 4.6.x

### Version 0.6.26 - 17 February 2025

- Share data directory between GN5 and GN46.

### Version 0.6.25 - 14 February 2025

- Add GN5.

### Version 0.6.24 - 13 February 2025

- Update GN to e54c9b9d.

### Version 0.6.23 - 06 February 2025

- Update GN to 28973fb1.
  
### Version 0.6.22 - 05 February 2025

- Update GN to 6c72fe0c.

### Version 0.6.21 - 27 January 2025

- Update GN to 66a77c30.
- Add the option to allow ciertain hosts to bypass the Basic Auth in Apache.

### Version 0.6.20 - 19 December 2024

- Update GN to 3b75aaea.

### Version 0.6.19 - 17 December 2024

- Update GN to fe7ee40a.

### Version 0.6.18 - 12 December 2024

- Update GN to 72fa5c64.

### Version 0.6.17 - 05 December 2024

- Update GN to 8152c023.

### Version 0.6.16 - 21 October 2024

- Update GN to 4314733c.
- Record view / More like this / Add filter option.
- EEA / Editor / Fix open source and sibling panel. <https://taskman.eionet.europa.eu/issues/277292>

### Version 0.6.15 - 07 October 2024

- Update GN to e1fde81a. EEA / Statistical dataset / Default to EEA list of unit of measure.
- Keyword / Not capitalize and do not display thesaurus if no keywords.
- EEA / SDMX / Fix XPath for other constraints mapping.

### Version 0.6.14 - 02 October 2024

- Update GN to 3afedac5. EEA / Editor / Statistical data / Add action when missing unit of measure or ref period.
  
### Version 0.6.13 - 01 October 2024

- Update GN to b6d6d7da

### Version 0.6.12 - 12 September 2024

- Update GN to cef73a4c

### Version 0.6.11 - 12 September 2024

- Remove shareit job

### Version 0.6.10 - 12 September 2024

- Fix validator ConfigMap mount point

### Version 0.6.9 - 12 September 2024

- Add missing /etc/network/interfaces to validator pod as ConfigMap

### Version 0.6.8 - 12 September 2024

- Update validator pod privileges

### Version 0.6.7 - 10 September 2024

- Update GN to 295bd177. EEA / Thesaurus / Update ROD <https://taskman.eionet.europa.eu/issues/270841>

### Version 0.6.6 - 10 September 2024

- Update inspire validator image to 2024.2

### Version 0.6.5 - 10 September 2024

- Made sysctl updates optional, as the values are the default on the nodes now.
- Upgraded the postfix container.

### Version 0.6.4 - 08 August 2024

  <dd>Upgraded GN to b1adafc2.
    <ul>
      <li>EEA / Script / Add hierarchylevelname if not present https://taskman.eionet.europa.eu/issues/273346</li>
      <li>Record view / Improve layout of table (eg. quality measures)</li>
    </ul>
  </dd>

### Version 0.6.3 - 06 August 2024

- Upgraded Apache version.

### Version 0.6.2 - 06 August 2024

- Update GN to c3949e2c. EEA / SDMX / Add maintenance info to FREQ_DISS.

### Version 0.6.1 - 29 July 2024

  <dd>
    <ul>
      <li>EEA / Statistical data / Add date of next update.</li>
      <li>EEA / Statistical data / Migrate frequency of dissemination from maintenance to specific element.</li>
      <li>EEA / SDMX / Add frequency of dissemination.</li>
      <li>Standard / ISO19139 / Fix removal of link when multiple transferoptions are used.</li>
    </ul>
  </dd>

### Version 0.6.0 - 26 June 2024

- Use CronJob for all cron jobs. Must be enabled in values.yaml.

### Version 0.5.17 - 24 June 2024

- Optional cronjob for syncronising Nextcloud files with Apache.

### Version 0.5.16 - 11 June 2024

- Deactivate TRACE in Apache.

### Version 0.5.15 - 11 June 2024

- Upgraded Apache version.

### Version 0.5.14 - 04 June 2024

- The argument to Require ldap-group must not have quotes - implement everywhere.

### Version 0.5.13 - 04 June 2024

- The argument to Require ldap-group must not have quotes.

### Version 0.5.12 - 29 May 2024

- Update GN to 8a0008a6.

### Version 0.5.11 - 23 May 2024

- Update GN to 384d7b8c.

### Version 0.5.10 - 17 May 2024

- Update GN to 57c1ae49.

### Version 0.5.9 - 17 May 2024

- Redirect HTTP to HTTPS. Update GN to c255d985.

### Version 0.5.8 - 17 May 2024

- Remove CSP form-action directive casusing problems with the login form redirection.

### Version 0.5.7 - 17 May 2024

- Updated GN to ecb45615. Added some extra CSP header entries for the validator and OGC Records API

### Version 0.5.6 - 14 May 2024

- Removed unused sdi-public-catalogue-resources-pvc volume.

### Version 0.5.5 - 13 May 2024

- Remove Authorization header for /catalogue if the site is protected with basic auth.

### Version 0.5.4 - 09 May 2024

  <dd>Use only one header in Content-Security-Policy. This allow to fix a problem with img-src ignored if
  multiple hearders are used.</dd>

### Version 0.5.3 - 09 May 2024

- Add openstreetmap.org to allowed img-src policy.

### Version 0.5.2 - 09 May 2024

- Fix typo

### Version 0.5.1 - 09 May 2024

  <dd>Tune Content-Security-Policy headers. Use Header add instead of Header set to avoid
  override previous headers already set.
  </dd>

### Version 0.5.0 - 07 May 2024

  <dd>Clean up apache config.
    Added reportUri, privilegedIPs, privilegedGroups and privilegedUsers in values.yaml.
    Add basic auth globally to the web controlled by a value.
    The ssl.conf file is now applied unconditionally.
  </dd>
