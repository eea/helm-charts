# copernicus-insitu-db

Helm chart for the Copernicus In-Situ DB stack.
## Releases

### Version 1.2.17 - 26 November 2026
- Automated release of nginx:1.31.10 [Valentina Balan - [`122a22dd4`](https://github.com/eea/helm-charts/commit/122a22dd4aac511ee6011f439cd419266a9451f4)]

### Version 1.2.16 - 20 November 2026
- Automated release of nginx:1.31.9 [EEA Jenkins - [`9631d50a5`](https://github.com/eea/helm-charts/commit/9631d50a5b954adff7f778a912304c218a12ee92)]

### Version 1.2.15 - 16 November 2026
- Upgraded eeacms/copernicus-insitu-db:4.0.10 [Diana Boiangiu - [`42bb52802`](https://github.com/eea/helm-charts/commit/42bb52802cad36fefccbfc6b898405d6591b8d6b)]

### Version 1.2.14 - 01 July 2026
- Upgraded eeacms/copernicus-insitu-db:4.0.9 [Diana Boiangiu - [`2f918f97`](https://github.com/eea/helm-charts/commit/2f918f975b0202774191cafdd2715e78f5e9604a)]

### Version 1.2.13 - 01 July 2026
- Upgraded eeacms/copernicus-insitu-db:4.0.8 [Diana Boiangiu - [`c82cabac`](https://github.com/eea/helm-charts/commit/c82cabac65e191171e52089afeb41ff535d5c1d2)]

### Version 1.2.12 - 11 June 2026
- Upgraded eeacms/copernicus-insitu-db:4.0.7 [Diana Boiangiu - [`8c941ae7`](https://github.com/eea/helm-charts/commit/8c941ae78b379d1c6c4fa4ef2179618b3ee8225e)]

### Version 1.2.11 - 03 June 2026
- Update nginx to 1.31.1 - Refs [#304237](https://taskman.eionet.europa.eu/issues/304237) [valentinab25 - [`0bcee03f`](https://github.com/eea/helm-charts/commit/0bcee03fb066289ab92bb074b750bc0e6c7657da)]

### Version 1.2.10 - 27 May 2026
- Upgraded eeacms/copernicus-insitu-db:4.0.6 [Diana Boiangiu - [`85101ca3`](https://github.com/eea/helm-charts/commit/85101ca39cab1db6bf90c35f2b2713cff9983785)]

### Version 1.2.9 - 18 May 2026
- add nodeport for testing [Dobricean Ioan Dorian - [`27521fc5`](https://github.com/eea/helm-charts/commit/27521fc5be787e324b1b9cb185e44fdeed84afb5)]

### Version 1.2.8 - 18 May 2026
- Added configurable NodePort questions for CIS2 web services

### Version 1.2.7 - 18 May 2026
- Upgraded eeacms/copernicus-insitu-db:4.0.5 [Diana Boiangiu - [`d298bff4`](https://github.com/eea/helm-charts/commit/d298bff4fddddc7771d63cf332597d129314f326)]

### Version 1.2.6 - 15 May 2026
- Upgraded eeacms/copernicus-insitu-db:4.0.3 [Diana Boiangiu - [`578d76de`](https://github.com/eea/helm-charts/commit/578d76de98504841130bb4c532fb058b2283c3f7)]

### Version 1.2.5 - 15 May 2026
- configmap & appversion [Dobricean Ioan Dorian - [`905c87f7`](https://github.com/eea/helm-charts/commit/905c87f73928df2cd0d0481b644910764747c5cd)]

### Version 1.2.4 - 15 May 2026
- Upgraded eeacms/copernicus-insitu-db:3.0.8 [Diana Boiangiu - [`1f1344e1`](https://github.com/eea/helm-charts/commit/1f1344e1be1b067b86b9f0d3ce2489f35f118353)]

### Version 1.2.3 - 23 March 2026
- fix error message [Dobricean Ioan Dorian - [`19097289`](https://github.com/eea/helm-charts/commit/19097289fc86b1d2fe1b7a3d5205cc3de8d0d831)]

### Version 1.2.2 - 23 March 2026
- add missing variables [Dobricean Ioan Dorian - [`7baf9dae`](https://github.com/eea/helm-charts/commit/7baf9dae9da1c37387ef4d722bff6ab8a910fd83)]

### Version 1.2.1 - 10 March 2026
- fix imout [Dobricean Ioan Dorian - [`bd4bd6f3`](https://github.com/eea/helm-charts/commit/bd4bd6f3b95c6219535f0799ba3e574a366243f8)]

### Version 1.2.0 - 03 March 2026
- remove unneded crons [Dobricean Ioan Dorian - [`34faae54`](https://github.com/eea/helm-charts/commit/34faae54a738982e5750202699ec3885a534d45e)]

### Version 1.1.4 - 02 March 2026
- fix nginx [Dobricean Ioan Dorian - [`33ad5b83`](https://github.com/eea/helm-charts/commit/33ad5b83f1dd1417017a2930e181230ceaae4842)]

### Version 1.1.3 - 02 March 2026
- fix nginx [Dobricean Ioan Dorian - [`39912aa1`](https://github.com/eea/helm-charts/commit/39912aa13f63334c3f514d4ca88a93db0a8abb21)]

### Version 1.1.2 - 02 March 2026
- fix nginx [Dobricean Ioan Dorian - [`2e7c3418`](https://github.com/eea/helm-charts/commit/2e7c341861274556d65977c205eb0d6315d67a07)]

### Version 1.1.1 - 27 February 2026
- ingress [Dobricean Ioan Dorian - [`82eaf01e`](https://github.com/eea/helm-charts/commit/82eaf01e89c4c38acc6d9fe12b508a48f03775de)]

### Version 1.1.0 - 27 February 2026
- cleanup [Dobricean Ioan Dorian - [`61dbc289`](https://github.com/eea/helm-charts/commit/61dbc289994ba8c48aa5fd3fe6cca6335515ad47)]

### Version 1.0.0 - 27 February 2026
- remove unneeded services [Dobricean Ioan Dorian - [`204fc9c7`](https://github.com/eea/helm-charts/commit/204fc9c726a581a5763da1fe86cfb55aca4c85cd)]

### Version 0.2.0 - 27 February 2026
- change vars [Dobricean Ioan Dorian - [`9703d771`](https://github.com/eea/helm-charts/commit/9703d771f481fdf0d67b48c85a10ae9924dea404)]

### Version 0.1.1 - 27 February 2026
- fix ingres [Dobricean Ioan Dorian - [`956d42ab`](https://github.com/eea/helm-charts/commit/956d42abcfe84268a175b67e8f5d78762ef90e9b)]
