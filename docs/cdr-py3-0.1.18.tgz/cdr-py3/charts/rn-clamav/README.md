# Reportnet Clamav Scanner

Clamav scanner for Reportek.

## Configuration

- `timezone` - Time zone.
- `maxFileSize` - Maximum file size to scan.
- `maxScanSize` - Maximum scan size.
- `streamMaxLength` - Maximum stream length.
- `storage` - Size of the persistent volume claim.
- `storageName` - Name of the persistent volume claim.
- `networkPolicy.enabled` - Enable network policy. Defaults to true.
- `networkPolicy.spec` - Additional network policy specifications. Defaults to {}.

## Releases

### Version 1.0.0 - 07 May 2026
- Moved to official clamav/clamav image [Olimpiu Rob - [`8315ad4b`](https://github.com/eea/helm-charts/commit/8315ad4b5a38a8a0c538830600a26701354e484a)]

### Version 0.1.9 - 05 May 2026
- Updated appVersion to 2.6.99 [Olimpiu Rob - [`cc4ecc06`](https://github.com/eea/helm-charts/commit/cc4ecc061f44c67850276f755d58ca7e3a4a572b)]

### Version 0.1.8
- Further egress restrictions.

### Version 0.1.7
- Renamed network policy metadata component label to network-policy.

### Version 0.1.6
- Added NetworkPolicy support.

### Version 0.1.5
- Added behavior section to hpa.
- Updated appVersion to 2.6.21.

### Version 0.1.4
- Tweaked hpa name
- Fixed README

### Version 0.1.3
- Updated appVersion to 2.6.20.

### Version 0.1.2
- Some refactoring and added component label.

### Version 0.1.1
- Added enabled flag.

### Version 0.1.0
- Initial release.
