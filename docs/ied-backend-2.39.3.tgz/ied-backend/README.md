# European Industrial Emissions Portal backend - Plone 6

This chart deployes the European Industrial Emissions Portal backend app

## Values

| Key           | Type | Default | Description                       |
| ------------- | ---- | ------- | --------------------------------- |
| debug.enabled | bool | false   | Activate the Plone debug instance |

## Releases

### Version 2.39.3 - 10 November 2026
- fix(ied-backend): fix HPA/replicas conflict, expose autoscaling in UI [Claudia Ifrim - [`1e5a2a367`](https://github.com/eea/helm-charts/commit/1e5a2a36775e240bbae8bf25f2b754d174f28cb3)]

### Version 2.39.2 - 10 November 2026
- fix(ied-backend): block portal_modifier [Claudia Ifrim - [`97b72fc57`](https://github.com/eea/helm-charts/commit/97b72fc57d2313f6f25517ab673be9f4ba2d69b3)]

### Version 2.39.1 - 04 September 2026
- chore: Refs [#305742](https://taskman.eionet.europa.eu/issues/305742) - reduce kept failed cronjob pods from 5 to 1 [Claudia Ifrim - [`3ed8dc68`](https://github.com/eea/helm-charts/commit/3ed8dc68fe7e59e06b3bc4658da84ffd607bd079)]

### Version 2.39.0 - 19 August 2026
- Automated release of [eeacms/ied-backend:6.20.0](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`b8052338`](https://github.com/eea/helm-charts/commit/b8052338f4f0cc4f967a3bd0bbf19162fe4835e3)]

### Version 2.38.1 - 16 June 2026
- increase cpu cronjobs [Dobricean Ioan Dorian - [`ecf905f4`](https://github.com/eea/helm-charts/commit/ecf905f4b84c5639271ac472cb2cc9701ee98e1c)]

### Version 2.38.0 - 29 May 2026
- Automated release of [eeacms/ied-backend:6.19.5](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`e58c0acb`](https://github.com/eea/helm-charts/commit/e58c0acb3a11a995f17c868f37a3befa7c094a04)]

### Version 2.37.1 - 28 May 2026
- Automated release of [eeacms/ied-backend:6.19.4-1.beta-1](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`36716771`](https://github.com/eea/helm-charts/commit/36716771a70762514e548d4d0d599ed44244104e)]

### Version 2.37.0 - 28 May 2026
- Automated release of [eeacms/ied-backend:6.19.1](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`f0e1925d`](https://github.com/eea/helm-charts/commit/f0e1925de02ecab461773217095bc2a49819edb4)]

### Version 2.36.0 - 22 May 2026
- Automated release of [eeacms/ied-backend:6.1.4-4](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`12078541`](https://github.com/eea/helm-charts/commit/120785412763e1214d46dbe5fc0e1b383dba1024)]

### Version 2.35.0 - 08 May 2026
- Automated release of [eeacms/ied-backend:6.1.4-3](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`f5137b38`](https://github.com/eea/helm-charts/commit/f5137b38adcb9752b2382ba9cbdd17b67d5a4b22)]

### Version 2.34.0 - 29 April 2026
- Automated release of [eeacms/ied-backend:6.1.4-2](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`1c9f9dd1`](https://github.com/eea/helm-charts/commit/1c9f9dd190333a90715351a290b465c01256783a)]

### Version 2.33.0 - 29 April 2026
- Automated release of [eeacms/ied-backend:6.1.4-1](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`f99dfd19`](https://github.com/eea/helm-charts/commit/f99dfd195cf2f5b1e333f560aabdee9edc21945c)]

### Version 2.32.1 - 24 April 2026
- increase plone replicas [Dobricean Ioan Dorian - [`f81f8bf7`](https://github.com/eea/helm-charts/commit/f81f8bf737a03231d359d4ca26445dc121675474)]

### Version 2.32.0 - 22 April 2026
- Automated release of [eeacms/ied-backend:6.1.3-59](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`8c378628`](https://github.com/eea/helm-charts/commit/8c378628b9b7c2fd78d174b2c916d5e97dbc05c9)]

### Version 2.31.0 - 17 April 2026
- Automated release of [eeacms/ied-backend:6.1.3-57](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`bd38bf16`](https://github.com/eea/helm-charts/commit/bd38bf1655062f0e5fb4ff7a709babfd0d974c88)]

### Version 2.30.5 - 05 February 2026
- Automated release of [eeacms/ied-backend:6.1.3-56.beta](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`ef9bef84`](https://github.com/eea/helm-charts/commit/ef9bef8452239bc6e01c9c29901671423de087c2)]

### Version 2.30.4 - 05 February 2026
- Automated release of [eeacms/ied-backend:6.1.3-54.beta](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`3e91c76b`](https://github.com/eea/helm-charts/commit/3e91c76b1a18fc7b0686cd1d1685c34020626ff6)]

### Version 2.30.3 - 05 February 2026
- Automated release of [eeacms/ied-backend:6.1.3-53.beta](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`a032986d`](https://github.com/eea/helm-charts/commit/a032986d64640328ec6f051dcc46f5185985dbb2)]

### Version 2.30.2 - 05 February 2026
- Automated release of [eeacms/ied-backend:6.1.3-52.beta](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`13a34c06`](https://github.com/eea/helm-charts/commit/13a34c061eb2d863ee344fe4fea89add56e2238e)]

### Version 2.30.1 - 05 February 2026
- Automated release of [eeacms/ied-backend:6.1.3-51.beta](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`9763a00f`](https://github.com/eea/helm-charts/commit/9763a00ffd3b5995c9b008c47ffe84c15d4c30a7)]

### Version 2.30.0 - 28 January 2026
- Automated release of [eeacms/ied-backend:6.1.3-50](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`b60dbc64`](https://github.com/eea/helm-charts/commit/b60dbc6440f558f7dc734a2097928545c2ce427b)]

### Version 2.29.0 - 28 January 2026
- Automated release of [eeacms/ied-backend:6.1.3-49](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`1eb271ab`](https://github.com/eea/helm-charts/commit/1eb271abca9d5dbac73c9e8d8f14c3e8b47acafa)]

### Version 2.28.2 - 27 January 2026
- debug instance [Dobricean Ioan Dorian - [`00c44033`](https://github.com/eea/helm-charts/commit/00c44033d94b2be38280e50c0c443f13df2e248a)]

### Version 2.28.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`9f09351d`](https://github.com/eea/helm-charts/commit/9f09351d07bb3dfdd80c9f475231e510fc509a4a)]

### Version 2.28.0 - 30 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-48](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`18819245`](https://github.com/eea/helm-charts/commit/18819245b2842aee8f89bb7c82c9c96d646f5d5f)]

### Version 2.27.0 - 29 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-47](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`20a51974`](https://github.com/eea/helm-charts/commit/20a51974131a93a170047da561e4f5dc0bdae158)]

### Version 2.26.0 - 28 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-46](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`74283441`](https://github.com/eea/helm-charts/commit/74283441141d3e4f2b4028049fabb5a8e7b3f1a2)]

### Version 2.25.0 - 27 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-45](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`5e0ceeec`](https://github.com/eea/helm-charts/commit/5e0ceeeccfd111a372acbf037d77aa1fea5acb0f)]

### Version 2.24.0 - 26 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-44](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`5693dc0b`](https://github.com/eea/helm-charts/commit/5693dc0b7703ac9da4fa70be381ea58ae93fef0f)]

### Version 2.23.0 - 25 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-43](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`94f7f121`](https://github.com/eea/helm-charts/commit/94f7f121f7b03bd8accf2cb75bf29c18b6af2545)]

### Version 2.22.0 - 24 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-42](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`4f6b7a24`](https://github.com/eea/helm-charts/commit/4f6b7a24884d525e82573e59477c465649121ef4)]

### Version 2.21.0 - 23 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-41](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`23f0f108`](https://github.com/eea/helm-charts/commit/23f0f1089352fd280d0ad70b0e26fe3e3801faea)]

### Version 2.20.0 - 22 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-40](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`6f53bd71`](https://github.com/eea/helm-charts/commit/6f53bd710dc9457e23bed26f53c83a429308ccc3)]

### Version 2.19.0 - 22 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-39](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`1ffa014d`](https://github.com/eea/helm-charts/commit/1ffa014df9d83e6c593b366e5216a3688d2c7a82)]

### Version 2.18.0 - 21 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-38](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`6baedf23`](https://github.com/eea/helm-charts/commit/6baedf23c5396dad7edc60cd001eff5c5b063bb2)]

### Version 2.17.0 - 20 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-37](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`db5a816d`](https://github.com/eea/helm-charts/commit/db5a816d5fa4765c9c02130a938f277ddbdc4d8a)]

### Version 2.16.1 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`7e799945`](https://github.com/eea/helm-charts/commit/7e7999457c1a463d491f03b895b5faa0f6f61c77)]

### Version 2.16.0 - 18 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-36](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`fc416b21`](https://github.com/eea/helm-charts/commit/fc416b2102067a39e2e9d8b62aa792cf9162d1b6)]

### Version 2.15.0 - 17 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-35](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`ddbe7b29`](https://github.com/eea/helm-charts/commit/ddbe7b2977d1baf288abd63c1fa081328cc37dca)]

### Version 2.14.0 - 16 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-34](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`aa63a0aa`](https://github.com/eea/helm-charts/commit/aa63a0aa157f6355f1749da1a762b7f17526f9b3)]

### Version 2.13.0 - 15 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-33](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`402bfcf8`](https://github.com/eea/helm-charts/commit/402bfcf8225b941c5b19ef3e717663d9a5ea9a08)]

### Version 2.12.0 - 14 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-32](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`f52382e4`](https://github.com/eea/helm-charts/commit/f52382e4b8c2c6c19af21a31b22f6961338281b7)]

### Version 2.11.0 - 13 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-31](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`9f43ab5b`](https://github.com/eea/helm-charts/commit/9f43ab5b77ea6bbd79b3dff81561d2115ca900dc)]

### Version 2.10.0 - 12 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-30](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`5d088f26`](https://github.com/eea/helm-charts/commit/5d088f26c11d4abc7281a5865ba24a1f4753afcd)]

### Version 2.9.0 - 11 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-29](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`afc274e9`](https://github.com/eea/helm-charts/commit/afc274e94764d90ef5fa1df5bac34fffa005790e)]

### Version 2.8.1 - 10 December 2025
- updatepostfix [Dobricean Ioan Dorian - [`8e5c7f58`](https://github.com/eea/helm-charts/commit/8e5c7f58fe2f91ca092bda949d4924b08f88996a)]

### Version 2.8.0 - 09 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-28](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`47ea41a2`](https://github.com/eea/helm-charts/commit/47ea41a26a27acda1df51b80dfc00d7e3bc4bf19)]

### Version 2.7.0 - 08 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-27](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`09e2bc60`](https://github.com/eea/helm-charts/commit/09e2bc605bdf543ebac91a0ad2d2f5250f6291de)]

### Version 2.6.0 - 07 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-26](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`5f7839a5`](https://github.com/eea/helm-charts/commit/5f7839a59f18c77efa8b262eb8b1d86b1b38aaa0)]

### Version 2.5.0 - 06 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-25](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`ba185988`](https://github.com/eea/helm-charts/commit/ba1859885c80c73ec1de60194a038c3dbeda4892)]

### Version 2.4.0 - 05 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-24](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`397186b8`](https://github.com/eea/helm-charts/commit/397186b8ac67b69a41b4e0bebf4ca3990669c459)]

### Version 2.3.0 - 04 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-23](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`b4d41579`](https://github.com/eea/helm-charts/commit/b4d4157958842462b851432366cc61dd12bef79d)]

### Version 2.2.0 - 04 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-22](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`b3c3707a`](https://github.com/eea/helm-charts/commit/b3c3707afd8d899257affa9e22fdadf791428f1e)]

### Version 2.1.0 - 04 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-21](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`b76f90df`](https://github.com/eea/helm-charts/commit/b76f90dfffd37f53553342122312d8e9630b9f9b)]

### Version 2.0.1 - 03 December 2025
- update helm version [Dobricean Ioan Dorian - [`a590f59f`](https://github.com/eea/helm-charts/commit/a590f59f01a3d34e6b6c1731ddfc1305d9a81af3)]

### Version 1.3.2 - 03 December 2025
- Update helm version [Dobricean Ioan Dorian - [`8ae37da1`](https://github.com/eea/helm-charts/commit/8ae37da149d03372cc193d2830dfdfa2bf604948)]

### Version 1.3.0 - 03 December 2025
- Automated release of [eeacms/ied-backend:6.1.3-20](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`7a76dc49`](https://github.com/eea/helm-charts/commit/7a76dc49dd05e8b86ef7a559402fb894ec874d56)]

### Version 1.110.0 - 11 November 2025
- Automated release of [eeacms/ied-backend:6.18.3.demo](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`3be6249c`](https://github.com/eea/helm-charts/commit/3be6249c2186b67267046537d2e3f95b33f37e70)]

### Version 1.109.0 - 25 October 2025
- Automated release of [eeacms/ied-backend:6.0.15-96](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`7c8e1e3f`](https://github.com/eea/helm-charts/commit/7c8e1e3fd8cd8feeaffb8b53b4553955095364ae)]

### Version 1.108.0 - 24 October 2025
- Automated release of [eeacms/ied-backend:6.0.15-95](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`bd5a2442`](https://github.com/eea/helm-charts/commit/bd5a2442ecd7f4e54b998520f556303c00e1c952)]

### Version 1.107.0 - 08 October 2025
- Automated release of [eeacms/ied-backend:6.0.15-94](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`a085e047`](https://github.com/eea/helm-charts/commit/a085e0474892b04b8b2ba9558c155863b763959f)]

### Version 1.106.0 - 13 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-93](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`1a8c99bb`](https://github.com/eea/helm-charts/commit/1a8c99bb8169fbc0edea0c442eca20152da9e08d)]

### Version 1.105.0 - 12 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-92](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`a8f64737`](https://github.com/eea/helm-charts/commit/a8f647379bafa5c352e5d354ffacbceea87466aa)]

### Version 1.104.0 - 11 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-91](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`354fab75`](https://github.com/eea/helm-charts/commit/354fab7514c4e99eba7fb052152a8b79898881a9)]

### Version 1.103.0 - 10 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-90](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`eb10e505`](https://github.com/eea/helm-charts/commit/eb10e5050c52cf1c793356416575ebcf3eba5c18)]

### Version 1.102.0 - 09 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-89](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`41beb752`](https://github.com/eea/helm-charts/commit/41beb752b5ceec2a37645fe05bbe1fbd93db0531)]

### Version 1.101.0 - 08 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-88](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`5d2b9169`](https://github.com/eea/helm-charts/commit/5d2b9169540f562f5964feba63e21f84ae43c253)]

### Version 1.100.0 - 07 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-87](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`db74a795`](https://github.com/eea/helm-charts/commit/db74a795eb88252ebe8127cb295103461b3509d5)]

### Version 1.99.0 - 06 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-86](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`2c96a86f`](https://github.com/eea/helm-charts/commit/2c96a86f2872ac29039ae7ebfd405025fc39ebbe)]

### Version 1.98.0 - 05 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-85](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`05809886`](https://github.com/eea/helm-charts/commit/0580988616f8f5bd7fb5d046f3d90572a3ce395e)]

### Version 1.97.0 - 04 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-84](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`3f8176a2`](https://github.com/eea/helm-charts/commit/3f8176a298305806cddd2804d7ab147d9fe461f8)]

### Version 1.96.0 - 03 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-83](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`20db049e`](https://github.com/eea/helm-charts/commit/20db049e9aeff192cb0f2cc9bb70cb38b7de16a1)]

### Version 1.95.0 - 02 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-82](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`7c6aa67d`](https://github.com/eea/helm-charts/commit/7c6aa67dcbee986230ede3a9222adc645bb72f46)]

### Version 1.94.0 - 01 September 2025
- Automated release of [eeacms/ied-backend:6.0.15-81](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`e8532928`](https://github.com/eea/helm-charts/commit/e8532928c89bbb4dd970b53a9ef43149725df5eb)]

### Version 1.93.0 - 31 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-80](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`1951d081`](https://github.com/eea/helm-charts/commit/1951d0813f415ffc8583474963a61fa2b6670d78)]

### Version 1.92.0 - 30 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-79](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`d47f68da`](https://github.com/eea/helm-charts/commit/d47f68da106167ad737e3687ad5e93a0d150c89d)]

### Version 1.91.0 - 29 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-78](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`b8f9ed3c`](https://github.com/eea/helm-charts/commit/b8f9ed3c60249b4a092f976e9116700ffec5e36e)]

### Version 1.90.0 - 28 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-77](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`3b0f1df3`](https://github.com/eea/helm-charts/commit/3b0f1df303df3ab80239521dad9b669b83f70bbf)]

### Version 1.89.0 - 28 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-76](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`90f71a91`](https://github.com/eea/helm-charts/commit/90f71a917a2cd33621652f62de63f70a5be64475)]

### Version 1.88.0 - 27 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-75](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`5eea0952`](https://github.com/eea/helm-charts/commit/5eea0952834c4acddc3b4c02c8fa4144cc8351ef)]

### Version 1.87.0 - 27 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-74](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`d0ac8600`](https://github.com/eea/helm-charts/commit/d0ac8600a58bf27062f43edcc30c61d49a95fc4b)]

### Version 1.86.0 - 27 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-73](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`2123463c`](https://github.com/eea/helm-charts/commit/2123463c70dceedd332060d0e565a62a2277d5c6)]

### Version 1.85.0 - 26 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-72](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`a547cc91`](https://github.com/eea/helm-charts/commit/a547cc915d0f45e3f30793da56f80b30818bcd17)]

### Version 1.84.0 - 25 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-71](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`e4170b0f`](https://github.com/eea/helm-charts/commit/e4170b0f77f8079de01ddd6fbf127a1a90290c2a)]

### Version 1.83.1 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`1e0899ba`](https://github.com/eea/helm-charts/commit/1e0899bab42a316e34494065f6f015e65a5495cf)]

### Version 1.83.0 - 24 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-70](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`07118b41`](https://github.com/eea/helm-charts/commit/07118b4193f6cb19b7b9b6b83441e165f6903bf9)]

### Version 1.82.0 - 23 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-69](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`27c5e9e2`](https://github.com/eea/helm-charts/commit/27c5e9e274d622e19c0ee629632bf13295066098)]

### Version 1.81.0 - 22 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-68](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`0d77f9bf`](https://github.com/eea/helm-charts/commit/0d77f9bf71ac22eb936d7333c029c30580a3feae)]

### Version 1.80.0 - 21 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-67](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`888eecf3`](https://github.com/eea/helm-charts/commit/888eecf3abba4d0bcfb4346c161dec7fd1143286)]

### Version 1.79.0 - 20 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-66](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`09b347c2`](https://github.com/eea/helm-charts/commit/09b347c272a33179d13b3222508a00f52c813814)]

### Version 1.78.0 - 20 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-65](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`6c893722`](https://github.com/eea/helm-charts/commit/6c8937226c746317b845524e96120519c4b66b97)]

### Version 1.77.0 - 20 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-64](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`c65ba008`](https://github.com/eea/helm-charts/commit/c65ba008cbafbc002215684e3c171f7eaeb73f7d)]

### Version 1.76.0 - 18 August 2025
- Automated release of [eeacms/ied-backend:6.18.0](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`2bed5cba`](https://github.com/eea/helm-charts/commit/2bed5cbae338456f40e38735434b22a9bfe14fa3)]

### Version 1.75.0 - 13 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-63](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`1cc7ee6c`](https://github.com/eea/helm-charts/commit/1cc7ee6cfd5e4e02014a5ce9c01c1b9cb0be4c77)]

### Version 1.74.0 - 12 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-62](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`e32b4637`](https://github.com/eea/helm-charts/commit/e32b46373e48e198c6b75660ef378fa8b756b01e)]

### Version 1.73.0 - 11 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-61](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`bb2d681a`](https://github.com/eea/helm-charts/commit/bb2d681aec570d878d56a4e3af2ab69407d46ce5)]

### Version 1.72.0 - 10 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-60](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`af17af47`](https://github.com/eea/helm-charts/commit/af17af47562abe18361789eb02af345ac23fac65)]

### Version 1.71.0 - 09 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-59](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`279783c9`](https://github.com/eea/helm-charts/commit/279783c94039d9067b2029fe70f30cf1df1869c5)]

### Version 1.70.0 - 08 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-58](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`c40bb1f9`](https://github.com/eea/helm-charts/commit/c40bb1f94023f1e2e7a3cf94a7b880dd8cc0df41)]

### Version 1.69.0 - 07 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-57](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`9925efbd`](https://github.com/eea/helm-charts/commit/9925efbd71e46cd6702268325ea934e29d55a71b)]

### Version 1.68.0 - 06 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-56](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`f152bcc0`](https://github.com/eea/helm-charts/commit/f152bcc0982dc9ea289300f111361e695d7a81a8)]

### Version 1.67.0 - 05 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-55](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`c10a843e`](https://github.com/eea/helm-charts/commit/c10a843ea0992112415f8b1118a4f4f5dca47b2c)]

### Version 1.66.0 - 05 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-54](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`357b874e`](https://github.com/eea/helm-charts/commit/357b874e135a56ef81a3305e629c60a6c670b573)]

### Version 1.65.0 - 04 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-53](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`3944e70d`](https://github.com/eea/helm-charts/commit/3944e70d5ebd8b4e6ee3f3ea8228fc97cf02bdd0)]

### Version 1.64.0 - 04 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-52](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`d131b247`](https://github.com/eea/helm-charts/commit/d131b247d97f869b34e34e1441d6b696922459ff)]

### Version 1.63.0 - 03 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-51](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`86dbfdba`](https://github.com/eea/helm-charts/commit/86dbfdba8d0072ab3a2b1c75e8107fc1aaba9c97)]

### Version 1.62.0 - 02 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-50](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`bc0e3b88`](https://github.com/eea/helm-charts/commit/bc0e3b887dd58eb5388b9b3b3da679a419cc46a2)]

### Version 1.61.0 - 01 August 2025
- Automated release of [eeacms/ied-backend:6.0.15-49](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`73c079bc`](https://github.com/eea/helm-charts/commit/73c079bc9058aa2ba957ff3d70ef5f07f23c25d8)]

### Version 1.60.1 - 01 August 2025
- Automated release of [eeacms/plone-varnish:7.7-1.1](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`8fce01b5`](https://github.com/eea/helm-charts/commit/8fce01b51266ca11ca2b5de9201877f99357f860)]

### Version 1.60.0 - 25 July 2025
- Automated release of [eeacms/ied-backend:6.0.24](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`d84cabc6`](https://github.com/eea/helm-charts/commit/d84cabc6af6e6a2610e4e0a17510c1ad90c3c6fa)]

### Version 1.59.0 - 24 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-48](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`cef76a55`](https://github.com/eea/helm-charts/commit/cef76a5590d47a92e063e6e46a6d30fbeeafaf07)]

### Version 1.58.0 - 23 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-47](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`da485313`](https://github.com/eea/helm-charts/commit/da485313ca691fce50903c0d4a49b004f895cb0f)]

### Version 1.57.0 - 22 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-46](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`4df61418`](https://github.com/eea/helm-charts/commit/4df61418458fae979a6fb2d8f9caf08c8db24a9e)]

### Version 1.56.0 - 21 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-45](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`f0b40a7c`](https://github.com/eea/helm-charts/commit/f0b40a7ce52217512c365ace6844b4faf47550d4)]

### Version 1.55.0 - 20 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-44](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`52efeae9`](https://github.com/eea/helm-charts/commit/52efeae9266f113ffe8657291ead6ba6a516df51)]

### Version 1.54.0 - 19 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-43](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`65ff5e93`](https://github.com/eea/helm-charts/commit/65ff5e93c7ec5dbba4e19c704b66fb3d4e9c9551)]

### Version 1.53.0 - 18 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-42](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`5cce2577`](https://github.com/eea/helm-charts/commit/5cce257727c2cab34c34c05a7c94d61318c3fc0d)]

### Version 1.52.0 - 16 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-41](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`3b9a5718`](https://github.com/eea/helm-charts/commit/3b9a5718190b1f7698bbad3ba1b4757a0212e185)]

### Version 1.51.0 - 15 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-40](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`7a8aff9a`](https://github.com/eea/helm-charts/commit/7a8aff9a5ddde1a03895564b3162972bc6af8641)]

### Version 1.50.0 - 15 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-39](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`82037305`](https://github.com/eea/helm-charts/commit/8203730599e9f61eeba982d2d40f720a4047e555)]

### Version 1.49.0 - 14 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-38](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`fb5a3286`](https://github.com/eea/helm-charts/commit/fb5a3286480f260719152458c0e2493d9a8e1a4e)]

### Version 1.48.0 - 13 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-37](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`ebae61b3`](https://github.com/eea/helm-charts/commit/ebae61b3bc4d8c409fd1f2064ec00a80de9b7880)]

### Version 1.47.0 - 12 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-36](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`7830b7cc`](https://github.com/eea/helm-charts/commit/7830b7ccd9fc1d864f981fb6f7122b1ffe58e6cb)]

### Version 1.46.0 - 11 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-35](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`05088f1b`](https://github.com/eea/helm-charts/commit/05088f1b461eaf392d8a81e6544705f23e209e95)]

### Version 1.45.0 - 10 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-34](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`db8dd0a1`](https://github.com/eea/helm-charts/commit/db8dd0a15586e6b7884f50b52b7bf375f70a5015)]

### Version 1.44.0 - 09 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-33](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`7f612611`](https://github.com/eea/helm-charts/commit/7f612611720ce1189889084ef35a1cd399df8a67)]

### Version 1.43.0 - 08 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-32](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`79d4bb84`](https://github.com/eea/helm-charts/commit/79d4bb84335a9482526d2abb5118302aec41f687)]

### Version 1.42.0 - 06 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-30](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`88237afb`](https://github.com/eea/helm-charts/commit/88237afb9b351a5af4680f64c697291ad935fdd3)]

### Version 1.41.0 - 05 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-29](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`acfd9322`](https://github.com/eea/helm-charts/commit/acfd9322084f6a72bf5a5e4d585fbd9cec302f7f)]

### Version 1.40.0 - 04 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-28](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`236a0776`](https://github.com/eea/helm-charts/commit/236a0776f6c1165484daf892742d568f0f4fe6a2)]

### Version 1.39.0 - 03 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-27](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`d77f7cd6`](https://github.com/eea/helm-charts/commit/d77f7cd6c5b5e941cf25a3c55192540f152f3874)]

### Version 1.38.0 - 01 July 2025
- Automated release of [eeacms/ied-backend:6.0.15-26](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`bc4a8557`](https://github.com/eea/helm-charts/commit/bc4a8557043f1c32aeec27d0b0f61495d3a22dff)]

### Version 1.37.0 - 30 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-25](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`ee7b341a`](https://github.com/eea/helm-charts/commit/ee7b341ae5a942504ae370d595dfac3a1387fb3c)]

### Version 1.36.0 - 29 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-24](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`86911743`](https://github.com/eea/helm-charts/commit/869117434e30fbf6f6d438f3a1f926c7810b5b5f)]

### Version 1.35.0 - 28 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-23](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`acd4dd41`](https://github.com/eea/helm-charts/commit/acd4dd412d1ac72c9993c4e6a5017fe55586e671)]

### Version 1.34.0 - 27 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-22](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`9888df0f`](https://github.com/eea/helm-charts/commit/9888df0f01856f5f55bc030a6a415d751cbab6b5)]

### Version 1.33.0 - 20 June 2025
- Automated release of [eeacms/ied-backend:6.0.23](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`88d98e7b`](https://github.com/eea/helm-charts/commit/88d98e7b04b2b0f4e8354ec67ca8b3801d3cfb3e)]

### Version 1.32.0 - 19 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-21](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`e10df46b`](https://github.com/eea/helm-charts/commit/e10df46bcaa7789025d4e2cd98a27ea607906e28)]

### Version 1.31.0 - 18 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-20](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`66ba8898`](https://github.com/eea/helm-charts/commit/66ba8898f23d705b7ab2b527bc7ced8c518ec760)]

### Version 1.30.0 - 17 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-19](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`ffdb4c0c`](https://github.com/eea/helm-charts/commit/ffdb4c0c70dfc708bf723d72ad5309ef4a1bf192)]

### Version 1.29.0 - 17 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-18](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`953de5f4`](https://github.com/eea/helm-charts/commit/953de5f496556e7acff601fe687657bdb1dd8b13)]

### Version 1.28.0 - 16 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-17](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`53590ef2`](https://github.com/eea/helm-charts/commit/53590ef2dbe547eb2e50166f610f04727c77edfe)]

### Version 1.27.0 - 15 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-16](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`d17c6b8`](https://github.com/eea/helm-charts/commit/d17c6b84f8029eb21988703bde6085feb7c5f085)]

### Version 1.26.0 - 14 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-15](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`5717bca`](https://github.com/eea/helm-charts/commit/5717bca97e28375fbbaa465769132ece34555a8a)]

### Version 1.25.0 - 13 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-14](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`fc1e39a`](https://github.com/eea/helm-charts/commit/fc1e39a555ac9358cbdc59f2e3ff4539ba91257f)]

### Version 1.24.0 - 12 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-13](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`afed85c`](https://github.com/eea/helm-charts/commit/afed85ccb5ca37aa3ff0004d1f129073877f010e)]

### Version 1.23.0 - 11 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-12](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`cf55cf7`](https://github.com/eea/helm-charts/commit/cf55cf7aad111b027182fb196dfb77d4e6f2a735)]

### Version 1.22.0 - 11 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-11](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`547bf2c`](https://github.com/eea/helm-charts/commit/547bf2c8241bbccd3716928cef422e33a44cfa34)]

### Version 1.21.0 - 11 June 2025
- Automated release of [eeacms/ied-backend:6.0.22](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`d3f11db`](https://github.com/eea/helm-charts/commit/d3f11dbf997a5f39723d9866042730041a379194)]

### Version 1.20.0 - 11 June 2025
- Automated release of [eeacms/ied-backend:6.0.21](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`83de153`](https://github.com/eea/helm-charts/commit/83de153f3a5788d5c78fb616a98e93baa584a945)]

### Version 1.19.0 - 10 June 2025
- Automated release of [eeacms/ied-backend:6.0.20](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`0352798`](https://github.com/eea/helm-charts/commit/0352798c23aed43b92a0115327419dfa4ab54d58)]

### Version 1.18.0 - 10 June 2025
- Automated release of [eeacms/ied-backend:6.0.19](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`23b0840`](https://github.com/eea/helm-charts/commit/23b08403df53c44e50a52ad891c645544e84fcf0)]

### Version 1.17.0 - 10 June 2025
- Automated release of [eeacms/ied-backend:6.0.18](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`1fcaa23`](https://github.com/eea/helm-charts/commit/1fcaa235e06f6e9cc96233528adc4fdfa609734a)]

### Version 1.16.0 - 03 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-10](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`c91af2b`](https://github.com/eea/helm-charts/commit/c91af2ba3f040b9bf55f24d0563288ed4377e77b)]

### Version 1.15.0 - 03 June 2025
- Automated release of [eeacms/ied-backend:6.0.15-9](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`62134fa`](https://github.com/eea/helm-charts/commit/62134fa535d183603b18fda7cb4c20099c08a4ff)]

### Version 1.14.0 - 02 June 2025
- Automated release of [eeacms/ied-backend:6.0.16](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`6682ea3`](https://github.com/eea/helm-charts/commit/6682ea3c59ec8be7b139e02aa541f18803bd2ca5)]

### Version 1.13.0 - 28 May 2025
- Automated release of [eeacms/ied-backend:6.0.15-8](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`39bb92c`](https://github.com/eea/helm-charts/commit/39bb92cb37263b5dd8f8e9844100d4538518b999)]

### Version 1.12.0 - 21 May 2025
- Automated release of [eeacms/ied-backend:6.0.15-7](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`e3e335d`](https://github.com/eea/helm-charts/commit/e3e335d90057674d677fd16c6734ccb1c48fc160)]

### Version 1.11.1 - 21 May 2025
- Automated release of [eeacms/plone-varnish:7.7-1.0](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`0e8e60e`](https://github.com/eea/helm-charts/commit/0e8e60e2354fb9d30cec0dec30007756ef3d1e19)]

### Version 1.11.0 - 30 April 2025
- Automated release of [eeacms/ied-backend:6.0.15-6](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`b204f5b`](https://github.com/eea/helm-charts/commit/b204f5b87e48e6d41ad73b455893abe0139f71d2)]

### Version 1.10.0 - 28 April 2025
- Automated release of [eeacms/ied-backend:6.0.15-5](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`75b7804`](https://github.com/eea/helm-charts/commit/75b78040a9e1b8048be55f97da70a525b90becc5)]

### Version 1.9.0 - 25 April 2025
- Automated release of [eeacms/ied-backend:6.0.15-4](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`6265e9d`](https://github.com/eea/helm-charts/commit/6265e9d16c0f5039c276ef4781b2c92e47714d64)]

### Version 1.8.0 - 13 April 2025
- Automated release of [eeacms/ied-backend:6.0.15-3](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`4049129`](https://github.com/eea/helm-charts/commit/4049129de5ea19a0c4b97ac561c841180840cb71)]

### Version 1.7.0 - 11 April 2025
- Automated release of [eeacms/ied-backend:6.0.15-2](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`9c684f1`](https://github.com/eea/helm-charts/commit/9c684f1bc9b5ab2960b6537fb1920f091842e515)]

### Version 1.6.0 - 09 April 2025
- Automated release of [eeacms/ied-backend:6.0.15-1](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`6467be9`](https://github.com/eea/helm-charts/commit/6467be9f1c010cec2b3e45ae9bf3e74e25ca2cc1)]

### Version 1.5.0 - 09 April 2025
- Automated release of [eeacms/ied-backend:6.0.14-1](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`d9e5538`](https://github.com/eea/helm-charts/commit/d9e5538562ec478d1f834e36da74864786175549)]

### Version 1.4.2 - 08 April 2025
- Fix google rewrite, remove microsoft login unused path [valentinab25 - [`420203f`](https://github.com/eea/helm-charts/commit/420203f066a45b39b9b09a4ce3c7088513fd1274)]

### Version 1.4.1 - 08 April 2025
- Add plone.site variable, rewrite path rewrite for api [valentinab25 - [`a650413`](https://github.com/eea/helm-charts/commit/a6504138608dc802014553d150e0d7d45eede6ff)]

### Version 1.4.0 - 02 April 2025
- Allow empty certificate for default one, add tls variable [valentinab25 - [`4495a4c`](https://github.com/eea/helm-charts/commit/4495a4c12ec5772f7dc45a1d1ed3b421f57e5441)]

### Version 1.3.0 - 02 April 2025
- Automated release of [eeacms/ied-backend:6.0.13-2](https://github.com/eea/ied-backend/releases) [EEA Jenkins - [`1d7ec30`](https://github.com/eea/helm-charts/commit/1d7ec30dbeefe9f358f2e99d8f7d73c983966cb8)]

### Version 1.2.0 - 13 March 2025
- Automated release of [eeacms/ied-backend:6.0.13-1](https://github.com/eea/ied-backend/releases)

### Version 1.1.0 - 12 March 2025
- Automated release of [eeacms/ied-backend:1.0.1](https://github.com/eea/ied-backend/releases)

### Version 1.0.1 - 12 March 2025
- Automated release of [eeacms/plone-varnish:7.6-1.0](https://github.com/eea/plone-varnish/releases)

### Version 1.0.0

- Initial release.
