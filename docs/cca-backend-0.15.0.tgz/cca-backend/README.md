# CCA Backend

Helm chart for the Climate-ADAPT backend stack.

The chart follows the conventions already used in this repository for Plone
backends and adds the CCA-specific supporting services from the Rancher stack:
`plone-translate`, `redis`, `async`, `converter`, `zodbpack`
and the broken-links cron job.

Sensitive values are intentionally left empty in `values.yaml`.
## Releases

### Version 0.15.0 - 12 November 2026
- Automated release of [eeacms/eea.docker.plone-climateadapt:v11.0.93-plone6.1](https://github.com/eea/eea.docker.plone-climateadapt/releases) [EEA Jenkins - [`bfdcb8933`](https://github.com/eea/helm-charts/commit/bfdcb89337abac9724962828fcbc8508acd1edbb)]

### Version 0.14.1 - 12 November 2026
- v11.0.92-plone6.1 [GhitaB - [`13bd14387`](https://github.com/eea/helm-charts/commit/13bd14387a8753ca2a96a7c28fb1969b94d264d4)]

### Version 0.14.0 - 11 November 2026
- Automated release of [eeacms/eea.docker.plone-climateadapt:v11.0.91-plone6.1](https://github.com/eea/eea.docker.plone-climateadapt/releases) [EEA Jenkins - [`a08817e94`](https://github.com/eea/helm-charts/commit/a08817e94482876514822b9ec7e9ba1bb695c25b)]

### Version 0.13.1 - 11 noiembrie 2026
- Re-release of the v11.0.90-plone6.1 chart package (0.13.0 was committed but GitHub Pages had not published it); document that image.tag defaults to Chart.AppVersion [Tiberiu Ichim - [`af38f067c`](https://github.com/eea/helm-charts/commit/af38f067cdd3c5e269d0e143bcf1e3d8f138bf6e)]

### Version 0.13.0 - 11 November 2026
- Automated release of [eeacms/eea.docker.plone-climateadapt:v11.0.90-plone6.1](https://github.com/eea/eea.docker.plone-climateadapt/releases) [EEA Jenkins - [`94425d0de`](https://github.com/eea/helm-charts/commit/94425d0de811d54e76e441aa972720121b2ac428)]

### Version 0.12.13 - 10 November 2026
- v11.0.89-plone6.1 [GhitaB - [`18003adab`](https://github.com/eea/helm-charts/commit/18003adabce5137ff9417888d5a03efdd9dfed73)]

### Version 0.12.12 - 9 November 2026
- plone v11.0.88-plone6.1: verify translation registration before reporting a save successful (eea.climateadapt 7.1, PR #359) [Tiberiu Ichim - [`ac0f186f2`](https://github.com/eea/helm-charts/commit/ac0f186f20fab88aa26fb931bc6ff2c1efdc1899)]

### Version 0.12.11 - 9 November 2026
- async v1.2.2: fix stale-job age units (1000x) and stop caching unregistered translations [Tiberiu Ichim - [`755051da7`](https://github.com/eea/helm-charts/commit/755051da7669888e82e1a2a4e6c680cf0b2d592c)]

### Version 0.12.10 - 6 November 2026
- v11.0.87-plone6.1 [Tiberiu Ichim - [`b8b4278de`](https://github.com/eea/helm-charts/commit/b8b4278dede7524fbf658fdc4bf9a12c884da734)]

### Version 0.12.9 - 6 November 2026
- Block portal_modifier at the edge; commit ETL_MAX_INFLIGHT=4 and the ETL_CORR_TTL_SEC / ETL_STALE_JOB_MAX_AGE_MS async values [Tiberiu Ichim - [`dc8c2eb5a`](https://github.com/eea/helm-charts/commit/dc8c2eb5ae030601eb2f63accd4b229630abc70a)]

### Version 0.12.8 - 05 November 2026
- v11.0.86-plone6.1 [GhitaB - [`c62015916`](https://github.com/eea/helm-charts/commit/c620159163510a224b436a62dde266a034d9de15)]

### Version 0.12.7 - 2 November 2026
- Backend v11.0.85-plone6.1 - skip TranslateAsync content rule on the job executor [Tiberiu Ichim - [`46281383b`](https://github.com/eea/helm-charts/commit/46281383bd75affc33fde9c1352e6331d9e70544)]

### Version 0.12.6 - 02 noiembrie 2026
- Fix translate on change env value [Tiberiu Ichim - [`5bad456d6`](https://github.com/eea/helm-charts/commit/5bad456d68f28b0d0d265226a1bc4ddef6f6d81d)]

### Version 0.12.5 - 30 October 2026
- v11.0.84-plone6.1 [GhitaB - [`bc96b695f`](https://github.com/eea/helm-charts/commit/bc96b695f4e39fb908de700f5744008fa3aa03f5)]

### Version 0.12.4 - 27 October 2026
- Upgrade converter to v1.0.8 - fix teaser itemModel 500 [Tiberiu Ichim - [`1fe1e4ac9`](https://github.com/eea/helm-charts/commit/1fe1e4ac97fe43ba7f6decb1121421a6e337fe13)]

### Version 0.12.3 - 27 octombrie 2026
- Tweak translation values and upgrade [Tiberiu Ichim - [`21c090682`](https://github.com/eea/helm-charts/commit/21c09068228a5a4b2b8b4e5c9ff0deadc4fea11e)]

### Version 0.12.2 - 26 octombrie 2026
- fix etranslation delay disable [Tiberiu Ichim - [`9bce0586f`](https://github.com/eea/helm-charts/commit/9bce0586f07032ecbd7b18dc0066dc9875ddbdf7)]

### Version 0.12.1 - 26 October 2026
- v11.0.83-plone6.1 [GhitaB - [`5e5da9f31`](https://github.com/eea/helm-charts/commit/5e5da9f318a133df9c3ef50d3b15d2b68210f460)]

### Version 0.12.0 - 26 octombrie 2026
- Separate configuration for translation stuff [Tiberiu Ichim - [`2a0017f8f`](https://github.com/eea/helm-charts/commit/2a0017f8fdfdfa99373a015b46648d42ad507841)]

### Version 0.11.0 - 23 octombrie 2026
- Update climateadapt-translate-async [Tiberiu Ichim - [`fa290f389`](https://github.com/eea/helm-charts/commit/fa290f38921fdc97fcbbed8aa3d50d8bb2b2ec0a)]

### Version 0.10.11 - 23 octombrie 2026
- v11.0.82-plone6.1 — eTranslation quota work on the Plone side: `@@call-etranslation`
  accepts a comma separated `target_lang` plus an optional `ext_ref` (short
  correlation id, avoids the 200-char `externalReference` limit), `@@translate-callback`
  forwards `targetLanguage`, malformed language codes are dropped instead of
  failing the whole request, and `@@translate-failure` receives eTranslation's
  failure notifications.
- v1.2.0 async: quota-aware eTranslation submissions — bundles the 26 target
  languages into one request, gates concurrent submissions under the service's
  50-active quota, and acts on eTranslation failure notifications. Needs
  `etranslation_submit` in `BULL_QUEUE_NAMES_CSV` and `submit_group` plus
  `translation_failed` in `ENABLED_JOBS`. `ETL_GROUPING_ENABLED` stays false
  until the new backend image is rolled out.

### Version 0.10.10 - 20 octombrie 2026
- Add script to fix mission images [Tiberiu Ichim - [`b5b9396d5`](https://github.com/eea/helm-charts/commit/b5b9396d5589a36bed4fa0ae3f755e8bdaab3e27)]

### Version 0.10.9 - 15 October 2026
- v11.0.80-plone6.1 [GhitaB - [`007660a6`](https://github.com/eea/helm-charts/commit/007660a63eced9d04225ae06f0fb7ffdc73e2423)]

### Version 0.10.8 - 14 October 2026
- v11.0.79-plone6.1 [GhitaB - [`4ff6652d`](https://github.com/eea/helm-charts/commit/4ff6652dec40335442cd28593de4523ce03ae0a8)]

### Version 0.10.7 - 08 October 2026
- v11.0.78-plone6.1 [GhitaB - [`d8fd2a17`](https://github.com/eea/helm-charts/commit/d8fd2a1762e47814b47211ca2cb063f19af74f63)]

### Version 0.10.6 - 07 October 2026
- v11.0.77-plone6.1 [GhitaB - [`aedc73aa`](https://github.com/eea/helm-charts/commit/aedc73aab2f92f2ce394d7c049cc6cee885be0c8)]

### Version 0.10.5 - 07 October 2026
- v11.0.76-plone6.1 [GhitaB - [`132ee5a4`](https://github.com/eea/helm-charts/commit/132ee5a45aae3066acd5c888216dec1bd31997bf)]

### Version 0.10.4 - 05 October 2026
- v11.0.74-plone6.1 [GhitaB - [`505e0926`](https://github.com/eea/helm-charts/commit/505e0926fc40c758ba23258160d50d5665b38b58)]

### Version 0.10.3 - 05 October 2026
- v11.0.73-plone6.1 [GhitaB - [`19720551`](https://github.com/eea/helm-charts/commit/197205519d9dcf4f838f1bef9975b2e8c6fea5b1)]

### Version 0.10.2 - 02 October 2026
- v11.0.71-plone6.1 [GhitaB - [`539e591c`](https://github.com/eea/helm-charts/commit/539e591ce6dacac29ea43825a9ed443887ba19ce)]

### Version 0.10.1 - 29 septembrie 2026
- Fix frontend reference [Tiberiu Ichim - [`eee9bd8f`](https://github.com/eea/helm-charts/commit/eee9bd8fda301393d82904573f09ac11ef0e7a4e)]

### Version 0.10.0 - 29 septembrie 2026
- Link to frontend for images/download paths [Tiberiu Ichim - [`0da16d43`](https://github.com/eea/helm-charts/commit/0da16d43112e63a58953b5b48d0b4ec6eb87953b)]

### Version 0.9.35 - 28 September 2026
- Use eeacms/plone-varnish 7.7-1.2 [GhitaB - [`63fcc56e`](https://github.com/eea/helm-charts/commit/63fcc56e7a1d66bfc27d0c096c067aeebade9915)]

### Version 0.9.33 - 17 septembrie 2026
- upgrade [Tiberiu Ichim - [`e7226754`](https://github.com/eea/helm-charts/commit/e72267544981b1ce516d8dbb3af247ac106a1f9d)]

### Version 0.9.32 - 14 September 2026
- v11.0.69-plone6.1 [GhitaB - [`18040a11`](https://github.com/eea/helm-charts/commit/18040a110c074182fd260ffb5e3ffd78d26a407c)]

### Version 0.9.31 - 10 September 2026
- v11.0.68-plone6.1 [GhitaB - [`16d5ef2e`](https://github.com/eea/helm-charts/commit/16d5ef2e4e2a87406eb0f6d53e29183587728835)]

### Version 0.9.30 - 10 September 2026
- v11.0.67-plone6.1 [GhitaB - [`dc9a4634`](https://github.com/eea/helm-charts/commit/dc9a4634e91b43d267dc816859cb620a23dcb7ec)]

### Version 0.9.29 - 09 September 2026
- v1.1.3 async [GhitaB - [`a25989ff`](https://github.com/eea/helm-charts/commit/a25989ff97bb31899d4c8734342be85d443193db)]

### Version 0.9.28 - 08 September 2026
- v11.0.66-plone6.1 [GhitaB - [`6743ceb6`](https://github.com/eea/helm-charts/commit/6743ceb69b2d12015b8ffe2263368d8904b046ea)]

### Version 0.9.27 - 07 September 2026
- v11.0.65-plone6.1 [GhitaB - [`30a980e1`](https://github.com/eea/helm-charts/commit/30a980e13898e204b6b12138daa399a894da5a2c)]

### Version 0.9.26 - 07 September 2026
- v11.0.64-plone6.1 [GhitaB - [`488886f1`](https://github.com/eea/helm-charts/commit/488886f15c48ecb47ca1fffde6405c930922b49f)]

### Version 0.9.25 - 04 September 2026
- v11.0.63-plone6.1 [GhitaB - [`688564c3`](https://github.com/eea/helm-charts/commit/688564c3df80870c36b2b8e2aa8cee049c278d4f)]

### Version 0.9.24 - 03 September 2026
- v11.0.62-plone6.1 [GhitaB - [`74d4ba89`](https://github.com/eea/helm-charts/commit/74d4ba893b213e6975642db2dcff6466acf72912)]

### Version 0.9.23 - 03 September 2026
- v11.0.61-plone6.1 [GhitaB - [`b4218814`](https://github.com/eea/helm-charts/commit/b42188147938acbd6dfd381c78798a39c4384c9f)]

### Version 0.9.22 - 03 September 2026
- v11.0.60-plone6.1 [GhitaB - [`cdbe93c9`](https://github.com/eea/helm-charts/commit/cdbe93c933f237a65b698381f0dc643fa10def3b)]

### Version 0.9.21 - 01 September 2026
- v11.0.59-plone6.1 [GhitaB - [`5a61f93a`](https://github.com/eea/helm-charts/commit/5a61f93a2438794abc0c72b5ee9391fd15bdaa79)]

### Version 0.9.20 - 01 September 2026
- v11.0.58-plone6.1 [GhitaB - [`f51a602c`](https://github.com/eea/helm-charts/commit/f51a602c13caf733d0ea3ab58f6bb27a59bd31f1)]

### Version 0.9.19 - 01 September 2026
- v11.0.57-plone6.1 [GhitaB - [`e679d802`](https://github.com/eea/helm-charts/commit/e679d802af79638dffe882279f799ad6f72d548b)]

### Version 0.9.18 - 31 August 2026
- v11.0.56-plone6.1 [GhitaB - [`efb6878a`](https://github.com/eea/helm-charts/commit/efb6878af1d6a9d3d21bd0fe9b8e910af39bbfce)]

### Version 0.9.17 - 28 August 2026
- v11.0.55-plone6.1 [GhitaB - [`6b348e7b`](https://github.com/eea/helm-charts/commit/6b348e7b9b7d83d89781e11ccb61e99b5eb72af2)]

### Version 0.9.16 - 27 August 2026
- v11.0.54-plone6.1 [GhitaB - [`6da3156c`](https://github.com/eea/helm-charts/commit/6da3156ccadf8d7d8240027c1d8ed201ffb95ab0)]

### Version 0.9.15 - 27 August 2026
- v11.0.53-plone6.1 [GhitaB - [`3fdee296`](https://github.com/eea/helm-charts/commit/3fdee296f8776f16bdb53a574fd3a27725432163)]

### Version 0.9.14 - 24 August 2026
- v11.0.52-plone6.1 [GhitaB - [`1e8c1273`](https://github.com/eea/helm-charts/commit/1e8c12732d15f0bc01259a202e2c928489480c36)]

### Version 0.9.13 - 24 August 2026
- v11.0.51-plone6.1 [GhitaB - [`5527ac00`](https://github.com/eea/helm-charts/commit/5527ac007d19687e3cca4bf06d370bb6036154d3)]

### Version 0.9.11 - 20 August 2026
- v11.0.49-plone6.1 [GhitaB - [`7dc5212b`](https://github.com/eea/helm-charts/commit/7dc5212b7547585d5c06c23f5a196acaedffdf15)]

### Version 0.9.8 - 19 August 2026
- v11.0.46-plone6.1 [GhitaB - [`60088158`](https://github.com/eea/helm-charts/commit/6008815840ca0f676cacd9c7bc0637ca514887cc)]

### Version 0.9.6 - 18 August 2026
- v11.0.44-plone6.1 [GhitaB - [`691708f1`](https://github.com/eea/helm-charts/commit/691708f1e38996ad7c1a4ada07c3a2d6777de6d2)]

### Version 0.9.5 - 18 August 2026
- v11.0.43-plone6.1 [GhitaB - [`17b4753a`](https://github.com/eea/helm-charts/commit/17b4753a431e9ab695acc39e22bbd538416f8f14)]

### Version 0.9.4 - 17 August 2026
- v11.0.42-plone6.1 [GhitaB - [`11ff16ac`](https://github.com/eea/helm-charts/commit/11ff16ac322d518058d244e403b6b6131ac230f9)]

### Version 0.9.0 - 10 August 2026
- Automated release of [eeacms/eea.docker.plone-climateadapt:v11.0.34-plone6.1](https://github.com/eea/eea.docker.plone-climateadapt/releases) [EEA Jenkins - [`193d46d0`](https://github.com/eea/helm-charts/commit/193d46d0a4ebc10a9e9b4361154a1e6dbbb9324c)]

### Version 0.8.0 - 06 August 2026
- Automated release of [eeacms/eea.docker.plone-climateadapt:v11.0.33-plone6.1](https://github.com/eea/eea.docker.plone-climateadapt/releases) [EEA Jenkins - [`a116406c`](https://github.com/eea/helm-charts/commit/a116406c264633ca78a680a26110fd5504ff7333)]

### Version 0.7.0 - 04 August 2026
- Automated release of [eeacms/eea.docker.plone-climateadapt:v11.0.32-plone6.1](https://github.com/eea/eea.docker.plone-climateadapt/releases) [EEA Jenkins - [`c9dc5aaa`](https://github.com/eea/helm-charts/commit/c9dc5aaa45ea2c5725126cd8852756de2b5e0e9a)]

### Version 0.6.15 - 28 July 2026
- in cca-backend: 0.6.15 [GhitaB - [`6b1cd375`](https://github.com/eea/helm-charts/commit/6b1cd375d0e71a0a4862a7707e5ef82b3c5d76ae)]

### Version 0.6.12 - 22 iulie 2026
- Upgrade to v11.0.27 backend [Tiberiu Ichim - [`1cea07df`](https://github.com/eea/helm-charts/commit/1cea07dffe273b526e5f80da1ca92561df675fa2)]

### Version 0.6.8 - 20 iulie 2026
- Upgrade to v11.0.24-plone6.1 [Tiberiu Ichim - [`bd720643`](https://github.com/eea/helm-charts/commit/bd720643ab421cd280d8c2c9a41fc22d057eb755)]

### Version 0.6.4 - 19 June 2026
- appVersion to v11.0.17-plone6.1 [Tiberiu Ichim - [`2ccc2748`](https://github.com/eea/helm-charts/commit/2ccc27488dcc7562198e4cd02e878aa852b38721)]

### Version 0.6.3 - 16 June 2026
- v11.0.16-plone6.1 [Tiberiu Ichim - [`fad3b608`](https://github.com/eea/helm-charts/commit/fad3b6083a8505338feb8eeb5131dc32ffc3db74)]

### Version 0.6.2 - 12 June 2026
- upgrade to v11.0.15-plone6.1 [Tiberiu Ichim - [`1364e9e4`](https://github.com/eea/helm-charts/commit/1364e9e47bc6e8f9095edf24ce8d71f6b219249d)]

### Version 0.6.1 - 11 June 2026
- Upgrade to v11.0.13-plone6.1 [Tiberiu Ichim - [`fd6c36e7`](https://github.com/eea/helm-charts/commit/fd6c36e7f236ce6ae649bd7b06453ea798270412)]

### Version 0.6.0 - 10 June 2026
- Upgrade to backend v11.0.11-plone6.1 [Tiberiu Ichim - [`f22b0899`](https://github.com/eea/helm-charts/commit/f22b0899bf76a0ca06d82fedeb0a7b920e38173c)]

### Version 0.5.0 - 09 June 2026
- upgrade to v11.0.10-plone6.1 [Tiberiu Ichim - [`d2ef248f`](https://github.com/eea/helm-charts/commit/d2ef248f6bad5c5561c723c10d8d40f4309edcad)]

### Version 0.4.1 - 04 June 2026
- add convertor [Dobricean Ioan Dorian - [`d45d633e`](https://github.com/eea/helm-charts/commit/d45d633ed9f743f99cdb00dab9db4d2bc80edaee)]

### Version 0.4.0 - 25 May 2026
- Upgrade backend [Tiberiu Ichim - [`13f3b5b4`](https://github.com/eea/helm-charts/commit/13f3b5b4926a53e1fbd28df05af0fe7b50fca20e)]

### Version 0.3.0 - 25 May 2026
- Sync for Rancher 2 deployment [Tiberiu Ichim - [`00b99718`](https://github.com/eea/helm-charts/commit/00b9971822628992b1dc099186bbf7d1e8b2a112)]

### Version 0.2.30 - 14 May 2026
- add missing vars [Dobricean Ioan Dorian - [`d9debafa`](https://github.com/eea/helm-charts/commit/d9debafaa4be711863a1e96a909a47441ca85642)]

### Version 0.2.29 - 28 April 2026
- update image and ingresses [Dobricean Ioan Dorian - [`53687a01`](https://github.com/eea/helm-charts/commit/53687a0188f0dcb85da13dd3e85c33ef96d9fe67)]

### Version 0.2.28 - 23 April 2026
- move to offical eea image [Dobricean Ioan Dorian - [`b8102bd7`](https://github.com/eea/helm-charts/commit/b8102bd7bb7391c7ee0a2ef3b2f3e99075d45a29)]

### Version 0.2.26 - 09 April 2026
- change zodbpack iamge [Dobricean Ioan Dorian - [`0399bb3c`](https://github.com/eea/helm-charts/commit/0399bb3c5c8b608aae24787f630d2db93ed7e210)]

### Version 0.2.25 - 09 April 2026
- make zodbpack inherit the main backend image by default

### Version 0.2.24 - 09 April 2026
- relax plone [Dobricean Ioan Dorian - [`5b0ee8b9`](https://github.com/eea/helm-charts/commit/5b0ee8b92c5d151cd7ce8effb764007a9dff07b2)]

### Version 0.2.23 - 09 April 2026
- relax plone health probes to avoid restarts during long broken-links scans

### Version 0.2.22 - 08 April 2026
- change docker image to test the latest changes [Dobricean Ioan Dorian - [`6b847b70`](https://github.com/eea/helm-charts/commit/6b847b70abe9aa9a7f2d3b85dda8925e256bc8c9)]

### Version 0.2.21 - 02 April 2026
- remove dependency on pv [Dobricean Ioan Dorian - [`8596ea09`](https://github.com/eea/helm-charts/commit/8596ea091aaa4d8b144b5fe3f7a9e53532013745)]

### Version 0.2.20 - 02 April 2026
- change app version [Dobricean Ioan Dorian - [`e13c6e0e`](https://github.com/eea/helm-charts/commit/e13c6e0ec5432d762ea3291e0d32e5d7a473db2a)]

### Version 0.2.19 - 02 April 2026
- remove hardcoded image [Dobricean Ioan Dorian - [`daefb85e`](https://github.com/eea/helm-charts/commit/daefb85e6cf9a3e06f8eedf46439a72d9f4b9127)]

### Version 0.2.18 - 02 April 2026
- fix entrasync and zodbpack [Dobricean Ioan Dorian - [`0ca45b93`](https://github.com/eea/helm-charts/commit/0ca45b93d67426ee0cb91e9039295f9df7c77632)]

### Version 0.2.17 - 02 April 2026
- Fix zodbpack [Dobricean Ioan Dorian - [`3d670d7c`](https://github.com/eea/helm-charts/commit/3d670d7cc7a827a19cdd8ffa56b2ea40460e4537)]

### Version 0.2.16 - 02 April 2026
- fix zodbpack [Dobricean Ioan Dorian - [`57511646`](https://github.com/eea/helm-charts/commit/57511646d01c8617cc37516eeec1be9d3027c0ba)]

### Version 0.2.15 - 02 April 2026
- add entrasync corn job [Dobricean Ioan Dorian - [`e7b207ad`](https://github.com/eea/helm-charts/commit/e7b207ada67d1d133de738f1463b12d8b79c8901)]

### Version 0.2.14 - 02 April 2026
- remove /admin [Dobricean Ioan Dorian - [`2b135d01`](https://github.com/eea/helm-charts/commit/2b135d0138f37c39e8bf9cd00aa73591af91e19f)]

### Version 0.2.13 - 02 April 2026
- add debug instance [Dobricean Ioan Dorian - [`d1226659`](https://github.com/eea/helm-charts/commit/d1226659f492213080bcfce32c6fadf30c0ce9bb)]

### Version 0.2.12 - 26 March 2026
- memory [Dobricean Ioan Dorian - [`b61a123c`](https://github.com/eea/helm-charts/commit/b61a123c52578b501404fff6100466592c63e346)]

### Version 0.2.10 - 25 March 2026
- align service with other backens [Dobricean Ioan Dorian - [`f4bd16fe`](https://github.com/eea/helm-charts/commit/f4bd16fe562264ef5c8635da583369653efbdfba)]

### Version 0.2.9 - 25 March 2026
- fix ingress [Dobricean Ioan Dorian - [`203532de`](https://github.com/eea/helm-charts/commit/203532de9c134331137e4d170d1ed60c2605f8c6)]

### Version 0.2.8 - 25 March 2026
- ingress [Dobricean Ioan Dorian - [`c31fab65`](https://github.com/eea/helm-charts/commit/c31fab6576b8db5bab270766a6ee9f13b1923b7d)]

### Version 0.2.7 - 25 March 2026
- fix ingresses [Dobricean Ioan Dorian - [`15f96814`](https://github.com/eea/helm-charts/commit/15f9681417ca5af45c4229a9667462f1bc708a36)]

### Version 0.2.6 - 13 March 2026
- remove memcache [Dobricean Ioan Dorian - [`d810cf06`](https://github.com/eea/helm-charts/commit/d810cf06b6ad32c0bb3ebb6978b6a248793a2f4f)]

### Version 0.2.4 - 13 March 2026
- align to deafult plone ingress [Dobricean Ioan Dorian - [`96ec0111`](https://github.com/eea/helm-charts/commit/96ec0111414ef54c7630cec54a39a71b6e347fc3)]

### Version 0.2.2 - 13 March 2026
- change questions [Dobricean Ioan Dorian - [`d02e405a`](https://github.com/eea/helm-charts/commit/d02e405af2aebb1f6dee9cae7e2f6e172615db11)]
