# EEA-QUERY-INTENT

Multilingual query-intent classifier for the EEA website. Decides which search queries are genuine questions, exploratory requests, or factual claims that warrant an AI-generated answer, and which are plain keyword searches.

Based on [eea-query-intent](https://github.com/eea/eea-query-intent)

Using [eeacms/eea-query-intent](https://hub.docker.com/repository/docker/eeacms/eea-query-intent/tags) docker image

## Releases

### Version 0.0.13 - 29 October 2026
- Fix default securityEnabled [valentinab25 - [`1ec70b194`](https://github.com/eea/helm-charts/commit/1ec70b1947b52e3cc8dfb009cf5039bc4b793be0)]

### Version 0.0.12 - 07 October 2026
- fix questions [valentinab25 - [`a9fa4763`](https://github.com/eea/helm-charts/commit/a9fa4763f314d42be76db494e1b5e024c218c33e)]

### Version 0.0.11 - 06 October 2026
- add environment vars [valentinab25 - [`1aa229c4`](https://github.com/eea/helm-charts/commit/1aa229c4585b2fbc4db3279f7fc20a5354ab99e9)]

### Version 0.0.10 - 29 September 2026
- add readiness [valentinab25 - [`a08252d0`](https://github.com/eea/helm-charts/commit/a08252d0d862c06ae3d395e89e7223048bc18c2a)]

### Version 0.0.9 - 29 September 2026
- fix indent [valentinab25 - [`4d4ba6fa`](https://github.com/eea/helm-charts/commit/4d4ba6fa474d07a4fc57e9fa5699084dce87e9f0)]

### Version 0.0.8 - 29 September 2026
- fix letsencrypt [valentinab25 - [`611279c1`](https://github.com/eea/helm-charts/commit/611279c1dffe421e5078cac98d27c108a31df46c)]

### Version 0.0.7 - 29 September 2026
- fix name [valentinab25 - [`88999040`](https://github.com/eea/helm-charts/commit/88999040618bb0a4ccb8e96f7eb0eca7030d574e)]

### Version 0.0.6 - 29 September 2026
- add healthchecks [valentinab25 - [`0b2ca75f`](https://github.com/eea/helm-charts/commit/0b2ca75f1d56571057e2dae33b58623196c237f8)]

### Version 0.0.5 - 29 September 2026
- other small values fixed [valentinab25 - [`f93e4d4d`](https://github.com/eea/helm-charts/commit/f93e4d4d73c9b2930c21e08b9f8b3312a3161593)]

### Version 0.0.4 - 29 September 2026
- fix default values [valentinab25 - [`36830c50`](https://github.com/eea/helm-charts/commit/36830c50aff7c90f75c45713166e84ac1645ecdd)]

### Version 0.0.3 - 29 September 2026
- fix readme [valentinab25 - [`b8387d17`](https://github.com/eea/helm-charts/commit/b8387d17b62f423d38979221ea689b9307e58ea5)]

### Version 0.0.2 - 29 September 2026
- First release [valentinab25 - [`d147195a`](https://github.com/eea/helm-charts/commit/d147195a813c95e2e8a7507004a98383b4ce3fc8)]

