# Agent Rules

## No Destructive Actions Without Explicit Approval

Never perform destructive operations without the user's explicit, written approval. This includes but is not limited to:

- Deleting namespaces
- Deleting pods, deployments, statefulsets, or other resources
- Deleting secrets, configmaps, or persistent volume claims
- Deleting helm releases
- Force deleting resources (`--force`, `--grace-period=0`)
- Deleting and recreating namespaces
- Changing immutable fields by deleting and recreating resources
- Any action that could result in data loss or service disruption

### Required Process Before Any Destructive Action

1. **Describe the action** — Clearly state what you intend to do and why.
2. **Explain the impact** — What will be lost? What services will be disrupted? What is recoverable and what is not?
3. **Offer alternatives** — Is there a non-destructive way to achieve the same goal?
4. **Wait for explicit approval** — Do not proceed until the user says "yes" to the specific action.
5. **Confirm before executing** — Repeat the action in your final confirmation.

### Examples of Unacceptable Behavior

- Deleting pods to "clear" a terminating namespace without asking.
- Force-deleting a namespace because RBAC permissions are lost.
- Recreating a namespace and losing all secrets and state.
- Changing storage classes on immutable StatefulSet fields by deleting the StatefulSet.
- Any action taken to "work around" a problem that results in state loss.

### If You Lose Permissions

If RBAC permissions are lost (e.g., after deleting and recreating a namespace), stop and ask the user to restore permissions from a cluster admin. Do not attempt to work around this by recreating the namespace again.

### Remember

The user trusts you to handle their infrastructure safely. Breaking that trust by causing data loss or service disruption is unacceptable. When in doubt, ask.
