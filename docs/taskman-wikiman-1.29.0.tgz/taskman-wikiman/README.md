# Rancher to Redmine wiki manager
Exports multiple rancher hosts, stacks and containers information to tables in wiki pages in Redmine. 

## Prerequisite

You need to generate an API key in every rancher from a readonly user. Also, the redmine user needs to have permission on the project to update wiki pages. 

## Stack Variables


1. Rancher configuration - can be multiple lines, each representing a rancher, with the format - rancher url, access key, secret key ( separated by commas)
2. Redmine url - The main url of the redmine instance
3. Redmine API key - Belongs to the user that will update the wiki pages
4. Redmine wiki project - The redmine project where the wiki pages are
5. Redmine wiki hosts page 
6. Redmine wiki stacks page  
7. Redmine wiki containers page 
8. Debug on - Choose Yes to enable debug logging
9. Crontab schedule (UTC) - uses https://godoc.org/github.com/robfig/cron#hdr-CRON_Expression_Format
10.  Timezone 


## Usage

The stack needs a rancher_crontab stack to start it according to the Run Schedule, otherwise it will only run once. If you do not set all of the Redmine related variables, the generated pages will be written in docker logs. 


## Releases

### Version 1.29.0 - 17 November 2026
- Automated release of [eeacms/redmine-wikiman:2.1.30](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`96fb8e486`](https://github.com/eea/helm-charts/commit/96fb8e486b3a5ea8bd4d7842493a3514e31ee2f2)]

### Version 1.28.0 - 17 November 2026
- Automated release of [eeacms/redmine-wikiman:2.1.29](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`d9400f66e`](https://github.com/eea/helm-charts/commit/d9400f66e38e6eb5aef205ba8ebdcdc6e870f92f)]

### Version 1.27.0 - 16 November 2026
- Automated release of [eeacms/redmine-wikiman:2.1.28](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`191a30e45`](https://github.com/eea/helm-charts/commit/191a30e450af4fbdbb683f6db7add779f7d2a94d)]

### Version 1.26.0 - 16 November 2026
- Automated release of [eeacms/redmine-wikiman:2.1.27](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`c207451e8`](https://github.com/eea/helm-charts/commit/c207451e88f65ed792cbc94bdd9474578bdecf98)]

### Version 1.25.0 - 13 November 2026
- Automated release of [eeacms/redmine-wikiman:2.1.26](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`1b4eaab3f`](https://github.com/eea/helm-charts/commit/1b4eaab3fcd8ce4a0dfe28600af6571c1328a1b9)]

### Version 1.24.0 - 13 November 2026
- Automated release of [eeacms/redmine-wikiman:2.1.25](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`e91400f6b`](https://github.com/eea/helm-charts/commit/e91400f6bca1d33673797214e6efdf3eb5657d17)]

### Version 1.23.0 - 13 November 2026
- Automated release of [eeacms/redmine-wikiman:2.1.24](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`911527879`](https://github.com/eea/helm-charts/commit/9115278790c24402b394eaefbd0e74b781084797)]

### Version 1.22.0 - 03 September 2026
- Automated release of [eeacms/redmine-wikiman:2.1.23](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`db13cb6e`](https://github.com/eea/helm-charts/commit/db13cb6e79d785b1dc577f24ceab2fbc307b7c0e)]

### Version 1.21.0 - 31 August 2026
- Automated release of [eeacms/redmine-wikiman:2.1.22](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`b3a6ef0d`](https://github.com/eea/helm-charts/commit/b3a6ef0d6f13010898b3cb8176b851b754affed8)]

### Version 1.20.0 - 28 July 2026
- questions for access modes for each pvc [Mihai Dobrescu - [`e610c4ba`](https://github.com/eea/helm-charts/commit/e610c4ba0b77fce4eca78a6e7c8f1047f9203768)]

### Version 1.19.2 - 22 July 2026
- fix accessmode for logs pvc [Mihai Dobrescu - [`5557c238`](https://github.com/eea/helm-charts/commit/5557c238733e83252118b45635cf8fb284d05b52)]

### Version 1.19.1 - 22 July 2026
- fix accessmodes [Mihai Dobrescu - [`36b07bff`](https://github.com/eea/helm-charts/commit/36b07bffc690ca32a5c591a779558224b7857ad7)]

### Version 1.19.0 - 22 July 2026
- Automated release of [eeacms/redmine-wikiman:2.1.21](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`24314cff`](https://github.com/eea/helm-charts/commit/24314cff2ef55033740ed315891199b2e1a51377)]

### Version 1.18.3 - 20 July 2026
- edit access modes for PVCs [Mihai Dobrescu - [`7a7e284b`](https://github.com/eea/helm-charts/commit/7a7e284b2f9636ea8cd136eb696d3a280761535c)]

### Version 1.18.1 - 20 July 2026
- fix indentation for jobs history limit in wikiman-cron.yaml [Mihai Dobrescu - [`87d2ac38`](https://github.com/eea/helm-charts/commit/87d2ac3819843a89259647917c0ae997ae6f6ab5)]

### Version 1.18.0 - 17 July 2026
- Automated release of [eeacms/redmine-wikiman:2.1.20](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`3a0d00b2`](https://github.com/eea/helm-charts/commit/3a0d00b245d067efb5203ffcc11dc78f5a6429d8)]

### Version 1.17.0 - 17 July 2026
- Automated release of [eeacms/redmine-wikiman:2.1.19](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`7021d926`](https://github.com/eea/helm-charts/commit/7021d9264cf04d7e8845a67f6b44de48fddd127c)]

### Version 1.16.0 - 16 July 2026
- Automated release of [eeacms/redmine-wikiman:2.1.18](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`ef928f40`](https://github.com/eea/helm-charts/commit/ef928f40cc262bd6e5b497fa5ff9fa956f1bef49)]

### Version 1.15.0 - 16 July 2026
- Automated release of [eeacms/redmine-wikiman:2.1.17](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`1ebba2df`](https://github.com/eea/helm-charts/commit/1ebba2df1e8e7a32f46fdca37e8dc523c01aea59)]

### Version 1.14.0 - 13 July 2026
- Automated release of [eeacms/redmine-wikiman:2.1.16](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`d89cb7fd`](https://github.com/eea/helm-charts/commit/d89cb7fd7f59f817044e780dd53fd796f282cbea)]

### Version 1.13.0 - 13 July 2026
- Automated release of [eeacms/redmine-wikiman:2.1.15](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`a6704c12`](https://github.com/eea/helm-charts/commit/a6704c129428106016e3e76aefdf6ddc39692e1c)]

### Version 1.12.0 - 13 July 2026
- Automated release of [eeacms/redmine-wikiman:2.1.14](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`b27b5ca5`](https://github.com/eea/helm-charts/commit/b27b5ca5e828cfeb08f2fe978aabd4c8939287e2)]

### Version 1.11.0 - 21 January 2026
- Automated release of [eeacms/redmine-wikiman:2.1.13](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`0c0771b2`](https://github.com/eea/helm-charts/commit/0c0771b28286a5c8c62cece59185412ed958f191)]

### Version 1.10.0 - 14 January 2026
- Automated release of [eeacms/redmine-wikiman:2.1.12](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`60241f66`](https://github.com/eea/helm-charts/commit/60241f6642b121d6799bce33b341f5469aa2f8c6)]

### Version 1.9.0 - 14 January 2026
- Automated release of [eeacms/redmine-wikiman:2.1.11](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`7f1f26c8`](https://github.com/eea/helm-charts/commit/7f1f26c8ae941014a66cc9e0f77377e780403e4f)]

### Version 1.8.0 - 14 January 2026
- Automated release of [eeacms/redmine-wikiman:2.1.10](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`9123a280`](https://github.com/eea/helm-charts/commit/9123a280189b1a912a658f8bfa7ece631e29dc61)]

### Version 1.7.0 - 14 January 2026
- Automated release of [eeacms/redmine-wikiman:2.1.9](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`29c54052`](https://github.com/eea/helm-charts/commit/29c540526d404d136887d7b17d9ff36a94081115)]

### Version 1.6.0 - 12 August 2025
- Automated release of [eeacms/redmine-wikiman:2.1.4](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`c23ad4e0`](https://github.com/eea/helm-charts/commit/c23ad4e08cf7e34cf415472b95a902ee1e0eff5c)]

### Version 1.5.0 - 12 August 2025
- Automated release of [eeacms/redmine-wikiman:2.1.3](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`cfccd403`](https://github.com/eea/helm-charts/commit/cfccd4039b8191995b38a680e73243cbf6fe955e)]

### Version 1.4.0 - 11 August 2025
- Automated release of [eeacms/redmine-wikiman:2.1.2](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`86a44524`](https://github.com/eea/helm-charts/commit/86a44524aa10db42689aeb4546861ae441702819)]

### Version 1.3.0 - 31 July 2025
- Automated release of [eeacms/redmine-wikiman:2.1.1](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`365738a0`](https://github.com/eea/helm-charts/commit/365738a0b846e221d4feff7fdcd1e0ece4ff0332)]

### Version 1.2.0 - 21 July 2025
- Automated release of [eeacms/redmine-wikiman:2.1](https://github.com/eea/eea.docker.redmine-wikiman/releases) [EEA Jenkins - [`e521549f`](https://github.com/eea/helm-charts/commit/e521549f6491ffffdcac38c82603e2c50151b247)]


### Version 1.1.2
- Add limits to keep pods history

### Version 1.1.0
- Add volume to keep GIT directory between runs

### Version 1.0.0
- First production release 



