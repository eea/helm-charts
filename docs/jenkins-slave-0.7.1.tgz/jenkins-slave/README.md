# Releases

### Version 0.7.1 - 04 August 2026
- Fix version [valentinab25 - [`ad424825`](https://github.com/eea/helm-charts/commit/ad4248254e82691715a9b22a3215f7630ea7880a)]

### Version 0.7.0 - 04 August 2026
- Upgrade to 29.6.1-1254-1 [valentinab25 - [`4a708dd8`](https://github.com/eea/helm-charts/commit/4a708dd821f64c43a08a0b0766fe0ab637631e14)]

### Version 0.6.1 - 04 August 2026
- rollback on docker version after timeouts [valentinab25 - [`7f883a1b`](https://github.com/eea/helm-charts/commit/7f883a1ba43f59eb0a3160db8cee44571b87244f)]

### Version 0.6.0 - 29 June 2026
- Automated release of [eeacms/jenkins-slave-dind:29.6.1-1254](https://github.com/eea/eea.docker.jenkins.slave-dind/releases) [EEA Jenkins - [`c21a0852`](https://github.com/eea/helm-charts/commit/c21a08526fbc1dc353663152c049d734a70e08f3)]

### Version 0.5.1 - 29 June 2026
- Upgrade docker image to 29.6.1-dind-alpine3.24 [valentinab25 - [`9c080afd`](https://github.com/eea/helm-charts/commit/9c080afd540dd2f34319624f8efd76d60c74bb0e)]

### Version 0.5.0 - 26 June 2026
- Automated release of [eeacms/jenkins-slave-dind:29.6-1254](https://github.com/eea/eea.docker.jenkins.slave-dind/releases) [EEA Jenkins - [`03de933b`](https://github.com/eea/helm-charts/commit/03de933b19fb5c7a3daea071caad2cbb92530aab)]

### Version 0.4.0 - 15 January 2026
- Automated release of [eeacms/jenkins-slave-dind:28.1-3.51-3](https://github.com/eea/eea.docker.jenkins.slave-dind/releases) [EEA Jenkins - [`5d3bf374`](https://github.com/eea/helm-charts/commit/5d3bf37498f7f94f31d54ebdd47e946a535ea654)]

### Version 0.3.0 - 13 January 2026
- Automated release of [eeacms/jenkins-slave-dind:28.1-3.51-2](https://github.com/eea/eea.docker.jenkins.slave-dind/releases) [EEA Jenkins - [`9ffc70b5`](https://github.com/eea/helm-charts/commit/9ffc70b540b59e062ea92d06928903b48f92e680)]

### Version 0.2.1 - 12 January 2026
- Run jenkins worker as root [EEA Jenkins - [`2d931833`](https://github.com/eea/helm-charts/commit/2d93183366ae667843b86b23ff0b5a88fed36f63)]

### Version 0.2.0 - 09 January 2026
- Automated release of [eeacms/jenkins-slave-dind:28.1-3.51-1](https://github.com/eea/eea.docker.jenkins.slave-dind/releases) [EEA Jenkins - [`70107162`](https://github.com/eea/helm-charts/commit/70107162799c9701d58b9bd8b743c8eb0a0274f4)]

### Version 0.1.0 - 30 October 2025
- Automated release of [eeacms/jenkins-slave-dind:28.1-3.51](https://github.com/eea/eea.docker.jenkins.slave-dind/releases) [EEA Jenkins - [`c0ee509e`](https://github.com/eea/helm-charts/commit/c0ee509ea9dc4cbc879cb837c0555610a363f9f3)]

### Version 0.0.3 - 26 June 2025
- patch jenkins volumes [Silviu - [`8635d70`](https://github.com/eea/helm-charts/commit/8635d70df06db477fcd7e45a62ed6bdaf413da00)]

### Version 0.0.2 - 26 June 2025
- patch docker config map for multi app deployment [Silviu - [`fd9c572`](https://github.com/eea/helm-charts/commit/fd9c5720303a35b10409adc8cbe715f265d8e4d2)]

### Version 0.0.1 - 22 May 2025
- init helm chart [Silviu - [`7e35c8b`](https://github.com/eea/helm-charts/commit/7e35c8b680ad5127c3b4f3649edf0557bfe37b7f)]
