# Converters

This chart is configured for production use.

## Releases

<dl>
  <dt>Version 0.1.11</dt>
  <dd>Thymeleaf, log4j upgrades, invalid property fix.</dd>

  <dt>Version 0.1.10</dt>
  <dd>Send message to rabbitmq after transaction is committed, sonarqube update use of branches</dd>

  <dt>Version 0.1.9</dt>
  <dd>Libraries and tomcat upgrades.</dd>

  <dt>Version 0.1.8</dt>
  <dd>Libraries upgrades.</dd>

  <dt>Version 0.1.7</dt>
  <dd>Job not found check.</dd>

  <dt>Version 0.1.6</dt>
  <dd>Use token instead of basic auth for FME communication.</dd>

  <dt>Version 0.1.5</dt>
  <dd>Graylog config.</dd>

  <dt>Version 0.1.4</dt>
  <dd>Java 17 upgrade.</dd>

  <dt>Version 0.1.3</dt>
  <dd>Tomcat/libraries upgrades.</dd>

  <dt>Version 0.1.2</dt>
  <dd>Missing env variable.</dd>

  <dt>Version 0.1.1</dt>
  <dd>Asyncfme database upgrade.</dd>

  <dt>Version 0.1.0</dt>
  <dd>Initial version.</dd>

</dl>

