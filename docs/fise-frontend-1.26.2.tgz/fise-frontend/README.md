# Forest Information System of Europe website frontend - Plone 6

This chart deployes the Forest Information System of Europe website frontend app

## Values

| Key           | Type   | Default        | Description                                                               |
| ------------- | ------ | -------------- | ------------------------------------------------------------------------- |
| links.backend | string | NAME.NAMESPACE | Service name for varnish for backend instance, followed by the namespace. |

## Releases

### Version 1.26.2 - 06 May 2026
- remove datacatalogue [Dobricean Ioan Dorian - [`556c8d9b`](https://github.com/eea/helm-charts/commit/556c8d9b3b24b6f2444209ac411d206d8d8648ee)]

### Version 1.26.0 - 06 May 2026
- Removed `/datacatalogue` redirection and the `ingress.datacatalogueRedirectUrl` value.

### Version 1.25.0 - 30 April 2026
- Automated release of [eeacms/fise-frontend:4.13.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`18d61ac7`](https://github.com/eea/helm-charts/commit/18d61ac755a92dd638808147397d4aef3618ec99)]

### Version 1.24.0 - 30 April 2026
- Automated release of [eeacms/fise-frontend:4.12.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`3424dc64`](https://github.com/eea/helm-charts/commit/3424dc642d23e43b21479539fae3ac2216ff6201)]

### Version 1.23.0 - 23 April 2026
- Automated release of [eeacms/fise-frontend:4.11.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`7fbe5ac7`](https://github.com/eea/helm-charts/commit/7fbe5ac7b874f21d96de425e6a4567c37df8cc8a)]

### Version 1.22.0 - 22 April 2026
- Automated release of [eeacms/fise-frontend:4.10.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`68d757e6`](https://github.com/eea/helm-charts/commit/68d757e6134d22de13d9de59b6cab6baa0901dea)]

### Version 1.21.0 - 19 April 2026
- Automated release of [eeacms/fise-frontend:4.9.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`99a81c28`](https://github.com/eea/helm-charts/commit/99a81c283ad32d5f8c2fb03fbf033a7156a30a57)]

### Version 1.20.0 - 17 March 2026
- Automated release of [eeacms/fise-frontend:4.8.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`29bbf2a5`](https://github.com/eea/helm-charts/commit/29bbf2a591e2250b4023ecd8964a2f4b46d49718)]

### Version 1.19.0 - 13 March 2026
- Automated release of [eeacms/fise-frontend:4.7.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`9924a6b7`](https://github.com/eea/helm-charts/commit/9924a6b7fd077ef9ce00b6f89f19509c6e2be6ca)]

### Version 1.17.0 - 04 March 2026
- Automated release of [eeacms/fise-frontend:4.6.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`c9bdf003`](https://github.com/eea/helm-charts/commit/c9bdf00308424818f92c7020c7b1c0c0c7d1df3b)]

### Version 1.16.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`70572c5b`](https://github.com/eea/helm-charts/commit/70572c5b7c6deb11d0b35be0d7275c13eb2e7319)]

### Version 1.16.0 - 19 November 2025
- Automated release of [eeacms/fise-frontend:4.5.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`55d4e3d5`](https://github.com/eea/helm-charts/commit/55d4e3d5f8380cccc71ceb0adc75620901c75f2f)]

### Version 1.15.0 - 28 August 2025
- Automated release of [eeacms/fise-frontend:4.4.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`9271b1e0`](https://github.com/eea/helm-charts/commit/9271b1e049dee68bfb863b69fa7028a81be8996d)]

### Version 1.14.0 - 26 August 2025
- Automated release of [eeacms/fise-frontend:4.3.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`f5d765d0`](https://github.com/eea/helm-charts/commit/f5d765d0b8dcfe8fb1b98dbe4340c491ad805fac)]

### Version 1.13.0 - 22 August 2025
- Automated release of [eeacms/fise-frontend:4.2.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`24435c6c`](https://github.com/eea/helm-charts/commit/24435c6cd573bf55d1e714e3b8afb9180bf62440)]

### Version 1.12.0 - 22 August 2025
- Automated release of [eeacms/fise-frontend:4.1.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`7fe87e50`](https://github.com/eea/helm-charts/commit/7fe87e50fc9630c6bead4885615185e5fcd90e49)]

### Version 1.11.0 - 04 August 2025
- Automated release of [eeacms/fise-frontend:4.0.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`ea2f6271`](https://github.com/eea/helm-charts/commit/ea2f6271dd3a5863dc941b9c058957885e13f663)]

### Version 1.10.1 - 01 August 2025
- Automated release of [eeacms/plone-varnish:7.7-1.1](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`9c0f7b2c`](https://github.com/eea/helm-charts/commit/9c0f7b2c0cea3ba9d7b4642300482cadf3015ef6)]

### Version 1.10.0 - 29 July 2025
- Automated release of [eeacms/fise-frontend:3.5.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`3ff883b8`](https://github.com/eea/helm-charts/commit/3ff883b86c998fe11fff35e4e6e7dbd1fa05744a)]

### Version 1.9.0 - 19 June 2025
- Automated release of [eeacms/fise-frontend:3.4.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`fa4cd22b`](https://github.com/eea/helm-charts/commit/fa4cd22b2562b27fda18b1284707b8555491ac1c)]

### Version 1.8.1 - 21 May 2025
- Automated release of [eeacms/plone-varnish:7.7-1.0](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`69d84df`](https://github.com/eea/helm-charts/commit/69d84df5bfdf8084e758d87c9a028caa15fa7595)]

### Version 1.8.0 - 08 May 2025
- Automated release of [eeacms/fise-frontend:3.3.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`8b9d48a`](https://github.com/eea/helm-charts/commit/8b9d48a6a910bb1026fb27a5c0660b8f8b52f301)]

### Version 1.7.1 - 08 May 2025
- add environment variables for Resource Catalog

### Version 1.7.0 - 08 May 2025
- Automated release of [eeacms/fise-frontend:3.2.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`8c23882`](https://github.com/eea/helm-charts/commit/8c238825414a787eac8b066be8e2b756620ef36c)]

### Version 1.6.0 - 16 April 2025
- Automated release of [eeacms/fise-frontend:3.1.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`8f13f04`](https://github.com/eea/helm-charts/commit/8f13f04613fcd395f19b429c0a005b79be8216ba)]

### Version 1.5.0 - 15 April 2025
- Automated release of [eeacms/fise-frontend:3.0.3-beta.4](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`2f5b74e`](https://github.com/eea/helm-charts/commit/2f5b74e350e032a661ffd39eddbd8443f9756d72)]

### Version 1.4.0 - 14 April 2025
- Automated release of [eeacms/fise-frontend:3.0.3-beta.3](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`646a41a`](https://github.com/eea/helm-charts/commit/646a41a945c24577d39d211546d129bb702e168e)]

### Version 1.3.2 - 10 April 2025
- Add variable debug.addonsPath [valentinab25 - [`1082ad7`](https://github.com/eea/helm-charts/commit/1082ad7f8ade8f2f56e07d17c104da9cc27a9dbf)]

### Version 1.3.1 - 10 April 2025
- Add debug deployment & service for volto [valentinab25 - [`eb6f4a2`](https://github.com/eea/helm-charts/commit/eb6f4a25d8f1d534bf9768a4d4c3cd563a58c104)]
- Add debug pvc [valentinab25 - [`e34a052`](https://github.com/eea/helm-charts/commit/4e34a052f0efddaacacef874808b6783706cfee5)]


### Version 1.3.0 - 10 April 2025
- Automated release of [eeacms/fise-frontend:3.0.3-beta.2](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`2c59d84`](https://github.com/eea/helm-charts/commit/2c59d84b068577be46eb7d8272a2a9995d3be124)]

### Version 1.2.0 - 10 April 2025
- Automated release of [eeacms/fise-frontend:3.0.3-beta.1](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`7d4919f`](https://github.com/eea/helm-charts/commit/7d4919f5e3b96b6cff5ead44c84fc8adfbf54fd8)]

### Version 1.1.0 - 10 April 2025
- Automated release of [eeacms/fise-frontend:3.0.3-beta.0](https://github.com/eea/fise-frontend/releases) [EEA Jenkins - [`40290ea`](https://github.com/eea/helm-charts/commit/40290ea04a1cf97d662f504d6d3fee448988b57e)]

### Version 1.0.3 - 26 March 2025
- Add datacatalogueRedirectUrl [valentinab25 - [`01d42d0`](https://github.com/eea/helm-charts/commit/01d42d0e17c169d243a5633a35293f592d76eb1d)]

### Version 1.0.2 - 20 March 2025
- Add ingress.tls variable, use empty certificate for default [valentinab25 - [`0135b29`](https://github.com/eea/helm-charts/commit/0135b29490b3c27818b3e5a4c9cf836a5be0b2e6)]

### Version 1.0.0

- Initial release.

### Version 1.0.1

- Update values.
