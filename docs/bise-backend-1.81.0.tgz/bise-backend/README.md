# BISE backend - Plone 6

This chart deployes the BISE backend app

## Values

| Key           | Type | Default | Description                       |
| ------------- | ---- | ------- | --------------------------------- |
| debug.enabled | bool | false   | Activate the Plone debug instance |

## Releases

### Version 1.81.0 - 02 October 2026
- Automated release of [eeacms/bise-backend:6.1.4-29](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`2b206cb5`](https://github.com/eea/helm-charts/commit/2b206cb5dc84a5dd7f8da47c02855a61eb9aa5d8)]

### Version 1.80.0 - 01 October 2026
- Automated release of [eeacms/bise-backend:6.1.4-28](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`25af9d27`](https://github.com/eea/helm-charts/commit/25af9d2785163e946a9d0d33e7bc62ad9374501a)]

### Version 1.79.0 - 30 September 2026
- Automated release of [eeacms/bise-backend:6.1.4-27](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`791a027e`](https://github.com/eea/helm-charts/commit/791a027e4c043472f1f17ce6f6353f2de40c62ed)]

### Version 1.78.0 - 26 September 2026
- Automated release of [eeacms/bise-backend:6.1.4-26](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`bbc7b0f5`](https://github.com/eea/helm-charts/commit/bbc7b0f5b14190f15bff4a0e593243b64a2082d5)]

### Version 1.77.0 - 18 September 2026
- Automated release of [eeacms/bise-backend:6.1.4-25](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`af9cd55b`](https://github.com/eea/helm-charts/commit/af9cd55bab9abcd223bd3eee2f877d604b4d31f9)]

### Version 1.76.0 - 18 September 2026
- Automated release of [eeacms/bise-backend:6.1.4-24](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`16cae12e`](https://github.com/eea/helm-charts/commit/16cae12e7a6892e5be4de38e7fff03c5952af171)]

### Version 1.75.0 - 18 September 2026
- Automated release of [eeacms/bise-backend:6.1.4-23](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`a7ba8453`](https://github.com/eea/helm-charts/commit/a7ba8453e3ef658d628ee5272e8c431aaa3bad45)]

### Version 1.74.1 - 04 September 2026
- chore: Refs [#305742](https://taskman.eionet.europa.eu/issues/305742) - reduce kept failed cronjob pods from 5 to 1 [Claudia Ifrim - [`60c0f84b`](https://github.com/eea/helm-charts/commit/60c0f84bf636a56d2f745f5625faef04b216ac1a)]

### Version 1.74.0 - 20 August 2026
- Automated release of [eeacms/bise-backend:6.1.4-22](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`8ddf4bcd`](https://github.com/eea/helm-charts/commit/8ddf4bcdef12b1b52565eaf530f4cd3fdf223909)]

### Version 1.73.0 - 17 August 2026
- Automated release of [eeacms/bise-backend:6.1.4-21](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`d434ef5f`](https://github.com/eea/helm-charts/commit/d434ef5f5101a2f2a652ff1ab1bef394416e0467)]

### Version 1.72.0 - 17 August 2026
- Automated release of [eeacms/bise-backend:6.1.4-20](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`0a9b4b25`](https://github.com/eea/helm-charts/commit/0a9b4b2500b9cf0a4cd0d287761b22cbf5299d8c)]

### Version 1.71.0 - 09 August 2026
- Automated release of [eeacms/bise-backend:6.1.4-19](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`fcb527c8`](https://github.com/eea/helm-charts/commit/fcb527c8c8e4eb64cef3eac497d7fc30e24d320c)]

### Version 1.70.0 - 07 August 2026
- Automated release of [eeacms/bise-backend:6.1.4-18](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`9fcde4e4`](https://github.com/eea/helm-charts/commit/9fcde4e47f90d0e788bd8c5b8e84da23df05ef55)]

### Version 1.69.0 - 06 August 2026
- Automated release of [eeacms/bise-backend:6.1.4-17](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`c74590f2`](https://github.com/eea/helm-charts/commit/c74590f2c0fdef0be9128840912129347c9986c0)]

### Version 1.68.0 - 30 July 2026
- Automated release of [eeacms/bise-backend:6.1.4-16](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`e698b5c5`](https://github.com/eea/helm-charts/commit/e698b5c55236a3898efe6405b21b5cbff65de689)]

### Version 1.67.0 - 23 July 2026
- Automated release of [eeacms/bise-backend:6.1.4-15](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`88573675`](https://github.com/eea/helm-charts/commit/8857367504acd47bf932a69a0bc3a3a73a6ecc82)]

### Version 1.66.0 - 15 July 2026
- Automated release of [eeacms/bise-backend:6.1.4-14](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`cbb66418`](https://github.com/eea/helm-charts/commit/cbb664181d292d8ea2dc6155379118aceec23b75)]

### Version 1.65.0 - 14 July 2026
- Automated release of [eeacms/bise-backend:6.1.4-13](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`eb7d5fcd`](https://github.com/eea/helm-charts/commit/eb7d5fcd43b955170040bcca5933d670737ce81a)]

### Version 1.64.0 - 11 July 2026
- Automated release of [eeacms/bise-backend:6.1.4-12](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`1e31c7dc`](https://github.com/eea/helm-charts/commit/1e31c7dcf1bae1755b50440d9fefdcfa0f727c8a)]

### Version 1.63.0 - 08 July 2026
- Automated release of [eeacms/bise-backend:6.1.4-11](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`70ff36c9`](https://github.com/eea/helm-charts/commit/70ff36c90534e4fcffeed42287a0d00297a44b23)]

### Version 1.62.0 - 06 July 2026
- Automated release of [eeacms/bise-backend:6.1.4-10](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`51ed1245`](https://github.com/eea/helm-charts/commit/51ed1245b05b5ae2fd730417e248b30bb6bfbcf0)]

### Version 1.61.0 - 26 June 2026
- Automated release of [eeacms/bise-backend:6.1.4-9](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`ad785f3b`](https://github.com/eea/helm-charts/commit/ad785f3bc180a4559572268b3bfc46e586915880)]

### Version 1.60.0 - 24 June 2026
- Automated release of [eeacms/bise-backend:6.1.4-8](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`f4d92947`](https://github.com/eea/helm-charts/commit/f4d92947f6418e9247e9d5561831893864ab6ac0)]

### Version 1.59.0 - 19 June 2026
- Automated release of [eeacms/bise-backend:6.1.4-7](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`ad66a032`](https://github.com/eea/helm-charts/commit/ad66a0328ab8468fe3b77f92dc03887c7ba9e43e)]

### Version 1.58.3 - 16 June 2026
- increase cpu for cronjobs [Dobricean Ioan Dorian - [`01103656`](https://github.com/eea/helm-charts/commit/011036563d3f2bd2fa57561bc0ebf3d3feb0aa2c)]

### Version 1.58.2 - 08 June 2026
- fix entrasync active deadline [Dobricean Ioan Dorian - [`b17003ac`](https://github.com/eea/helm-charts/commit/b17003ac9fa4fa11b02eece41cfc7c41e9b28b4b)]

### Version 1.58.1 - 08 June 2026
- Fix Entra sync CronJob history limits and add a 10h active deadline for stuck Jobs

### Version 1.58.0 - 27 May 2026
- Automated release of [eeacms/bise-backend:6.1.4-4](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`bbb0922c`](https://github.com/eea/helm-charts/commit/bbb0922c59c63ac9167d513122cda755211b4315)]

### Version 1.57.0 - 29 April 2026
- Automated release of [eeacms/bise-backend:6.1.4-2](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`72d3557e`](https://github.com/eea/helm-charts/commit/72d3557ec7d06f2f8a68202445092c4e4bef19c6)]

### Version 1.56.0 - 29 April 2026
- Automated release of [eeacms/bise-backend:6.1.4-1](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`daac82b8`](https://github.com/eea/helm-charts/commit/daac82b8fe5d3dfaf3d82d0611540c804bbc0dfe)]

### Version 1.55.0 - 22 April 2026
- Automated release of [eeacms/bise-backend:6.1.3-55](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`b9922b5f`](https://github.com/eea/helm-charts/commit/b9922b5f5b1b49492ec02dc0744cb5dcd694f7bf)]

### Version 1.54.0 - 18 April 2026
- Automated release of [eeacms/bise-backend:6.1.3-54](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`445914e7`](https://github.com/eea/helm-charts/commit/445914e7176cbbbfc153e569306a9213ab9b2008)]

### Version 1.53.0 - 15 April 2026
- Automated release of [eeacms/bise-backend:6.1.3-52](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`473396ed`](https://github.com/eea/helm-charts/commit/473396ed1d435d5380429501b62b3c7666d20778)]

### Version 1.52.0 - 26 March 2026
- Automated release of [eeacms/bise-backend:6.1.3-51](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`f800741c`](https://github.com/eea/helm-charts/commit/f800741ce0b59fc403108ca2eee9a38134544974)]

### Version 1.51.0 - 07 March 2026
- Automated release of [eeacms/bise-backend:6.1.3-50](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`85e9a5cd`](https://github.com/eea/helm-charts/commit/85e9a5cdc7187cbe01ff33fe791342d313a0b356)]

### Version 1.50.0 - 05 March 2026
- Automated release of [eeacms/bise-backend:6.1.3-49](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`54d9eedd`](https://github.com/eea/helm-charts/commit/54d9eedd935436539f739d30d132e25c3644f0c3)]

### Version 1.49.0 - 25 February 2026
- Automated release of [eeacms/bise-backend:6.1.3-48](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`038e180d`](https://github.com/eea/helm-charts/commit/038e180d5ff24831d7dc0cdfa8a6b02eeadab28c)]

### Version 1.48.0 - 06 February 2026
- Automated release of [eeacms/bise-backend:6.1.3-47](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`494061b7`](https://github.com/eea/helm-charts/commit/494061b7e7c7557856bd7e008012b545ab578045)]

### Version 1.47.0 - 28 January 2026
- Automated release of [eeacms/bise-backend:6.1.3-46](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`48b86a1e`](https://github.com/eea/helm-charts/commit/48b86a1e1b5cf9aea3e5bf7f0bbe564ea087c7d7)]

### Version 1.46.0 - 23 January 2026
- Automated release of [eeacms/bise-backend:6.1.3-45](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`49a30677`](https://github.com/eea/helm-charts/commit/49a3067734d7aae3ceb938f9e77bd9bf259e1b7e)]

### Version 1.45.0 - 23 January 2026
- Automated release of [eeacms/bise-backend:6.1.3-43](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`fe8943a7`](https://github.com/eea/helm-charts/commit/fe8943a71f4733aa5bae1890d73b7549ca09d5c4)]

### Version 1.44.0 - 23 January 2026
- Automated release of [eeacms/bise-backend:6.1.3-42](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`18ba0075`](https://github.com/eea/helm-charts/commit/18ba00751bf8887d3ff931e78e86fe9d68ae11f8)]

### Version 1.43.0 - 22 January 2026
- Automated release of [eeacms/bise-backend:6.1.3-41](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`7d8564d5`](https://github.com/eea/helm-charts/commit/7d8564d55c54c62946c52c6b1d1a5572bf181f37)]

### Version 1.42.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`bd55c256`](https://github.com/eea/helm-charts/commit/bd55c256ca1d7b7838de0f9b9afa59024df1e23b)]

### Version 1.42.0 - 19 January 2026
- Automated release of [eeacms/bise-backend:6.1.3-40](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`129ba5af`](https://github.com/eea/helm-charts/commit/129ba5af7de5d65c5ffc64819867c2aa123b3bad)]

### Version 1.41.0 - 15 January 2026
- Automated release of [eeacms/bise-backend:6.1.3-39](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`01ff6c40`](https://github.com/eea/helm-charts/commit/01ff6c4047665b0468910299cfc92e7a49a6fbe0)]

### Version 1.40.0 - 15 January 2026
- Automated release of [eeacms/bise-backend:6.1.3-38](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`984f8954`](https://github.com/eea/helm-charts/commit/984f895420333e4e642c50c635d81fbab0138d70)]

### Version 1.39.0 - 23 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-37](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`b93b4bf9`](https://github.com/eea/helm-charts/commit/b93b4bf982de6079cdec835444e17c3d7fcaa6bc)]

### Version 1.38.0 - 22 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-36](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`cc57d543`](https://github.com/eea/helm-charts/commit/cc57d543f2908dc09ce11f73aae399f8efcafe3c)]

### Version 1.37.1 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`ac5081e9`](https://github.com/eea/helm-charts/commit/ac5081e92e6e2e742281c1b302b15f4dad423472)]

### Version 1.37.0 - 18 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-34](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`288130ad`](https://github.com/eea/helm-charts/commit/288130addccb874a20131203b5e77cdff80f5dc6)]

### Version 1.36.0 - 17 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-33](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`ea7a8926`](https://github.com/eea/helm-charts/commit/ea7a8926cd5837a5eb4c7999cf9d81a7d89b7aad)]

### Version 1.35.0 - 16 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-32](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`c12a23fd`](https://github.com/eea/helm-charts/commit/c12a23fd12816d5fc60d4dde509626eb18ca6377)]

### Version 1.34.0 - 15 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-31](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`4b68c973`](https://github.com/eea/helm-charts/commit/4b68c9735cfc806998772ee4f1f084cd640fcdd3)]

### Version 1.33.0 - 14 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-30](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`ef22c771`](https://github.com/eea/helm-charts/commit/ef22c771af6ee9bd59873ebacc8160d2e954d91e)]

### Version 1.32.0 - 12 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-28](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`bec354c1`](https://github.com/eea/helm-charts/commit/bec354c1e83c1255556d2bedc447661b6845a715)]

### Version 1.31.0 - 11 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-27](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`34f0d0a0`](https://github.com/eea/helm-charts/commit/34f0d0a063099bbfbb696a1cf64efe04cd1cc9d5)]

### Version 1.30.0 - 10 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-26](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`36dce79c`](https://github.com/eea/helm-charts/commit/36dce79c49588ceec908ac8842a643beb2cd11ef)]

### Version 1.29.0 - 09 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-25](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`54f1fa72`](https://github.com/eea/helm-charts/commit/54f1fa7218c9db42e6f6d2a5c3f21df4f08c6acb)]

### Version 1.28.0 - 08 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-24](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`e5cb118d`](https://github.com/eea/helm-charts/commit/e5cb118d854c33c74872bfcf391ed0dd8cd75392)]

### Version 1.27.0 - 07 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-23](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`ab75c3d2`](https://github.com/eea/helm-charts/commit/ab75c3d2ed646176a0d603fc9df9a71f6a9ce387)]

### Version 1.26.0 - 06 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-22](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`d84eb202`](https://github.com/eea/helm-charts/commit/d84eb202ae13289cd26e5d80660e6d4797ed8857)]

### Version 1.25.0 - 05 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-21](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`f389e667`](https://github.com/eea/helm-charts/commit/f389e66717fbc043600c1e326ae018b46cd74485)]

### Version 1.24.0 - 04 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-20](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`d8528c50`](https://github.com/eea/helm-charts/commit/d8528c50552350266f2a1f2ef7371daaf2f5f1c9)]

### Version 1.23.0 - 04 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-19](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`828a36a0`](https://github.com/eea/helm-charts/commit/828a36a0f4d169d64de736f847881f5fe0fe7746)]

### Version 1.22.0 - 04 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-18](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`687b9f72`](https://github.com/eea/helm-charts/commit/687b9f725b46d1d2842ea24ce6a1d66053804fbb)]

### Version 1.21.0 - 03 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-17](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`2c425c82`](https://github.com/eea/helm-charts/commit/2c425c8224b4b482e6871f89d580ae207c8e72f0)]

### Version 1.20.0 - 01 December 2025
- Automated release of [eeacms/bise-backend:6.1.3-14](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`d41d30bd`](https://github.com/eea/helm-charts/commit/d41d30bd5ca69fa33ff8cf9e96b881e27d86290c)]

### Version 1.19.0 - 30 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-13](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`0e0b2500`](https://github.com/eea/helm-charts/commit/0e0b2500217d1277afa8ad936ad611f5c9a56667)]

### Version 1.18.0 - 29 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-12](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`2e74670a`](https://github.com/eea/helm-charts/commit/2e74670a631932e2bceec8502a77ce3a1f0593a5)]

### Version 1.17.0 - 28 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-11](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`ffe1441f`](https://github.com/eea/helm-charts/commit/ffe1441fed382bb584ac3c75a4067a02871406ae)]

### Version 1.16.0 - 27 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-10](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`9661b078`](https://github.com/eea/helm-charts/commit/9661b07830b38d211a49b3db0cb39ee2615a30e1)]

### Version 1.15.0 - 26 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-9](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`adc70fd0`](https://github.com/eea/helm-charts/commit/adc70fd0c3da240c3651381c53276b23b576f226)]

### Version 1.14.1 - 25 November 2025
- Release of dependent chart postfix:3.1.2 [valentinab25 - [`5436af42`](https://github.com/eea/helm-charts/commit/5436af42c1b061dce9c63aa6989349b0884f38b8)]

### Version 1.14.0 - 25 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-8](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`f017c0c7`](https://github.com/eea/helm-charts/commit/f017c0c7eb37d6bf3001d2b1258dc9f1feebfe98)]

### Version 1.13.0 - 23 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-7](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`a9ab0849`](https://github.com/eea/helm-charts/commit/a9ab0849a43a532d887fb13ea93e85ac62620f3c)]

### Version 1.12.0 - 22 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-6](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`06553593`](https://github.com/eea/helm-charts/commit/065535930d6ac5187f9bbf7e2f82e2e75c857a5e)]

### Version 1.11.0 - 21 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-5](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`987d4bd3`](https://github.com/eea/helm-charts/commit/987d4bd38f4f7e7be0aad3b530df38cc60262c47)]

### Version 1.10.0 - 20 November 2025
- Automated release of [eeacms/bise-backend:6.1.6](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`f224faeb`](https://github.com/eea/helm-charts/commit/f224faebfb49bb7cbdb290fb157c02bb3766a002)]

### Version 1.9.0 - 20 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-4](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`eb7e893c`](https://github.com/eea/helm-charts/commit/eb7e893caf6d36554d7ee86e5a9e1efbe3627b23)]

### Version 1.8.0 - 19 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-3](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`c36a88df`](https://github.com/eea/helm-charts/commit/c36a88dfd46adbb2b515537f42c6e83523d2bf61)]

### Version 1.7.0 - 19 November 2025
- Automated release of [eeacms/bise-backend:6.1.3-2](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`b6f64485`](https://github.com/eea/helm-charts/commit/b6f64485eb0a9f84776c0527a8b5e01acd576808)]

### Version 1.6.0 - 17 November 2025
- Automated release of [eeacms/bise-backend:6.0.15-21](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`025fd719`](https://github.com/eea/helm-charts/commit/025fd719ca2dae67ed2734ca5c212bcd8b1cbe64)]

### Version 1.5.0 - 28 October 2025
- Automated release of [eeacms/bise-backend:6.1.3-1.demo.02](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`05176e0f`](https://github.com/eea/helm-charts/commit/05176e0f473ad25de0f08313e6c3562bec53b29b)]

### Version 1.4.0 - 27 October 2025
- Automated release of [eeacms/bise-backend:6.0.15-5](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`9e1f86c7`](https://github.com/eea/helm-charts/commit/9e1f86c7df19edd4ccfdcbe51008035059884915)]

### Version 1.3.0 - 24 October 2025
- Automated release of [eeacms/bise-backend:6.0.15-3](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`7e0dd9f3`](https://github.com/eea/helm-charts/commit/7e0dd9f3062f669bf00c62115c554414b1bbbe0d)]

### Version 1.2.0 - 23 October 2025
- Automated release of [eeacms/bise-backend:6.0.15-2](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`b9e0e4cb`](https://github.com/eea/helm-charts/commit/b9e0e4cb127d0b1fcfaabcb9fabc7347be4c0c8a)]

### Version 1.1.0 - 22 October 2025
- Automated release of [eeacms/bise-backend:6.0.15-1](https://github.com/eea/bise-backend/releases) [EEA Jenkins - [`2080f6c1`](https://github.com/eea/helm-charts/commit/2080f6c133dd19a1b3202eeabb1628d2b4677dc7)]

### Version 1.0.0 - 11 October 2025
- Initial release of BISE backend based on IED backend
