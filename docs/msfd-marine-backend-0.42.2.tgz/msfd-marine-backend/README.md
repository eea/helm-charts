# MSFD Marine backend

## Releases

### Version 0.42.2 - 13 May 2026
- fix [Dobricean Ioan Dorian - [`16afad62`](https://github.com/eea/helm-charts/commit/16afad62a25c5fb32680fe9d66b10212f47be234)]

### Version 0.42.1 - 13 May 2026
- fix entrasync [Dobricean Ioan Dorian - [`43a0f5e5`](https://github.com/eea/helm-charts/commit/43a0f5e59d443cd7cee73bffe7963651056ac927)]

### Version 0.42.0 - 13 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.08](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`dce238c2`](https://github.com/eea/helm-charts/commit/dce238c258c3bf86f999ba324f02636fea36233b)]

### Version 0.41.3 - 13 May 2026
- fix [Dobricean Ioan Dorian - [`d4d55399`](https://github.com/eea/helm-charts/commit/d4d55399ab1ded09c14d80701c18f006f9f37152)]

### Version 0.41.2 - 13 May 2026
- fix entrasync cron [Dobricean Ioan Dorian - [`2096f928`](https://github.com/eea/helm-charts/commit/2096f928455bdc9f475a54adcda979095bc91308)]

### Version 0.41.1 - 13 May 2026
- fix entrasync [Dobricean Ioan Dorian - [`15dc6ebd`](https://github.com/eea/helm-charts/commit/15dc6ebd5e3706ed33cbdd42988e49af91a1fa3d)]

### Version 0.41.0 - 13 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.07](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`b9d96e01`](https://github.com/eea/helm-charts/commit/b9d96e012ee5d73ad4d125b5545c8a4fb4939684)]

### Version 0.40.0 - 13 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.06](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`772a4fbc`](https://github.com/eea/helm-charts/commit/772a4fbcbbcd927248168b4b57caf6c32a732dbe)]

### Version 0.39.0 - 12 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.05](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`2e4f2daa`](https://github.com/eea/helm-charts/commit/2e4f2daa156fc98e87523cfad190ab091b26a36f)]

### Version 0.38.0 - 11 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.04](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`70ee582f`](https://github.com/eea/helm-charts/commit/70ee582f5b38b63b41aaf802e3f03831ed93d30f)]

### Version 0.37.0 - 11 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.03](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`a4c480ff`](https://github.com/eea/helm-charts/commit/a4c480ff9a17550c4dad469b96fcaea9c29910f0)]

### Version 0.36.0 - 11 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.02](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`251e4d60`](https://github.com/eea/helm-charts/commit/251e4d6096fa85cec37e709aad3e663ec08b6661)]

### Version 0.35.1 - 11 May 2026
- fix ingress [Dobricean Ioan Dorian - [`84bb475d`](https://github.com/eea/helm-charts/commit/84bb475d3bd4bb6073f91734e50d130adfa82316)]

### Version 0.35.0 - 11 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5.entraId.01](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5a1e9768`](https://github.com/eea/helm-charts/commit/5a1e9768ee5a6c2bc52a84a4a85e2d08ba321d0d)]

### Version 0.34.0 - 11 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-5](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`941fdbb6`](https://github.com/eea/helm-charts/commit/941fdbb6d8f554a05ec29ef9a4d820032ee947da)]

### Version 0.33.0 - 08 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-4](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5480673d`](https://github.com/eea/helm-charts/commit/5480673dc1831c1044616c05f60693d6d3420bbb)]

### Version 0.32.0 - 08 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-3.entraId.01](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`a44f08bd`](https://github.com/eea/helm-charts/commit/a44f08bdcd7a3ac23c6801d6fde48cde28691c06)]

### Version 0.31.4 - 06 May 2026
- fix ingresses [Dobricean Ioan Dorian - [`632e382a`](https://github.com/eea/helm-charts/commit/632e382a133af3ea4ac891ec4bf3fd387e65bb71)]

### Version 0.31.3 - 06 May 2026
- fix ingresses [Dobricean Ioan Dorian - [`4aed3af4`](https://github.com/eea/helm-charts/commit/4aed3af460f04352e3473cf88f9e710e601c64a3)]

### Version 0.31.2 - 06 May 2026
- add more exceptions [Dobricean Ioan Dorian - [`4882d941`](https://github.com/eea/helm-charts/commit/4882d94111889aa530192e575197367185dbbba5)]

### Version 0.31.1 - 06 May 2026
- fix ingress msfd [Dobricean Ioan Dorian - [`3ef45746`](https://github.com/eea/helm-charts/commit/3ef4574611430ec362e88f73f36d965206364af0)]

### Version 0.31.0 - 06 May 2026
- Automated release of [eeacms/msfd-backend:6.1.4-3](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`591d60e4`](https://github.com/eea/helm-charts/commit/591d60e4dcc866773dea0a0c2cd0d6d29b504dfb)]

### Version 0.30.0 - 29 April 2026
- Automated release of [eeacms/msfd-backend:6.1.4-2](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`19dbdc55`](https://github.com/eea/helm-charts/commit/19dbdc55684852dded475cc90a15683fb400f433)]

### Version 0.29.0 - 29 April 2026
- Automated release of [eeacms/msfd-backend:6.1.4-1](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5c48bf83`](https://github.com/eea/helm-charts/commit/5c48bf8395cf0a7fe532fa7d88ee5fd2e0f5f8d2)]

### Version 0.28.0 - 22 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-20](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`50f8d7f4`](https://github.com/eea/helm-charts/commit/50f8d7f4f0270644b358f3fbf7caac487156e266)]

### Version 0.27.0 - 18 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-19](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`c2f54c1b`](https://github.com/eea/helm-charts/commit/c2f54c1b7e7243e580eac078ebfc2d714904d15f)]

### Version 0.26.0 - 17 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-18](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`f0a8e4f5`](https://github.com/eea/helm-charts/commit/f0a8e4f56b9187ec4c50391db050b0ff40ffe65c)]

### Version 0.25.0 - 16 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-17](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`53cb6e0d`](https://github.com/eea/helm-charts/commit/53cb6e0ded7c3d419231eaa3a5e9b15c829822e9)]

### Version 0.24.0 - 15 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-16](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`37fdd4ea`](https://github.com/eea/helm-charts/commit/37fdd4eae4df6ec1536677ed56122bb2ad7f1bfc)]

### Version 0.23.1 - 14 April 2026
- add plone registry yaml [Dobricean Ioan Dorian - [`af314e3b`](https://github.com/eea/helm-charts/commit/af314e3b4f76789ac24cab9d527bc76b19d6394b)]

### Version 0.23.0 - 14 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-15](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`068a141f`](https://github.com/eea/helm-charts/commit/068a141f161dc199bc4885180cf08e08466b22b3)]

### Version 0.22.0 - 02 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-14](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`84fcb7d6`](https://github.com/eea/helm-charts/commit/84fcb7d6559e11f332bd6798e59ddcedb6f1a04c)]

### Version 0.21.0 - 01 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-13](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`38b34165`](https://github.com/eea/helm-charts/commit/38b341653c5fc91c2c7e5e37ff8305e8a39a41ec)]

### Version 0.20.0 - 01 April 2026
- Automated release of [eeacms/msfd-backend:6.1.3-12.entraId.02](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`8821cf93`](https://github.com/eea/helm-charts/commit/8821cf93960fa7ea8757744a2219a9cc36f537ee)]

### Version 0.19.3 - 30 March 2026
- make for zeo [Dobricean Ioan Dorian - [`48a2c612`](https://github.com/eea/helm-charts/commit/48a2c612fbce86ec90d730920b8be804d3a50d2c)]

### Version 0.19.2 - 30 March 2026
- fix entrasync [Dobricean Ioan Dorian - [`a66e6bfb`](https://github.com/eea/helm-charts/commit/a66e6bfb1b615ce39e67f2796546a2b75342f0e1)]

### Version 0.19.1 - 30 March 2026
- cronjob entrasync [Dobricean Ioan Dorian - [`09e8ea66`](https://github.com/eea/helm-charts/commit/09e8ea66186a41d56c15fed315debd6e1ed315ad)]

### Version 0.18.0 - 18 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-12](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`f1c136e6`](https://github.com/eea/helm-charts/commit/f1c136e66068327aa4931925f4bb8dd2d00630b2)]

### Version 0.17.0 - 18 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-11](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`70a71015`](https://github.com/eea/helm-charts/commit/70a7101538eeadd01ef93d61e77c40dfa990426b)]

### Version 0.16.0 - 16 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-10](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`8a174aad`](https://github.com/eea/helm-charts/commit/8a174aad5fe5419bcf17a082c56c5f5ad90ad0a9)]

### Version 0.15.0 - 12 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-7](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`bbaa8564`](https://github.com/eea/helm-charts/commit/bbaa85647046fb6727beeafb504d95663726ea4f)]

### Version 0.14.0 - 12 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-6](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`3c548623`](https://github.com/eea/helm-charts/commit/3c5486232a486e7cd54c87293e0bd8187cbf87a7)]

### Version 0.13.1 - 11 March 2026
- fix command and port [Dobricean Ioan Dorian - [`7d7e2890`](https://github.com/eea/helm-charts/commit/7d7e289063d2f1922fa1b58a7e5f002bafc968be)]

### Version 0.13.0 - 11 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-5](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`357e76b2`](https://github.com/eea/helm-charts/commit/357e76b254c0a2ffde280698214e1fe9b91ea5f0)]

### Version 0.12.0 - 11 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-4](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`c712c9bc`](https://github.com/eea/helm-charts/commit/c712c9bc7aaf8ae887eb84869252e3354a482335)]

### Version 0.11.1 - 11 March 2026
- change zeo iamge [Dobricean Ioan Dorian - [`3b7f4c11`](https://github.com/eea/helm-charts/commit/3b7f4c11eab1631e04a82b7dff5d7ecdc00aedc0)]

### Version 0.11.0 - 10 March 2026
- Automated release of [eeacms/msfd-backend:6.1.3-2](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`806a9fb0`](https://github.com/eea/helm-charts/commit/806a9fb0c21fc29434f44f4b9b656a13f524184a)]

### Version 0.10.0 - 09 March 2026
- update  msfd image [Dobricean Ioan Dorian - [`75bf6490`](https://github.com/eea/helm-charts/commit/75bf6490c0461042378e31aefec97996e7860a3a)]

### Version 0.9.1 - 08 March 2026
- choose storage [Dobricean Ioan Dorian - [`935ca6fb`](https://github.com/eea/helm-charts/commit/935ca6fbd759bf485da414d97dc346ad6c245100)]

### Version 0.9.0 - 02 March 2026
- Automated release of [eeacms/msfd-backend:5.2.13-14](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`5e0748c8`](https://github.com/eea/helm-charts/commit/5e0748c8b92c128dec6a7484bfd9de8ad130d4c0)]

### Version 0.8.0 - 26 February 2026
- Automated release of [eeacms/msfd-backend:5.2.13-11](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`bb62a9c2`](https://github.com/eea/helm-charts/commit/bb62a9c205ce5410c46552300d1544aff307af75)]

### Version 0.7.0 - 11 February 2026
- Automated release of [eeacms/msfd-backend:5.2.13-9](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`cdb8baca`](https://github.com/eea/helm-charts/commit/cdb8baca2248e3263c4a87030643ab8d58e0fe48)]

### Version 0.6.0 - 04 February 2026
- Automated release of [eeacms/msfd-backend:5.2.13-8](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`240a241f`](https://github.com/eea/helm-charts/commit/240a241f9b665b6fa6ac0acf3cdcda1f7b8cc199)]

### Version 0.5.0 - 04 February 2026
- Automated release of [eeacms/msfd-backend:5.2.13-7](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`7da487d5`](https://github.com/eea/helm-charts/commit/7da487d539a473976b06ca09c13e599a7497eb42)]

### Version 0.4.0 - 04 February 2026
- Automated release of [eeacms/msfd-backend:5.2.13-6](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`89297e76`](https://github.com/eea/helm-charts/commit/89297e76a9fce303ae5f22a6a963f4121a2a77aa)]

### Version 0.3.0 - 30 January 2026
- Automated release of [eeacms/msfd-backend:5.2.13-5](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`f453f435`](https://github.com/eea/helm-charts/commit/f453f4350043a4bbc829821eadcdf0e15dc2b69e)]

### Version 0.2.0 - 29 January 2026
- Automated release of [eeacms/msfd-backend:5.2.13-4](https://github.com/eea/msfd-backend/releases) [EEA Jenkins - [`26db93d1`](https://github.com/eea/helm-charts/commit/26db93d12c5d8a6d77e8736b29e44a735f7c5f92)]

### Version 0.1.47 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`5ce7488a`](https://github.com/eea/helm-charts/commit/5ce7488a023979ad9929f5b0d4a4e2beb85130b8)]

### Version 0.1.46 - 15 January 2026
- fix plone cache [Dobricean Ioan Dorian - [`6c2593c0`](https://github.com/eea/helm-charts/commit/6c2593c019c9fadbc85671cc8eb7c95159a58b66)]

### Version 0.1.44 - 15 January 2026
- fix pvc [Dobricean Ioan Dorian - [`c3332461`](https://github.com/eea/helm-charts/commit/c333246137162c6b44764f518149812dcafa4d6c)]

### Version 0.1.42 - 15 January 2026
- fix pvc claims [Dobricean Ioan Dorian - [`d9b7f71c`](https://github.com/eea/helm-charts/commit/d9b7f71c5e01e85bcf375b405d78d733900f8a14)]

### Version 0.1.40 - 14 January 2026
- fix ingress [Dobricean Ioan Dorian - [`cc3fcbee`](https://github.com/eea/helm-charts/commit/cc3fcbee46ff344a12e599f170c5d1478a06cc9b)]

### Version 0.1.38 - 30 December 2025
- change varnish image [Dobricean Ioan Dorian - [`7e9c99e0`](https://github.com/eea/helm-charts/commit/7e9c99e04b50859d6a0441ab29cdb2ce365b053f)]

### Version 0.1.22 - 28 December 2025
- fix ingress [Dobricean Ioan Dorian - [`8996367e`](https://github.com/eea/helm-charts/commit/8996367eaeb97ad21e000fb6418b2eb894621e84)]

### Version 0.1.20 - 28 December 2025
- fix theme ingress [Dobricean Ioan Dorian - [`852b2234`](https://github.com/eea/helm-charts/commit/852b2234f0364cc0ce26e0812f914c66a7a4a677)]

### Version 0.1.18 - 24 December 2025
- fix [Dobricean Ioan Dorian - [`53fa8c57`](https://github.com/eea/helm-charts/commit/53fa8c5761884b82f20f60bb1d303663950b777b)]

### Version 0.1.17 - 24 December 2025
- fix [Dobricean Ioan Dorian - [`0c6fc14c`](https://github.com/eea/helm-charts/commit/0c6fc14c53ce41bff05ac93d7bcd615f62b01222)]

### Version 0.1.16 - 23 December 2025
- fix memcached [Dobricean Ioan Dorian - [`2616a7af`](https://github.com/eea/helm-charts/commit/2616a7af6a0140c5b6268a94321da73dbc169f44)]

### Version 0.1.15 - 23 December 2025
- fix [Dobricean Ioan Dorian - [`a64a1b68`](https://github.com/eea/helm-charts/commit/a64a1b68e7622ae8378b9741cfef5d2e96efe83a)]

### Version 0.1.14 - 23 December 2025
- fix command [Dobricean Ioan Dorian - [`4145f9a6`](https://github.com/eea/helm-charts/commit/4145f9a64057466df4aa79a393ee31fe20538fba)]

### Version 0.1.13 - 23 December 2025
- fix zeo command [Dobricean Ioan Dorian - [`c4ce68dc`](https://github.com/eea/helm-charts/commit/c4ce68dc80fffbec43268d3b7cb39bea5e23c93d)]

### Version 0.1.12 - 23 December 2025
- fix zeo image [Dobricean Ioan Dorian - [`ce92b508`](https://github.com/eea/helm-charts/commit/ce92b5088e1e50254000020e9668782c5d8012d1)]

### Version 0.1.11 - 23 December 2025
- exterlname [Dobricean Ioan Dorian - [`8811a5db`](https://github.com/eea/helm-charts/commit/8811a5dbed8563300428d72dc555837e4a970392)]

### Version 0.1.10 - 22 December 2025
- fix service name [Dobricean Ioan Dorian - [`6ae338f4`](https://github.com/eea/helm-charts/commit/6ae338f42b2b39051c811048ce16496861727619)]

### Version 0.1.9 - 22 December 2025
- fix backend msfd [Dobricean Ioan Dorian - [`eb552570`](https://github.com/eea/helm-charts/commit/eb5525702191d620f30e5941e039ed2e8de36399)]

### Version 0.1.8 - 22 December 2025
- fix port [Dobricean Ioan Dorian - [`45c33604`](https://github.com/eea/helm-charts/commit/45c33604f12cfc6947884d390b7b59ad79386024)]

### Version 0.1.7 - 22 December 2025
- fix [Dobricean Ioan Dorian - [`c072beae`](https://github.com/eea/helm-charts/commit/c072beae84d4b4c085138b1e2a34d78a6bf1de3e)]

### Version 0.1.6 - 22 December 2025
- remove zeo command [Dobricean Ioan Dorian - [`7c238c75`](https://github.com/eea/helm-charts/commit/7c238c7544c86c40c37b461bd4f74cc901c01f60)]

### Version 0.1.5 - 22 December 2025
- fix marine zeo [Dobricean Ioan Dorian - [`a2f27804`](https://github.com/eea/helm-charts/commit/a2f27804e67e277a3b05fe57dda4576cc549ee35)]

### Version 0.1.4 - 22 December 2025
- fix [Dobricean Ioan Dorian - [`a65aacbd`](https://github.com/eea/helm-charts/commit/a65aacbdc417a8c460ef5f90da2144b80b17f85d)]

### Version 0.1.3 - 22 December 2025
- change zeo mode in zeoserver [Dobricean Ioan Dorian - [`b5c70c0e`](https://github.com/eea/helm-charts/commit/b5c70c0ee4c6661c02fcfe0a9df8419a0988eec3)]

### Version 0.1.2 - 22 December 2025
- fix memchached zeo [Dobricean Ioan Dorian - [`1dd12f44`](https://github.com/eea/helm-charts/commit/1dd12f4476795b9fbbaceeef02ed3aeb02f0e8b1)]

### Version 0.1.1 - 22 December 2025
- zeo configuration [Dobricean Ioan Dorian - [`1aab59ab`](https://github.com/eea/helm-charts/commit/1aab59ab931ea298da794b85220b7426a5fa2363)]

### Version 0.1.0 - 22 December 2025
- Initial release based on marine-backend chart
- Configured for /marine/assessment-module path
