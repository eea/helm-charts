# Dependency updates (when subchart versions are bumped)
* If updating subcharts, you need to run this before committing!
* cd charts/onyx
* helm dependency update .

# Local testing

## One time setup
* brew install kind
* Ensure you have no config at ~/.kube/config
* kind create cluster
* mv ~/.kube/config ~/.kube/kind-config

## Automated install and test with ct
* export KUBECONFIG=~/.kube/kind-config
* kubectl config use-context kind-kind
* from source root run the following. This does a very basic test against the web server
  * ct install --all --helm-extra-set-args="--set=nginx.enabled=false" --debug --config ct.yaml

## Output template to file and inspect
* cd charts/onyx
* helm template test-output . > test-output.yaml

## Test the entire cluster manually
* cd charts/onyx
* helm install onyx . -n onyx --set postgresql.primary.persistence.enabled=false
  * the postgres flag is to keep the storage ephemeral for testing. You probably don't want to set that in prod.
  * no flag for ephemeral vespa storage yet, might be good for testing
* kubectl -n onyx port-forward service/onyx-nginx 8080:80
  * this will forward the local port 8080 to the installed chart for you to run tests, etc.
* When you are finished
  * helm uninstall onyx -n onyx
  * Vespa leaves behind a PVC. Delete it if you are completely done.
    * k -n onyx get pvc
    * k -n onyx delete pvc vespa-storage-da-vespa-0
  * If you didn't disable Postgres persistence earlier, you may want to delete that PVC too.

## Run as non-root user
By default, some onyx containers run as root. If you'd like to explicitly run the onyx containers as a non-root user, update the values.yaml file for the following components:
  * `celery_shared`, `api`, `webserver`, `indexCapability`, `inferenceCapability`
    ```yaml
    securityContext:
      runAsNonRoot: true
      runAsUser: 1001
    ```
  * `vespa`
    ```yaml
    podSecurityContext:
      fsGroup: 1000
    securityContext:
      privileged: false
      runAsUser: 1000
    ```

## Resourcing
In the helm charts, we have resource suggestions for all Onyx-owned components. 
These are simply initial suggestions, and may need to be tuned for your specific use case.

Please talk to us in Slack if you have any questions!

## Autoscaling options
The chart renders Kubernetes HorizontalPodAutoscalers by default. To keep this behavior, leave
`autoscaling.engine` as `hpa` and adjust the per-component `autoscaling.*` values as needed.

If you would like to use KEDA ScaledObjects instead:

1. Install and manage the KEDA operator in your cluster yourself (for example via the official KEDA Helm chart). KEDA is no longer packaged as a dependency of the Onyx chart.
2. Set `autoscaling.engine: keda` in your `values.yaml` and enable autoscaling for the components you want to scale.

When `autoscaling.engine` is set to `keda`, the chart will render the existing ScaledObject templates; otherwise HPAs will be rendered.


## Releases

### Version 0.32.1 - 23 September 2026
- Data caches are now configured per service through a `caches` block (`hf`, `tiktoken`, `nltk`) on api, celery_beat, every celery worker, the model servers, slackbot, discordbot and mcpServer. Mount paths stay shared under `hfCache` / `tiktokenCache` / `nltkCache`, so every service sees the same location.
- Added `nltkCache` (emptyDir at `/usr/share/nltk_data`, seeded by `hf-cache-init` when the image ships data). The model servers disable it by default because the model_server image has no `nltk`.
- `HF_HOME`, `TIKTOKEN_CACHE_DIR` and `NLTK_DATA` moved out of the shared `configMap` and are set per pod, only for the caches that service mounts. Optional `caches.xdgCacheHome` sets `XDG_CACHE_HOME`.

### Version 0.32.0 - 11 September 2026
- Automated release of [eeacms/danswer:v4.3.9-eea.0.0.118-dev](https://github.com/eea/danswer/releases) [EEA Jenkins - [`77092aab`](https://github.com/eea/helm-charts/commit/77092aabb27102edebc10ec6c5ac7f6c8f37f9d0)]

### Version 0.13.0 - 28 July 2026
- Automated release of [eeacms/danswer:v4.3.9-eea.0.0.117-dev](https://github.com/eea/danswer/releases) [EEA Jenkins - [`805780b2`](https://github.com/eea/helm-charts/commit/805780b2ba14474fe92e7a905b38603bda8ca311)]

### Version 0.12.0 - 28 July 2026
- Automated release of [eeacms/danswer:v4.3.9-eea.0.0.116-dev](https://github.com/eea/danswer/releases) [EEA Jenkins - [`c18c46d0`](https://github.com/eea/helm-charts/commit/c18c46d0d3c92d15bfa24fda7bcd52fb2e9661b4)]

### Version 0.11.0 - 27 July 2026
- Automated release of [eeacms/danswer:v4.3.9-eea.0.0.115-dev](https://github.com/eea/danswer/releases) [EEA Jenkins - [`1895f1eb`](https://github.com/eea/helm-charts/commit/1895f1ebc327c425e0ccb3192d3fa61e7f656aa1)]

### Version 0.10.0 - 20 July 2026
- Automated release of [eeacms/danswer:v4.3.9-eea.0.0.114-dev](https://github.com/eea/danswer/releases) [EEA Jenkins - [`777071c7`](https://github.com/eea/helm-charts/commit/777071c73e6cda7246cb0deab4b504f95ec63cd7)]

### Version 0.9.0 - 01 July 2026
- Automated release of [eeacms/danswer:v3.2.1-eea.0.0.115](https://github.com/eea/danswer/releases) [EEA Jenkins - [`a9b4931a`](https://github.com/eea/helm-charts/commit/a9b4931a3bd909f2e865b9135f64cebfa5dbab93)]

### Version 0.8.0 - 01 July 2026
- Automated release of [eeacms/danswer:v3.2.1-eea.0.0.114](https://github.com/eea/danswer/releases) [EEA Jenkins - [`cc7a0327`](https://github.com/eea/helm-charts/commit/cc7a03278a0b92136aaad1c358d4a86908553f3a)]

### Version 0.7.1 - 03 June 2026
- Update nginx to 1.31.1 - Refs [#304237](https://taskman.eionet.europa.eu/issues/304237) [valentinab25 - [`635e2f4a`](https://github.com/eea/helm-charts/commit/635e2f4a87783ecd8352f4fdc4acc66578c87e2d)]

### Version 0.7.0 - 20 May 2026
- Automated release of [eeacms/danswer:v3.2.1-eea.0.0.112-dev](https://github.com/eea/danswer/releases) [EEA Jenkins - [`3876fa70`](https://github.com/eea/helm-charts/commit/3876fa70ad8af933ef45fa035ad1d5e8ac4a0c41)]

### Version 0.6.0 - 20 May 2026
- Automated release of [eeacms/danswer:v3.2.1-eea.0.0.111-dev](https://github.com/eea/danswer/releases) [EEA Jenkins - [`17b83c12`](https://github.com/eea/helm-charts/commit/17b83c124733c3eb75300a6f94a6604fd07075b2)]

### Version 0.5.3 - 14 May 2026
- Added postfix upgrade compatibility hook (pre-upgrade cleanup of legacy `onyx-postfix` Deployment selector conflicts), then fixed hook execution by running `kubectl` directly (no `/bin/sh` dependency) and by honoring explicit `postfix.upgradeCompatibility.cleanupLegacyDeploymentSelector: false`.
- Kept image tag resolution from Chart `appVersion` (`global.version: ""`) and fixed 01dev nginx rate-limiting typo (`enabled: true`).
- Added optional shared HuggingFace cache support (`hfCache.*`): globally disabled by default, opt-in PVC + mounts for API/indexing/inference at `/usr/share/huggingface`, with optional seed Job.
- Seed Job now follows chart versioning/image conventions (`global.image.repository` + model-server tag fallback from `global.image.tags.modelServer` to `model_server-<appVersion/global.version>`), with pull behavior tunables for large images.
- Fixed PostgreSQL backup CronJob container resources rendering to use valid Kubernetes schema (`resources.requests/limits`) and remove upgrade warnings.

### Version 0.5.2 - 14 May 2026
- Added MCP server (deployment, service, ingress) and Discord bot deployment
- Added pgInto tooling ConfigMap with psql script mounting helpers
- Added Celery worker `user-files-indexing` (deployment, HPA, ScaledObject)
- Added Prometheus ServiceMonitor templates for all Celery workers
- Added Redis chart dependency (redis v0.16.6) with Redis standalone config (`redis.redisStandalone.name`)
- Added `auth.opensearch` secret config with admin password validation
- Added `securityEnabled` flag to values.yaml
- Added `auth.userauth` secret for password reset / verification tokens and OAuth/OIDC state signing
- Default `global.version` set to `v2.3.0-eea.0.0.90-dev`; default `vespa.enabled` set to `true`
- PostgreSQL defaults updated: `nameOverride: cloudnative-pg`, 1 instance, 10Gi storage, superuser access
- Network policies tightened: removed egress to OpenSearch (9200) and HTTPS/80 from most services
- Added cert-manager network policy for HTTP-01 solver matching sonarqube/matomo pattern
- Added ingress-nginx dependency (v4.13.3)
- Refactored `_helpers.tpl`: removed `onyx.autoscaling.engine` and `onyx.version` helpers; added `onyx.pgInto.*` helpers
- Updated HPA/ScaledObject templates across all Celery worker deployments
- Updated PostgreSQL backup cronjob, restore job, and statefulset templates

### Version 0.5.0 - 22 April 2026
- Set chart `appVersion` to `v3.2.1-eea.0.0.106-dev` and keep image tag resolution automatic from chart appVersion when `global.version` is empty.
- Added Vespa migration fix support:
  - optional Vespa deploy proxy (`vespa.deployProxy.*`) that appends `ignoreValidationErrors=true` for `prepareandactivate`.
  - optional no-op ranksetup verification ConfigMap (`vespa.migrationFix.*`) for migration windows.
  - automatic `VESPA_HOST` switch to deploy-proxy service when proxy is enabled.
- Added upstream monitoring integration:
  - optional Grafana dashboard ConfigMap via `monitoring.grafana.dashboards.enabled`.
- Added upstream Code Interpreter integration:
  - `codeInterpreter` dependency and `CODE_INTERPRETER_BASE_URL` env wiring.
  - network policy rules for API/Celery egress to port `8000` and Code Interpreter ingress from backend pods.
- Updated dev values to mount `vespa-verify-ranksetup-bin` from `vespa-noop-verify` ConfigMap and enable the deploy proxy.
- OpenSearch migration note: if API startup fails on `... requires setting [index.knn]`, delete stale old-format index so Onyx can recreate it with k-NN settings.

### Vespa Migration Fix (Documents Migration)

Use this only during Vespa document/schema migration windows:

1. Enable `vespa.migrationFix.enabled: true` to create `vespa-noop-verify`.
2. Mount `vespa-verify-ranksetup-bin` into Vespa at `/opt/vespa/bin/vespa-verify-ranksetup-bin`.
3. Enable `vespa.deployProxy.enabled: true` and point `VESPA_HOST` to the proxy (handled automatically by the chart).
4. Upgrade chart and restart API if needed.

Verification checks:
- `kubectl -n <ns> get deploy <release>-onyx-stack-api-server`
- `kubectl -n <ns> get deploy vespa-deploy-proxy` (or custom proxy name)
- `kubectl -n <ns> get cm vespa-noop-verify`
- `kubectl -n <ns> exec deploy/<release>-onyx-stack-api-server -- wget -qO- http://localhost:8080/health`

### Version 0.4.12 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`db97375f`](https://github.com/eea/helm-charts/commit/db97375fccb5b7460fb4809d77e3092727ff2848)]
