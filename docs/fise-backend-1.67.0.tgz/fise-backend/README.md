# Forest Information System of Europe website backend - Plone 6

This chart deployes the Forest Information System of Europe website backend app

## Values

| Key           | Type | Default | Description                       |
| ------------- | ---- | ------- | --------------------------------- |
| debug.enabled | bool | false   | Activate the Plone debug instance |

## Releases

### Version 1.67.0 - 26 September 2026
- Automated release of [eeacms/fise-backend:6.1.4-23](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`05eeb1e1`](https://github.com/eea/helm-charts/commit/05eeb1e113c096a88e41736a3849ad4f671cc1d7)]

### Version 1.66.0 - 18 September 2026
- Automated release of [eeacms/fise-backend:6.1.4-22](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`aa3cdc31`](https://github.com/eea/helm-charts/commit/aa3cdc318a39397da768adb9c28bac6e67e15943)]

### Version 1.65.2 - 04 September 2026
- chore: Refs [#305742](https://taskman.eionet.europa.eu/issues/305742) - reduce kept failed cronjob pods from 5 to 1 [Claudia Ifrim - [`4dabbbdd`](https://github.com/eea/helm-charts/commit/4dabbbdd8b46cd363729a2369c11165d1db8a73a)]

### Version 1.65.1 - 26 August 2026
- removed the unused RAZZLE_PROXY_ES_DSN_globalsea [Claudia Ifrim - [`48e9e929`](https://github.com/eea/helm-charts/commit/48e9e929305cd77f534b3d095fa9027b70cc8a53)]

### Version 1.65.0 - 24 August 2026
- Automated release of [eeacms/fise-backend:6.1.4-21](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`eecfa1e9`](https://github.com/eea/helm-charts/commit/eecfa1e9a5af0a72b9bc7ee4d91bfd550d09e425)]

### Version 1.64.0 - 08 August 2026
- Automated release of [eeacms/fise-backend:6.1.4-20](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`dcf7577c`](https://github.com/eea/helm-charts/commit/dcf7577c2264f63657f67d6ed4edb82ee2633149)]

### Version 1.63.0 - 07 August 2026
- Automated release of [eeacms/fise-backend:6.1.4-19](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`387077b7`](https://github.com/eea/helm-charts/commit/387077b7a203277d5ac5f23f4541e81899ed11bf)]

### Version 1.62.0 - 06 August 2026
- Automated release of [eeacms/fise-backend:6.1.4-18](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`e18ed389`](https://github.com/eea/helm-charts/commit/e18ed389c2c463eee9a83fb3a557df71e8062dda)]

### Version 1.61.0 - 29 July 2026
- Automated release of [eeacms/fise-backend:6.1.4-17](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`0db1d3ea`](https://github.com/eea/helm-charts/commit/0db1d3ea086570d2d87ea73226e8789691ea80c6)]

### Version 1.60.0 - 15 July 2026
- Automated release of [eeacms/fise-backend:6.1.4-16](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`be1ef132`](https://github.com/eea/helm-charts/commit/be1ef132d335a438a615caefba72e9d51e074b37)]

### Version 1.59.0 - 14 July 2026
- Automated release of [eeacms/fise-backend:6.1.4-15](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`821b5148`](https://github.com/eea/helm-charts/commit/821b5148e35e944b23c76afa7e1a3e7a66b89fb2)]

### Version 1.58.0 - 11 July 2026
- Automated release of [eeacms/fise-backend:6.1.4-14](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`80956964`](https://github.com/eea/helm-charts/commit/80956964aff56243159472065a8420456cf91008)]

### Version 1.57.0 - 25 June 2026
- Automated release of [eeacms/fise-backend:6.1.4-11](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`74b788fb`](https://github.com/eea/helm-charts/commit/74b788fb7e20a9a0a337248d68b942624a87bb9a)]

### Version 1.56.0 - 18 June 2026
- Automated release of [eeacms/fise-backend:6.1.4-10](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`0eee1ef9`](https://github.com/eea/helm-charts/commit/0eee1ef97610243aefb532702a048f854d1177af)]

### Version 1.55.0 - 18 June 2026
- Automated release of [eeacms/fise-backend:6.1.4-9](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`f523a1f5`](https://github.com/eea/helm-charts/commit/f523a1f5ec4c0e7ab140eb6dcb5c956c2a7d3198)]

### Version 1.54.1 - 16 June 2026
- increase cpu for cronjobs [Dobricean Ioan Dorian - [`fffa2d10`](https://github.com/eea/helm-charts/commit/fffa2d10188763527cc0471df523f15664a82e00)]

### Version 1.54.0 - 10 June 2026
- Automated release of [eeacms/fise-backend:6.1.4-8](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`13154775`](https://github.com/eea/helm-charts/commit/1315477546a36bc776c523cb6e73719869ff899e)]

### Version 1.53.2 - 08 June 2026
- fix entrasync active deadline [Dobricean Ioan Dorian - [`1ca40c60`](https://github.com/eea/helm-charts/commit/1ca40c6066cd6876a46d5b8c878cc6ec8bab0dfe)]

### Version 1.53.1 - 08 June 2026
- Fix Entra sync CronJob history limits and add a 10h active deadline for stuck Jobs

### Version 1.53.0 - 04 June 2026
- Automated release of [eeacms/fise-backend:6.1.4-7](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`892760bb`](https://github.com/eea/helm-charts/commit/892760bb0077522705beb5594d2265a74b73ab77)]

### Version 1.52.1 - 29 May 2026
- Add IPC_LOCK [valentinab25 - [`ab5dcf69`](https://github.com/eea/helm-charts/commit/ab5dcf69ec2f4d4803a71a4375ec4a02cff9c3b2)]

### Version 1.52.0 - 22 May 2026
- Automated release of [eeacms/fise-backend:6.1.4-5](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`c1ad1e42`](https://github.com/eea/helm-charts/commit/c1ad1e42df207e02609707f7fcce07fb39f0fff8)]

### Version 1.51.0 - 13 May 2026
- Automated release of [eeacms/fise-backend:6.1.4-4](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`f76e057e`](https://github.com/eea/helm-charts/commit/f76e057e40882ed4a9982128b14d88066b61b549)]

### Version 1.50.0 - 08 May 2026
- Automated release of [eeacms/fise-backend:6.1.4-3](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`fc152f95`](https://github.com/eea/helm-charts/commit/fc152f95205a12bb2062bc71548bc3bd0de05520)]

### Version 1.49.0 - 29 April 2026
- Automated release of [eeacms/fise-backend:6.1.4-2](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`f3bb131a`](https://github.com/eea/helm-charts/commit/f3bb131a79ad4437e2839470dcd4dbd01cc9e0c4)]

### Version 1.48.0 - 29 April 2026
- Automated release of [eeacms/fise-backend:6.1.4-1](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`f7cf6cc8`](https://github.com/eea/helm-charts/commit/f7cf6cc8f88c2c3380cf2e21bf5459ce6ca4caf8)]

### Version 1.47.0 - 22 April 2026
- Automated release of [eeacms/fise-backend:6.1.3-23](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`f29c512a`](https://github.com/eea/helm-charts/commit/f29c512abe8013eb44f1dca761eb9240bd614124)]

### Version 1.46.0 - 18 April 2026
- Automated release of [eeacms/fise-backend:6.1.3-22](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`c8adf7b1`](https://github.com/eea/helm-charts/commit/c8adf7b1849150def1821fa937543ea52ee231e0)]

### Version 1.45.0 - 17 April 2026
- Automated release of [eeacms/fise-backend:6.1.3-21](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`4856988a`](https://github.com/eea/helm-charts/commit/4856988a402bbf548710276dab6f8a1905a14160)]

### Version 1.44.1 - 16 April 2026
- fix postgres [Dobricean Ioan Dorian - [`ec7ff866`](https://github.com/eea/helm-charts/commit/ec7ff866c3ea3e63d884ca52c0fa31afdfc68dd5)]

### Version 1.44.0 - 16 April 2026
- Automated release of [eeacms/fise-backend:6.1.3-20](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`4a1dc5d4`](https://github.com/eea/helm-charts/commit/4a1dc5d4da03cd742427f362dbb6359005d981d5)]

### Version 1.43.0 - 15 April 2026
- Automated release of [eeacms/fise-backend:6.1.3-19](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`e6f19a28`](https://github.com/eea/helm-charts/commit/e6f19a28cdd14e1999e21a8650f41a38305eaadc)]

### Version 1.42.0 - 26 March 2026
- Automated release of [eeacms/fise-backend:6.1.3-18](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`9a6ce7a9`](https://github.com/eea/helm-charts/commit/9a6ce7a90d6d501473aa82a3daee5286d6d645a7)]

### Version 1.41.0 - 17 March 2026
- Automated release of [eeacms/fise-backend:6.1.3-17](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`b29a1248`](https://github.com/eea/helm-charts/commit/b29a1248756f3b2566a74738f78e20a645f3d98c)]

### Version 1.40.0 - 12 March 2026
- Automated release of [eeacms/fise-backend:6.1.3-16](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`ef496962`](https://github.com/eea/helm-charts/commit/ef4969622119be6c31125085e4395bea876ab1a7)]

### Version 1.39.0 - 07 March 2026
- Automated release of [eeacms/fise-backend:6.1.3-15](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`1cf216a5`](https://github.com/eea/helm-charts/commit/1cf216a52276eb89226149c6e563f5ce6cae6fea)]

### Version 1.38.0 - 05 March 2026
- Automated release of [eeacms/fise-backend:6.1.3-14](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`8f030acd`](https://github.com/eea/helm-charts/commit/8f030acded42792464e74cefd2ec2db51365d670)]

### Version 1.37.0 - 25 February 2026
- Automated release of [eeacms/fise-backend:6.1.3-13](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`d018c195`](https://github.com/eea/helm-charts/commit/d018c195f3cc2049ebd6dd5f95707483b7b611e8)]

### Version 1.36.0 - 06 February 2026
- Automated release of [eeacms/fise-backend:6.1.3-12](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`b5a79ebf`](https://github.com/eea/helm-charts/commit/b5a79ebf6a5398923201a46b90b5c3ef78858591)]

### Version 1.35.0 - 28 January 2026
- Automated release of [eeacms/fise-backend:6.1.3-11](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`fb03d2de`](https://github.com/eea/helm-charts/commit/fb03d2de7f286c0341567d4e607aa13a197bd742)]

### Version 1.34.0 - 28 January 2026
- Automated release of [eeacms/fise-backend:6.1.3-10](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`15ccd788`](https://github.com/eea/helm-charts/commit/15ccd7888302eb87245978406c3f85cc0534d887)]

### Version 1.33.0 - 21 January 2026
- Automated release of [eeacms/fise-backend:6.1.3-9](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`dc197433`](https://github.com/eea/helm-charts/commit/dc19743352469d5439b7ee2ce4087dcb91d47712)]

### Version 1.32.0 - 21 January 2026
- Automated release of [eeacms/fise-backend:6.1.3-8](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`4beb0430`](https://github.com/eea/helm-charts/commit/4beb043098b7784c25fa326706c5259be1692338)]

### Version 1.31.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`ff620e8c`](https://github.com/eea/helm-charts/commit/ff620e8cc9e245654ee4fa216633230c16ac6282)]

### Version 1.31.0 - 23 December 2025
- Automated release of [eeacms/fise-backend:6.1.3-7](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`cdff0082`](https://github.com/eea/helm-charts/commit/cdff008274abcbb6bda453ed3207d2fc8b3d8db3)]

### Version 1.30.0 - 22 December 2025
- Automated release of [eeacms/fise-backend:6.1.3-5](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`7f5605b0`](https://github.com/eea/helm-charts/commit/7f5605b078c8e8e4fdc6c4c58b119051b3899e4f)]

### Version 1.29.1 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`62034331`](https://github.com/eea/helm-charts/commit/6203433193a58f6511dcd5dfa93d215b3baff443)]

### Version 1.29.0 - 04 December 2025
- Automated release of [eeacms/fise-backend:6.1.3-4](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`11d949e4`](https://github.com/eea/helm-charts/commit/11d949e4a3d8a0b02557d6c5fb9352b4048ab712)]

### Version 1.28.0 - 22 November 2025
- Automated release of [eeacms/fise-backend:6.1.3-3](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`4b886870`](https://github.com/eea/helm-charts/commit/4b886870735db8ffef83f4a558729d6e73c7fbf9)]

### Version 1.27.0 - 19 November 2025
- Automated release of [eeacms/fise-backend:6.1.3-2](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`278f60c5`](https://github.com/eea/helm-charts/commit/278f60c5bc6d279294badfd23711a714047a4811)]

### Version 1.26.0 - 19 November 2025
- Automated release of [eeacms/fise-backend:6.1.3-1](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`de6dc65b`](https://github.com/eea/helm-charts/commit/de6dc65bccfc47039453793e21bd90fdb6a04968)]

### Version 1.25.0 - 25 October 2025
- Automated release of [eeacms/fise-backend:6.0.15-27](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`18b5ca70`](https://github.com/eea/helm-charts/commit/18b5ca706e8be3d71b5ed487cf4ab1310e6ff226)]

### Version 1.24.0 - 08 October 2025
- Automated release of [eeacms/fise-backend:6.0.15-25](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`472e1801`](https://github.com/eea/helm-charts/commit/472e1801797682b6393a3c7c64c5f7fddf703ebb)]

### Version 1.23.0 - 28 August 2025
- Automated release of [eeacms/fise-backend:6.0.15-24](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`f656db2b`](https://github.com/eea/helm-charts/commit/f656db2be01a0116a421a40adc95b0121b19515d)]

### Version 1.22.1 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`4b711c9f`](https://github.com/eea/helm-charts/commit/4b711c9f9e430051d173721c710cb21997feba31)]

### Version 1.22.0 - 20 August 2025
- Automated release of [eeacms/fise-backend:6.0.15-21](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`a6fa5e9e`](https://github.com/eea/helm-charts/commit/a6fa5e9e2c43ede4c7445c555c5473187fc584ed)]

### Version 1.21.0 - 20 August 2025
- Automated release of [eeacms/fise-backend:6.0.15-20](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`e6c6d440`](https://github.com/eea/helm-charts/commit/e6c6d440d3bb3589229aca547bea28182ae5aa67)]

### Version 1.20.0 - 20 August 2025
- Automated release of [eeacms/fise-backend:6.0.15-19](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`53b9c316`](https://github.com/eea/helm-charts/commit/53b9c31671eeb4e5eb6e69ed06a816f07626967e)]

### Version 1.19.0 - 11 August 2025
- Automated release of [eeacms/fise-backend:6.0.15-18](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`70799a98`](https://github.com/eea/helm-charts/commit/70799a98a00500cc9d1c620772bc9640c2424c3b)]

### Version 1.18.0 - 05 August 2025
- Automated release of [eeacms/fise-backend:6.0.15-17](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`0f915a2a`](https://github.com/eea/helm-charts/commit/0f915a2a6427f7bd07bb8adfa0e7046fba794cdc)]

### Version 1.17.0 - 05 August 2025
- Automated release of [eeacms/fise-backend:6.0.15-16](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`e72160b8`](https://github.com/eea/helm-charts/commit/e72160b83021da68f4ec37f5204a55782c0722fa)]

### Version 1.16.0 - 01 August 2025
- Automated release of [eeacms/fise-backend:6.0.15-15](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`97f50467`](https://github.com/eea/helm-charts/commit/97f50467a5ee76a8010d5697d4af70ce3cb12993)]

### Version 1.15.1 - 01 August 2025
- Automated release of [eeacms/plone-varnish:7.7-1.1](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`362fdc52`](https://github.com/eea/helm-charts/commit/362fdc52b92e41974aaba0287dd51d1bcb3ba2d0)]

### Version 1.15.0 - 24 July 2025
- Automated release of [eeacms/fise-backend:6.0.15-14](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`0d0f2f5f`](https://github.com/eea/helm-charts/commit/0d0f2f5f71c049e40cd2916de46bfe38c435bae7)]

### Version 1.14.0 - 23 July 2025
- Automated release of [eeacms/fise-backend:6.0.15-13](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`157db687`](https://github.com/eea/helm-charts/commit/157db6876a647f8226e3f1cc138a72fef1bf6e70)]

### Version 1.13.0 - 12 June 2025
- Automated release of [eeacms/fise-backend:6.0.15-12](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`254ae13`](https://github.com/eea/helm-charts/commit/254ae133c536089109cf95f3838130104cadee55)]

### Version 1.12.0 - 11 June 2025
- Automated release of [eeacms/fise-backend:6.0.15-11](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`5725d6a`](https://github.com/eea/helm-charts/commit/5725d6af02541fddd2972fb3bfd2b45c3d5f80f3)]

### Version 1.11.0 - 03 June 2025
- Automated release of [eeacms/fise-backend:6.0.15-10](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`8e85576`](https://github.com/eea/helm-charts/commit/8e855769b0866411597448c3ef146814f9b48fde)]

### Version 1.10.0 - 28 May 2025
- Automated release of [eeacms/fise-backend:6.0.15-9](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`e2a2cc6`](https://github.com/eea/helm-charts/commit/e2a2cc644166f9186ae13289d92ce35045becd3f)]

### Version 1.9.0 - 21 May 2025
- Automated release of [eeacms/fise-backend:6.0.15-8](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`6ca322e`](https://github.com/eea/helm-charts/commit/6ca322e8ce466a3ee28e32ce7b948a3d29b9b32d)]

### Version 1.8.1 - 21 May 2025
- Automated release of [eeacms/plone-varnish:7.7-1.0](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`8d0fc00`](https://github.com/eea/helm-charts/commit/8d0fc009a6b743d7e5d31a92fc488102d1e692b0)]

### Version 1.8.0 - 07 May 2025
- Automated release of [eeacms/fise-backend:6.0.15-7](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`71886ef`](https://github.com/eea/helm-charts/commit/71886ef42e9bc09b10e2c030e2d1d16fd0559752)]

### Version 1.7.0 - 28 April 2025
- Automated release of [eeacms/fise-backend:6.0.15-5](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`00c4a19`](https://github.com/eea/helm-charts/commit/00c4a1913b37263a3f0fef5aa36b81f1e1b78837)]

### Version 1.6.0 - 25 April 2025
- Automated release of [eeacms/fise-backend:6.0.15-4](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`a7bda51`](https://github.com/eea/helm-charts/commit/a7bda5106c2a22e0afa34781ebac3ae7ea0f6c3b)]

### Version 1.5.0 - 13 April 2025
- Automated release of [eeacms/fise-backend:6.0.15-3](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`40d311b`](https://github.com/eea/helm-charts/commit/40d311bb35b10f36ecce82643bc9a9adadf0d47d)]

### Version 1.4.0 - 11 April 2025
- Automated release of [eeacms/fise-backend:6.0.15-2](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`541ff5f`](https://github.com/eea/helm-charts/commit/541ff5f3757220de7481220ac68c6e50b872fdd2)]

### Version 1.3.0 - 09 April 2025
- Automated release of [eeacms/fise-backend:6.0.15-1](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`72caf64`](https://github.com/eea/helm-charts/commit/72caf64deff5c4b255c486614bb3c01a5a05534b)]

### Version 1.2.0 - 09 April 2025
- Automated release of [eeacms/fise-backend:6.0.14-1](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`1ce662a`](https://github.com/eea/helm-charts/commit/1ce662a7183d41a6828a49ef580428220eebb6cf)]

### Version 1.1.2 - 09 April 2025
- Add plone.googleUrl variable, fix admin ingress Refs [#286358](https://taskman.eionet.europa.eu/issues/286358) [valentinab25 - [`727ffbf`](https://github.com/eea/helm-charts/commit/727ffbf03de5d20de70fe70da7fb4553b0052dc2)]

### Version 1.1.1 - 08 April 2025
- Add plone.site variable, rewrite api-ingress using snippet [valentinab25 - [`abb241e`](https://github.com/eea/helm-charts/commit/abb241e489d9e3c6c3e131e331df9985fbc4fb3a)]

### Version 1.1.0 - 01 April 2025
- Automated release of [eeacms/fise-backend:6.0.13-23](https://github.com/eea/fise-backend/releases) [EEA Jenkins - [`1716746`](https://github.com/eea/helm-charts/commit/1716746e78fef0df4209a1228268bf33a8f70259)]

### Version 1.0.2 - 20 March 2025
- Add ingress.tls variable, empty certificate name for default [valentinab25 - [`5cceb9b`](https://github.com/eea/helm-charts/commit/5cceb9b60d74a9d703476694a250d0cd2a38c252)]

### Version 1.0.0

- Initial release.

### Version 1.0.1

- Update values.
