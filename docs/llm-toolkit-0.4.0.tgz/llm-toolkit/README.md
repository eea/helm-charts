# LLM Toolkit Helm Chart

A comprehensive Kubernetes Helm chart for deploying a complete LLM (Large Language Model) Toolkit with [Langfuse](https://langfuse.com) observability platform and [LiteLLM](https://github.com/BerriAI/litellm) proxy.

## Overview

This Helm chart deploys the following components:

- **Langfuse**: An open-source LLM engineering platform for prompt management, observability, and evaluation
- **LiteLLM** (optional): A unified API for various LLM providers with additional features like routing and load balancing
- **PostgreSQL**: Database for Langfuse and LiteLLM
- **ClickHouse**: Database for Langfuse analytics and event storage
- **Redis**: Cache for Langfuse and LiteLLM
- **MinIO**: Object storage for Langfuse event upload, media storage, and batch exports

## Prerequisites

- Kubernetes 1.19+
- Helm 3.2+
- PV provisioner support in the underlying infrastructure
- Approximately 4-8 GB of RAM available for the complete stack (depending on configuration)

## Installing the Chart

Add the repository (if not already added):
```bash
helm repo add eea https://eea.github.io/helm-charts
helm repo update
```

To install the chart with the release name `llm-toolkit`:
```bash
helm install llm-toolkit eea/llm-toolkit
```

## Configuration

The chart supports a wide range of configuration options. Some key parameters include:

### Timezone Settings

The chart uses a top-level `timezone` parameter for the main containers (defaults to Europe/Copenhagen). When changing this timezone, you must also explicitly set the timezone for each subchart:

```yaml
timezone: Europe/Copenhagen

# Also update timezone in subchart configurations:
postgresql:
  primary:
    extraEnvVars:
      - name: TZ
        value: "Europe/Copenhagen"

redis:
  master:
    extraEnvVars:
      - name: TZ
        value: "Europe/Copenhagen"

clickhouse:
  extraEnvVars:
    - name: TZ
      value: "Europe/Copenhagen"

minio:
  extraEnvVars:
    - name: TZ
      value: "Europe/Copenhagen"
```

### Langfuse Configuration

```yaml
langfuse:
  # Security settings
  salt:
    value: "your-salt-here"  # Used to hash API keys
  encryptionKey:
    value: "your-encryption-key-here"  # Must be 256 bits (64 chars in hex)
  nextauth:
    secret:
      value: "your-nextauth-secret-here"
    url: "https://your-langfuse-domain.com"

  # Optional Enterprise Edition license
  licenseKey:
    value: ""  # Leave empty for Community Edition

  # Feature flags
  features:
    signUpDisabled: false
    telemetryEnabled: true
    experimentalFeaturesEnabled: false

  # Default resource settings
  resources:
    requests:
      cpu: 100m
      memory: 256Mi
    limits:
      cpu: 500m
      memory: 512Mi
```

### LiteLLM Configuration

LiteLLM is disabled by default. To enable it:

```yaml
litellm:
  enabled: true
  masterKey: "your-secure-master-key"
  langfusePublicKey: "pk-your-langfuse-public-key"
  langfuseSecretKey: "sk-your-langfuse-secret-key"

  # Default resource settings
  resources:
    requests:
      cpu: 100m
      memory: 128Mi
    limits:
      cpu: 500m
      memory: 512Mi

  # Optional LLM Guard plugin for content filtering
  llmGuardPlugin:
    enabled: false

  # Health check paths
  livenessProbe:
    httpGet:
      path: /health/liveliness
      port: http
  readinessProbe:
    httpGet:
      path: /health/readiness
      port: http
```

### Database Configurations

You can either deploy the databases as part of the chart or use external databases:

```yaml
postgresql:
  deploy: true  # Set to false to use external PostgreSQL
  port: 5432
  host: ""  # External host (when deploy is false)
  maxConnections: 200  # Raises PostgreSQL max_connections for the bundled database
  args: "?connection_limit=20&pool_timeout=20"  # Optional client-side pool tuning
  auth:
    username: postgres
    password: "secure-password"
    database: postgres_langfuse

clickhouse:
  deploy: true  # Set to false to use external ClickHouse

redis:
  deploy: true  # Set to false to use external Redis
  auth:
    username: "default"
    database: 0
    password: "secure-password"

minio:
  deploy: true  # Set to false to use external S3-compatible storage
```

### Media Upload Configuration

You can configure the MaxIO media upload settings:

```yaml
minio:
  mediaUpload:
    enabled: true
    maxContentLength: 1000000000  # 1GB max file size
    downloadUrlExpirySeconds: 3600  # URLs expire after 1 hour
```

## Resource Requirements

By default, the chart deploys with minimal resource requirements suitable for testing. For production use, you should increase the resources:

```yaml
langfuse:
  resources:
    requests:
      cpu: 500m
      memory: 512Mi
    limits:
      cpu: 2000m
      memory: 1Gi

postgresql:
  primary:
    resources:
      requests:
        memory: 1Gi
        cpu: 1
      limits:
        memory: 2Gi

clickhouse:
  resourcesPreset: 2xlarge  # Adjust based on expected load
```

If you are seeing PostgreSQL saturation, set both the server-side limit and the application-side pool size deliberately. `connection refused` can also indicate the PostgreSQL pod is restarting or not yet ready, so check pod health alongside any connection-limit changes.

## Persistence

The chart configures persistent storage for the databases and MinIO. Default values are 11Gi, but you may want to customize the storage size for production:

```yaml
postgresql:
  primary:
    persistence:
      size: 20Gi

redis:
  master:
    persistence:
      size: 10Gi

clickhouse:
  persistence:
    size: 50Gi

minio:
  persistence:
    size: 50Gi
```

## Networking

To expose the services, you can configure Ingress for both Langfuse and LiteLLM:

```yaml
langfuse:
  ingress:
    enabled: true
    className: nginx
    hosts:
      - host: langfuse.your-domain.com
        paths:
          - path: /
            pathType: ImplementationSpecific

litellm:
  ingress:
    enabled: true
    className: nginx
    hosts:
      - host: litellm.your-domain.com
        paths:
          - path: /
            pathType: Prefix
```

### AI Gateway (API-only) ingress

An optional second ingress exposes only the LLM inference paths on a dedicated host.
Everything not explicitly listed returns 404 (admin UI, `/key/*`, `/v1/model/info`, ...):

```yaml
litellm:
  aigatewayIngress:
    enabled: true
    className: nginx
    host: aigateway.your-domain.com
    annotations:
      nginx.ingress.kubernetes.io/proxy-body-size: 10m
      nginx.ingress.kubernetes.io/proxy-read-timeout: "300"
      nginx.ingress.kubernetes.io/proxy-send-timeout: "300"
      nginx.ingress.kubernetes.io/whitelist-source-range: 10.0.0.0/8
    paths:
      - path: /v1/chat/completions
        pathType: Exact
      - path: /v1/completions
        pathType: Exact
      - path: /v1/messages
        pathType: Exact
      - path: /v1/messages/count_tokens
        pathType: Exact
      - path: /v1/models
        pathType: Prefix
      - path: /v1/responses
        pathType: Prefix
      - path: /v1/embeddings
        pathType: Exact
      - path: /v1/rerank
        pathType: Exact
      - path: /v1/moderations
        pathType: Exact
      - path: /v1/ocr
        pathType: Exact
      - path: /v1/audio/speech
        pathType: Exact
      - path: /v1/audio/transcriptions
        pathType: Exact
      - path: /v1/images/generations
        pathType: Exact
      - path: /v1/images/edits
        pathType: Exact
      - path: /v1/batches
        pathType: Prefix
      - path: /v1/files
        pathType: Prefix
      - path: /v1/model/info
        pathType: Exact
      - path: /v1/model/deprecations
        pathType: Exact
      - path: /health
        pathType: Exact
      - path: /health/liveliness
        pathType: Exact
      - path: /health/liveness
        pathType: Exact
      - path: /health/readiness
        pathType: Exact
    tls:
      - hosts:
          - aigateway.your-domain.com
```

## Uninstalling the Chart

To uninstall/delete the `llm-toolkit` deployment:

```bash
helm delete llm-toolkit
```

## Releases

### Version 0.4.0 - 01 October 2026
- Added optional AI Gateway (API-only) ingress for LiteLLM (`litellm.aigatewayIngress`) exposing exact inference paths on a dedicated host
- Pinned MinIO image to `onyxdotapp/minio:RELEASE.2025-07-23T15-54-02Z-cpuv1` (digest `7330be2e`)

### Version 0.3.2 - 06 July 2026
- Upgraded appVersion to 3.205.1 and LiteLLM to v1.91.0; lowered default numWorkers to 4 [Silviu - [`bc391bf0`](https://github.com/eea/helm-charts/commit/bc391bf00c75ba09374a855364ec60fd118ea768)]

### Version 0.3.1 - 18 May 2026
- litellm: replace args with command to avoid security profile violations while keeping num_workers configurable [Silviu - [`b6f4f4b6`](https://github.com/eea/helm-charts/commit/b6f4f4b66937e7aadd9cc1192666c33ddc081d1a)]

### Version 0.3.0 - 05 March 2026
- Updated LiteLLM to v1.81.14-stable; made `--num_workers` configurable (default 6); added MinIO export ingress for `/langfuse/exports/` [Silviu - [`a3b7205f`](https://github.com/eea/helm-charts/commit/a3b7205f0af82ad5e744536c73a9f0a218259875)].

### Version 0.2.5 - 07 November 2025
- Updated appVersion to 3.127.0 and litellm to v1.79.0-stable [Olimpiu Rob - [`ba49371d`](https://github.com/eea/helm-charts/commit/ba49371d6456e07205a6381576da682d64a84a58)] 

### Version 0.2.4 - 28 October 2025
- Updated litellm to v1.78.5-stable [Olimpiu Rob - [`00822b19`](https://github.com/eea/helm-charts/commit/00822b1976b7182bb252163415aaed1f163eaef4)]

### Version 0.2.3 - 24 September 2025
- Added LANGFUSE_S3_BATCH_EXPORT_EXTERNAL_ENDPOINT environment variable [Olimpiu Rob - [`a050d35a`](https://github.com/eea/helm-charts/commit/a050d35a1d3951e2e317d1f621fa245e646613dc)]

### Version 0.2.2
- Added missing TZ to litellm.

### Version 0.2.1
- Updated livenessProbe for litellm.

### Version 0.2.0
- Switched to bitnamilegacy repository and added additional LiteLLM env variables as well as changed the arguments for litellm.

### Version 0.1.9
- Updated appVersion to v3.95.2 and liteLLM to v1.74.9-stable.

### Version 0.1.8
- Updated LiteLLM to v1.72.6-stable and increased it's memory limits.

### Version 0.1.7
- Updated appVersion to 3.72.1.

### Version 0.1.6
- Allow defining externalTrafficPolicy for litellm.

### Version 0.1.5
- Updated grouping in `questions.yaml`.

### Version 0.1.4
- Removed externalTrafficPolicy from default values.

### Version 0.1.3
- Updated `questions.yaml`.

### Version 0.1.2
- Ingress fixes in `questions.yaml`.

### Version 0.1.1
- Updated questions.yaml.

### Version 0.1.0
- Initial release.
