# EEA Website backend - Plone 6

This chart deployes the EEA Website Plone 6 backend app 

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| debug.enabled | bool | false | Activate the Plone debug instance |

## Releases

### Version 1.57.0 - 12 June 2026
- Automated release of [eeacms/eea-website-backend:6.1.4-8](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`532d6431`](https://github.com/eea/helm-charts/commit/532d643145de7ddcae0cb4c9015fa51624761623)]

### Version 1.56.0 - 04 June 2026
- Automated release of [eeacms/eea-website-backend:6.1.4-7](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`b6d1f4b7`](https://github.com/eea/helm-charts/commit/b6d1f4b77f3755208ef0f2d744c065c9051ec5d2)]

### Version 1.55.1 - 03 June 2026
- Update nginx to 1.31.1 - Refs [#304237](https://taskman.eionet.europa.eu/issues/304237) [valentinab25 - [`493d9f2f`](https://github.com/eea/helm-charts/commit/493d9f2f0b8ccbd46ed18513033de60327a2e1ce)]

### Version 1.55.0 - 27 May 2026
- Automated release of [eeacms/eea-website-backend:6.1.4-6](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`079bc7b1`](https://github.com/eea/helm-charts/commit/079bc7b19a1106c7c410c7604a5229c8d238236d)]

### Version 1.54.2 - 18 May 2026
- Automated release of [eeacms/eea-website-backend:6.1.4-5.beta-1](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`a76ae3d2`](https://github.com/eea/helm-charts/commit/a76ae3d258376c2e7e94643dfbbc6857baad1713)]

### Version 1.54.1 - 05 May 2026
- Automated release of [eeacms/eea-website-backend:6.1.4-4.beta-1](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`b9564228`](https://github.com/eea/helm-charts/commit/b95642281befc9884e35923af2c2927202859635)]

### Version 1.54.0 - 29 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.4-3](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`4214233c`](https://github.com/eea/helm-charts/commit/4214233c9170927226cf58b1205cfb87e0ec92f3)]

### Version 1.53.0 - 29 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.4-2](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`8e5996d1`](https://github.com/eea/helm-charts/commit/8e5996d1e6b440d5ec520734d23afbd319cfe5e9)]

### Version 1.52.0 - 29 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.4-1](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`490849ae`](https://github.com/eea/helm-charts/commit/490849aeaf8de420c52c873773a0d9c3137379ea)]

### Version 1.51.0 - 28 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-34](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`d4ab3bdc`](https://github.com/eea/helm-charts/commit/d4ab3bdc1a1c1cea3464fc18bffdf1b017e57127)]

### Version 1.50.0 - 24 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-33](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`5b812c39`](https://github.com/eea/helm-charts/commit/5b812c39d8197b5d059d7687e05cca3783a96c88)]

### Version 1.49.5 - 23 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-32.beta-2](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`056aca30`](https://github.com/eea/helm-charts/commit/056aca303d157e86b2436b2542d8adee5a6f8df3)]

### Version 1.49.4 - 23 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-32.beta-1](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`b4b98f80`](https://github.com/eea/helm-charts/commit/b4b98f80aa8c154c3507b4c43f93659fc5ea9af9)]

### Version 1.49.3 - 21 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-31.beta-5](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`e1632a38`](https://github.com/eea/helm-charts/commit/e1632a3888e1a7b898ecd7122229b95fd78bd099)]

### Version 1.49.2 - 20 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-31.beta-4](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`d45a5429`](https://github.com/eea/helm-charts/commit/d45a54290e35f2b637edb31152ee3e3bf1594d07)]

### Version 1.49.1 - 20 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-31.beta-3](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`da1bec1f`](https://github.com/eea/helm-charts/commit/da1bec1f0119aeee26c350c8283a79e2df7e7e7f)]

### Version 1.49.0 - 18 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-30](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`fce72b3c`](https://github.com/eea/helm-charts/commit/fce72b3cb4ba21cd9133af371107b92e7ef3c196)]

### Version 1.48.0 - 16 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-28](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`0ef95235`](https://github.com/eea/helm-charts/commit/0ef952352520e8950cfd1496fbd138df39d90720)]

### Version 1.47.0 - 15 April 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-27](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`ff37f2c5`](https://github.com/eea/helm-charts/commit/ff37f2c585dde0ef6a44f244151970011b7c82a6)]

### Version 1.46.2 - 19 March 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-26.beta-2](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`d262ce9c`](https://github.com/eea/helm-charts/commit/d262ce9c90d7da97accd68376af6c146701ea3a0)]

### Version 1.46.1 - 17 March 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-26.beta-1](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`786f443b`](https://github.com/eea/helm-charts/commit/786f443b7ec425899f6f1075b942ddcad470d9c2)]

### Version 1.46.0 - 07 March 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-25](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`ad5a8c24`](https://github.com/eea/helm-charts/commit/ad5a8c240cd5db54dc6df9e9977ceb840eda29a4)]

### Version 1.45.0 - 05 March 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-24](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`732f0b57`](https://github.com/eea/helm-charts/commit/732f0b5709bee72039ba2a1b928157370694aad5)]

### Version 1.44.0 - 25 February 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-23](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`8d2cadbe`](https://github.com/eea/helm-charts/commit/8d2cadbe7e80cee50902b61b835abcfbd59aaa8a)]

### Version 1.43.0 - 11 February 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-22](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`8750ee72`](https://github.com/eea/helm-charts/commit/8750ee72ba182f2683bfa45bff21e81954dbe8c5)]

### Version 1.41.0 - 06 February 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-21](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`b6e8c640`](https://github.com/eea/helm-charts/commit/b6e8c640df5b9ac188c7fafda73b77e1c07dafcd)]

### Version 1.40.0 - 28 January 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-20](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`75cac1c8`](https://github.com/eea/helm-charts/commit/75cac1c80349a74c7f6e34938ec3709f57f33bd3)]

### Version 1.39.0 - 28 January 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-19](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`d2b77151`](https://github.com/eea/helm-charts/commit/d2b7715127e63ce4c23d2cec87e2b7c5061a9944)]

### Version 1.38.0 - 21 January 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-18](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`2926013b`](https://github.com/eea/helm-charts/commit/2926013b608cfd0f2b93126a98c1ebcb6dd2dab6)]

### Version 1.37.0 - 20 January 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-17](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`1eb497fb`](https://github.com/eea/helm-charts/commit/1eb497fb8e006cbffffea01d96810b754e3c9661)]

### Version 1.36.0 - 20 January 2026
- Automated release of [eeacms/eea-website-backend:6.1.3-16](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`aa63fdac`](https://github.com/eea/helm-charts/commit/aa63fdac8dce1c565bcbe1d402bb2ce48897d898)]

### Version 1.35.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`35510151`](https://github.com/eea/helm-charts/commit/35510151e8e6f94134e3ed843ac06931e0aaceac)]

### Version 1.35.0 - 24 December 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-15](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`13735afc`](https://github.com/eea/helm-charts/commit/13735afc73986aa885cad3175375dc6b5b7933d4)]

### Version 1.34.0 - 23 December 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-14](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`72531b28`](https://github.com/eea/helm-charts/commit/72531b28a50c212632d36bd3c1d599ee34c4258e)]

### Version 1.33.0 - 22 December 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-13](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`8579e2dc`](https://github.com/eea/helm-charts/commit/8579e2dcb4418a9c936926d048c97138da70f5f7)]

### Version 1.32.0 - 20 December 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-12](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`3797c102`](https://github.com/eea/helm-charts/commit/3797c10239fa8ec72b360fc8fefa49600409d95a)]

### Version 1.31.1 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`6ee4effc`](https://github.com/eea/helm-charts/commit/6ee4effc747e03720b8dee12792364e07e6d1c65)]

### Version 1.31.0 - 13 December 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-11](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`15862f00`](https://github.com/eea/helm-charts/commit/15862f0053ded9665807a770ea2cc3310d4680e8)]

### Version 1.30.0 - 04 December 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-10](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`784c3d0f`](https://github.com/eea/helm-charts/commit/784c3d0f12738b94827960af4a1112b0c6b25b9d)]

### Version 1.29.0 - 29 November 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-8](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`d06bea8a`](https://github.com/eea/helm-charts/commit/d06bea8a8bfde40d189138f17b506fe3938e6b2f)]

### Version 1.28.0 - 19 November 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-6](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`a5b5d26d`](https://github.com/eea/helm-charts/commit/a5b5d26dee787324866e66b0407cac59f6db758e)]

### Version 1.27.0 - 18 November 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-5](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`a29435d4`](https://github.com/eea/helm-charts/commit/a29435d4aed282547e0114262a9fe3dcd403d47d)]

### Version 1.26.0 - 18 November 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-4](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`a7188542`](https://github.com/eea/helm-charts/commit/a7188542eb8611f2cb24b12c6ee9518c2fd2a3e6)]

### Version 1.25.0 - 17 November 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-3](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`4719ffd4`](https://github.com/eea/helm-charts/commit/4719ffd47c5e5adeb6031e5232f8d92f9b477df5)]

### Version 1.24.0 - 13 November 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-2](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`cc9eeb2e`](https://github.com/eea/helm-charts/commit/cc9eeb2e1fa416b1b1144d3f8a57ad2f82043df1)]

### Version 1.23.0 - 29 October 2025
- Automated release of [eeacms/eea-website-backend:6.1.3-1](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`d240880b`](https://github.com/eea/helm-charts/commit/d240880bec50c0d864e3b12377014929773609b6)]

### Version 1.22.0 - 24 October 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-47](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`2c395787`](https://github.com/eea/helm-charts/commit/2c3957875e35a7f3e540506d9bf6851dc44151ff)]

### Version 1.21.0 - 22 October 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-46](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`15549b7d`](https://github.com/eea/helm-charts/commit/15549b7d88c08035f8ca22743860995a5135982d)]

### Version 1.20.0 - 08 October 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-45](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`90d5696f`](https://github.com/eea/helm-charts/commit/90d5696f763fdd5a6141489107082f094763f263)]

### Version 1.19.2 - 26 September 2025
- Fix nginx conf when debug is disabled [Alin Voinea - [`6866a3eb`](https://github.com/eea/helm-charts/commit/6866a3eb5a2779e9eeaecd28446fb8f47a1f4707)]

### Version 1.19.1 - 23 September 2025
- Add possibility to deploy debug_backend [Alin Voinea - [`ecd63a0d`](https://github.com/eea/helm-charts/commit/ecd63a0d202a5487fb87031c7eec8bed5de988d6)]

### Version 1.19.0 - 23 September 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-44](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`9cd79028`](https://github.com/eea/helm-charts/commit/9cd79028ae1b41315d6916106580bde69621b579)]

### Version 1.18.1 - 10 September 2025
- fix: entrasync and zodbpack cronjobs - Refs [#291988](https://taskman.eionet.europa.eu/issues/291988) [Alin Voinea - [`19a3c028`](https://github.com/eea/helm-charts/commit/19a3c0284f34e1319915d8cfcce4df879cbcb076)]

### Version 1.18.0 - 28 August 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-43](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`468ca1d7`](https://github.com/eea/helm-charts/commit/468ca1d786c79c3dad201468e8de4584d08468b1)]

### Version 1.17.0 - 27 August 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-42](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`e1083e6f`](https://github.com/eea/helm-charts/commit/e1083e6fb876292f240a5f55d74eb07027d085fb)]

### Version 1.16.0 - 27 August 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-41](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`94908adb`](https://github.com/eea/helm-charts/commit/94908adb39c17c14388fe3bd775357c81fd6d920)]

### Version 1.15.2 - 27 August 2025
- Fix deployments/scale.apps plone not found [Alin Voinea - [`61e5fc40`](https://github.com/eea/helm-charts/commit/61e5fc4074f3729290260a7ac522d44946ee9b02)]

### Version 1.15.1 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`6b299527`](https://github.com/eea/helm-charts/commit/6b299527cae96cccfc8170c80a78b37f47854d92)]

### Version 1.15.0 - 20 August 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-40](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`e360f568`](https://github.com/eea/helm-charts/commit/e360f568926a896af88714cc2049107cca6f7de0)]

### Version 1.14.0 - 20 August 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-39](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`8f23ed88`](https://github.com/eea/helm-charts/commit/8f23ed8862bb45c9efe036006e937e5fc2149564)]

### Version 1.13.0 - 20 August 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-38](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`a3d08314`](https://github.com/eea/helm-charts/commit/a3d08314cade2d3b2a83e1b3874c13c4a34ee96b)]

### Version 1.12.6 - 14 August 2025
- Add ingress.enabled variable [valentinab25 - [`4121ae87`](https://github.com/eea/helm-charts/commit/4121ae8734e8c3aaa1c29b5ff2af17cb7f27313e)]

### Version 1.12.5 - 13 August 2025
- add log to stdout for nginx [Silviu - [`dd4f5421`](https://github.com/eea/helm-charts/commit/dd4f542153adb1265fcce49e0936e96e25214a91)]

### Version 1.12.4 - 13 August 2025
- Use ingress class name in configuration [valentinab25 - [`80728629`](https://github.com/eea/helm-charts/commit/807286291165f56ee9a87ca01e2cf07cb45bc937)]

### Version 1.12.3 - 13 August 2025
- Use selector labels [valentinab25 - [`b30ea52d`](https://github.com/eea/helm-charts/commit/b30ea52d07799ba75a97700fa682a2d67ee7700b)]

### Version 1.12.2 - 13 August 2025
- Fix postgres service if external [valentinab25 - [`06e1a86a`](https://github.com/eea/helm-charts/commit/06e1a86a3e418b268dbac27b83d2ea9a14ad4ee7)]

### Version 1.12.1 - 13 August 2025
- Add ingressClassName variable [valentinab25 - [`e9e1b6e6`](https://github.com/eea/helm-charts/commit/e9e1b6e6a47b4bd4c0a9591276ec492b7a40ef7f)]

### Version 1.12.0 - 11 August 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-37](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`2f999e42`](https://github.com/eea/helm-charts/commit/2f999e42a6f9ca9808265a30964834dbfe548fd4)]

### Version 1.11.1 - 07 August 2025
- Add db host as variable [Silviu - [`b4eef131`](https://github.com/eea/helm-charts/commit/b4eef131f7d0663a3c01ec44545000eb7b7dddf5)]

### Version 1.11.0 - 05 August 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-36](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`cda877e2`](https://github.com/eea/helm-charts/commit/cda877e2a32b149f0757b6f040b0e61c12c32cf2)]

### Version 1.10.0 - 05 August 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-35](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`3e62d172`](https://github.com/eea/helm-charts/commit/3e62d17259033e285ccb27d02ea7e5ddb5edcc61)]

### Version 1.9.0 - 02 August 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-34](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`952c2da1`](https://github.com/eea/helm-charts/commit/952c2da1ee2aec205757f96fa6764071ee53940e)]

### Version 1.8.1 - 01 August 2025
- Automated release of [eeacms/plone-varnish:7.7-1.1](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`a61144cc`](https://github.com/eea/helm-charts/commit/a61144ccc62d4c02bd4352957f63807a383b184a)]

### Version 1.8.0 - 01 August 2025
- Automated release of [eeacms/eea-website-backend:internal](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`faae0c88`](https://github.com/eea/helm-charts/commit/faae0c8820b3750fe433eda2be1a35183fd7f23a)]

### Version 1.7.0 - 28 July 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-32](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`205b509a`](https://github.com/eea/helm-charts/commit/205b509a0c6d3bf8be6c3f9c5d564bc2c05ab665)]

### Version 1.6.0 - 25 July 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-31](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`bb22277e`](https://github.com/eea/helm-charts/commit/bb22277e83438ccc73234464988ba3926749da97)]

### Version 1.5.0 - 23 July 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-30](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`196c8e04`](https://github.com/eea/helm-charts/commit/196c8e04a98fc143cdb2ffddf5a75d0bf6072af7)]

### Version 1.4.0 - 16 July 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-29](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`2cd405a4`](https://github.com/eea/helm-charts/commit/2cd405a44f15e396ef71d9d87f5bf20ed173a003)]

### Version 1.3.0 - 20 June 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-27](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`60f983e8`](https://github.com/eea/helm-charts/commit/60f983e8d4e1ebf10c5324a7165bc886211eee37)]

### Version 1.2.0 - 12 June 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-26](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`188019a`](https://github.com/eea/helm-charts/commit/188019a7fc47ff0820b57167461df246b41a6203)]

### Version 1.1.0 - 11 June 2025
- Automated release of [eeacms/eea-website-backend:6.0.15-25](https://github.com/eea/eea-website-backend/releases) [EEA Jenkins - [`c6142dd`](https://github.com/eea/helm-charts/commit/c6142ddd56ad4ad7f387b06c350bd2f1013266e8)]

### Version 1.0.6 - 11 June 2025
- update nginx defaults [Silviu - [`b629266`](https://github.com/eea/helm-charts/commit/b6292663d8d4ca59f0b13895478c68ce4c2691f9)]

### Version 1.0.5 - 11 June 2025
- update rewrite rules [Silviu - [`f848977`](https://github.com/eea/helm-charts/commit/f8489772ffbbe2db4d1ba20115f3604c346643da)]

### Version 1.0.4 - 11 June 2025
- ingress update [Silviu - [`17525fb`](https://github.com/eea/helm-charts/commit/17525fbd75a12abf92a3bc59efe8521d8551b738)]

### Version 1.0.4 - 11 June 2025
- ingress update [Silviu - [`5570716`](https://github.com/eea/helm-charts/commit/557071648484c9838ce34c5e64ae5769065f438f)]

### Version 1.0.4 - 11 June 2025
- ingress update [Silviu - [`5b15ba6`](https://github.com/eea/helm-charts/commit/5b15ba6f9e6bd46e415ec89f022020b55c1048a5)]

### Version 1.0.4 - 11 June 2025
- dasd [Silviu - [`26be0ec`](https://github.com/eea/helm-charts/commit/26be0ec8030eec943eb6cfd7a1182b455ea0fbda)]

### Version 1.0.4 - 11 June 2025
- update ingress [Silviu - [`d5b0d59`](https://github.com/eea/helm-charts/commit/d5b0d59e4108187b9dc68fcb8752d2e6dc611a2e)]
### Version 1.0.4 - 11 June 2025
- patch nginx deployment [Silviu - [`2b095e9`](https://github.com/eea/helm-charts/commit/2b095e9dead5eaa28b4b0807ab8993246cb65730)]

### Version 1.0.2 - 11 June 2025
- update nginx service name [Silviu - [`060146f`](https://github.com/eea/helm-charts/commit/060146fd845b701a5781acef1842bd94df58f59f)]

### Version 1.0.1 - 11 June 2025
- add nginx deployment [Silviu - [`65dd5e3`](https://github.com/eea/helm-charts/commit/65dd5e3bea73e4b993ce41979bcd0995efefbff6)]

### Version 1.0.0
- Initial release. Version matching Rancher 1 catalog version.
