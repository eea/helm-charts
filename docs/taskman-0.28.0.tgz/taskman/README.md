## EEA Taskman docker setup
Taskman is a web application based on [Redmine](http://www.redmine.org) that facilitates Agile project management for EEA and Eionet software projects. It comes with some plugins and specific Taskman Redmine theme.

### Horizontal scaling and performance tuning

Use the settings below together when scaling Redmine web pods.

1) Keep one stable session secret across all replicas

  - Set `redmine.environment.SECRET_KEY_BASE` to a fixed value (do not rotate on each pod restart).

2) Use shared persistent volumes when `redmine.replicas > 1`

  - Set these to shared RWX claims:
    - `storage.filesDir.existingClaim`
    - `storage.tmpDir.existingClaim`
    - `storage.github.existingClaim`
    - `storage.plugins.existingClaim`
  - For existing installations, reusing the existing `...-redmine-ss-0` claims is supported.

3) Tune Puma and DB pool together

  - `redmine.environment.WEB_CONCURRENCY`: number of Puma workers per pod.
  - `redmine.environment.RAILS_MAX_THREADS`: threads per worker.
  - `redmine.environment.REDMINE_DB_POOL`: should be at least `WEB_CONCURRENCY * RAILS_MAX_THREADS` for each web pod, plus headroom for jobs.
  - Practical start values per web pod: `WEB_CONCURRENCY=2`, `RAILS_MAX_THREADS=5`, `REDMINE_DB_POOL=20-30`.

4) Tune nginx fronting Redmine

  - `httpd.replicas`: number of nginx pods in front of Redmine.
  - Keep `proxy_next_upstream` enabled for transient upstream failures.
  - If nginx config changes, restart nginx deployment on older releases that mount config via `subPath`.

5) Validate after each change

  - Check external and internal status codes.
  - Check nginx logs for upstream reset errors.
  - Confirm Redmine endpoints are healthy.

### Taskman stack variables

1. RESTART_CRON - Crontab schedule (for example 0 2 * * *) to stop redmine container, will be started by Rancher ( not recreated), not mandatory
1. INCOMING_MAIL_API_KEY - Incoming mail API key: Administration -> Settings -> Incoming email - API key
1. REDMINE_SMTP_HOST - Default SMTP host for outgoing email ( default postfix )
1. REDMINE_SMTP_PORT - Default SMTP port for outgoing email ( default 25 )
1. REDMINE_SMTP_DOMAIN - Default SMTP domain for outgoing email ( default eionet.europa.eu )
1. REDMINE_SMTP_TLS - Default SMTP TLS enabled for outgoing email ( default true )
1. REDMINE_SMTP_STARTTLSAUTO - Default SMTP SSL enabled for outgoing email ( default true )
1. T_EMAIL_HOST - Taskman email configuration: hostname
1. T_EMAIL_PORT - Taskman email configuration: port
1. T_EMAIL_USER - Taskman email configuration: user
1. T_EMAIL_PASS - Taskman email configuration: user password
1. H_EMAIL_HOST - Helpdesk email configuration: hostname
1. H_EMAIL_PORT - Helpdesk email configuration: port
1. H_EMAIL_USER - Helpdesk email configuration: username
1. H_EMAIL_PASS - Helpdesk email configuration: user password
1. SYNC_API_KEY - GitHub synchronisation API KEY. Can be found under /settings?tab=repositories
1. PLUGINS_URL - Plugins location SVN URL. The SVN URL that point to the folder where the PRO plugins are located
1. PLUGINS_USER - Plugins SVN User. 
1. PLUGINS_PASSWORD - Plugins SVN User Password.
1. DB_NAME - Redmine Mysql database name. 
1. DB_USERNAME - Redmine database username. 
1. DB_PASSWORD - Redmine database user password. 
1. DB_ROOT_PASSWORD - Redmine database server root password.
1. DB_DUMP_TIME - Time to start database backup. UTC time, formatted as a 4 digit number
1. DB_DUMP_FREQ - Frequency of backup. Minutes between backups, set 1440 for daily
1. DB_DUMP_FILENAME - Database backup filename. The name of the database dump file
1. TZ - Time zone.
1. POSTFIX_RELAY - Postfix SMTP relay, not used in development mode
1. POSTFIX_PORT - Postfix SMTP relay port, not used in development mode
1. POSTFIX_USER - Postfix user used to send email, not used in development mode
1. POSTFIX_PASS - Postfix password used for MTP_USER, not used in development mode

### Setting up Taskman development replica

1) Copy the .zip archives containing the paid plugins into an SVN folder

3) Add Taskman stack, using the development variable values ( special care with email configuration options)

4) Start the stack

4) If a development stack already exists, backup the database table `settings`. This should be done using the first step from the [restore procedure](#by-script)

4) Stop Redmine & MySQL services

5) Sync data from production:

    - Redmine files [Import Taskman files](https://github.com/eea/eea.docker.taskman#import-taskman-files)
    - MySQL database [Import Taskman database](https://github.com/eea/eea.docker.taskman#import-taskman-database)
    - Set development settings after a production [database restore](#set-development-settings-after-a-production)
    
6) Start Mysql

7) Give user administrator rights, if necessary. Execute shell on taskman-mysql-1 container.

        $ mysql -u<MYSQL_ROOT_USER> -p<MYSQL_ROOT_PASSWORD> <MYSQL_DB_NAME>           
        $ update users set admin=1 where login=<USER_NAME>;
        $ exit

11) Setup network and firewall to allow access of the devel host on the EEA email accounts.

    - Get <H_EMAIL_HOST> and <H_EMAIL_PORT> values from .email.secret file
    - Check 
    ```
    $ telnet <H_EMAIL_HOST> <H_EMAIL_PORT>
    ```
    - If telnet command unsuccesfull, create issue in Infrastructure project to solve this
   
9) Start Redmine services

### Set development settings after a production

#### By script

This script is an alternative to the manual restore steps described lower. Works for redmine > 4.1

0) **Before** the database restore, save the settings in a file:

       mysqldump --skip-add-drop-table --skip-add-locks --no-create-info --replace --user=root --password="$MYSQL_ROOT_PASSWORD" redmine settings --where="name in ('mail_from', 'plugin_redmine_contacts', 'sys_api_key', 'plugin_redmine_contacts_helpdesk','host_name', 'plugin_redmine_drawio', 'plugin_redmine_banner', 'mail_handler_api_key')" > /var/lib/mysql/export_settings.sql
       
1) Database backup ( save in `/var/lib/mysql/backup_$(date '+%F').sql.tar.gz`) and restore ( `prodbackup.sql`) commands:

       mysqldump -u root -p$MYSQL_ROOT_PASSWORD --add-drop-table $MYSQL_DATABASE > /var/lib/mysql/backup_$(date '+%F').sql
       tar -czvf backup_$(date '+%F').sql.tar.gz backup_$(date '+%F').sql
       mysql -u root -p$MYSQL_ROOT_PASSWORD $MYSQL_DATABASE  < prodbackup.sql

2) **After** the database restore:

    - Create script to update ids in settings in case they were changed ( not likely, but it's important to keep them consistent) and run it 

          cd /var/lib/mysql/
          mysql -N --password="$MYSQL_ROOT_PASSWORD" redmine -e "select concat(\"sed -i \\\"s/([0-9]*,'\",name,\"'/(\",id,\",'\",name,\"'/g\\\" export_settings.sql\") from settings where name in ('mail_from', 'plugin_redmine_contacts', 'sys_api_key', 'plugin_redmine_contacts_helpdesk','host_name', 'plugin_redmine_drawio', 'plugin_redmine_banner', 'mail_handler_api_key');" > execute_id_replacement.sh
          chmod 755 execute_id_replacement.sh
          ./execute_id_replacement.sh

    - Run the update of the settings 

          mysql --password="$MYSQL_ROOT_PASSWORD" redmine < export_settings.sql

#### Manually from the taskman website

1) Disable helpdesk email accounts from the following Taskman projects ( needs to be done only if database was copied from production):

    - check via Redmine REST API where Helpdesk module is enabled
      - http://YOUR_TASKMAN_DEV_HOST/projects.xml?include=enabled_modules&limit=1000
        - <enabled_module id="111" name="contacts"/>
        - <enabled_module id="222" name="contacts_helpdesk"/>
      - currentlly the projects REST API is not showing all the projects. This are the known projects where the Helpdesk module is enabled:
        - zope (IDM2 A-Team)
        - it-helpdesk (IT Helpdesk)
        - ied (CWS support)
      - alternativelly you can connect to the MySQL server and do the following queries:
        - select * from enabled_modules where name='contacts_helpdesk';
        - select * from enabled_modules where name='contacts';
        - select identifier, name, id from projects where id in ( select project_id from enabled_modules where name='contacts_helpdesk' union all select project_id from enabled_modules where name='contacts');
        
    - delete *Incoming mail server* settings ( from *Mail server settings* )  from all projects excluding zope found in previous step using the following url: http://YOUR_TASKMAN_DEV_HOST:8080/projects/<PROJECT_IDENTIFIER>/settings/helpdesk 


9) If the database was copied from production, change the following settings to set-up the development mail account  :

    - http://YOUR_TASKMAN_DEV_HOST/projects/zope/settings/helpdesk :
        -  From address: support.taskmannt AT eea.europa.eu 
        -  User name: support.taskmannt AT eea.europa.eu
        -  Password  

    - http://YOUR_TASKMAN_DEV_HOST/settings/plugin/redmine_contacts_helpdesk?tab=general ( From address: support.taskmannt AT eea.europa.eu )
    - http://YOUR_TASKMAN_DEV_HOST/settings?tab=notifications ( Emission email address: taskmannt AT eionet.europa.eu )

10) If the database was copied from production, set the banner to  development message

    - http://YOUR_TASKMAN_DEV_HOST/settings/plugin/redmine_banner ( Banner message: This is a Taskman development replica, please do not use/login if you are not part of the development team.)
    
    
12) Change the following settings:

    - http://YOUR_TASKMAN_DEV_HOST/settings?tab=general ( Host name and path: YOUR_TASKMAN_DEV_HOST )
    

13) Update HELPDESK_EMAIL_KEY variable with API key:

    - add value from http://YOUR_TASKMAN_DEV_HOST/settings?tab=mail_handler, "API key" to HELPDESK_EMAIL_KEY
       

14) Test e-mails using mailtrap on the folowing address: http://YOUR_TASKMAN_DEV_HOST:EXPOSED_PORT


15) Configure drawio development url here: https:/YOUR_TASKMAN_DEV_HOST/settings/plugin/redmine_drawio ( needs to be done only if database was copied from production) 


### First time installation of the Taskman stack on Production

Add the certificate to rancher 

1) Copy the .zip archives containing the paid plugins into an SVN folder

3) Add Taskman stack, using the production variable values

4) Start the stack

5) Follow [import existing data](#import-existing-data) if you need to import existing data

6) Add a loadbalancer service to the taskman/apache service, using a certificate for https 

7) Configure drawio loadbalancer service to the taskman/drawio service, on port 8080, using a certificate for https

[Start updating Taskman](#upgrade-procedure) if you updated the Redmine version or if you updated the Redmine's plugins.

#### Import existing data

If you already have a Taskman installation then follow the steps below to import the files and mysql db into the data containers.

For rancher rsync instructions follow this [wiki](https://github.com/eea/eea.docker.rsync/blob/master/Readme.md#rsync-data-between-containers-in-rancher)

##### Import Taskman files

Copy Taskman files from one instance ( ex. production ) to another ( ex. replica) . For rancher, use the steps bellow and the  [wiki](https://github.com/eea/eea.docker.rsync/blob/master/Readme.md#rsync-data-between-containers-in-rancher)

1. Start **rsync client** on host from where do you want to migrate data (ex. production)

  ```
    $ docker run -it --rm --name=r-client \
                 --volumes-from=eeadockertaskman_redmine_1 \
             eeacms/rsync sh
  ```

2. Start **rsync server** on host from where do you want to migrate data (ex. devel)

  ```
    $ docker run -it --rm --name=r-server -p 2222:22 \
                 --volumes-from=eeadockertaskman_redmine_1 \
                 -e SSH_AUTH_KEY="<SSH-KEY-FROM-R-CLIENT-ABOVE>" \
             eeacms/rsync server
  ```

3. Within **rsync client** container from step 1 run:

  ```
    $ rsync -e 'ssh -p 2222' -avz /usr/src/redmine/files/ root@<TARGET_HOST_IP_ON_DEVEL>:/usr/src/redmine/files/
  ```

4. Close **rsync client**

  ```
    $ CTRL+d
  ```

5. Close **rsync server**

  ```
    $ docker kill r-server
  ```

##### Import Taskman database

Uses the  MYSQL_ROOT_PASSWORD and MYSQL_DATABASE from the docker container environment of the database.

1. Make a dump of the database from source server.

  ```
    $ docker exec -it eeadockertaskman_mysql_1 bash
      mysqldump -u root -p$MYSQL_ROOT_PASSWORD --add-drop-table $MYSQL_DATABASE > /var/lib/mysql/backup_$(date '+%F').sql
      cd /var/lib/mysql/
      tar -czvf backup_$(date '+%F').sql.tar.gz backup_$(date '+%F').sql
      $ exit
  ```

2. Start **rsync client** on source server

  ```
    $ docker run -it --rm --name=r-client \
                 --volumes-from=eeadockertaskman_mysql_1 \
             eeacms/rsync sh
  ```

3. Start **mysql** and the **rsync server** on destination server

> The eeadockertaskman_mysql_1 container must be started, check documentation for start command

> <SSH-KEY-FROM-R-CLIENT-ABOVE> must contain "ssh-rsa ..."

  ```
    $ docker run -it --rm --name=r-server -p 2222:22 \
                 --volumes-from=eeadockertaskman_mysql_1 \
                 -e SSH_AUTH_KEY="<SSH-KEY-FROM-R-CLIENT-ABOVE>" \
             eeacms/rsync server
  ```

4. Sync mysql dump. Within **rsync client** container from step 2 (source server) run:

  ```
    $ scp -P 2222 /var/lib/mysql/backup_$(date '+%F').sql root@<TARGET_HOST_IP_ON_DEVEL>:/var/local/backup/
    $ exit
  ```
  
5. Close **rsync client**

  ```
    $ CTRL+d
  ```
  
6. Import the dump file (on destination server)

  ```
    $ docker exec -it eeadockertaskman_mysql_1 bash
      mysql -u root -p$MYSQL_ROOT_PASSWORD $MYSQL_DATABASE  < backup_$(date '+%F').sql
      exit
  ```

7. Close **rsync server**

  ```
    $ docker kill r-server
  ```

#### Email settings - tested on Development/Testing installation

**IMPORTANT:** test first if the email notification are sent!
Use first time the email development accounts.

Features to be tested:

* create ticket via email
* create ticket for Helpdesk
* receive email notification on content update
* email issue reminder notification

Verify in mailtrap if the emails are sent correctly.

### Upgrade procedure

1) Create new release in Rancher Catalog Taskman.

1) Make a backup of database - Run on mysql container

       $ mysqldump -u<MYSQL_ROOT_USER> -p<MYSQL_ROOT_PASSWORD> --add-drop-table <MYSQL_DB_NAME> > /var/local/backup/taskman.sql
      
1) If possible, pull latest version of Redmine to minimize waiting time during the next step

       $ docker pull eeacms/redmine:<imagetag>

1) Backup existing plugins and remove them from SVN directory

1) Upgrade the Taskman stack to the new version, making sure the variables are correct.


#### Upgrade Redmine version

Start updating Taskman ( if necessary - by default, `gosu redmine rake db:migrate` is run on start )

    $ docker exec -it eeadockertaskman_redmine_1 bash
    $ bundle exec rake db:migrate RAILS_ENV=production

If required by the migrate, run 

    $ bundle install

Finish upgrade

    $ bundle exec rake tmp:cache:clear tmp:sessions:clear RAILS_ENV=production

Restart Redmine service

#### Upgrade plugins

1. For free plugins, you need to modify Dockerfile. For paid ones, you need to add them to the SVN folder, and modify plugins.cfg file in Redmine.

2. Create a new Redmine image

3. Add a new template in Taskman Rancher Catalog with the new image

4. Upgrade it on the development replica and test it

5. Upgrade on the production


#### Manual Upgrade Redmine's plugins (not recommended)
    
Copy the source code to the plugins directory in Redmine, then run:    

    $ bundle install --without development test
    $ bundle exec rake redmine:plugins:migrate RAILS_ENV=production

## How-tos
### How to add repository to Redmine

*Prerequisites*: You have "Manager"/"Product Owner"-role in your <Project>.

1) Within Redmine Web Interface of your project: Settings > Repositories > Add new repository

    - SCM: Git
    - Identifier: eea-mypackage
    - Path to repository: /var/local/redmine/github/eea.mypackage.git

<pre>
All local repositories within */var/local/redmine/github* folder are synced automatically
from https://github.com/eea every 5 minutes (see */etc/chaperone.d/chaperone.conf* and
*/var/local/redmine/crons/redmine_github_sync.sh*) so you don't have to add them manually on server side.
</pre>

2) Update users mapping for your new repository:

    - Within Redmine Web Interface > Projects > <Project> > Settings > Repositories click on *Users* link available for your new repository and Update missing users

If it still doesn't update automatically after a while:

* login to the docker host and become root
* enter the Redmine container (docker exec -it eeadockertaskman_redmine_1 bash)
* cd /var/local/redmine/github
* git clone --mirror https://github.com/eea/eea.mypackage.git
* cd eea.mypackage.git
* git fetch --all
* chown -R apache.apache .

You can "read more":http://www.redmine.org/projects/redmine/wiki/HowTo_keep_in_sync_your_git_repository_for_redmine

### How to add check Redmine's logs

Use [Graylog](https://logs.eea.europa.eu/)


### How to manually sync LDAP users/groups

If you want to manually sync LDAP users and/or groups you need to run the following rake command inside the Redmine container:

    $ bundle exec rake -T redmine:plugins:ldap_sync

For more info see the [LDAP sync documentation](https://github.com/eea/redmine_ldap_sync#rake-tasks)


### How to uninstall Redmine Premium plugins

On Redmine container:

    $ bundle exec rake redmine:plugins:migrate NAME=redmine_plugin-name VERSION=0 RAILS_ENV=production

Remove it from configuration file ( plugins.cfg ), follow the upgrade [steps])(#upgrade-plugins)

### How to uninstall Redmine plugins

1) Uninstall plugin 

       $ bundle exec rake redmine:plugins:migrate NAME=redmine_plugin-name VERSION=0 RAILS_ENV=production
     
2) Remove the plugin from docker image, follow the upgrade [steps])(#upgrade-plugins)

### How to make changes on Taskman theme

Under Redmine container follow the next steps:

1) Upgrade the current packages to the latest version.
```
apt update
apt-get install curl
```
2) Installing Node.js
```
apt-get install software-properties-common
curl -sL https://deb.nodesource.com/setup_8.x | bash -
apt-get install nodejs npm
```
3) Make sure you have successfully installed node.js and npm on your system
```
node --version
npm --version
```
4) Install Grunt
```
npm install -g grunt
```
5) This will install Grunt globally on your system. Run command to check the version installed on your system.
```
grunt --version
```

After you installed node, npm and grunt, under Redmine theme follow the next steps:
```
cd /usr/src/redmine/public/themes/taskman.redmine.theme
```
1) Install project dependencies
```
npm install
```
2) Run Grunt
```
grunt
```

### Specific plugins documentation

* [Agile plugin](http://www.redminecrm.com/projects/agile/pages/1).
* [Checklists plugin](https://www.redminecrm.com/projects/checklist/pages/1).
* [LDAP Sync plugin](https://github.com/eea/redmine_ldap_sync).


## Releases

### Version 0.28.0 - 26 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.50](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`83decedd`](https://github.com/eea/helm-charts/commit/83deceddf720360f337c7706d61c8e3d40457805)]

### Version 0.27.0 - 16 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.49](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`1d93e4b5`](https://github.com/eea/helm-charts/commit/1d93e4b5d0b22bea918c16a81b554339121b6dcf)]

### Version 0.26.0 - 15 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.48](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`77fb7d68`](https://github.com/eea/helm-charts/commit/77fb7d68fe1855540e846f5744de9a6936dc07e0)]

### Version 0.25.0 - 15 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.47](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`1d4c7012`](https://github.com/eea/helm-charts/commit/1d4c7012e99e996b6ff34d9ab0c61200e00aefdc)]

### Version 0.24.0 - 12 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.46](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`b99da24f`](https://github.com/eea/helm-charts/commit/b99da24f84561d13ea056fa40789d174dc9c9c7b)]

### Version 0.23.0 - 11 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.45](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`98886892`](https://github.com/eea/helm-charts/commit/9888689257190185991e9bf54ed86f27f3159d99)]

### Version 0.22.0 - 11 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.44](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`f5ec7164`](https://github.com/eea/helm-charts/commit/f5ec71647df81700448e191df12b28d178f1accd)]

### Version 0.21.0 - 11 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.43](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`674ca487`](https://github.com/eea/helm-charts/commit/674ca487c93716862e39a2284902f57df23d4350)]

### Version 0.20.0 - 10 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.42](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`205437ea`](https://github.com/eea/helm-charts/commit/205437ea29b29f22078b72828ff39dd0a5f75a14)]

### Version 0.19.0 - 03 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.41](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`4d923f2d`](https://github.com/eea/helm-charts/commit/4d923f2d9b658f1bc4a00deffec20dbd4a20c06d)]

### Version 0.18.0 - 03 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.40](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`f8a3be0e`](https://github.com/eea/helm-charts/commit/f8a3be0e1dbb86734c993505869df25ff0cfcb56)]

### Version 0.17.0 - 03 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.39](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`54840ba8`](https://github.com/eea/helm-charts/commit/54840ba85ce1176da9e5d029b8375fc16a50928f)]

### Version 0.16.1 - 03 June 2026
- Upgrade nginx to 1.31.1, fix netsecpol [valentinab25 - [`823d750a`](https://github.com/eea/helm-charts/commit/823d750a4082d64bc963f71c3e5f2d1a6184f83c)]

### Version 0.16.0 - 02 June 2026
- Automated release of [eeacms/redmine:6.1.2-1.38](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`e2be8a88`](https://github.com/eea/helm-charts/commit/e2be8a882d35fed30ad89ddeb4eabe3967cb2d4d)]

### Unreleased
- Runtime patch operations note: when `runtime-compat-config` ConfigMap is mounted to `/usr/src/redmine/config/initializers/runtime_compat.rb` using `subPath`, container image updates do not change effective runtime patch code.
  - To roll out runtime patch changes in this mode: update ConfigMap data first, then restart/rollout Redmine deployment.
- Added runtime toggle guidance for activity endpoint patch:
  - `TASKMAN_PATCH_ACTIVITY_AUTHOR_PRELOAD` (default enabled in `runtime_compat.rb`)
  - Intended to reduce author-related N+1 on `/projects/:identifier/activity`.

### Version 0.15.1 - 31 March 2026
- Add ratelimiting configuration [valentinab25 - [`2ea970bf`](https://github.com/eea/helm-charts/commit/2ea970bf17fb5fb6dd27c395cb524b3277b03542)]

### Version 0.14.0 - 12 February 2026
- Automated release of [eeacms/redmine:5.1-1.33](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`c8e1ca7d`](https://github.com/eea/helm-charts/commit/c8e1ca7d0a756fcb49062c4f820577c88848d477)]

### Version 0.13.0 - 11 February 2026
- Automated release of [eeacms/redmine:5.1-1.32](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`953ef63b`](https://github.com/eea/helm-charts/commit/953ef63be383349ccd362e039973437b5d6bb7c2)]

### Version 0.12.0 - 11 February 2026
- Automated release of [eeacms/redmine:5.1-1.31](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`06331973`](https://github.com/eea/helm-charts/commit/06331973051b99948e4b40f332b60c6172b23528)]

### Version 0.11.0 - 09 February 2026
- Automated release of [eeacms/redmine:5.1-1.30](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`d95dd908`](https://github.com/eea/helm-charts/commit/d95dd9085bad46146c0f51f2db06a9f42c8eeb99)]

### Version 0.10.0 - 27 January 2026
- Automated release of [eeacms/redmine:5.1-1.29](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`6639c5f3`](https://github.com/eea/helm-charts/commit/6639c5f344357fc83e029dc3e6d26523c650186e)]

### Version 0.9.0 - 26 January 2026
- Automated release of [eeacms/redmine:5.1-1.28](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`24aec4f8`](https://github.com/eea/helm-charts/commit/24aec4f887678fa540a5733cb409e4d5dd6d40bb)]

### Version 0.8.0 - 26 January 2026
- Automated release of [eeacms/redmine:5.1-1.27](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`8430aed1`](https://github.com/eea/helm-charts/commit/8430aed146b546374d105762c21d71d07ac20803)]

### Version 0.7.1 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`f97d4ded`](https://github.com/eea/helm-charts/commit/f97d4ded4c40904d43ee121906178714025899f7)]

### Version 0.7.0 - 18 December 2025
- Automated release of [eeacms/redmine:5.1-1.26](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`a7c0cb07`](https://github.com/eea/helm-charts/commit/a7c0cb074b1ecfcf7b0825e939c8fa99310fcefa)]

### Version 0.6.2 - 18 December 2025
- Remove % from nginx config map [EEA Jenkins - [`7824dda6`](https://github.com/eea/helm-charts/commit/7824dda6bf3bf85f74b142a3e60092848068e824)]

### Version 0.6.1 - 17 December 2025
- Fix webserver healthchecks [EEA Jenkins - [`a92c24a1`](https://github.com/eea/helm-charts/commit/a92c24a1c70d14801fd42dac5e4f2a0e37a77e81)]

### Version 0.6.0 - 16 December 2025
- Automated release of [eeacms/redmine:5.1-1.25](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`dae02d42`](https://github.com/eea/helm-charts/commit/dae02d42a839563c15a9ffff656da4958e971004)]

### Version 0.5.0 - 16 December 2025
- Automated release of [eeacms/redmine:5.1-1.24](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`ab7fae53`](https://github.com/eea/helm-charts/commit/ab7fae53002efaf857f75a10ee4df02ece505685)]

### Version 0.4.0 - 13 November 2025
- Automated release of [eeacms/redmine:5.1-1.23](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`cf16a29c`](https://github.com/eea/helm-charts/commit/cf16a29c972383b7e35d4e13363ebd4c46f1a3e5)]

### Version 0.3.11 - 13 October 2025
- add nginx static cache [Silviu - [`7ecc7ba3`](https://github.com/eea/helm-charts/commit/7ecc7ba31e812360c1beb47f8d9bbc18321f57d5)]

### Version 0.3.10 - 10 October 2025
- MySQL configuration update [Silviu - [`2f7f2ed5`](https://github.com/eea/helm-charts/commit/2f7f2ed5ebab4671f8ae88e39682af49100913c4)]

### Version 0.3.9 - 15 September 2025
- switch to nginx from apache [Silviu - [`27a7f8b9`](https://github.com/eea/helm-charts/commit/27a7f8b91db8b6baea29d937246b506056927173)]

### Version 0.3.8 - 26 August 2025
- Fix ingress path type [valentinab25 - [`f9061efb`](https://github.com/eea/helm-charts/commit/f9061efba86b964b67465bbc7a95c92b11cd59d1)]

### Version 0.3.7 - 26 August 2025
- Add widget ingress rate limiting [valentinab25 - [`f9739612`](https://github.com/eea/helm-charts/commit/f97396124e922ab6c841e4787eb31c1ed8426f4f)]

### Version 0.3.6 - 25 August 2025
- Upgrade postfix chart, allow custom vars on postfix [valentinab25 - [`f99625b5`](https://github.com/eea/helm-charts/commit/f99625b5e488cd742c1d7be09315f5121c035743)]

### Version 0.3.5 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`c160dd82`](https://github.com/eea/helm-charts/commit/c160dd822b0f3638f0e4e920fea09aedf0a9509e)]

### Version 0.3.4 - 25 August 2025
- Add colation variable [valentinab25 - [`b23f30f9`](https://github.com/eea/helm-charts/commit/b23f30f9a4d0a40c89cc6fcbde7e3d14cd00a31b)]

### Version 0.3.3 - 25 August 2025
- Set last version of postfix [valentinab25 - [`d3445e0a`](https://github.com/eea/helm-charts/commit/d3445e0a93e71c7b8e1616442d0837e3f4af7021)]

### Version 0.3.2 - 25 August 2025
- Fix default drawio port [valentinab25 - [`2f03c758`](https://github.com/eea/helm-charts/commit/2f03c7588df1a9146fb0294a953c792fb69d0ebc)]

### Version 0.3.1 - 25 August 2025
- small variable name fixes [valentinab25 - [`33bc0802`](https://github.com/eea/helm-charts/commit/33bc08023319fc1200dc23afefcf3e454128e28e)]

### Version 0.3.0 - 18 August 2025
- Automated release of [eeacms/redmine:5.1-1.22](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`c459a21d`](https://github.com/eea/helm-charts/commit/c459a21d40be5cab28c43c99e33effd5485f8b22)]

### Version 0.2.0 - 14 August 2025
- Automated release of [eeacms/redmine:5.1-1.21](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`fddebdd3`](https://github.com/eea/helm-charts/commit/fddebdd3319b1a075452227e56ae999f6a1ffb39)]

### Version 0.1.0 - 14 August 2025
- Automated release of [eeacms/redmine:5.1-1.20](https://github.com/eea/eea.docker.redmine/releases) [EEA Jenkins - [`fea97c79`](https://github.com/eea/helm-charts/commit/fea97c79b9784bd6402b976e30fd8a8de6d196b5)]

### Version 0.0.3 - 14 August 2025
- fix variables [valentinab25 - [`3461b079`](https://github.com/eea/helm-charts/commit/3461b079addf8f39b860509afae6f69434b68a26)]

### Version 0.0.2 - 13 August 2025
- Fix questions [valentinab25 - [`02160c2e`](https://github.com/eea/helm-charts/commit/02160c2e8fc00adcbb703197220d70e16e934162)]

### Version 0.0.1
- First draft
