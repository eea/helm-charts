# BISE frontend - Plone 6

This chart deployes the BISE frontend app

## Values

| Key           | Type   | Default        | Description                                                               |
| ------------- | ------ | -------------- | ------------------------------------------------------------------------- |
| links.backend | string | NAME.NAMESPACE | Service name for varnish for backend instance, followed by the namespace. |

## Releases

### Version 2.23.2 - 20 August 2026
- Automated release of [eeacms/bise-frontend:4.7.0-beta.02](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`c08d93b7`](https://github.com/eea/helm-charts/commit/c08d93b74e0de083ef79d3ab92dee784e90cacdb)]

### Version 2.23.1 - 19 August 2026
- Automated release of [eeacms/bise-frontend:4.7.0-beta.01](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`06423a5b`](https://github.com/eea/helm-charts/commit/06423a5babae92681797566227bde465313e7785)]

### Version 2.23.0 - 07 August 2026
- Automated release of [eeacms/bise-frontend:4.6.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`24be22be`](https://github.com/eea/helm-charts/commit/24be22bef47f068688de5f20a1e0ca5bfe951530)]

### Version 2.21.0 - 05 August 2026
- Automated release of [eeacms/bise-frontend:4.5.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`b5cc2e40`](https://github.com/eea/helm-charts/commit/b5cc2e40a324d4939cb3fe7d5d49b77e1a239489)]

### Version 2.20.1 - 10 July 2026
- Improve Content-Security-Policy headers Refs [#294574](https://taskman.eionet.europa.eu/issues/294574) [Teodor Voicu - [`33fcc319`](https://github.com/eea/helm-charts/commit/33fcc319ed2a6b1d7c726d66cb8c61dbea4c34bb)]

### Version 2.20.0 - 10 July 2026
- Automated release of [eeacms/bise-frontend:4.4.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`291305f3`](https://github.com/eea/helm-charts/commit/291305f3802d75b6557c22145529459a53c2cdbf)]

### Version 2.19.0 - 09 July 2026
- Automated release of [eeacms/bise-frontend:4.3.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`33c338e5`](https://github.com/eea/helm-charts/commit/33c338e581adf420b11eed1e01174f2211b61418)]

### Version 2.18.0 - 24 June 2026
- Automated release of [eeacms/bise-frontend:4.2.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`725b2983`](https://github.com/eea/helm-charts/commit/725b2983c1d483b250d25294902b99a57806a7f0)]

### Version 2.17.0 - 23 June 2026
- Automated release of [eeacms/bise-frontend:4.1.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`52ae7b2a`](https://github.com/eea/helm-charts/commit/52ae7b2a9349571bbd3bcf29da348accfbb50fe0)]

### Version 2.16.0 - 22 June 2026
- Automated release of [eeacms/bise-frontend:4.0.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`401796b5`](https://github.com/eea/helm-charts/commit/401796b597790862f802f7952f4f519749c7b341)]

### Version 2.15.2 - 18 June 2026
- Automated release of [eeacms/bise-frontend:3.44.0-beta.3](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`2b8526ef`](https://github.com/eea/helm-charts/commit/2b8526ef6f8eb6789bdfe37def93a0a66f580048)]

### Version 2.15.1 - 27 May 2026
- Automated release of [eeacms/bise-frontend:3.44.0-beta.1](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`3a51917c`](https://github.com/eea/helm-charts/commit/3a51917c4474288fcc2444e8dcc0293db7958dda)]

### Version 2.15.0 - 05 May 2026
- Automated release of [eeacms/bise-frontend:3.43.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`7adfe532`](https://github.com/eea/helm-charts/commit/7adfe532ad32402336a837254542f643fe32c1a6)]

### Version 2.14.0 - 04 May 2026
- Automated release of [eeacms/bise-frontend:3.42.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`338eae21`](https://github.com/eea/helm-charts/commit/338eae214c7cc4dfd2e60b2a8c25a0aa52b5b0c8)]

### Version 2.13.0 - 14 April 2026
- Automated release of [eeacms/bise-frontend:3.41.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`0914f215`](https://github.com/eea/helm-charts/commit/0914f2154b340a389ea11350103939bb943552df)]

### Version 2.12.0 - 13 April 2026
- Automated release of [eeacms/bise-frontend:3.40.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`509d93de`](https://github.com/eea/helm-charts/commit/509d93de96ce9bd853d295906411f036b1343949)]

### Version 2.11.0 - 13 April 2026
- Automated release of [eeacms/bise-frontend:3.39.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`67d3cf03`](https://github.com/eea/helm-charts/commit/67d3cf03862ce7e601a01a3b2781a9892884952f)]

### Version 2.10.0 - 09 April 2026
- Automated release of [eeacms/bise-frontend:3.38.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`832104f2`](https://github.com/eea/helm-charts/commit/832104f2ddd8e1ff3bc19a9fefef2dc49846f864)]

### Version 2.9.0 - 26 March 2026
- Automated release of [eeacms/bise-frontend:3.37.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`709e0dab`](https://github.com/eea/helm-charts/commit/709e0dab4ac54ee3ead0d34e38ba2cdf3bd793ff)]

### Version 2.8.0 - 26 March 2026
- Automated release of [eeacms/bise-frontend:3.36.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`507392a7`](https://github.com/eea/helm-charts/commit/507392a793a09660381d2d8b16681867b5cec1c4)]

### Version 2.7.0 - 13 March 2026
- Automated release of [eeacms/bise-frontend:3.35.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`c6d18b0b`](https://github.com/eea/helm-charts/commit/c6d18b0b082bd3b14ea2e599f396d885680168c9)]

### Version 2.6.0 - 27 February 2026
- Automated release of [eeacms/bise-frontend:3.34.1](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`e7338f97`](https://github.com/eea/helm-charts/commit/e7338f973bae26ec561b575abac81ebe676f077b)]

### Version 2.5.0 - 27 February 2026
- Automated release of [eeacms/bise-frontend:3.34.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`2cc96174`](https://github.com/eea/helm-charts/commit/2cc96174e0b2157fd17b510bbc0332f3bb448851)]

### Version 2.4.0 - 25 February 2026
- Automated release of [eeacms/bise-frontend:3.33.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`16ee80e2`](https://github.com/eea/helm-charts/commit/16ee80e2a48535b84c6d35de7e744a20d323ba1e)]

### Version 2.3.0 - 23 February 2026
- Automated release of [eeacms/bise-frontend:3.32.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`c80b5f36`](https://github.com/eea/helm-charts/commit/c80b5f36afbc19d0543b18f7044b2221dd2199f3)]

### Version 2.2.0 - 16 February 2026
- Automated release of [eeacms/bise-frontend:3.31.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`7b78195c`](https://github.com/eea/helm-charts/commit/7b78195cf20e9145e09fb45fcd85dce5cbd744ef)]

### Version 2.1.1 - 12 February 2026
- Automated release of [eeacms/bise-frontend:3.30.1-beta.1](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`f6b9bfe3`](https://github.com/eea/helm-charts/commit/f6b9bfe3b4d23cd5e5690b7e8023b155b33b30d4)]

### Version 2.1.0 - 11 February 2026
- Automated release of [eeacms/bise-frontend:3.30.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`dff8672d`](https://github.com/eea/helm-charts/commit/dff8672daf31c69d9a242fae3c1a223992eb4b2c)]

### Version 2.0.6 - 04 February 2026
- Automated release of [eeacms/bise-frontend:3.29.3-beta.4](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`eed703ab`](https://github.com/eea/helm-charts/commit/eed703abc47484ae2598a4069ecf7bca94c770a1)]

### Version 2.0.5 - 04 February 2026
- Automated release of [eeacms/bise-frontend:3.29.3-beta.3](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`43e84a77`](https://github.com/eea/helm-charts/commit/43e84a771d257e0c999f6b72038bf13200618e89)]

### Version 2.0.4 - 03 February 2026
- Automated release of [eeacms/bise-frontend:3.29.3-beta.2](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`1db1503a`](https://github.com/eea/helm-charts/commit/1db1503ab097b0413d222f9fc24f26b2acd4658b)]

### Version 2.0.3 - 03 February 2026
- fix tabluea [Dobricean Ioan Dorian - [`154d2816`](https://github.com/eea/helm-charts/commit/154d281643470c58be507a969642270d0b84afdf)]

### Version 2.0.2 - 03 February 2026
- Fix tableau csp [Dobricean Ioan Dorian - [`4be7d09a`](https://github.com/eea/helm-charts/commit/4be7d09ac5fc9196cb719350adbba138adf6c230)]

### Version 2.0.1 - 30 January 2026
- Automated release of [eeacms/bise-frontend:3.29.3-beta.1](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`cfdf613b`](https://github.com/eea/helm-charts/commit/cfdf613bfc85fb2de6085d8764a71d73a352f41d)]

### Version 2.0.0 - 29 January 2026
- Rewrite nginx to redirect anex habitats from lowercase to uppercase [Dobricean Ioan Dorian - [`62b3ab88`](https://github.com/eea/helm-charts/commit/62b3ab889fb314c2e2a10cec8a01824555cc11ec)]

### Version 1.20.0 - 29 January 2026
- Automated release of [eeacms/bise-frontend:3.29.2](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`e4f5c471`](https://github.com/eea/helm-charts/commit/e4f5c4710e6818280270fceb75ed16db3bec8096)]

### Version 1.19.0 - 27 January 2026
- Automated release of [eeacms/bise-frontend:3.29.1](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`680c7a1b`](https://github.com/eea/helm-charts/commit/680c7a1bcb95c6a4c25fac7c47d55d318eacdb34)]

### Version 1.18.0 - 26 January 2026
- Automated release of [eeacms/bise-frontend:3.29.0-demo.05](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`c6bb61d2`](https://github.com/eea/helm-charts/commit/c6bb61d2397b095a7de94a872a6c99d93c58ee4c)]

### Version 1.17.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`e3a1d49e`](https://github.com/eea/helm-charts/commit/e3a1d49e3c8e84a6050e362b70b95d67d1ae1018)]

### Version 1.17.0 - 19 January 2026
- Automated release of [eeacms/bise-frontend:3.29.0-demo.04](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`18997e76`](https://github.com/eea/helm-charts/commit/18997e7606b0a05013e3efaeeab4abc3bf8693b8)]

### Version 1.16.0 - 15 January 2026
- Automated release of [eeacms/bise-frontend:3.29.0-demo.03](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`696d4359`](https://github.com/eea/helm-charts/commit/696d4359c80a224d8f636e24e7b4762eef0ba900)]

### Version 1.15.0 - 13 January 2026
- Automated release of [eeacms/bise-frontend:3.29.0-demo.02](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`4fc6ff7f`](https://github.com/eea/helm-charts/commit/4fc6ff7ff1dc751edb47d4b4c1e33f4a47b6c02c)]

### Version 1.14.0 - 04 December 2025
- Automated release of [eeacms/bise-frontend:3.29.0-demo.01](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`4f8ce1fa`](https://github.com/eea/helm-charts/commit/4f8ce1fadb3e78fc796e9e93dcf84a5346d7ba30)]

### Version 1.13.0 - 28 November 2025
- Automated release of [eeacms/bise-frontend:3.27.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`543f67f3`](https://github.com/eea/helm-charts/commit/543f67f3d0a8d00670e9ffae77a2614644740369)]

### Version 1.12.0 - 28 November 2025
- Automated release of [eeacms/bise-frontend:3.27.0-demo.01](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`5ec715dd`](https://github.com/eea/helm-charts/commit/5ec715dd7f1430d89e601d4ac5ad282820933cf1)]

### Version 1.11.0 - 26 November 2025
- Automated release of [eeacms/bise-frontend:3.26.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`5bd6f01b`](https://github.com/eea/helm-charts/commit/5bd6f01be848ebc8dd7cb3b9e6ba5a2385df9042)]

### Version 1.10.0 - 19 November 2025
- Automated release of [eeacms/bise-frontend:3.25.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`00b31ebf`](https://github.com/eea/helm-charts/commit/00b31ebfce5a8abdb5d25980642602f3ddfa6d34)]

### Version 1.9.0 - 17 November 2025
- Automated release of [eeacms/bise-frontend:3.24.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`c258e12a`](https://github.com/eea/helm-charts/commit/c258e12abf8917fe184c8463d3e30ba17f2bd82b)]

### Version 1.8.0 - 07 November 2025
- Automated release of [eeacms/bise-frontend:3.22.0-demo.02](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`f60b6a53`](https://github.com/eea/helm-charts/commit/f60b6a538d50cdb5f7ba70c158d127220f0d5a4e)]

### Version 1.7.0 - 06 November 2025
- Automated release of [eeacms/bise-frontend:3.22.0-demo.01](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`de2e1d77`](https://github.com/eea/helm-charts/commit/de2e1d77a1ef69d022b483a9ee6cc8e921211c24)]

### Version 1.6.0 - 03 November 2025
- Automated release of [eeacms/bise-frontend:3.21.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`b94f3be1`](https://github.com/eea/helm-charts/commit/b94f3be184db96a298876b606e9bfce4d789baad)]

### Version 1.5.0 - 03 November 2025
- Automated release of [eeacms/bise-frontend:3.20.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`be44fb67`](https://github.com/eea/helm-charts/commit/be44fb67d4ce6246b591feeaadb2b2b9794cd9c2)]

### Version 1.4.0 - 31 October 2025
- Automated release of [eeacms/bise-frontend:3.20.0.demo.06](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`08e7f64d`](https://github.com/eea/helm-charts/commit/08e7f64d339c1fda3124402f5e582a7a01e5a4ab)]

### Version 1.3.0 - 30 October 2025
- Automated release of [eeacms/bise-frontend:3.20.0.demo.05](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`fc1ea006`](https://github.com/eea/helm-charts/commit/fc1ea0061afcf4eb25e9a66eb3790eb54d77fab7)]

### Version 1.2.0 - 28 October 2025
- Automated release of [eeacms/bise-frontend:3.20.0.demo.04](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`f126f8cb`](https://github.com/eea/helm-charts/commit/f126f8cbc1340128153c8f055ed36c7ca0242ea1)]

### Version 1.1.0 - 22 October 2025
- Automated release of [eeacms/bise-frontend:3.19.0](https://github.com/eea/bise-frontend/releases) [EEA Jenkins - [`164abe3f`](https://github.com/eea/helm-charts/commit/164abe3f5b7ee0c9a9f3d0dc7dfa436451d9ca6e)]

### Version 1.0.0 - 11 October 2025
- Initial release of BISE frontend based on IED frontend
