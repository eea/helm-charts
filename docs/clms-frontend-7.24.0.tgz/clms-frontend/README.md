# Copernicus Land Monitoring Service (CLMS) frontend - Plone 6

This chart deploys the Copernicus Land Monitoring Service (CLMS) frontend application using Volto.

## Architecture

The chart deploys a three-tier architecture:
- **Volto Frontend**: React-based frontend application
- **Varnish**: HTTP cache layer
- **Backend**: External Plone backend service

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| image.repository | string | eeacms/clms-frontend | Container image repository |
| image.tag | string | "" | Image tag (uses Chart.appVersion if empty) |
| links.backend | string | backend-varnish.clms | Service name for backend varnish instance |
| volto.hostname | string | dev-clms.copernicus.01dev.eea.europa.eu | Hostname for the application |
| volto.replicaCount | int | 1 | Number of frontend replicas |
| volto.environment.RAZZLE_BACKEND_NAME | string | eea.docker.plone.clms | Backend identifier |
| volto.environment.DANSWER_URL | string | "" | Danswer service URL |
| volto.environment.LLMGW_URL | string | "" | LLM Gateway URL |

## Releases

### Version 7.24.0 - 14 April 2026
- Automated release of [eeacms/clms-frontend:3.544.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`6c0e4993`](https://github.com/eea/helm-charts/commit/6c0e49937eccd9949a15d6227626d4fd071b7b5c)]

### Version 7.23.0 - 10 April 2026
- Automated release of [eeacms/clms-frontend:3.543.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`e7ad4ffc`](https://github.com/eea/helm-charts/commit/e7ad4ffc7c7fc3fab82a82ea1b68e86a4be68fa2)]

### Version 7.22.0 - 08 April 2026
- Automated release of [eeacms/clms-frontend:3.542.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`1d8a58c1`](https://github.com/eea/helm-charts/commit/1d8a58c134bbdf75711b1f8a95a45400be9de7ae)]

### Version 7.21.0 - 07 April 2026
- Automated release of [eeacms/clms-frontend:3.541.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`493a1472`](https://github.com/eea/helm-charts/commit/493a14729235eb59a36da8ae01fabb0c17cb1b6b)]

### Version 7.20.0 - 02 April 2026
- Automated release of [eeacms/clms-frontend:3.540.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`7649611a`](https://github.com/eea/helm-charts/commit/7649611ab682f977059dc3ff90d81a6e73b6546d)]

### Version 7.19.0 - 31 March 2026
- Automated release of [eeacms/clms-frontend:3.539.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`d0e3c9ee`](https://github.com/eea/helm-charts/commit/d0e3c9ee59d9f1fe6d433dd86bfe28c3c24aa063)]

### Version 7.18.0 - 26 March 2026
- Automated release of [eeacms/clms-frontend:3.538.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`085923a6`](https://github.com/eea/helm-charts/commit/085923a639d660ff517800c671b26252dced55f3)]

### Version 7.17.0 - 23 March 2026
- Automated release of [eeacms/clms-frontend:3.537.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`72e05ea3`](https://github.com/eea/helm-charts/commit/72e05ea3e11c843f714555d8a4d4f7ff293bb33e)]

### Version 7.16.0 - 20 March 2026
- Automated release of [eeacms/clms-frontend:3.536.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`fe7e494e`](https://github.com/eea/helm-charts/commit/fe7e494e8422a044c1bbcf21bbef054f05595d46)]

### Version 7.15.0 - 12 March 2026
- Automated release of [eeacms/clms-frontend:3.535.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`d8c42642`](https://github.com/eea/helm-charts/commit/d8c42642e2f08aef002ee5bdd1c2c477582a6dc5)]

### Version 7.14.0 - 12 March 2026
- Automated release of [eeacms/clms-frontend:3.534.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`2545a777`](https://github.com/eea/helm-charts/commit/2545a77759fc54b113a12eb43de19a871393b912)]

### Version 7.13.0 - 12 March 2026
- Automated release of [eeacms/clms-frontend:3.533.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`5293cedc`](https://github.com/eea/helm-charts/commit/5293cedcbbeed103caadcc1648fd1accd3aebc37)]

### Version 7.12.0 - 11 March 2026
- Automated release of [eeacms/clms-frontend:3.532.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`439c6062`](https://github.com/eea/helm-charts/commit/439c60625ddd8e8e037cb7f242869f1ae4b97584)]

### Version 7.11.0 - 10 March 2026
- Automated release of [eeacms/clms-frontend:3.531.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`eb77a6e2`](https://github.com/eea/helm-charts/commit/eb77a6e23b7dc0eb92113b8742aa0abbf9ef3c4e)]

### Version 7.10.0 - 10 March 2026
- Automated release of [eeacms/clms-frontend:3.530.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`a1b59f66`](https://github.com/eea/helm-charts/commit/a1b59f66b50618b4b5dab2f61cedcafa71f92645)]

### Version 7.9.0 - 09 March 2026
- Automated release of [eeacms/clms-frontend:3.529.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`79cf4f57`](https://github.com/eea/helm-charts/commit/79cf4f576179078ae131b2f284fb2c12683e47d4)]

### Version 7.8.0 - 04 March 2026
- Automated release of [eeacms/clms-frontend:3.528.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`0b8a2130`](https://github.com/eea/helm-charts/commit/0b8a213031670f82e577c4a3c7069ba8553190c7)]

### Version 7.7.0 - 03 March 2026
- Automated release of [eeacms/clms-frontend:3.527.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`dd0c8da9`](https://github.com/eea/helm-charts/commit/dd0c8da9e86136d29ad64b5aa4d9a18dc29f3805)]

### Version 7.6.0 - 02 March 2026
- Automated release of [eeacms/clms-frontend:3.526.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`1e203a13`](https://github.com/eea/helm-charts/commit/1e203a131e3b1e243ee9dd61ba4673811e5b78a4)]

### Version 7.5.0 - 26 February 2026
- Automated release of [eeacms/clms-frontend:3.525.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f7dc4c1c`](https://github.com/eea/helm-charts/commit/f7dc4c1c7802292c1251a3f21d6b5537b817e036)]

### Version 7.4.0 - 24 February 2026
- nginx [Dobricean Ioan Dorian - [`ec63785a`](https://github.com/eea/helm-charts/commit/ec63785acff9437a8351d3153b9f4bf0238db81c)]

### Version 7.3.0 - 23 February 2026
- Automated release of [eeacms/clms-frontend:3.524.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`95eec5d3`](https://github.com/eea/helm-charts/commit/95eec5d30dc6692172bcb37f09dc09e57b8ddaa8)]

### Version 7.2.1 - 21 February 2026
- fix ingress [Dobricean Ioan Dorian - [`12f5224b`](https://github.com/eea/helm-charts/commit/12f5224b4e61a7b013353cfcbb225342b95ad25a)]

### Version 7.2.0 - 19 February 2026
- Automated release of [eeacms/clms-frontend:3.523.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`a950ab56`](https://github.com/eea/helm-charts/commit/a950ab56c03fddfe12e2d18dd961c142e746d1b3)]

### Version 7.1.0 - 17 February 2026
- Automated release of [eeacms/clms-frontend:3.522.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`c1284a59`](https://github.com/eea/helm-charts/commit/c1284a5949fbe017caa21ed8b9efe9244ea134b0)]

### Version 7.0.0 - 16 February 2026
- add apache and static content [Dobricean Ioan Dorian - [`d4738ee5`](https://github.com/eea/helm-charts/commit/d4738ee51a7812490973c6fb09198466e698b0a0)]

### Version 6.0.0 - 15 February 2026
- fix ingresses and apache [Dobricean Ioan Dorian - [`fb31f9eb`](https://github.com/eea/helm-charts/commit/fb31f9eb2a26bbd3c5872eea1a80689711ef6757)]

### Version 5.0.0 - 15 February 2026
- apache [Dobricean Ioan Dorian - [`e9599a31`](https://github.com/eea/helm-charts/commit/e9599a31a93ddf0666616e4d989101b6a83a171d)]

### Version 4.0.0 - 15 February 2026
- apache [Dobricean Ioan Dorian - [`03e33fe9`](https://github.com/eea/helm-charts/commit/03e33fe985c70c05b4250d3f3a9c62e57e6df254)]

### Version 3.521.0 - 13 February 2026
- Automated release of [eeacms/clms-frontend:3.521.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`b4b9704b`](https://github.com/eea/helm-charts/commit/b4b9704bbb4475c8efb5475d5acfc9ad6c486df8)]

### Version 3.520.0 - 11 February 2026
- Automated release of [eeacms/clms-frontend:3.520.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`e662a2c6`](https://github.com/eea/helm-charts/commit/e662a2c68a17178f9577f8ddecf0241fd9a30796)]

### Version 3.519.0 - 10 February 2026
- Automated release of [eeacms/clms-frontend:3.519.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`b8794b0c`](https://github.com/eea/helm-charts/commit/b8794b0c2772c9b3bf58c77115d33b0e606fa39e)]

### Version 3.518.0 - 09 February 2026
- Automated release of [eeacms/clms-frontend:3.518.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`63cf3cef`](https://github.com/eea/helm-charts/commit/63cf3cefbc9637fed16dbb29a89a5c2411103a43)]

### Version 3.517.0 - 04 February 2026
- Automated release of [eeacms/clms-frontend:3.517.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`06a220e8`](https://github.com/eea/helm-charts/commit/06a220e8c8d4a01e6d9b8deacf33f01a8027ee45)]

### Version 3.516.0 - 02 February 2026
- Automated release of [eeacms/clms-frontend:3.516.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`43f4324f`](https://github.com/eea/helm-charts/commit/43f4324f250476e80ee03e000bb0c1f0541f842b)]

### Version 3.515.0 - 29 January 2026
- Automated release of [eeacms/clms-frontend:3.515.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`35c6ecc2`](https://github.com/eea/helm-charts/commit/35c6ecc28d8e4520bc0c906d8984867a6b96d0d0)]

### Version 3.514.0 - 29 January 2026
- Automated release of [eeacms/clms-frontend:3.514.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`976b4428`](https://github.com/eea/helm-charts/commit/976b4428330fc87b6ee0244f11e94c647e5d8cbf)]

### Version 3.513.0 - 28 January 2026
- Automated release of [eeacms/clms-frontend:3.513.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`789c6b9e`](https://github.com/eea/helm-charts/commit/789c6b9e43e345dc01480919abf70de7aec22bc6)]

### Version 3.512.0 - 27 January 2026
- Automated release of [eeacms/clms-frontend:3.512.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`d20c9293`](https://github.com/eea/helm-charts/commit/d20c9293ba6d2106523d42fd825a3d7d491c8fd8)]

### Version 3.511.0 - 27 January 2026
- Automated release of [eeacms/clms-frontend:3.511.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`1d66622d`](https://github.com/eea/helm-charts/commit/1d66622dae4ddabbfcf885594d78be812b4d173c)]

### Version 3.510.0 - 22 January 2026
- Automated release of [eeacms/clms-frontend:3.510.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`e28cb4a1`](https://github.com/eea/helm-charts/commit/e28cb4a1b3036994dd2e858aace76eba5ce26fc7)]

### Version 3.509.0 - 20 January 2026
- Automated release of [eeacms/clms-frontend:3.509.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`66726238`](https://github.com/eea/helm-charts/commit/66726238a696748961a65f8f82d856535c49fe05)]

### Version 3.508.1 - 19 January 2026
- Automated release of [eeacms/plone-varnish:7.7-1.2](https://github.com/eea/plone-varnish/releases) [EEA Jenkins - [`48a3d11e`](https://github.com/eea/helm-charts/commit/48a3d11e418c65c9742887c6d61af97186cfb917)]

### Version 3.508.0 - 19 January 2026
- Automated release of [eeacms/clms-frontend:3.508.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f41b6805`](https://github.com/eea/helm-charts/commit/f41b6805826f3b8473fb6e0d96220a8a04239eae)]

### Version 3.507.0 - 16 January 2026
- Automated release of [eeacms/clms-frontend:3.507.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`a74a00da`](https://github.com/eea/helm-charts/commit/a74a00da1426227189affa06c75e3379a7b9a99b)]

### Version 3.506.0 - 14 January 2026
- Automated release of [eeacms/clms-frontend:3.506.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f3aea727`](https://github.com/eea/helm-charts/commit/f3aea727bd646f70a43cdce8866c9ebb35cd6af9)]

### Version 3.505.1 - 16 December 2025
- Add missing variables [Dobricean Ioan Dorian - [`40b235c7`](https://github.com/eea/helm-charts/commit/40b235c7fb4f8e191c82f3140adc60c5c05d9da9)]

### Version 3.505.0 - 16 December 2025
- Automated release of [eeacms/clms-frontend:3.505.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`c578bbc5`](https://github.com/eea/helm-charts/commit/c578bbc5716ce58c6a4116217ebedefad96981c3)]

### Version 3.504.0 - 11 December 2025
- Automated release of [eeacms/clms-frontend:3.504.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`8b4322e1`](https://github.com/eea/helm-charts/commit/8b4322e1dccc980a0b262f12ecac98f876a6e634)]

### Version 3.503.0 - 11 December 2025
- Automated release of [eeacms/clms-frontend:3.503.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`94ce75d8`](https://github.com/eea/helm-charts/commit/94ce75d8e01d11668c478f61b1228064ce6bfcd4)]

### Version 3.502.0 - 11 December 2025
- Automated release of [eeacms/clms-frontend:3.502.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`b53cdcef`](https://github.com/eea/helm-charts/commit/b53cdcef2d0fb06c111ecb8370444f331d68d4d8)]

### Version 3.501.1 - 10 December 2025
- Add nginx proxys [Dobricean Ioan Dorian - [`89341f82`](https://github.com/eea/helm-charts/commit/89341f8292cf3124d11a206e2f96c3d45411840d)]

### Version 3.501.0 - 09 December 2025
- Automated release of [eeacms/clms-frontend:3.501.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`62553b46`](https://github.com/eea/helm-charts/commit/62553b46b7f3411fceebfd15a5f96ecaf682d35f)]

### Version 3.500.3 - 08 December 2025
- remove cdse ingress [Dobricean Ioan Dorian - [`04dceae8`](https://github.com/eea/helm-charts/commit/04dceae837ed7e3b9d40651d21b4845926e99aa0)]

### Version 3.500.2 - 08 December 2025
- Move appache to ingress [Dobricean Ioan Dorian - [`578e1570`](https://github.com/eea/helm-charts/commit/578e15704b4ab5364f80a3605400b95f5e34151e)]

### Version 3.500.1 - 08 December 2025
- Add razzle public url [Dobricean Ioan Dorian - [`6ad17978`](https://github.com/eea/helm-charts/commit/6ad1797897158e5143cd05dd4a5edd78b5c8769d)]

### Version 3.500.0 - 08 December 2025
- Automated release of [eeacms/clms-frontend:3.500.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`f0bec373`](https://github.com/eea/helm-charts/commit/f0bec373f8e2f116b0d6d948cf59005fe0382bb1)]

### Version 3.499.0 - 04 December 2025
- Automated release of [eeacms/clms-frontend:3.499.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`09642962`](https://github.com/eea/helm-charts/commit/09642962f459f28039542e82206acd894db55401)]

### Version 3.498.0 - 03 December 2025
- Automated release of [eeacms/clms-frontend:3.498.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`35e932b6`](https://github.com/eea/helm-charts/commit/35e932b62440cb592df6e4ff7991e8238735a2d6)]

### Version 3.497.0 - 02 December 2025
- Automated release of [eeacms/clms-frontend:3.497.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`cfc646ee`](https://github.com/eea/helm-charts/commit/cfc646ee031e5e32de982d91a883920ed12c59fa)]

### Version 3.496.0 - 27 November 2025
- Automated release of [eeacms/clms-frontend:3.496.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`fe93eefe`](https://github.com/eea/helm-charts/commit/fe93eefe953cccd8f123416f7f9f83538937a3b7)]

### Version 3.495.1 - 26 November 2025
- FIX redirect [Dobricean Ioan Dorian - [`b2242144`](https://github.com/eea/helm-charts/commit/b2242144d7ef866704305c834d5cfc9a5e8685a4)]

### Version 3.495.0 - 26 November 2025
- Automated release of [eeacms/clms-frontend:3.495.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`cce0bf42`](https://github.com/eea/helm-charts/commit/cce0bf4271a9438214277639c4b66e3c7dd0b270)]

### Version 3.494.1 - 26 November 2025
- Remove nginx [Dobricean Ioan Dorian - [`6c53dcc6`](https://github.com/eea/helm-charts/commit/6c53dcc6e944a1aa3fa465aaf7a8e3a727d73c1b)]

### Version 3.494.0 - 25 November 2025
- Automated release of [eeacms/clms-frontend:3.494.0](https://github.com/eea/clms-frontend/releases) [EEA Jenkins - [`61f0f799`](https://github.com/eea/helm-charts/commit/61f0f7999851dfd886e99c3f8cb05b409adcf8f2)]

### Version 3.493.1 - 24 November 2025
- Adding nginx configuration [Dobricean Ioan Dorian - [`dc8e63c1`](https://github.com/eea/helm-charts/commit/dc8e63c15d323b60c8bce1423f576348ce24b9cc)]

### Version 3.493.0
- Initial CLMS frontend Helm chart release based on insitu-frontend structure 
