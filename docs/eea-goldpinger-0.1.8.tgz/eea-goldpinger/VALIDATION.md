# Package validation

Prepared on 14 October 2026.

## Version 0.1.2 checks

- Strict Helm lint and both test-cluster renders passed.
- The default NavLink omits `spec.group`, retaining its previous resource name and service target. Named custom groups remain optional.
- Rendered Helm notes show Rancher sidebar access when enabled and port-forward instructions only when the sidebar link is disabled. The ServiceMonitor reminder is removed.
- Dashboard remains disabled in both examples; ServiceMonitor and PrometheusRule remain enabled.
- Live sidebar placement must be verified after upgrade.

## Version 0.1.1 checks

- Helm 3.19.0 strict lint passed.
- Both test-cluster examples rendered with a single cluster-scoped NavLink, ServiceMonitor and PrometheusRule; the Grafana dashboard ConfigMap is absent.
- NavLink targets the release's HTTP service and namespace on port 8080, with path `/`; Rancher's service model adds `/proxy/` itself. Fields checked against Rancher release/v2.14 API types and the Dashboard service/NavLink models.
- Standalone resources match 0.1.0 except chart-version labels and the dependent configuration checksum. The checksum change causes a normal DaemonSet rolling update.
- Missing NavLink API produces an actionable rendering error; optional Grafana provisioning still renders when enabled. Namespace-only list-pods RBAC remains unchanged.
- Rancher sidebar visibility and Grafana dashboard removal require verification after the user upgrades; no live cluster was accessed for this revision.

## Original 0.1.0 validation (unchanged workload and monitoring implementation)

- Helm 3.19.0 strict lint and rendering.
- Render matrix: standalone defaults; test monitoring examples; optional UDP; TLS ingress; externally managed service account/RBAC; second release in another namespace.
- Assertions: no ClusterRole/ClusterRoleBinding, exact namespace-only `list pods` permission, release-specific discovery selector, namespace from the Downward API, host networking disabled, no host ports, stable release-specific dashboard UID, matching Service/DaemonSet/ServiceMonitor selectors and source-node relabeling.
- Expected rejection: missing monitoring CRDs, missing existing service-account name, missing ingress hostname/TLS secret, non-positive refresh interval, unsupported cluster-wide RBAC option, and alert rules enabled without scraping.
- Kubernetes 1.33 schema validation: all 43 built-in resources in the seven successful render scenarios passed. The six monitoring custom resources were initially excluded from built-in validation; the complete 02test render subsequently passed all nine resources using upstream Prometheus Operator ServiceMonitor and PrometheusRule schemas, with no skips.
- Prometheus 3.15.0 promtool: all three alert rules and all ten dashboard PromQL expressions parsed successfully after expanding Grafana variables.
- Alert evaluation tests: all three alerts fire for persistent faults; healthy data produces no alerts; faults from a different release do not trigger this release's rules.
- Public image `docker.io/bloomberg/goldpinger:3.11.5` exists for Linux amd64. Its selected platform manifest digest at preparation was `sha256:4b89d4b8c6b016bbb8643f4ff170b0556cac015b0c190e1be71cefdfc550dab9`.
- The actual binary from that image started locally with the chart environment and chart logging configuration against a mocked Kubernetes API. `/`, `/metrics` and `/check_all` returned HTTP 200. Captured discovery requests used only the installation namespace and exact release labels.

## Limits

No EEA cluster was accessed and no release was installed during preparation. The local binary smoke test ran under the execution environment's current UID; UID 1000 execution was not available there. The manifest configures non-root UID/GID 1000, consistent with upstream's non-root deployment. Real pod admission, CNI connectivity, taint coverage, resource usage, Grafana rendering/sidecar pickup, Prometheus selectors and Alertmanager delivery need to be checked on the chosen test cluster. Optional UDP was validated in the manifests, not through a live cluster network.

## Version 0.1.4 checks

- Helm strict lint and render checks passed with graph-only mode enabled and disabled, including Rancher global values and NavLink enabled.
- Graph-only mode renders the page ConfigMap, read-only single-file mount and page checksum. Disabling the mode removes all three. The default service account and namespace-only discovery RBAC remain unchanged.
- The page removes the navigation links while preserving Reload, graph code and relative API/static asset paths. Inline JavaScript passed syntax validation.
- Browser rendering and the ConfigMap mount require verification after installation in the target cluster; no live cluster was accessed for this change.

## Version 0.1.7 checks

- Prepared from EEA chart commit `ae5451bc64d4c482af3aa73a43259bac5b015c16` (chart 0.1.6).
- Strict Helm lint passed; rendered both graph-only and full interfaces with target aliases, Rancher global values and NavLink enabled. Probe target environment values remain unchanged.
- Confirmed that changing aliases updates the UI checksum; full mode without aliases uses the image's original page. Invalid maps, non-string labels and empty/whitespace-only labels are rejected.
- Inline JavaScript passed syntax checks. Executed both rendered page scripts with mocked API, DOM and graph-renderer dependencies: labels, unmatched-target fallback, duplicate aliases, special characters, graph IDs/edges/status, target diagnostic clicks and Reload passed. These tests do not replace live browser verification.
- No live cluster was accessed. Verify appearance and browser refresh behavior after upgrading.
