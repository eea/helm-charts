# Cm-share Chart

A Nextcloud instance for sharing files.

## Releases

### Version 0.6.1 - 26 October 2026
- Add php configuration file from values, disable upload status [valentinab25 - [`cdc2ce340`](https://github.com/eea/helm-charts/commit/cdc2ce340e8fc5245d67feffde7cb7408b45ff8f)]

### Version 0.6.0 - 22 October 2026
- Upgrade to 35.0.2 [valentinab25 - [`06d4f1cbb`](https://github.com/eea/helm-charts/commit/06d4f1cbb0ec871588ac8ef2de6a4c947d841b86)]

### Version 0.5.1 - 22 October 2026
- Upgrade mariadb to 10.11 [valentinab25 - [`1b792f890`](https://github.com/eea/helm-charts/commit/1b792f890f6fc1695d2f2de6ea5f125ea4d7263c)]

### Version 0.5.0 - 22 October 2026
- Upgrade to 34 [valentinab25 - [`c753c93ae`](https://github.com/eea/helm-charts/commit/c753c93ae113f35d8903cbf7dc8a5db86f3c2993)]

### Version 0.4.1 - 23 July 2026
- Upgrade mariadb, nginx to latest patch [valentinab25 - [`cfdd5f90`](https://github.com/eea/helm-charts/commit/cfdd5f90fe0c86682521ef83972c43179bb5dccd)]

### Version 0.4.0 - 23 July 2026
- Nextcloud 33.0.6 [valentinab25 - [`cdd0985d`](https://github.com/eea/helm-charts/commit/cdd0985d059403f95743b903937a1852bf0bb441)]

### Version 0.3.0 - 23 July 2026
- Upgrade to 32.0.12-fpm [valentinab25 - [`e517b457`](https://github.com/eea/helm-charts/commit/e517b4571e4fb03c6576ce4f33253d8bbd052506)]

### Version 0.2.1 - 23 July 2026
- Add healthchecks [valentinab25 - [`cecf6fb8`](https://github.com/eea/helm-charts/commit/cecf6fb8edc7ecba8db449196a575f406e005100)]

### Version 0.2.0 - 05 June 2026
- Upgrade to 31.0.14 [valentinab25 - [`8753f4d0`](https://github.com/eea/helm-charts/commit/8753f4d0142696afbd6bea86e5ae9f2d409f9f8c)]

### Version 0.1.9 - 03 June 2026
- Update nginx to 1.31.1 - Refs [#304237](https://taskman.eionet.europa.eu/issues/304237) [valentinab25 - [`145a1102`](https://github.com/eea/helm-charts/commit/145a11020040a92549b55a82c383b24dee26d907)]

### Version 0.1.8 - 18 December 2025
- Release of dependent chart postfix:3.2.0 [EEA Jenkins - [`503f99c6`](https://github.com/eea/helm-charts/commit/503f99c640ea017ddf693abd257563e6271c6aae)]

### Version 0.1.7 - 25 November 2025
- Release of dependent chart postfix:3.1.2 [valentinab25 - [`56731dff`](https://github.com/eea/helm-charts/commit/56731dff9ae4718ebfc1648cbbac256954ef8321)]

### Version 0.1.6 - 03 October 2025
- 31.0.9-fpm-alpine update [Silviu - [`deec3808`](https://github.com/eea/helm-charts/commit/deec38085ee116477cccc524bceb5f4742bb0230)]

### Version 0.1.5 - 25 August 2025
- Release of dependent chart postfix:3.1.0 [EEA Jenkins - [`fc63311c`](https://github.com/eea/helm-charts/commit/fc63311ca08a41abfea27fa1dcde3a48279e99e7)]


### Version 0.1.0
- Initial version.



